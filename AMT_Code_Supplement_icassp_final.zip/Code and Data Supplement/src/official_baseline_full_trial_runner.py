"""
文件功能:
1. 运行官方 baseline 的 full-scale quantitative trial，并输出与主实验一致的预测文件、净值曲线和摘要指标。
2. 严格遵守“仅外层最小适配，不改官方模型核心逻辑”的原则，重点补齐 `QuantNet`、`TRA`、`DoubleAdapt` 三类论文主对比方法。
3. 为分层比较框架生成统一结果：同类迁移基线、相邻强基线和后续论文自动出表所需的结构化汇总。

代码逻辑:
1. 复用统一数据底座与 official artifact builder，确保 full 口径下的数据划分、标签和结果导出协议一致。
2. `TRA` 使用官方路由组件和官方骨干模块，在本项目统一样本上训练与预测。
3. `DoubleAdapt` 使用官方增量学习 manager，在统一序列样本上输出可量化的测试预测。
4. `QuantNet` 使用官方 transfer 变体 `GlobalLstmLstm`，在官方收益矩阵任务文件上训练，并回写为项目统一的逐日逐标的分数文件。
5. 所有结果统一写入 `对比实验/baseline_full_trial`，同时输出总表供论文主表与附录表自动生成。

代码结构:
1. baseline 注册表、方向解析和官方模块隔离加载工具。
2. `TRA / DoubleAdapt / QuantNet` 三类 quantitative runner。
3. 统一结果导出、汇总表生成和 CLI 入口。
"""

from __future__ import annotations

import argparse
import copy
import gzip
import importlib.util
import json
import pickle
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parent))

from data_pipeline import SplitConfig
from experiment_profiles import get_profile, resolve_max_symbols
from experiment_runner import (
    DIRECTION_SPECS,
    align_transfer_concept_arrays,
    build_split_arrays,
    evaluate_and_save,
    format_seconds,
)
from experiment_workspace import get_categorized_result_path, write_dataframe, write_json
from official_baseline_artifact_builder import apply_profile_view, apply_unified_split, build_artifacts, load_market_bundle


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULT_DIR = get_categorized_result_path("baseline", "baseline_full_trial")
OFFICIAL_DIR = ROOT_DIR / "third_party" / "official_baselines"
TRIAL_PREFIX = "[EXP-LOG][BASELINE-FULL]"
DEFAULT_BASELINES = ("QuantNet", "TRA", "DoubleAdapt")


@dataclass(frozen=True)
class BaselineRegistryItem:
    name: str
    comparison_layer: str
    paper_role: str
    repo_dir: str


BASELINE_REGISTRY: dict[str, BaselineRegistryItem] = {
    "QuantNet": BaselineRegistryItem(
        name="QuantNet",
        comparison_layer="direct_transfer",
        paper_role="主表",
        repo_dir="quantnet-main/quantnet-main",
    ),
    "TRA": BaselineRegistryItem(
        name="TRA",
        comparison_layer="adjacent_strong",
        paper_role="扩展对比",
        repo_dir="qlib-main  TRA/qlib-main",
    ),
    "DoubleAdapt": BaselineRegistryItem(
        name="DoubleAdapt",
        comparison_layer="adjacent_strong",
        paper_role="扩展对比",
        repo_dir="DoubleAdapt-main/DoubleAdapt-main",
    ),
}


def log(message: str) -> None:
    print(f"{TRIAL_PREFIX} {message}", flush=True)


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    display_df = df.copy()
    for column in display_df.columns:
        if pd.api.types.is_float_dtype(display_df[column]):
            display_df[column] = display_df[column].map(lambda value: f"{value:.6f}")
    headers = [str(column) for column in display_df.columns.tolist()]
    rows = [[str(value) for value in row] for row in display_df.astype(object).values.tolist()]
    separator = ["---"] * len(headers)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(separator) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def parse_optional_csv(raw_value: str | None) -> list[str]:
    if raw_value is None:
        return []
    return [token.strip() for token in str(raw_value).split(",") if token.strip()]


def normalize_direction(direction: str) -> str:
    normalized = str(direction).strip().upper()
    if normalized in DIRECTION_SPECS:
        return normalized
    normalized = normalized.replace("-", "_").replace("->", "_TO_").replace(" ", "")
    if normalized not in {"CN_TO_US", "US_TO_CN"}:
        raise ValueError(f"baseline_full_trial 当前仅支持股票跨市场方向，收到 {direction}")
    return normalized


def load_repo_module(repo_dir: Path, module_file: str, module_alias: str) -> Any:
    module_path = repo_dir / module_file
    before_modules = set(sys.modules)
    sys.path.insert(0, str(repo_dir))
    try:
        spec = importlib.util.spec_from_file_location(module_alias, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"无法构造模块 spec: {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_alias] = module
        spec.loader.exec_module(module)
        return module
    finally:
        sys.path.pop(0)
        created_modules = set(sys.modules) - before_modules
        created_modules.add(module_alias)
        for module_name in created_modules:
            module_obj = sys.modules.get(module_name)
            module_origin = getattr(module_obj, "__file__", None)
            try:
                if module_name == module_alias or (module_origin and Path(module_origin).resolve().is_relative_to(repo_dir.resolve())):
                    sys.modules.pop(module_name, None)
            except Exception:
                if module_name == module_alias:
                    sys.modules.pop(module_name, None)


def build_target_arrays(
    direction: str,
    mode: str,
    lookback: int,
    max_symbols: int,
    force_rebuild: bool,
) -> tuple[dict[str, dict[str, np.ndarray]], dict[str, pd.DataFrame], str, str]:
    del force_rebuild
    direction_key = direction.lower()
    source_market, target_market = DIRECTION_SPECS[direction_key]
    profile = get_profile(mode)
    source_limit = resolve_max_symbols(profile, source_market, max_symbols)
    target_limit = resolve_max_symbols(profile, target_market, max_symbols)
    effective_max_symbols = min(source_limit, target_limit)
    source_panel_df, source_incidence_df = load_market_bundle(source_market)
    target_panel_df, target_incidence_df = load_market_bundle(target_market)
    source_panel_df = apply_unified_split(source_panel_df)
    target_panel_df = apply_unified_split(target_panel_df)
    source_panel_df, source_incidence_df = apply_profile_view(source_panel_df, source_incidence_df, source_market, mode)
    target_panel_df, target_incidence_df = apply_profile_view(target_panel_df, target_incidence_df, target_market, mode)
    if effective_max_symbols > 0:
        source_symbols = source_panel_df["symbol"].astype(str).unique().tolist()[:effective_max_symbols]
        target_symbols = target_panel_df["symbol"].astype(str).unique().tolist()[:effective_max_symbols]
        source_panel_df = source_panel_df[source_panel_df["symbol"].astype(str).isin(source_symbols)].copy()
        target_panel_df = target_panel_df[target_panel_df["symbol"].astype(str).isin(target_symbols)].copy()
        source_incidence_df = source_incidence_df.reindex(source_symbols).fillna(0.0)
        target_incidence_df = target_incidence_df.reindex(target_symbols).fillna(0.0)
    split = SplitConfig()
    source_arrays, _ = build_split_arrays(source_panel_df, source_incidence_df, split=split, lookback=lookback)
    target_arrays, target_meta = build_split_arrays(target_panel_df, target_incidence_df, split=split, lookback=lookback)
    _, target_arrays, _ = align_transfer_concept_arrays(source_arrays, target_arrays)
    return target_arrays, target_meta, source_market, target_market


def build_test_index(meta_df: pd.DataFrame) -> pd.MultiIndex:
    return pd.MultiIndex.from_frame(
        meta_df[["date", "symbol"]].rename(columns={"date": "datetime", "symbol": "instrument"})
    )


def run_tra_full_trial(
    direction: str,
    mode: str,
    lookback: int,
    top_k: int,
    max_symbols: int,
    force_rebuild: bool,
    device: str,
    result_dir: Path,
) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / BASELINE_REGISTRY["TRA"].repo_dir / "examples" / "benchmarks" / "TRA" / "src"
    tra_module = load_repo_module(repo_dir, "model.py", "amt_official_tra_components")
    OfficialLSTM = tra_module.LSTM
    OfficialTRA = tra_module.TRA

    target_arrays, target_meta, _, _ = build_target_arrays(direction, mode, lookback, max_symbols, force_rebuild)
    train_x = torch.tensor(target_arrays["train"]["sequence_x"], dtype=torch.float32)
    valid_x = torch.tensor(target_arrays["valid"]["sequence_x"], dtype=torch.float32)
    test_x = torch.tensor(target_arrays["test"]["sequence_x"], dtype=torch.float32)
    train_y = torch.tensor(target_arrays["train"]["y"], dtype=torch.float32)
    valid_y = torch.tensor(target_arrays["valid"]["y"], dtype=torch.float32)

    run_device = torch.device(device if device.startswith("cuda") and torch.cuda.is_available() else "cpu")
    backbone = OfficialLSTM(
        input_size=train_x.shape[-1],
        hidden_size=32,
        num_layers=1,
        use_attn=True,
        dropout=0.0,
    ).to(run_device)
    router = OfficialTRA(backbone.output_size, num_states=3, hidden_size=16, tau=1.0).to(run_device)
    optimizer = torch.optim.Adam(list(backbone.parameters()) + list(router.parameters()), lr=1e-3)
    criterion = nn.MSELoss()
    train_loader = DataLoader(TensorDataset(train_x, train_y), batch_size=512, shuffle=True, drop_last=False)
    valid_hist = torch.zeros((len(valid_x), valid_x.shape[1] - 1, 3), dtype=torch.float32, device=run_device)

    best_state: dict[str, Any] | None = None
    best_valid_loss = float("inf")
    epoch_count = 8 if mode == "full" else 4
    for _ in range(epoch_count):
        backbone.train()
        router.train()
        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(run_device)
            batch_y = batch_y.to(run_device)
            hist_loss = torch.zeros((len(batch_x), batch_x.shape[1] - 1, 3), dtype=torch.float32, device=run_device)
            hidden = backbone(batch_x)
            pred, _, _ = router(hidden, hist_loss)
            loss = criterion(pred, batch_y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        backbone.eval()
        router.eval()
        with torch.no_grad():
            valid_hidden = backbone(valid_x.to(run_device))
            valid_pred, _, _ = router(valid_hidden, valid_hist)
            valid_loss = float(criterion(valid_pred, valid_y.to(run_device)).item())
        if valid_loss < best_valid_loss:
            best_valid_loss = valid_loss
            best_state = {
                "backbone": copy.deepcopy(backbone.state_dict()),
                "router": copy.deepcopy(router.state_dict()),
            }
    if best_state is not None:
        backbone.load_state_dict(best_state["backbone"])
        router.load_state_dict(best_state["router"])

    backbone.eval()
    router.eval()
    with torch.no_grad():
        test_hidden = backbone(test_x.to(run_device))
        test_hist = torch.zeros((len(test_x), test_x.shape[1] - 1, 3), dtype=torch.float32, device=run_device)
        prediction, _, _ = router(test_hidden, test_hist)
    summary = evaluate_and_save("TRA", result_dir, target_meta["test"], prediction.detach().cpu().numpy(), top_k=top_k)
    summary["valid_loss"] = best_valid_loss
    summary["device"] = str(run_device)
    return summary


def run_doubleadapt_full_trial(
    direction: str,
    mode: str,
    lookback: int,
    top_k: int,
    max_symbols: int,
    force_rebuild: bool,
    device: str,
    result_dir: Path,
) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / BASELINE_REGISTRY["DoubleAdapt"].repo_dir / "src"
    model_module = load_repo_module(repo_dir, "model.py", "amt_official_doubleadapt_model")
    DoubleAdaptManager = model_module.DoubleAdaptManager

    target_arrays, target_meta, _, _ = build_target_arrays(direction, mode, lookback, max_symbols, force_rebuild)
    train_x = torch.tensor(target_arrays["train"]["sequence_x"], dtype=torch.float32)
    valid_x = torch.tensor(target_arrays["valid"]["sequence_x"], dtype=torch.float32)
    test_x = torch.tensor(target_arrays["test"]["sequence_x"], dtype=torch.float32)
    train_y = torch.tensor(target_arrays["train"]["y"], dtype=torch.float32)
    valid_y = torch.tensor(target_arrays["valid"]["y"], dtype=torch.float32)
    test_y = torch.tensor(target_arrays["test"]["y"], dtype=torch.float32)

    x_dim = int(train_x.shape[1] * train_x.shape[2])
    base_model = nn.Sequential(
        nn.Flatten(),
        nn.Linear(x_dim, 128),
        nn.ReLU(),
        nn.Linear(128, 1),
    )
    manager = DoubleAdaptManager(
        model=base_model,
        lr_model=1e-3,
        lr_da=5e-3,
        lr_ma=1e-3,
        factor_num=train_x.shape[-1],
        x_dim=x_dim,
        need_permute=False,
        num_head=2,
        temperature=4.0,
        begin_valid_epoch=0,
    )
    train_task = {
        "X_train": train_x,
        "y_train": train_y,
        "X_test": valid_x,
        "y_test": valid_y,
        "meta_end": int(len(valid_y)),
        "test_idx": build_test_index(target_meta["valid"]),
    }
    valid_task = {
        "X_train": train_x,
        "y_train": train_y,
        "X_test": valid_x,
        "y_test": valid_y,
        "meta_end": int(len(valid_y)),
        "test_idx": build_test_index(target_meta["valid"]),
    }
    manager.fit([train_task], [valid_task])
    test_train_x = torch.cat([train_x, valid_x], dim=0)
    test_train_y = torch.cat([train_y, valid_y], dim=0)
    test_task = {
        "X_train": test_train_x,
        "y_train": test_train_y,
        "X_test": test_x,
        "y_test": test_y,
        "meta_end": int(len(test_y)),
        "test_idx": build_test_index(target_meta["test"]),
    }
    pred_df = manager.inference([test_task])
    pred_df = pred_df.reset_index()
    pred_df["datetime"] = pd.to_datetime(pred_df["datetime"])
    merged = target_meta["test"].rename(columns={"date": "datetime", "symbol": "instrument"}).merge(
        pred_df[["datetime", "instrument", "pred"]],
        on=["datetime", "instrument"],
        how="left",
    )
    meta_df = merged.rename(columns={"datetime": "date", "instrument": "symbol"})[["date", "symbol", "future_return", "label"]].copy()
    prediction = merged["pred"].to_numpy(dtype=np.float32)
    summary = evaluate_and_save("DoubleAdapt", result_dir, meta_df, prediction, top_k=top_k)
    summary["meta_task_count"] = 1
    summary["x_dim"] = x_dim
    return summary


def load_quantnet_dataframe(path: Path) -> pd.DataFrame:
    with gzip.open(path, "rb") as file_obj:
        payload = pickle.load(file_obj)
    if isinstance(payload, pd.DataFrame):
        return payload
    return pd.DataFrame(payload)


def cast_nested_tensors_to_double(payload: Any) -> Any:
    if isinstance(payload, torch.Tensor):
        return payload.double()
    if isinstance(payload, dict):
        return {key: cast_nested_tensors_to_double(value) for key, value in payload.items()}
    if isinstance(payload, list):
        return [cast_nested_tensors_to_double(value) for value in payload]
    if isinstance(payload, tuple):
        return tuple(cast_nested_tensors_to_double(value) for value in payload)
    return payload


def run_quantnet_full_trial(
    direction: str,
    mode: str,
    top_k: int,
    device: str,
    result_dir: Path,
) -> dict[str, Any]:
    manifest = build_artifacts("QuantNet", direction, mode=mode)
    artifact_dir = Path(manifest["artifact_dir"])
    source_market = str(manifest["source_market"]).lower()
    target_market = str(manifest["target_market"]).lower()

    repo_dir = OFFICIAL_DIR / BASELINE_REGISTRY["QuantNet"].repo_dir
    sys.path.insert(0, str(repo_dir))
    try:
        from quantnet.no_transfer.lstm_lstm import GlobalLstmLstm
        from quantnet.utils import get_data
    finally:
        sys.path.pop(0)

    export_dir = result_dir / "quantnet_exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    profile = get_profile(mode)
    model_config = {
        "t_steps": 160 if mode == "full" else 60,
        "tasks_t_steps": 1,
        "batch_size": 8,
        "seq_len": 20,
        "device": "cuda" if device.startswith("cuda") and torch.cuda.is_available() else "cpu",
        "export_path": export_dir.as_posix() + "/",
        "export_label": f"{direction.lower()}_{mode}_global_lstm_lstm",
        "global_lstm_lstm": {
            "opt_lr": 1e-3,
            "amsgrad": True,
            "export_model": False,
            "in_n_layers": 1,
            "out_n_layers": 1,
            "out_nhi": 16,
            "drop_rate": 0.0,
            "in_transfer_dim": 16,
            "out_transfer_dim": 16,
            "n_layers": 1,
            "drop_rate_transfer": 0.0,
        },
    }
    data_config = {
        "data_path": artifact_dir.as_posix() + "/",
        "region": ["AlphaMechTransferRegion"],
        "AlphaMechTransferRegion": [source_market, target_market],
        "additional_data_path": "_all_assets_data.pkl.gz",
    }
    problem_config = {
        "export_path": export_dir.as_posix() + "/",
        "val_period": 0,
        "holdout_period": int(profile.quantnet_holdout_period),
    }
    x_train, _x_val, x_test = get_data(data_config, problem_config, model_config)
    x_train = cast_nested_tensors_to_double(x_train)
    x_test = cast_nested_tensors_to_double(x_test)
    model = GlobalLstmLstm(x_train, model_config)
    model.train()
    prediction_tasks = model.predict(x_test)
    pred_tensor = prediction_tasks["AlphaMechTransferRegion"][target_market].detach().cpu().numpy().squeeze(0)

    target_matrix = load_quantnet_dataframe(artifact_dir / f"{target_market}_all_assets_data.pkl.gz")
    test_matrix = target_matrix.tail(int(problem_config["holdout_period"]))
    pred_dates = pd.to_datetime(test_matrix.index[1:1 + pred_tensor.shape[0]])
    pred_symbols = [str(symbol) for symbol in test_matrix.columns.tolist()]
    pred_df = (
        pd.DataFrame(pred_tensor, index=pred_dates, columns=pred_symbols)
        .stack()
        .reset_index()
        .rename(columns={"level_0": "date", "level_1": "symbol", 0: "prediction"})
    )

    target_panel, target_incidence = load_market_bundle(target_market.upper())
    target_panel = apply_unified_split(target_panel)
    target_panel, _ = apply_profile_view(target_panel, target_incidence, target_market.upper(), mode)
    test_panel = target_panel[target_panel["split"] == "test"][["date", "symbol", "future_return", "label_rank_proxy"]].copy()
    test_panel["symbol"] = test_panel["symbol"].astype(str)
    merged = pred_df.merge(test_panel, on=["date", "symbol"], how="inner")
    meta_df = merged.rename(columns={"label_rank_proxy": "label"})[["date", "symbol", "future_return", "label"]].copy()
    summary = evaluate_and_save("QuantNet", result_dir, meta_df, merged["prediction"].to_numpy(dtype=np.float32), top_k=top_k)
    summary["quantnet_variant"] = "GlobalLstmLstm"
    summary["holdout_period"] = int(problem_config["holdout_period"])
    summary["prediction_row_count"] = int(len(merged))
    return summary


def build_result_dir(direction: str, baseline: str) -> Path:
    return RESULT_DIR / direction.lower() / baseline.lower()


def load_existing_result(direction: str, baseline: str) -> dict[str, Any] | None:
    summary_path = build_result_dir(direction, baseline) / "summary.json"
    if not summary_path.exists():
        return None
    return json.loads(summary_path.read_text(encoding="utf-8"))


def execute_trial(args: argparse.Namespace, direction: str, baseline: str) -> dict[str, Any]:
    start_time = time.perf_counter()
    registry = BASELINE_REGISTRY[baseline]
    result_dir = build_result_dir(direction, baseline)
    result_dir.mkdir(parents=True, exist_ok=True)
    if not args.rerun_existing:
        existing = load_existing_result(direction, baseline)
        if existing is not None:
            return {
                "direction": direction,
                "baseline": baseline,
                "comparison_layer": registry.comparison_layer,
                "paper_role": registry.paper_role,
                "status": "existing_reused",
                "elapsed_seconds": 0.0,
                **existing,
            }

    log(f"trial started | direction={direction} | baseline={baseline}")
    if baseline == "TRA":
        summary = run_tra_full_trial(
            direction=direction,
            mode=args.mode,
            lookback=args.lookback,
            top_k=args.top_k,
            max_symbols=args.max_symbols,
            force_rebuild=args.force_rebuild,
            device=args.device,
            result_dir=result_dir,
        )
    elif baseline == "DoubleAdapt":
        summary = run_doubleadapt_full_trial(
            direction=direction,
            mode=args.mode,
            lookback=args.lookback,
            top_k=args.top_k,
            max_symbols=args.max_symbols,
            force_rebuild=args.force_rebuild,
            device=args.device,
            result_dir=result_dir,
        )
    elif baseline == "QuantNet":
        summary = run_quantnet_full_trial(
            direction=direction,
            mode=args.mode,
            top_k=args.top_k,
            device=args.device,
            result_dir=result_dir,
        )
    else:
        raise ValueError(baseline)

    elapsed = float(time.perf_counter() - start_time)
    log(
        f"trial finished | direction={direction} | baseline={baseline} | "
        f"elapsed={format_seconds(elapsed)} | RankIC={float(summary.get('RankIC', 0.0)):.6f}"
    )
    return {
        "direction": direction,
        "baseline": baseline,
        "comparison_layer": registry.comparison_layer,
        "paper_role": registry.paper_role,
        "status": "success",
        "elapsed_seconds": elapsed,
        **summary,
    }


def write_trial_tables(rows: list[dict[str, Any]]) -> dict[str, str]:
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    summary_df = pd.DataFrame(rows)
    csv_path = write_dataframe(summary_df, RESULT_DIR / "all_full_trial_summary.csv", index=False, encoding="utf-8-sig")
    json_path = write_json(RESULT_DIR / "all_full_trial_summary.json", rows)
    md_path = RESULT_DIR / "all_full_trial_summary.md"
    md_lines = [
        "# Official Baseline Full Trial Summary v1",
        "",
        render_markdown_table(summary_df),
        "",
    ]
    md_path.write_text("\n".join(md_lines), encoding="utf-8")
    return {"csv_path": str(csv_path), "json_path": str(json_path), "md_path": str(md_path)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行 official baseline 的 full-scale quantitative trial")
    parser.add_argument("--mode", default="full", choices=["full", "medium"])
    parser.add_argument("--directions", default="CN_TO_US,US_TO_CN")
    parser.add_argument("--baselines", default=",".join(DEFAULT_BASELINES))
    parser.add_argument("--lookback", type=int, default=12)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--max-symbols", type=int, default=160)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true")
    parser.add_argument("--rerun-existing", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    directions = [normalize_direction(item) for item in parse_optional_csv(args.directions)]
    baselines = [item for item in parse_optional_csv(args.baselines) if item in BASELINE_REGISTRY]
    if not baselines:
        raise ValueError("请至少指定一个受支持的 baseline: QuantNet, TRA, DoubleAdapt")

    rows: list[dict[str, Any]] = []
    for direction in directions:
        for baseline in baselines:
            rows.append(execute_trial(args, direction, baseline))

    payload = write_trial_tables(rows)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
