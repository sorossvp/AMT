"""
文件功能:
1. 为第三方官方 baseline 生成外层最小适配清单, 统一数据路径、标签口径与结果导出协议。
2. 不改动任何官方 baseline 核心逻辑, 仅写出 adapter manifest, 供人工或调度器执行官方训练入口。
3. 为论文实验提供统一的 `date, instrument, score` 结果协议说明。

代码逻辑:
1. 校验官方 repo 是否存在。
2. 根据迁移方向生成源域/目标域数据路径与输出目录。
3. 将最小适配边界、外围数据资产位置和预期结果文件写出为 manifest。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from experiment_workspace import get_categorized_result_path, write_json, write_text
from official_baseline_artifact_builder import build_artifacts


ROOT_DIR = Path(__file__).resolve().parents[1]
PROCESSED_DIR = ROOT_DIR / "DataToSever" / "processed_data"
RESULT_DIR = get_categorized_result_path("baseline", "baseline_adapter")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def parse_direction(direction: str) -> tuple[str, str]:
    mapping = {
        "CN_TO_US": ("CN", "US"),
        "US_TO_CN": ("US", "CN"),
        "CN_TO_FUTURE": ("CN", "FUTURE"),
        "FUTURE_TO_CN": ("FUTURE", "CN"),
    }
    return mapping[direction]


def build_manifest(
    baseline: str,
    direction: str,
    repo: Path,
    appendix_only: bool,
    supplementary: bool,
    build_assets: bool,
) -> dict[str, object]:
    source_market, target_market = parse_direction(direction)
    result_dir = RESULT_DIR / direction.lower() / baseline.lower()
    ensure_dir(result_dir)
    artifact_manifest = build_artifacts(baseline=baseline, direction=direction) if build_assets else None
    return {
        "baseline": baseline,
        "direction": direction,
        "repo_path": str(repo),
        "source_market": source_market,
        "target_market": target_market,
        "source_panel_path": str(PROCESSED_DIR / source_market.lower() / "panel.pkl"),
        "target_panel_path": str(PROCESSED_DIR / target_market.lower() / "panel.pkl"),
        "source_meta_path": str(PROCESSED_DIR / source_market.lower() / "universe_summary.csv"),
        "target_meta_path": str(PROCESSED_DIR / target_market.lower() / "universe_summary.csv"),
        "label_definition": "future 5-day cross-sectional return ranking",
        "allowed_changes": [
            "data_loader",
            "file_path",
            "label_generator",
            "result_export",
        ],
        "forbidden_changes": [
            "model_core",
            "loss_function",
            "attention_module",
            "graph_logic",
            "custom_innovation",
        ],
        "expected_outputs": {
            "predictions": str(result_dir / "test_predictions.csv"),
            "summary": str(result_dir / "summary.json"),
            "adapter_note": str(result_dir / "adapter_note.md"),
        },
        "artifact_manifest": artifact_manifest,
        "appendix_only": appendix_only,
        "supplementary": supplementary,
    }


def write_outputs(manifest: dict[str, object]) -> dict[str, str]:
    result_dir = Path(manifest["expected_outputs"]["summary"]).parent
    ensure_dir(result_dir)
    summary_path = Path(manifest["expected_outputs"]["summary"])
    note_path = Path(manifest["expected_outputs"]["adapter_note"])
    actual_summary_path = write_json(summary_path, manifest)
    note_lines = [
        f"# Adapter note: {manifest['baseline']} / {manifest['direction']}",
        "",
        f"- Repo path: `{manifest['repo_path']}`",
        f"- Source panel: `{manifest['source_panel_path']}`",
        f"- Target panel: `{manifest['target_panel_path']}`",
        f"- Label definition: `{manifest['label_definition']}`",
        f"- Allowed changes: `{', '.join(manifest['allowed_changes'])}`",
        f"- Forbidden changes: `{', '.join(manifest['forbidden_changes'])}`",
        f"- Expected predictions path: `{manifest['expected_outputs']['predictions']}`",
        "",
        "## Result export protocol",
        "",
        "- Required columns: `date, instrument, score`",
        "- Encoding: `utf-8-sig`",
        "- One row per test date and instrument",
        "- Sorted by `date, instrument` before evaluation",
    ]
    actual_note_path = write_text(note_path, "\n".join(note_lines))
    return {"summary_path": str(actual_summary_path), "note_path": str(actual_note_path)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成官方 baseline 最小适配 manifest")
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--direction", required=True, choices=["CN_TO_US", "US_TO_CN", "CN_TO_FUTURE", "FUTURE_TO_CN"])
    parser.add_argument("--repo", required=True)
    parser.add_argument("--appendix-only", action="store_true")
    parser.add_argument("--supplementary", action="store_true")
    parser.add_argument("--skip-build-assets", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo = Path(args.repo)
    if not repo.exists():
        raise FileNotFoundError(f"官方 baseline 目录不存在: {repo}")
    manifest = build_manifest(
        baseline=args.baseline,
        direction=args.direction,
        repo=repo,
        appendix_only=args.appendix_only,
        supplementary=args.supplementary,
        build_assets=not args.skip_build_assets,
    )
    payload = write_outputs(manifest)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

