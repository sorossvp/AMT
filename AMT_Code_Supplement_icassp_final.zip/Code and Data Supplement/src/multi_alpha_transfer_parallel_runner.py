"""
文件功能:
1. 面向 AAAI V2 的策略级补充实验, 批量调度 10 个代表性 alpha 在双向跨市场迁移任务上的迁移家族对比。
2. 基于现有 `transfer_family_comparison.py` 的统一训练入口, 为每个 alpha 独立创建结果目录, 保持模型核心不变。
3. 提供多 GPU 并行执行框架, 以“一个 alpha 任务占用一个 GPU worker”的方式高效完成批量正式实验。
4. 统一落盘运行清单、日志文件与任务状态摘要, 便于论文结果回溯与复核。

代码逻辑:
1. 预定义 10 个覆盖动量、反转、波动率、流动性、量价耦合等类别的代表性 alpha。
2. 将每个 alpha 任务封装成对 `transfer_family_comparison.py` 的一次独立调用, 结果写入 `主实验/multi_alpha_transfer/<alpha>/`。
3. 通过 GPU worker 队列并行调度所有 alpha, 每个 worker 顺序消费任务, 避免同一张 GPU 同时跑多个训练进程。
4. 汇总每个 alpha 的执行状态、耗时、日志路径与结果目录, 生成批量实验 manifest。

代码结构:
1. Alpha 基准清单与 GPU 参数解析。
2. 单 alpha 任务封装与日志写入。
3. 多 GPU worker 调度器。
4. CLI 入口与 manifest 导出。
"""

from __future__ import annotations

import argparse
import os
import queue
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import pandas as pd

from data_pipeline import prepare_transfer_artifacts
from experiment_workspace import get_categorized_result_path, write_dataframe, write_json


ROOT_DIR = Path(__file__).resolve().parents[1]
CODE_DIR = ROOT_DIR / "code"
RESULT_ROOT = get_categorized_result_path("main", "multi_alpha_transfer")
LOG_DIR = RESULT_ROOT / "_logs"


@dataclass(frozen=True)
class AlphaBenchmarkTask:
    name: str
    category: str
    rationale: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


ALPHA_TASKS: list[AlphaBenchmarkTask] = [
    AlphaBenchmarkTask("alpha_ret_5", "动量类", "最基础的短周期趋势 alpha, 用于检验价格延续性是否可迁移。"),
    AlphaBenchmarkTask("alpha_ma_ratio_5_20", "动量类", "短中期均线趋势 alpha, 当前跨市场中稳定性较高。"),
    AlphaBenchmarkTask("alpha_reversal_5", "反转类", "检验短期过度反应与均值回复模式的跨市场保真性。"),
    AlphaBenchmarkTask("alpha_high_low_spread", "波动率类", "衡量日内振幅, 检验波动扩散结构是否可迁移。"),
    AlphaBenchmarkTask("alpha_range_position", "波动率类", "反映收盘在日内区间中的相对位置, 代表尾盘交易行为。"),
    AlphaBenchmarkTask("alpha_amihud_proxy_20", "流动性类", "以冲击成本代理刻画流动性差异, 检验拥挤交易结构的迁移边界。"),
    AlphaBenchmarkTask("alpha_volume_momentum_20", "流动性类", "衡量成交量扩张, 检验换手扩散信号的跨市场稳定性。"),
    AlphaBenchmarkTask("alpha_price_volume_corr_10", "量价耦合类", "衡量价格与成交量的同步性, 代表交易行为共振。"),
    AlphaBenchmarkTask("alpha_volume_breakout_price_follow", "量价耦合类", "以放量突破作为统一策略对象, 适合考察机理锁存后的迁移表现。"),
    AlphaBenchmarkTask("alpha_breakout_20", "突破类", "趋势突破类 alpha, 用于区分结构延续与目标域失配。"),
]


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(f"[MULTI-ALPHA] {message}", flush=True)


def parse_csv(raw_value: str) -> list[str]:
    return [item.strip() for item in str(raw_value).split(",") if item.strip()]


def normalize_gpu_ids(raw_value: str | None) -> list[str]:
    if raw_value is None or not str(raw_value).strip():
        return [str(index) for index in range(8)]
    return parse_csv(raw_value)


def normalize_direction_pairs(raw_value: str) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for item in parse_csv(raw_value):
        normalized = str(item).strip().lower()
        if normalized == "cn_to_us":
            pairs.append(("CN", "US"))
        elif normalized == "us_to_cn":
            pairs.append(("US", "CN"))
        else:
            raise ValueError(f"不支持的方向: {item}")
    return pairs


def warm_shared_transfer_cache(args: argparse.Namespace, task_count: int) -> None:
    if not args.force_rebuild or task_count <= 0:
        return
    direction_pairs = normalize_direction_pairs(args.directions)
    if not direction_pairs:
        return
    # #region debug-point A:shared-cache-prewarm-start
    try:
        debug_url = "http://127.0.0.1:7777/event"
        debug_session_id = "multi-alpha-overflow"
        env_path = ROOT_DIR / ".dbg" / "multi-alpha-overflow.env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("DEBUG_SERVER_URL="):
                    debug_url = line.split("=", 1)[1].strip() or debug_url
                elif line.startswith("DEBUG_SESSION_ID="):
                    debug_session_id = line.split("=", 1)[1].strip() or debug_session_id
        payload = {
            "sessionId": debug_session_id,
            "runId": "pre-fix",
            "hypothesisId": "A",
            "location": "multi_alpha_transfer_parallel_runner.py:warm_shared_transfer_cache:start",
            "msg": "[DEBUG] shared cache prewarm start",
            "data": {
                "task_count": int(task_count),
                "direction_pairs": [f"{src}->{dst}" for src, dst in direction_pairs],
                "max_symbols": int(args.max_symbols),
                "force_rebuild": bool(args.force_rebuild),
            },
            "ts": int(time.time() * 1000),
        }
        import json
        import urllib.request

        urllib.request.urlopen(
            urllib.request.Request(
                debug_url,
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                headers={"Content-Type": "application/json"},
            ),
            timeout=2.0,
        ).read()
    except Exception:
        pass
    # #endregion
    log(
        "开始共享缓存预热: 仅重建一次 CN/US 底座特征与超图缓存，"
        "后续各 alpha 任务直接复用，避免重复刷全量市场 CSV。"
    )
    for source_market, target_market in direction_pairs:
        log(f"缓存预热中: {source_market}->{target_market}")
        prepare_transfer_artifacts(
            source_market=source_market,
            target_market=target_market,
            max_symbols=int(args.max_symbols),
            horizon=5,
            force_rebuild=True,
        )
    log("共享缓存预热完成，后续 alpha 任务将复用缓存继续训练。")
    # #region debug-point A:shared-cache-prewarm-end
    try:
        debug_url = "http://127.0.0.1:7777/event"
        debug_session_id = "multi-alpha-overflow"
        env_path = ROOT_DIR / ".dbg" / "multi-alpha-overflow.env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("DEBUG_SERVER_URL="):
                    debug_url = line.split("=", 1)[1].strip() or debug_url
                elif line.startswith("DEBUG_SESSION_ID="):
                    debug_session_id = line.split("=", 1)[1].strip() or debug_session_id
        payload = {
            "sessionId": debug_session_id,
            "runId": "pre-fix",
            "hypothesisId": "A",
            "location": "multi_alpha_transfer_parallel_runner.py:warm_shared_transfer_cache:end",
            "msg": "[DEBUG] shared cache prewarm finished",
            "data": {
                "task_count": int(task_count),
                "direction_pairs": [f"{src}->{dst}" for src, dst in direction_pairs],
            },
            "ts": int(time.time() * 1000),
        }
        import json
        import urllib.request

        urllib.request.urlopen(
            urllib.request.Request(
                debug_url,
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                headers={"Content-Type": "application/json"},
            ),
            timeout=2.0,
        ).read()
    except Exception:
        pass
    # #endregion


def build_command(
    python_bin: str,
    alpha_name: str,
    mode: str,
    directions: str,
    models: str,
    device: str,
    max_symbols: int,
    lookback: int,
    top_k: int,
    amt_top_r: int,
    amt_gate_temperature: float,
    amt_alpha_residual_scale: float,
    amt_delta_clip: float,
    amt_min_gate_mass: float,
    amt_weight_param: float,
    amt_weight_mech: float,
    force_rebuild: bool,
    rerun_existing: bool,
) -> list[str]:
    command = [
        python_bin,
        str(CODE_DIR / "transfer_family_comparison.py"),
        "--mode",
        mode,
        "--direction",
        directions,
        "--models",
        models,
        "--base-alpha",
        alpha_name,
        "--max-symbols",
        str(max_symbols),
        "--lookback",
        str(lookback),
        "--top-k",
        str(top_k),
        "--amt-top-r",
        str(amt_top_r),
        "--amt-gate-temperature",
        str(amt_gate_temperature),
        "--amt-alpha-residual-scale",
        str(amt_alpha_residual_scale),
        "--amt-delta-clip",
        str(amt_delta_clip),
        "--amt-min-gate-mass",
        str(amt_min_gate_mass),
        "--amt-weight-param",
        str(amt_weight_param),
        "--amt-weight-mech",
        str(amt_weight_mech),
        "--device",
        device,
        "--result-subdir",
        f"multi_alpha_transfer/{alpha_name}",
    ]
    if force_rebuild:
        command.append("--force-rebuild")
    if rerun_existing:
        command.append("--rerun-existing")
    return command


def run_single_alpha_job(
    task: AlphaBenchmarkTask,
    gpu_id: str,
    python_bin: str,
    mode: str,
    directions: str,
    models: str,
    device: str,
    max_symbols: int,
    lookback: int,
    top_k: int,
    amt_top_r: int,
    amt_gate_temperature: float,
    amt_alpha_residual_scale: float,
    amt_delta_clip: float,
    amt_min_gate_mass: float,
    amt_weight_param: float,
    amt_weight_mech: float,
    force_rebuild: bool,
    rerun_existing: bool,
) -> dict[str, Any]:
    ensure_dir(LOG_DIR)
    alpha_result_root = RESULT_ROOT / task.name
    ensure_dir(alpha_result_root)
    log_path = LOG_DIR / f"{task.name}.log"
    command = build_command(
        python_bin=python_bin,
        alpha_name=task.name,
        mode=mode,
        directions=directions,
        models=models,
        device=device,
        max_symbols=max_symbols,
        lookback=lookback,
        top_k=top_k,
        amt_top_r=amt_top_r,
        amt_gate_temperature=amt_gate_temperature,
        amt_alpha_residual_scale=amt_alpha_residual_scale,
        amt_delta_clip=amt_delta_clip,
        amt_min_gate_mass=amt_min_gate_mass,
        amt_weight_param=amt_weight_param,
        amt_weight_mech=amt_weight_mech,
        force_rebuild=force_rebuild,
        rerun_existing=rerun_existing,
    )
    env = os.environ.copy()
    if str(device).lower() == "cuda":
        env["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    start_time = time.perf_counter()
    status = "success"
    return_code = 0
    with log_path.open("w", encoding="utf-8") as log_file:
        log_file.write(f"[INFO] alpha={task.name} | gpu={gpu_id}\n")
        log_file.write(f"[INFO] command={' '.join(command)}\n")
        log_file.flush()
        completed = subprocess.run(
            command,
            cwd=str(ROOT_DIR),
            env=env,
            stdout=log_file,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )
        return_code = int(completed.returncode)
        if return_code != 0:
            status = "failed"
    # #region debug-point A:manifest-status
    try:
        debug_url = "http://127.0.0.1:7777/event"
        debug_session_id = "multi-alpha-overflow"
        env_path = ROOT_DIR / ".dbg" / "multi-alpha-overflow.env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("DEBUG_SERVER_URL="):
                    debug_url = line.split("=", 1)[1].strip() or debug_url
                elif line.startswith("DEBUG_SESSION_ID="):
                    debug_session_id = line.split("=", 1)[1].strip() or debug_session_id
        summary_exists = (alpha_result_root / "all_summary.csv").exists()
        config_exists = (alpha_result_root / "run_config.json").exists()
        log_exists = log_path.exists()
        payload = {
            "sessionId": debug_session_id,
            "runId": "pre-fix",
            "hypothesisId": "A",
            "location": "multi_alpha_transfer_parallel_runner.py:run_single_alpha_job",
            "msg": "[DEBUG] multi-alpha subprocess finished",
            "data": {
                "alpha_name": task.name,
                "gpu_id": str(gpu_id),
                "return_code": return_code,
                "status": status,
                "summary_exists": summary_exists,
                "config_exists": config_exists,
                "log_exists": log_exists,
                "summary_path": str(alpha_result_root / "all_summary.csv"),
                "log_path": str(log_path),
            },
            "ts": int(time.time() * 1000),
        }
        import json
        import urllib.request

        urllib.request.urlopen(
            urllib.request.Request(
                debug_url,
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                headers={"Content-Type": "application/json"},
            ),
            timeout=2.0,
        ).read()
    except Exception:
        pass
    # #endregion
    elapsed = float(time.perf_counter() - start_time)
    return {
        "alpha_name": task.name,
        "alpha_category": task.category,
        "alpha_rationale": task.rationale,
        "gpu_id": str(gpu_id),
        "status": status,
        "return_code": return_code,
        "elapsed_seconds": elapsed,
        "result_root": str(alpha_result_root),
        "summary_path": str(alpha_result_root / "all_summary.csv"),
        "config_path": str(alpha_result_root / "run_config.json"),
        "log_path": str(log_path),
    }


def worker_loop(
    gpu_id: str,
    task_queue: queue.Queue[AlphaBenchmarkTask],
    result_rows: list[dict[str, Any]],
    lock: threading.Lock,
    args: argparse.Namespace,
    force_rebuild_for_children: bool,
) -> None:
    while True:
        try:
            task = task_queue.get_nowait()
        except queue.Empty:
            return
        # #region debug-point D:worker-dispatch
        try:
            debug_url = "http://127.0.0.1:7777/event"
            debug_session_id = "multi-alpha-overflow"
            env_path = ROOT_DIR / ".dbg" / "multi-alpha-overflow.env"
            if env_path.exists():
                for line in env_path.read_text(encoding="utf-8").splitlines():
                    if line.startswith("DEBUG_SERVER_URL="):
                        debug_url = line.split("=", 1)[1].strip() or debug_url
                    elif line.startswith("DEBUG_SESSION_ID="):
                        debug_session_id = line.split("=", 1)[1].strip() or debug_session_id
            payload = {
                "sessionId": debug_session_id,
                "runId": "pre-fix",
                "hypothesisId": "D",
                "location": "multi_alpha_transfer_parallel_runner.py:worker_loop",
                "msg": "[DEBUG] worker picked alpha task",
                "data": {
                    "gpu_id": str(gpu_id),
                    "alpha_name": task.name,
                    "remaining_tasks_approx": int(task_queue.qsize()),
                    "force_rebuild_for_children": bool(force_rebuild_for_children),
                },
                "ts": int(time.time() * 1000),
            }
            import json
            import urllib.request

            urllib.request.urlopen(
                urllib.request.Request(
                    debug_url,
                    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                ),
                timeout=2.0,
            ).read()
        except Exception:
            pass
        # #endregion
        log(f"GPU {gpu_id} 开始任务: {task.name}")
        payload = run_single_alpha_job(
            task=task,
            gpu_id=gpu_id,
            python_bin=args.python_bin,
            mode=args.mode,
            directions=args.directions,
            models=args.models,
            device=args.device,
            max_symbols=args.max_symbols,
            lookback=args.lookback,
            top_k=args.top_k,
            amt_top_r=args.amt_top_r,
            amt_gate_temperature=args.amt_gate_temperature,
            amt_alpha_residual_scale=args.amt_alpha_residual_scale,
            amt_delta_clip=args.amt_delta_clip,
            amt_min_gate_mass=args.amt_min_gate_mass,
            amt_weight_param=args.amt_weight_param,
            amt_weight_mech=args.amt_weight_mech,
            force_rebuild=force_rebuild_for_children,
            rerun_existing=args.rerun_existing,
        )
        with lock:
            result_rows.append(payload)
        log(f"GPU {gpu_id} 完成任务: {task.name} | 状态={payload['status']} | 用时={payload['elapsed_seconds']:.1f}s")
        task_queue.task_done()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行 10 个 alpha 的多 GPU 并行迁移补充实验")
    parser.add_argument("--python-bin", default=os.environ.get("PYTHON_BIN", Path(sys.executable).as_posix()))
    parser.add_argument("--mode", default="full", choices=["full", "medium"])
    parser.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    parser.add_argument("--directions", default="cn_to_us,us_to_cn")
    parser.add_argument(
        "--models",
        default="direct_transfer,amt,lstm_transfer,transformer_transfer,tra_transfer,hist_transfer",
    )
    parser.add_argument("--max-symbols", type=int, default=160)
    parser.add_argument("--lookback", type=int, default=20)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--gpu-ids", default="0,1,2,3,4,5,6,7")
    parser.add_argument("--alpha-list", default="")
    parser.add_argument("--amt-top-r", type=int, default=3)
    parser.add_argument("--amt-gate-temperature", type=float, default=0.70)
    parser.add_argument("--amt-alpha-residual-scale", type=float, default=0.35)
    parser.add_argument("--amt-delta-clip", type=float, default=0.75)
    parser.add_argument("--amt-min-gate-mass", type=float, default=1e-6)
    parser.add_argument("--amt-weight-param", type=float, default=0.01)
    parser.add_argument("--amt-weight-mech", type=float, default=0.01)
    parser.add_argument("--force-rebuild", action="store_true")
    parser.add_argument("--rerun-existing", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    ensure_dir(RESULT_ROOT)
    ensure_dir(LOG_DIR)
    gpu_ids = normalize_gpu_ids(args.gpu_ids)
    selected_names = set(parse_csv(args.alpha_list)) if args.alpha_list.strip() else {task.name for task in ALPHA_TASKS}
    task_items = [task for task in ALPHA_TASKS if task.name in selected_names]
    if not task_items:
        raise ValueError("未选中任何 alpha 任务。")
    warm_shared_transfer_cache(args, task_count=len(task_items))
    # `force_rebuild` 已在共享预热阶段完成，子任务只需复用新缓存。
    # 这能显著减少多 alpha 看起来“卡在 feature build”的等待时间。
    child_force_rebuild = False if args.force_rebuild else False
    job_queue: queue.Queue[AlphaBenchmarkTask] = queue.Queue()
    for task in task_items:
        job_queue.put(task)
    result_rows: list[dict[str, Any]] = []
    lock = threading.Lock()
    threads: list[threading.Thread] = []
    start_time = time.perf_counter()
    for gpu_id in gpu_ids:
        thread = threading.Thread(
            target=worker_loop,
            args=(gpu_id, job_queue, result_rows, lock, args, child_force_rebuild),
            daemon=True,
        )
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()
    result_rows = sorted(result_rows, key=lambda item: item["alpha_name"])
    write_dataframe(pd.DataFrame(result_rows), RESULT_ROOT / "multi_alpha_parallel_manifest.csv", index=False, encoding="utf-8-sig")
    write_json(
        RESULT_ROOT / "multi_alpha_parallel_manifest.json",
        {
            "mode": args.mode,
            "gpu_ids": gpu_ids,
            "shared_cache_prewarm": bool(args.force_rebuild),
            "directions": parse_csv(args.directions),
            "models": parse_csv(args.models),
            "alpha_tasks": [task.to_dict() for task in task_items],
            "elapsed_seconds": float(time.perf_counter() - start_time),
            "rows": result_rows,
        },
    )
    failed = [row for row in result_rows if row["status"] != "success"]
    log(f"总任务数={len(result_rows)} | 失败任务数={len(failed)}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
