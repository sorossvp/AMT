"""
文件功能:
1. 下载沪深300、中证500、纳斯达克100、标普500当前成分股名单，并统一保存为结构化成分股清单。
2. 按指数逐只下载成分股完整历史日频行情，覆盖开盘价、最高价、最低价、收盘价、成交量等核心字段。
3. 对下载后的历史行情执行频率识别、时间覆盖统计、缺失值检查、重复值检查和异常值检查，并输出数据质量报告。
4. 将原始成分股清单、单股票历史 CSV、汇总统计表、JSON 报告和 Markdown 报告统一落盘到 `DataToSever/index_constituent_data/`，方便本地与服务器复用。

代码逻辑:
1. 先根据指数类型选择成分股来源: A 股指数使用 `AkShare + 中证指数接口`，美股指数使用 `Wikipedia / StockTi` 页面抓取当前成分股。
2. 再按市场分别下载历史行情: A 股走 `ak.stock_zh_a_hist(period='daily')`，美股走 `yfinance.download(interval='1d')` 批量拉取。
3. 下载后统一标准化字段为 `date/open/high/low/close/volume/adj_close/symbol/index_name/market/source`，并按股票写入单独 CSV。
4. 最后汇总每只股票的数据质量指标，生成指数级别汇总、全量质量明细以及 Markdown 文字报告。

代码结构:
1. 路径常量、指数元数据与通用工具函数。
2. 成分股抓取函数。
3. A 股 / 美股历史行情下载与标准化函数。
4. 数据质量检查与指数级报告汇总函数。
5. 命令行入口。
"""

from __future__ import annotations

import argparse
import json
import math
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import requests
import yfinance as yf

ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_ROOT = ROOT_DIR / "DataToSever" / "index_constituent_data"
CONSTITUENT_DIR = DATA_ROOT / "constituents"
HISTORY_DIR = DATA_ROOT / "history"
REPORT_DIR = DATA_ROOT / "reports"
US_LOCAL_CACHE_DIR = ROOT_DIR / "DataToSever" / "_workspace_us_2021_2025_csv"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"

EXPECTED_CORE_COLUMNS = ["date", "open", "high", "low", "close", "volume"]
US_HISTORY_START = "1990-01-01"
CN_HISTORY_START = "19900101"


@dataclass(frozen=True)
class IndexSpec:
    key: str
    display_name: str
    market: str
    constituent_source: str


INDEX_SPECS: dict[str, IndexSpec] = {
    "hs300": IndexSpec("hs300", "沪深300", "CN", "akshare_csindex"),
    "csi500": IndexSpec("csi500", "中证500", "CN", "akshare_csindex"),
    "nasdaq100": IndexSpec("nasdaq100", "NASDAQ100", "US", "stockti"),
    "sp500": IndexSpec("sp500", "S&P500", "US", "wikipedia"),
}


def log(message: str) -> None:
    print(message, flush=True)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def chunked(items: list[str], size: int) -> Iterable[list[str]]:
    for index in range(0, len(items), size):
        yield items[index : index + size]


def sanitize_symbol(symbol: str) -> str:
    text = str(symbol).strip().upper()
    return text.replace("/", "_").replace("\\", "_")


def request_text(url: str, timeout: int = 30) -> str:
    response = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=timeout)
    response.raise_for_status()
    return response.text


def normalize_sp500_symbol(symbol: str) -> str:
    return str(symbol).strip().upper().replace(".", "-")


def normalize_us_symbol_for_yf(symbol: str) -> str:
    return str(symbol).strip().upper().replace(".", "-")


def fetch_hs300_constituents() -> pd.DataFrame:
    import akshare as ak

    df = ak.index_stock_cons_csindex(symbol="000300").copy()
    df = df.rename(
        columns={
            "日期": "snapshot_date",
            "指数代码": "index_code",
            "指数名称": "index_name",
            "成分券代码": "symbol",
            "成分券名称": "company_name",
        }
    )
    df["symbol"] = df["symbol"].astype(str).str.zfill(6)
    df["market"] = "CN"
    df["index_key"] = "hs300"
    return df[["index_key", "index_name", "index_code", "snapshot_date", "symbol", "company_name", "market"]].drop_duplicates("symbol").reset_index(drop=True)


def fetch_csi500_constituents() -> pd.DataFrame:
    import akshare as ak

    df = ak.index_stock_cons_csindex(symbol="000905").copy()
    df = df.rename(
        columns={
            "日期": "snapshot_date",
            "指数代码": "index_code",
            "指数名称": "index_name",
            "成分券代码": "symbol",
            "成分券名称": "company_name",
        }
    )
    df["symbol"] = df["symbol"].astype(str).str.zfill(6)
    df["market"] = "CN"
    df["index_key"] = "csi500"
    return df[["index_key", "index_name", "index_code", "snapshot_date", "symbol", "company_name", "market"]].drop_duplicates("symbol").reset_index(drop=True)


def fetch_sp500_constituents() -> pd.DataFrame:
    html = request_text("https://en.wikipedia.org/wiki/List_of_S%26P_500_companies")
    tables = pd.read_html(StringIO(html))
    df = tables[0].copy()
    df = df.rename(
        columns={
            "Symbol": "symbol",
            "Security": "company_name",
            "GICS Sector": "sector",
            "GICS Sub-Industry": "industry",
            "Date added": "date_added",
        }
    )
    df["symbol"] = df["symbol"].map(normalize_sp500_symbol)
    df["index_key"] = "sp500"
    df["index_name"] = "S&P500"
    df["market"] = "US"
    df["snapshot_date"] = pd.Timestamp.utcnow().strftime("%Y-%m-%d")
    return df[["index_key", "index_name", "snapshot_date", "symbol", "company_name", "sector", "industry", "date_added", "market"]].reset_index(drop=True)


def fetch_nasdaq100_constituents() -> pd.DataFrame:
    html = request_text("https://stockti.com/stocks/nasdaq-100")
    row_matches = re.findall(
        r'<td[^>]*data-sort="(?P<symbol>[A-Z][A-Z0-9.\-]+)"[^>]*>.*?<a href="/stock/[A-Z][A-Z0-9.\-]+"[^>]*class="list-symbol">.*?</a>.*?</td>\s*'
        r'<td[^>]*data-sort="(?P<name>[^"]+)"[^>]*>.*?<span class="list-name">(?P=name)</span>',
        html,
        flags=re.DOTALL,
    )
    if not row_matches:
        fallback_symbols = sorted(set(re.findall(r'/stock/([A-Z][A-Z0-9.\-]+)', html)))
        row_matches = [(symbol, symbol) for symbol in fallback_symbols]
    if not row_matches:
        raise RuntimeError("未能从 StockTi 页面解析 NASDAQ100 成分股。")
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for symbol, name in row_matches:
        clean_symbol = normalize_us_symbol_for_yf(symbol)
        if clean_symbol in seen:
            continue
        seen.add(clean_symbol)
        rows.append(
            {
                "index_key": "nasdaq100",
                "index_name": "NASDAQ100",
                "snapshot_date": pd.Timestamp.utcnow().strftime("%Y-%m-%d"),
                "symbol": clean_symbol,
                "company_name": str(name).strip(),
                "market": "US",
            }
        )
    if len(rows) < 95:
        raise RuntimeError(f"NASDAQ100 成分股解析数量异常: {len(rows)}")
    return pd.DataFrame(rows)


def fetch_constituents(index_key: str) -> pd.DataFrame:
    normalized = index_key.strip().lower()
    if normalized == "hs300":
        return fetch_hs300_constituents()
    if normalized == "csi500":
        return fetch_csi500_constituents()
    if normalized == "sp500":
        return fetch_sp500_constituents()
    if normalized == "nasdaq100":
        return fetch_nasdaq100_constituents()
    raise KeyError(f"未知指数: {index_key}")


def save_constituents(df: pd.DataFrame, spec: IndexSpec) -> Path:
    ensure_dir(CONSTITUENT_DIR)
    output_path = CONSTITUENT_DIR / f"{spec.key}_constituents.csv"
    df.to_csv(output_path, index=False, encoding="utf-8-sig")
    return output_path


def standardize_cn_history(raw_df: pd.DataFrame, symbol: str, index_name: str) -> pd.DataFrame:
    rename_map = {
        "日期": "date",
        "开盘": "open",
        "收盘": "close",
        "最高": "high",
        "最低": "low",
        "成交量": "volume",
        "成交额": "amount",
        "换手率": "turnover",
    }
    df = raw_df.rename(columns=rename_map).copy()
    keep_cols = [column for column in rename_map.values() if column in df.columns]
    df = df[keep_cols].copy()
    df["date"] = pd.to_datetime(df["date"])
    numeric_cols = [column for column in ["open", "high", "low", "close", "volume", "amount", "turnover"] if column in df.columns]
    for column in numeric_cols:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    df["adj_close"] = df.get("close")
    df["symbol"] = symbol
    df["index_name"] = index_name
    df["market"] = "CN"
    df["source"] = "akshare_stock_zh_a_hist_daily"
    return df.sort_values("date").reset_index(drop=True)


def download_cn_history(symbol: str, index_name: str, start_date: str, end_date: str) -> pd.DataFrame:
    import akshare as ak

    try:
        raw_df = ak.stock_zh_a_hist(symbol=symbol, period="daily", start_date=start_date, end_date=end_date, adjust="")
    except Exception as exc:  # noqa: BLE001
        # 东财接口在当前网络环境下偶发代理失败时，回退到新浪日频接口继续完成下载。
        if "ProxyError" not in str(exc) and "Remote end closed connection" not in str(exc):
            raise
        market_prefix = "SH" if symbol.startswith("6") else "SZ"
        raw_df = ak.stock_zh_a_daily(symbol=f"{market_prefix.lower()}{symbol}", start_date=start_date, end_date=end_date, adjust="")
        raw_df = raw_df.rename(
            columns={
                "date": "日期",
                "open": "开盘",
                "high": "最高",
                "low": "最低",
                "close": "收盘",
                "volume": "成交量",
                "amount": "成交额",
                "turnover": "换手率",
            }
        )
    if raw_df.empty:
        return pd.DataFrame(columns=EXPECTED_CORE_COLUMNS + ["adj_close", "symbol", "index_name", "market", "source"])
    return standardize_cn_history(raw_df, symbol=symbol, index_name=index_name)


def standardize_us_history(df: pd.DataFrame, symbol: str, index_name: str) -> pd.DataFrame:
    work_df = df.copy()
    if isinstance(work_df.index, pd.DatetimeIndex):
        work_df = work_df.reset_index(names="date")
    rename_map = {
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Adj Close": "adj_close",
        "AdjClose": "adj_close",
        "Volume": "volume",
    }
    work_df = work_df.rename(columns=rename_map)
    keep_cols = [column for column in ["date", "open", "high", "low", "close", "adj_close", "volume"] if column in work_df.columns]
    work_df = work_df[keep_cols].copy()
    work_df["date"] = pd.to_datetime(work_df["date"])
    for column in [col for col in ["open", "high", "low", "close", "adj_close", "volume"] if col in work_df.columns]:
        work_df[column] = pd.to_numeric(work_df[column], errors="coerce")
    if "adj_close" not in work_df.columns:
        work_df["adj_close"] = work_df.get("close")
    work_df["symbol"] = symbol
    work_df["index_name"] = index_name
    work_df["market"] = "US"
    work_df["source"] = "yfinance_download_1d"
    return work_df.sort_values("date").reset_index(drop=True)


def load_local_us_history(symbol: str, index_name: str) -> pd.DataFrame:
    cache_path = US_LOCAL_CACHE_DIR / f"{normalize_us_symbol_for_yf(symbol)}.csv"
    if not cache_path.exists():
        return pd.DataFrame()
    cache_df = pd.read_csv(cache_path)
    required_columns = {"date", "open", "high", "low", "close", "volume", "factor", "adjclose"}
    if not required_columns.issubset(set(cache_df.columns)):
        return pd.DataFrame()
    work_df = cache_df.copy()
    work_df["date"] = pd.to_datetime(work_df["date"])
    for column in ["open", "high", "low", "close", "volume", "factor", "adjclose"]:
        work_df[column] = pd.to_numeric(work_df[column], errors="coerce")
    valid_factor = work_df["factor"].replace(0, pd.NA)
    work_df["open"] = work_df["open"] / valid_factor
    work_df["high"] = work_df["high"] / valid_factor
    work_df["low"] = work_df["low"] / valid_factor
    work_df["close"] = work_df["close"] / valid_factor
    work_df["volume"] = work_df["volume"] * work_df["factor"]
    work_df["adj_close"] = work_df["adjclose"]
    work_df["symbol"] = normalize_us_symbol_for_yf(symbol)
    work_df["index_name"] = index_name
    work_df["market"] = "US"
    work_df["source"] = "local_us_yahoo_cache_2021_2025"
    return work_df[["date", "open", "high", "low", "close", "adj_close", "volume", "symbol", "index_name", "market", "source"]].dropna(subset=["date"]).reset_index(drop=True)


def download_us_history_batch(symbols: list[str], index_name: str, start_date: str, pause_seconds: float) -> dict[str, pd.DataFrame]:
    if not symbols:
        return {}
    download_df = yf.download(
        tickers=" ".join(symbols),
        start=start_date,
        interval="1d",
        auto_adjust=False,
        repair=True,
        progress=False,
        threads=False,
        group_by="ticker",
        multi_level_index=True,
    )
    time.sleep(max(0.0, pause_seconds))
    result: dict[str, pd.DataFrame] = {}
    if isinstance(download_df.columns, pd.MultiIndex):
        for symbol in symbols:
            if symbol not in download_df.columns.get_level_values(0):
                result[symbol] = pd.DataFrame()
                continue
            symbol_df = download_df[symbol].dropna(how="all").copy()
            result[symbol] = standardize_us_history(symbol_df, symbol=symbol, index_name=index_name) if not symbol_df.empty else pd.DataFrame()
        return result
    if len(symbols) == 1:
        symbol_df = download_df.dropna(how="all").copy()
        result[symbols[0]] = standardize_us_history(symbol_df, symbol=symbols[0], index_name=index_name) if not symbol_df.empty else pd.DataFrame()
        return result
    for symbol in symbols:
        result[symbol] = pd.DataFrame()
    return result


def fallback_download_us_single(symbol: str, index_name: str, start_date: str) -> pd.DataFrame:
    ticker = yf.Ticker(symbol)
    history_df = ticker.history(start=start_date, interval="1d", auto_adjust=False, repair=True)
    if history_df.empty:
        return pd.DataFrame()
    return standardize_us_history(history_df, symbol=symbol, index_name=index_name)


def infer_observed_frequency(date_series: pd.Series) -> str:
    if len(date_series) <= 2:
        return "insufficient"
    deltas = date_series.sort_values().diff().dropna().dt.days
    if deltas.empty:
        return "insufficient"
    median_gap = float(deltas.median())
    if median_gap <= 3:
        return "daily"
    if median_gap <= 10:
        return "weekly_like"
    return "irregular"


def build_quality_row(df: pd.DataFrame, symbol: str, index_name: str, market: str, failure_reason: str = "") -> dict[str, Any]:
    if df.empty:
        return {
            "index_name": index_name,
            "market": market,
            "symbol": symbol,
            "status": "failed" if failure_reason else "empty",
            "failure_reason": failure_reason,
            "row_count": 0,
            "start_date": None,
            "end_date": None,
            "observed_frequency": "missing",
            "missing_core_total": None,
            "duplicate_date_count": None,
            "non_positive_price_rows": None,
            "negative_volume_rows": None,
            "extreme_return_rows": None,
        }
    work_df = df.copy()
    work_df["date"] = pd.to_datetime(work_df["date"])
    core_missing = int(work_df[EXPECTED_CORE_COLUMNS].isna().sum().sum())
    duplicate_date_count = int(work_df.duplicated(subset=["date"]).sum())
    non_positive_price_rows = int(((work_df[["open", "high", "low", "close"]] <= 0).any(axis=1)).sum())
    negative_volume_rows = int((work_df["volume"] < 0).sum())
    daily_returns = work_df["close"].pct_change().replace([math.inf, -math.inf], pd.NA)
    extreme_return_rows = int((daily_returns.abs() > 0.30).fillna(False).sum())
    return {
        "index_name": index_name,
        "market": market,
        "symbol": symbol,
        "status": "ok",
        "failure_reason": failure_reason,
        "row_count": int(len(work_df)),
        "start_date": work_df["date"].min().strftime("%Y-%m-%d"),
        "end_date": work_df["date"].max().strftime("%Y-%m-%d"),
        "observed_frequency": infer_observed_frequency(work_df["date"]),
        "missing_core_total": core_missing,
        "duplicate_date_count": duplicate_date_count,
        "non_positive_price_rows": non_positive_price_rows,
        "negative_volume_rows": negative_volume_rows,
        "extreme_return_rows": extreme_return_rows,
    }


def save_symbol_history(df: pd.DataFrame, spec: IndexSpec, symbol: str) -> Path:
    index_dir = HISTORY_DIR / spec.key
    ensure_dir(index_dir)
    output_path = index_dir / f"{sanitize_symbol(symbol)}.csv"
    df.to_csv(output_path, index=False, encoding="utf-8-sig")
    return output_path


def download_cn_index_history(
    constituent_df: pd.DataFrame,
    spec: IndexSpec,
    start_date: str,
    end_date: str,
    max_workers: int,
) -> pd.DataFrame:
    quality_rows: list[dict[str, Any]] = []

    def worker(row: dict[str, Any]) -> tuple[dict[str, Any], pd.DataFrame]:
        symbol = str(row["symbol"])
        try:
            history_df = download_cn_history(symbol=symbol, index_name=spec.display_name, start_date=start_date, end_date=end_date)
            if not history_df.empty:
                save_symbol_history(history_df, spec=spec, symbol=symbol)
            return build_quality_row(history_df, symbol=symbol, index_name=spec.display_name, market="CN"), history_df
        except Exception as exc:  # noqa: BLE001
            return build_quality_row(pd.DataFrame(), symbol=symbol, index_name=spec.display_name, market="CN", failure_reason=str(exc)), pd.DataFrame()

    rows = constituent_df.to_dict("records")
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(worker, row) for row in rows]
        for index, future in enumerate(as_completed(futures), start=1):
            quality_row, _ = future.result()
            quality_rows.append(quality_row)
            if index % 25 == 0 or index == len(rows):
                log(f"[CN][{spec.display_name}] 下载进度 {index}/{len(rows)}")
    return pd.DataFrame(quality_rows).sort_values(["status", "symbol"]).reset_index(drop=True)


def download_us_index_history(
    constituent_df: pd.DataFrame,
    spec: IndexSpec,
    start_date: str,
    batch_size: int,
    pause_seconds: float,
) -> pd.DataFrame:
    ensure_dir(HISTORY_DIR / spec.key)
    quality_rows: list[dict[str, Any]] = []
    symbols = [normalize_us_symbol_for_yf(symbol) for symbol in constituent_df["symbol"].astype(str).tolist()]
    cached_symbols: list[str] = []
    uncached_symbols: list[str] = []
    for symbol in symbols:
        local_df = load_local_us_history(symbol=symbol, index_name=spec.display_name)
        if local_df.empty:
            uncached_symbols.append(symbol)
            continue
        save_symbol_history(local_df, spec=spec, symbol=symbol)
        quality_rows.append(build_quality_row(local_df, symbol=symbol, index_name=spec.display_name, market="US"))
        cached_symbols.append(symbol)
    if cached_symbols:
        log(f"[US][{spec.display_name}] 复用本地缓存 {len(cached_symbols)} 个股票")
    symbols = uncached_symbols
    total_batches = math.ceil(len(symbols) / batch_size)
    for batch_index, batch_symbols in enumerate(chunked(symbols, batch_size), start=1):
        log(f"[US][{spec.display_name}] 下载批次 {batch_index}/{total_batches} | symbols={len(batch_symbols)}")
        batch_payload = download_us_history_batch(symbols=batch_symbols, index_name=spec.display_name, start_date=start_date, pause_seconds=pause_seconds)
        for symbol in batch_symbols:
            history_df = batch_payload.get(symbol, pd.DataFrame())
            if history_df.empty:
                try:
                    history_df = fallback_download_us_single(symbol=symbol, index_name=spec.display_name, start_date=start_date)
                except Exception as exc:  # noqa: BLE001
                    quality_rows.append(build_quality_row(pd.DataFrame(), symbol=symbol, index_name=spec.display_name, market="US", failure_reason=str(exc)))
                    continue
            save_symbol_history(history_df, spec=spec, symbol=symbol)
            quality_rows.append(build_quality_row(history_df, symbol=symbol, index_name=spec.display_name, market="US"))
    return pd.DataFrame(quality_rows).sort_values(["status", "symbol"]).reset_index(drop=True)


def summarize_index_quality(quality_df: pd.DataFrame, spec: IndexSpec, constituent_path: Path) -> dict[str, Any]:
    ok_df = quality_df.loc[quality_df["status"] == "ok"].copy()
    summary = {
        "index_key": spec.key,
        "index_name": spec.display_name,
        "market": spec.market,
        "constituent_source": spec.constituent_source,
        "constituent_path": str(constituent_path),
        "history_dir": str(HISTORY_DIR / spec.key),
        "symbol_count": int(len(quality_df)),
        "success_count": int((quality_df["status"] == "ok").sum()),
        "failed_count": int((quality_df["status"] != "ok").sum()),
        "all_daily_frequency": bool(ok_df["observed_frequency"].eq("daily").all()) if not ok_df.empty else False,
        "min_start_date": ok_df["start_date"].min() if not ok_df.empty else None,
        "max_end_date": ok_df["end_date"].max() if not ok_df.empty else None,
        "avg_row_count": float(ok_df["row_count"].mean()) if not ok_df.empty else 0.0,
        "symbols_with_missing_core_fields": int((ok_df["missing_core_total"] > 0).sum()) if not ok_df.empty else 0,
        "symbols_with_duplicates": int((ok_df["duplicate_date_count"] > 0).sum()) if not ok_df.empty else 0,
        "symbols_with_non_positive_prices": int((ok_df["non_positive_price_rows"] > 0).sum()) if not ok_df.empty else 0,
        "symbols_with_negative_volume": int((ok_df["negative_volume_rows"] > 0).sum()) if not ok_df.empty else 0,
        "symbols_with_extreme_returns": int((ok_df["extreme_return_rows"] > 0).sum()) if not ok_df.empty else 0,
    }
    return summary


def build_markdown_report(index_summaries: list[dict[str, Any]], output_path: Path) -> None:
    lines = [
        "# 指数成分股历史行情数据质量报告",
        "",
        f"- 生成时间: `{pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}`",
        f"- 数据目录: `{DATA_ROOT}`",
        "",
        "## 1. 汇总结论",
        "",
    ]
    for summary in index_summaries:
        lines.extend(
            [
                f"### 1.{len(lines)} {summary['index_name']}",
                "",
                f"- 成分股数量: `{summary['symbol_count']}`",
                f"- 下载成功数量: `{summary['success_count']}`",
                f"- 下载失败数量: `{summary['failed_count']}`",
                f"- 是否整体识别为日频: `{summary['all_daily_frequency']}`",
                f"- 最早覆盖日期: `{summary['min_start_date']}`",
                f"- 最晚覆盖日期: `{summary['max_end_date']}`",
                f"- 平均样本行数: `{summary['avg_row_count']:.1f}`",
                f"- 存在核心字段缺失的股票数: `{summary['symbols_with_missing_core_fields']}`",
                f"- 存在重复日期的股票数: `{summary['symbols_with_duplicates']}`",
                f"- 存在非正价格的股票数: `{summary['symbols_with_non_positive_prices']}`",
                f"- 存在负成交量的股票数: `{summary['symbols_with_negative_volume']}`",
                f"- 存在大幅异常收益跳变的股票数: `{summary['symbols_with_extreme_returns']}`",
                "",
            ]
        )
    output_path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="下载指数成分股历史行情并生成数据质量报告")
    parser.add_argument("--indexes", default="hs300,csi500,nasdaq100,sp500")
    parser.add_argument("--cn-start-date", default=CN_HISTORY_START)
    parser.add_argument("--cn-end-date", default=pd.Timestamp.now().strftime("%Y%m%d"))
    parser.add_argument("--us-start-date", default=US_HISTORY_START)
    parser.add_argument("--cn-workers", type=int, default=6)
    parser.add_argument("--us-batch-size", type=int, default=20)
    parser.add_argument("--us-sleep-seconds", type=float, default=1.0)
    parser.add_argument("--limit-per-index", type=int, default=0, help="仅用于 smoke/debug；0 表示下载全部成分股")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    ensure_dir(DATA_ROOT)
    ensure_dir(CONSTITUENT_DIR)
    ensure_dir(HISTORY_DIR)
    ensure_dir(REPORT_DIR)

    index_keys = [item.strip().lower() for item in args.indexes.split(",") if item.strip()]
    all_summaries: list[dict[str, Any]] = []
    quality_frames: list[pd.DataFrame] = []

    for index_key in index_keys:
        spec = INDEX_SPECS[index_key]
        log(f"[START] 处理指数: {spec.display_name}")
        constituent_df = fetch_constituents(index_key)
        if args.limit_per_index > 0:
            constituent_df = constituent_df.head(args.limit_per_index).copy()
        constituent_path = save_constituents(constituent_df, spec=spec)
        if spec.market == "CN":
            quality_df = download_cn_index_history(
                constituent_df=constituent_df,
                spec=spec,
                start_date=args.cn_start_date,
                end_date=args.cn_end_date,
                max_workers=max(1, args.cn_workers),
            )
        else:
            quality_df = download_us_index_history(
                constituent_df=constituent_df,
                spec=spec,
                start_date=args.us_start_date,
                batch_size=max(1, args.us_batch_size),
                pause_seconds=max(0.0, args.us_sleep_seconds),
            )
        quality_path = REPORT_DIR / f"{spec.key}_quality_detail.csv"
        quality_df.to_csv(quality_path, index=False, encoding="utf-8-sig")
        summary = summarize_index_quality(quality_df=quality_df, spec=spec, constituent_path=constituent_path)
        summary["quality_detail_path"] = str(quality_path)
        summary_path = REPORT_DIR / f"{spec.key}_quality_summary.json"
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        summary["quality_summary_path"] = str(summary_path)
        all_summaries.append(summary)
        quality_frames.append(quality_df.assign(index_key=spec.key))
        log(f"[DONE] {spec.display_name} 完成 | success={summary['success_count']} | failed={summary['failed_count']}")

    all_summary_path = REPORT_DIR / "all_index_quality_summary.json"
    all_summary_path.write_text(json.dumps(all_summaries, ensure_ascii=False, indent=2), encoding="utf-8")
    if quality_frames:
        pd.concat(quality_frames, axis=0, ignore_index=True).to_csv(REPORT_DIR / "all_index_quality_detail.csv", index=False, encoding="utf-8-sig")
    build_markdown_report(index_summaries=all_summaries, output_path=REPORT_DIR / "指数成分股数据质量报告.md")
    log(f"[SUCCESS] 全部指数处理完成，汇总报告: {all_summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
