"""
文件功能:
1. 重新整理 `results/` 下的实验输出, 按“主实验 / 对比实验 / 消融实验 / 其他”分类归档。
2. 对 `phase1_transfer` 的既有预测文件重新计算回测曲线与摘要, 修复小截面下 `top_k` 覆盖全市场导致的 P&L 曲线退化问题。
3. 基于 `alpha_case` 生成“无参数优化迁移 vs 参数优化后迁移”的对比收益曲线图, 直观展示参数迁移效果。
4. 生成归档清单与图表清单, 便于后续论文写作、结果核查与 bug 排查。

代码逻辑:
1. 读取 `phase1_transfer` 的 `test_predictions.csv`, 使用修复后的轻量回测逻辑重建 `equity_curve.csv` 与 `summary.json`。
2. 扫描 `results/` 根目录下的既有结果目录, 根据预定义分类表复制到四大类别目录。
3. 对 `alpha_case` 的 `source_transfer` 与优化后方法绘制 P&L 对比图, 并同步导出对比指标表。
4. 在 `results/结果整理_v1/` 与四大类别目录下写出 manifest 文档, 保证结果可追溯。

代码结构:
1. 路径常量、目录分类映射与基础工具函数。
2. `phase1_transfer` 回测重建函数。
3. `alpha_case` 参数迁移收益曲线对比生成函数。
4. 分类复制、归档清单输出与命令行入口。
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from experiment_runner import compute_prediction_metrics, run_fast_topk_backtest


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT_DIR / "results"
PHASE1_DIR = RESULTS_DIR / "phase1_transfer"
ALPHA_CASE_DIR = RESULTS_DIR / "alpha_case"
ORGANIZED_DIR = RESULTS_DIR / "结果整理_v1"

CATEGORY_MAP: dict[str, str] = {
    "phase1_transfer": "主实验",
    "alpha_case": "主实验",
    "baseline_adapter": "对比实验",
    "official_baseline_artifacts": "对比实验",
    "baseline_run_plans": "对比实验",
    "medium_trial": "对比实验",
    "baseline_full_trial": "对比实验",
    "compare_models": "对比实验",
    "aggregated_results": "其他",
    "future_experiment_time_report.json": "其他",
    "future_hgnn_time_report.json": "其他",
}


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: dict[str, Any] | list[Any]) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def copy_item(src: Path, dst: Path) -> None:
    ensure_dir(dst.parent)
    if src.is_dir():
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)


def infer_phase1_topk() -> int:
    run_config_path = PHASE1_DIR / "run_config.json"
    if not run_config_path.exists():
        return 10
    payload = json.loads(run_config_path.read_text(encoding="utf-8"))
    return int(payload.get("top_k", 10))


def rebuild_phase1_backtests() -> dict[str, Any]:
    if not PHASE1_DIR.exists():
        return {"status": "missing", "repaired_models": 0}

    top_k = infer_phase1_topk()
    all_rows: list[dict[str, Any]] = []
    repaired_models = 0

    for direction_dir in sorted(path for path in PHASE1_DIR.iterdir() if path.is_dir()):
        direction_rows: list[dict[str, Any]] = []
        for model_dir in sorted(path for path in direction_dir.iterdir() if path.is_dir()):
            prediction_path = model_dir / "test_predictions.csv"
            if not prediction_path.exists():
                continue
            pred_df = pd.read_csv(prediction_path)
            pred_df["date"] = pd.to_datetime(pred_df["date"])
            metrics = compute_prediction_metrics(pred_df, top_k=top_k)
            curve_df, backtest_metrics = run_fast_topk_backtest(pred_df, top_k=top_k)
            summary = {**metrics, **backtest_metrics}
            curve_df.to_csv(model_dir / "equity_curve.csv", index=False, encoding="utf-8-sig")
            write_json(model_dir / "summary.json", summary)
            direction_name = direction_dir.name.replace("_to_", "->").upper()
            row = {"direction": direction_name, "model": model_dir.name, **summary}
            direction_rows.append(row)
            all_rows.append(row)
            repaired_models += 1

        if direction_rows:
            pd.DataFrame(direction_rows).to_csv(direction_dir / "summary.csv", index=False, encoding="utf-8-sig")

    if all_rows:
        pd.DataFrame(all_rows).to_csv(PHASE1_DIR / "all_summary.csv", index=False, encoding="utf-8-sig")

    payload = {
        "status": "ok",
        "requested_top_k": top_k,
        "repaired_models": repaired_models,
    }
    write_json(ORGANIZED_DIR / "phase1_backtest_repair_manifest.json", payload)
    return payload


def choose_alpha_case_optimized_method(case_dir: Path) -> str:
    preferred_order = ["continuous_adapt_mech", "continuous_adapt", "parameter_adapt_mech", "parameter_adapt"]
    for method_name in preferred_order:
        if (case_dir / method_name / "equity_curve.csv").exists():
            return method_name
    raise FileNotFoundError(f"未在 {case_dir} 中找到参数优化后的方法曲线。")


def export_alpha_case_comparison(direction: str) -> dict[str, Any]:
    case_dir = ALPHA_CASE_DIR / direction
    if not case_dir.exists():
        return {"direction": direction, "status": "missing"}

    baseline_method = "source_transfer"
    optimized_method = choose_alpha_case_optimized_method(case_dir)
    baseline_curve_path = case_dir / baseline_method / "equity_curve.csv"
    optimized_curve_path = case_dir / optimized_method / "equity_curve.csv"
    summary_path = case_dir / "alpha_case_summary.csv"
    if not baseline_curve_path.exists() or not optimized_curve_path.exists() or not summary_path.exists():
        return {"direction": direction, "status": "missing_curve_or_summary"}

    baseline_curve_df = pd.read_csv(baseline_curve_path)
    optimized_curve_df = pd.read_csv(optimized_curve_path)
    summary_df = pd.read_csv(summary_path)
    baseline_curve_df["date"] = pd.to_datetime(baseline_curve_df["date"])
    optimized_curve_df["date"] = pd.to_datetime(optimized_curve_df["date"])

    baseline_summary = summary_df.loc[summary_df["method"] == baseline_method].reset_index(drop=True)
    optimized_summary = summary_df.loc[summary_df["method"] == optimized_method].reset_index(drop=True)
    compare_rows = []
    if not baseline_summary.empty:
        compare_rows.append({"method": baseline_method, **baseline_summary.iloc[0].to_dict()})
    if not optimized_summary.empty:
        compare_rows.append({"method": optimized_method, **optimized_summary.iloc[0].to_dict()})
    compare_df = pd.DataFrame(compare_rows)

    output_dir = RESULTS_DIR / "主实验" / "图表" / "参数优化迁移P&L对比"
    ensure_dir(output_dir)
    compare_csv_path = output_dir / f"{direction}_pnl_compare_metrics.csv"
    compare_df.to_csv(compare_csv_path, index=False, encoding="utf-8-sig")

    plt.figure(figsize=(10, 6))
    plt.plot(baseline_curve_df["date"], baseline_curve_df["nav"], label="Transfer w/o Param Opt", linewidth=2.0, color="#C44E52")
    plt.plot(optimized_curve_df["date"], optimized_curve_df["nav"], label="Transfer with Param Opt", linewidth=2.2, color="#4C72B0")
    plt.title(f"P&L Comparison: {direction}")
    plt.xlabel("Date")
    plt.ylabel("NAV")
    plt.legend()
    plt.tight_layout()
    png_path = output_dir / f"{direction}_pnl_compare.png"
    svg_path = output_dir / f"{direction}_pnl_compare.svg"
    plt.savefig(png_path, dpi=180)
    plt.savefig(svg_path)
    plt.close()

    payload = {
        "direction": direction,
        "status": "ok",
        "baseline_method": baseline_method,
        "optimized_method": optimized_method,
        "metrics_csv": str(compare_csv_path),
        "png_path": str(png_path),
        "svg_path": str(svg_path),
    }
    write_json(output_dir / f"{direction}_pnl_compare_manifest.json", payload)
    return payload


def export_phase1_curve_overview() -> dict[str, Any]:
    output_dir = RESULTS_DIR / "主实验" / "图表" / "phase1收益曲线"
    ensure_dir(output_dir)
    manifests: list[dict[str, str]] = []
    for direction in ["cn_to_us", "us_to_cn"]:
        direction_dir = PHASE1_DIR / direction
        if not direction_dir.exists():
            continue
        plt.figure(figsize=(10, 6))
        plotted = 0
        for model_name, color in [("main_transfer", "#4C72B0"), ("lasso", "#55A868"), ("xgboost", "#C44E52")]:
            curve_path = direction_dir / model_name / "equity_curve.csv"
            if not curve_path.exists():
                continue
            curve_df = pd.read_csv(curve_path)
            if curve_df.empty:
                continue
            curve_df["date"] = pd.to_datetime(curve_df["date"])
            plt.plot(curve_df["date"], curve_df["nav"], label=model_name, linewidth=2.0, color=color)
            plotted += 1
        if plotted == 0:
            plt.close()
            continue
        plt.title(f"Phase1 P&L: {direction}")
        plt.xlabel("Date")
        plt.ylabel("NAV")
        plt.legend()
        plt.tight_layout()
        png_path = output_dir / f"{direction}_phase1_overview.png"
        svg_path = output_dir / f"{direction}_phase1_overview.svg"
        plt.savefig(png_path, dpi=180)
        plt.savefig(svg_path)
        plt.close()
        manifests.append({"direction": direction, "png_path": str(png_path), "svg_path": str(svg_path)})
    write_json(output_dir / "phase1_curve_manifest.json", manifests)
    return {"status": "ok", "count": len(manifests)}


def classify_existing_results() -> dict[str, Any]:
    ensure_dir(ORGANIZED_DIR)
    manifest_rows: list[dict[str, str]] = []
    category_dirs = {"主实验", "对比实验", "消融实验", "其他", ORGANIZED_DIR.name}
    for item in sorted(RESULTS_DIR.iterdir()):
        if item.name in category_dirs:
            continue
        category = CATEGORY_MAP.get(item.name, "其他")
        destination = RESULTS_DIR / category / item.name
        copy_item(item, destination)
        manifest_rows.append(
            {
                "item": item.name,
                "category": category,
                "source_path": str(item),
                "destination_path": str(destination),
            }
        )
    manifest_df = pd.DataFrame(manifest_rows)
    manifest_df.to_csv(ORGANIZED_DIR / "results_category_manifest.csv", index=False, encoding="utf-8-sig")
    return {"status": "ok", "item_count": len(manifest_rows)}


def write_overview(repair_payload: dict[str, Any], alpha_payloads: list[dict[str, Any]], category_payload: dict[str, Any]) -> None:
    overview_path = ORGANIZED_DIR / "results_整理说明.md"
    lines = [
        "# results 整理说明",
        "",
        "## 1. 本次处理内容",
        "",
        f"- `phase1_transfer` 回测重建状态: `{repair_payload.get('status')}`",
        f"- `phase1_transfer` 修复模型数: `{repair_payload.get('repaired_models')}`",
        f"- 分类归档条目数: `{category_payload.get('item_count')}`",
        "",
        "## 2. 分类目录",
        "",
        "- `results/主实验`",
        "- `results/对比实验`",
        "- `results/消融实验`",
        "- `results/其他`",
        "",
        "## 3. 参数优化 P&L 对比",
        "",
    ]
    for payload in alpha_payloads:
        lines.append(
            f"- `{payload.get('direction')}`: 基线=`{payload.get('baseline_method')}`，优化后=`{payload.get('optimized_method')}`，图=`{payload.get('png_path')}`"
        )
    lines.extend(
        [
            "",
            "## 4. 说明",
            "",
            "- `CN->US` 曲线一致问题已按修复后的回测逻辑重建；当日截面过小时会自动保留至少一个未持有标的，避免退化为“全市场全买”。",
            "- `future` 阶段的缓存兼容修复属于程序级修复，本说明仅记录结果整理输出。",
        ]
    )
    overview_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    ensure_dir(ORGANIZED_DIR)
    repair_payload = rebuild_phase1_backtests()
    alpha_payloads = [export_alpha_case_comparison("cn_to_us"), export_alpha_case_comparison("us_to_cn")]
    export_phase1_curve_overview()
    category_payload = classify_existing_results()
    write_overview(repair_payload, alpha_payloads, category_payload)
    print(
        json.dumps(
            {
                "repair_payload": repair_payload,
                "alpha_payloads": alpha_payloads,
                "category_payload": category_payload,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
