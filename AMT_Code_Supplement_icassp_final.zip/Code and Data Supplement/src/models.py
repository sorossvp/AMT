"""
文件功能:
1. 提供第一阶段实验所需的可运行模型实现, 包括 `Lasso`、`XGBoost`、`LSTM`、
   `Transformer`、`TRA-like`、`HIST-like` 以及主模型
   `MechanismPreservingHypergraphTransferModel`。
2. 统一封装传统机器学习模型和 PyTorch 模型的训练/预测接口, 降低实验脚本复杂度。
3. 将静态超图、市场状态和公式 alpha 特征一起纳入主模型, 体现
   “时序编码 -> 超图关系 -> 因子机理 -> 基础打分模块 -> 参数高效迁移” 的主线。

代码逻辑:
1. 传统模型直接对表格特征做回归学习, 作为无迁移基线。
2. 神经模型对时间窗口序列编码后输出未来收益得分, 对应 LSTM/Transformer/TRA-like。
3. HIST-like 模型在时间编码之外拼接静态超图概念向量, 作为关系增强预测基线。
4. 主模型先在源市场预训练共享机理表示, 再在目标市场冻结主干并训练小规模适配器。
5. 训练过程中使用验证集早停, 输出统一的 `predict()` 接口。

代码结构:
1. 公共训练辅助函数。
2. 传统模型封装。
3. 神经网络模型定义。
4. 主模型迁移适配定义。
5. 统一构建器与训练入口。
"""

from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from typing import Any, Callable

import numpy as np
import pandas as pd
import torch
from sklearn.linear_model import Lasso
from torch import nn
from torch.utils.data import DataLoader, Dataset
from xgboost import XGBRegressor


ALPHA_FEATURES = [
    "alpha_momentum",
    "alpha_reversal",
    "alpha_volume_price",
    "alpha_breakout",
    "alpha_liquidity",
    "alpha_intraday",
]


def to_device(batch: tuple[torch.Tensor, ...], device: torch.device) -> tuple[torch.Tensor, ...]:
    return tuple(item.to(device) for item in batch)


def ndarray_to_tensor(array: np.ndarray, dtype: torch.dtype = torch.float32) -> torch.Tensor:
    return torch.as_tensor(array, dtype=dtype)


def maybe_wrap_data_parallel(model: nn.Module, device: str) -> nn.Module:
    """
    在可用时自动启用 DataParallel。

    说明:
    1. 当前主实验中的 LSTM/Transformer/HIST/MFHN 都是标准 batch-first 张量，
       适合用 `nn.DataParallel` 在多卡上按 batch 维拆分。
    2. 这里采用“自动探测、多卡即启用”的策略，避免服务器脚本再维护一套复杂的分布式启动命令。
    """
    if not device.startswith("cuda"):
        return model
    if not torch.cuda.is_available():
        return model
    if torch.cuda.device_count() <= 1:
        return model
    if isinstance(model, nn.DataParallel):
        return model
    return nn.DataParallel(model)


def masked_mse_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    mask = torch.isfinite(target)
    if mask.sum() == 0:
        return (pred * 0.0).sum()
    return ((pred[mask] - target[mask]) ** 2).mean()


def unwrap_model(model: nn.Module) -> nn.Module:
    """兼容 DataParallel，统一拿到真正的底层模型对象。"""
    if isinstance(model, nn.DataParallel):
        return model.module
    return model


def extract_prediction_tensor(pred: torch.Tensor | tuple[torch.Tensor, ...] | list[torch.Tensor]) -> torch.Tensor:
    """
    统一抽取可用于监督损失的主预测张量。

    说明:
    1. 普通基线模型直接返回 `Tensor`。
    2. 主模型 `MechanismPreservingHypergraphTransferModel` 返回 `(score, factor_repr)`，
       其中第一个元素才是回归目标对应的预测分数。
    """
    if isinstance(pred, (tuple, list)):
        if not pred:
            raise ValueError("模型返回了空的 tuple/list，无法提取预测张量")
        return pred[0]
    return pred


@dataclass
class TorchTrainingConfig:
    n_epochs: int = 12
    batch_size: int = 4096
    lr: float = 1e-3
    weight_decay: float = 1e-5
    early_stop_rounds: int = 3


@dataclass(frozen=True)
class SupervisedLossConfig:
    """
    监督损失配置。

    说明:
    1. `mse` 保留给旧基线与回归式训练入口。
    2. `rank_return` 用“排序正确性 + 年化收益代理”作为主导项，只保留极小的 MSE 稳定项。
    """

    objective: str = "mse"
    rank_weight: float = 1.0
    return_weight: float = 2.0
    mse_weight: float = 0.05
    pairwise_label_threshold: float = 1e-4
    return_temperature: float = 0.35
    annualization_factor: float = 252.0


@dataclass(frozen=True)
class AMTScoringConfig:
    """
    AMT 打分模块的稳定性配置。

    说明:
    1. `gate_temperature` 控制 Top-r 门控前的 softmax 平滑程度，避免注意力过早塌缩到单一 alpha 块。
    2. `alpha_residual_scale` 控制目标域增量相对源域权重的注入幅度，把目标域更新限制在“校准”而非“重写”。
    3. `delta_clip` 用于约束适配器输出的单样本增量幅度，降低极端权重更新对净值曲线的破坏。
    """

    hidden_dim: int = 64
    top_r: int = 3
    gate_temperature: float = 0.70
    alpha_residual_scale: float = 0.35
    delta_clip: float = 0.75
    min_gate_mass: float = 1e-6


DEFAULT_AMT_SCORING_CONFIG = AMTScoringConfig()


class SequencePanelDataset(Dataset):
    """
    将实验脚本构造好的 numpy 数据封装为统一数据集。
    """

    def __init__(
        self,
        sequence_x: np.ndarray,
        tabular_x: np.ndarray,
        concept_x: np.ndarray,
        regime_x: np.ndarray,
        alpha_x: np.ndarray,
        y: np.ndarray,
        date_group: np.ndarray | None = None,
    ) -> None:
        self.sequence_x = sequence_x.astype(np.float32)
        self.tabular_x = tabular_x.astype(np.float32)
        self.concept_x = concept_x.astype(np.float32)
        self.regime_x = regime_x.astype(np.int64)
        self.alpha_x = alpha_x.astype(np.float32)
        self.y = y.astype(np.float32)
        if date_group is None:
            self.date_group = np.arange(self.y.shape[0], dtype=np.int64)
        else:
            self.date_group = date_group.astype(np.int64)

    def __len__(self) -> int:
        return int(self.y.shape[0])

    def __getitem__(self, index: int) -> tuple[torch.Tensor, ...]:
        return (
            ndarray_to_tensor(self.sequence_x[index]),
            ndarray_to_tensor(self.tabular_x[index]),
            ndarray_to_tensor(self.concept_x[index]),
            ndarray_to_tensor(np.array(self.regime_x[index]), dtype=torch.int64),
            ndarray_to_tensor(self.alpha_x[index]),
            ndarray_to_tensor(np.array(self.y[index])),
            ndarray_to_tensor(np.array(self.date_group[index]), dtype=torch.int64),
        )


def build_loader(dataset: SequencePanelDataset, batch_size: int, shuffle: bool) -> DataLoader:
    import os
    num_workers = min(8, os.cpu_count() or 4)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, drop_last=False, num_workers=num_workers, pin_memory=True)


MODEL_INPUT_COUNT = 5
TARGET_INDEX = 5
DATE_GROUP_INDEX = 6


def extract_model_inputs(batch: tuple[torch.Tensor, ...]) -> tuple[torch.Tensor, ...]:
    return batch[:MODEL_INPUT_COUNT]


def extract_target_tensor(batch: tuple[torch.Tensor, ...]) -> torch.Tensor:
    return batch[TARGET_INDEX]


def extract_date_group_tensor(batch: tuple[torch.Tensor, ...]) -> torch.Tensor:
    if len(batch) <= DATE_GROUP_INDEX:
        return torch.arange(batch[0].shape[0], device=batch[0].device, dtype=torch.int64)
    return batch[DATE_GROUP_INDEX]


def daily_pairwise_rank_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    date_group: torch.Tensor,
    label_threshold: float = 1e-4,
) -> torch.Tensor:
    mask = torch.isfinite(pred) & torch.isfinite(target)
    if int(mask.sum().item()) < 2:
        return (pred * 0.0).sum()
    pred = pred[mask]
    target = target[mask]
    date_group = date_group[mask]
    group_losses: list[torch.Tensor] = []
    for group_id in torch.unique(date_group):
        group_mask = date_group == group_id
        if int(group_mask.sum().item()) < 2:
            continue
        group_pred = pred[group_mask]
        group_target = target[group_mask]
        target_diff = group_target.unsqueeze(1) - group_target.unsqueeze(0)
        valid_pairs = target_diff > float(label_threshold)
        if not bool(valid_pairs.any().item()):
            continue
        pred_diff = group_pred.unsqueeze(1) - group_pred.unsqueeze(0)
        group_losses.append(torch.nn.functional.softplus(-pred_diff[valid_pairs]).mean())
    if not group_losses:
        return (pred * 0.0).sum()
    return torch.stack(group_losses).mean()


def daily_annualized_return_surrogate_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    date_group: torch.Tensor,
    temperature: float = 0.35,
    annualization_factor: float = 252.0,
) -> torch.Tensor:
    mask = torch.isfinite(pred) & torch.isfinite(target)
    if int(mask.sum().item()) == 0:
        return (pred * 0.0).sum()
    pred = pred[mask]
    target = target[mask]
    date_group = date_group[mask]
    group_losses: list[torch.Tensor] = []
    effective_temperature = max(float(temperature), 1e-6)
    for group_id in torch.unique(date_group):
        group_mask = date_group == group_id
        if int(group_mask.sum().item()) == 0:
            continue
        group_pred = pred[group_mask]
        group_target = target[group_mask]
        weights = torch.softmax(group_pred / effective_temperature, dim=0)
        portfolio_return = torch.sum(weights * group_target)
        growth_proxy = torch.log1p(torch.clamp(portfolio_return, min=-0.95))
        group_losses.append(-growth_proxy * float(annualization_factor))
    if not group_losses:
        return (pred * 0.0).sum()
    return torch.stack(group_losses).mean()


def compute_supervised_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    date_group: torch.Tensor,
    config: SupervisedLossConfig | None = None,
) -> torch.Tensor:
    if config is None or str(config.objective).lower() == "mse":
        return masked_mse_loss(pred, target)
    normalized_objective = str(config.objective).lower()
    if normalized_objective != "rank_return":
        raise ValueError(f"未知监督损失类型: {config.objective}")
    rank_loss = daily_pairwise_rank_loss(
        pred,
        target,
        date_group,
        label_threshold=float(config.pairwise_label_threshold),
    )
    return_loss = daily_annualized_return_surrogate_loss(
        pred,
        target,
        date_group,
        temperature=float(config.return_temperature),
        annualization_factor=float(config.annualization_factor),
    )
    mse_loss = masked_mse_loss(pred, target)
    return (
        float(config.rank_weight) * rank_loss
        + float(config.return_weight) * return_loss
        + float(config.mse_weight) * mse_loss
    )


def fit_torch_regressor(
    model: nn.Module,
    train_dataset: SequencePanelDataset,
    valid_dataset: SequencePanelDataset,
    config: TorchTrainingConfig,
    supervised_loss_config: SupervisedLossConfig | None = None,
    extra_loss_fn: Callable[[nn.Module, tuple[torch.Tensor, ...], torch.Tensor], torch.Tensor] | None = None,
    optimizer_group_builder: Callable[[nn.Module, TorchTrainingConfig], list[dict[str, Any]]] | None = None,
    device: str = "cpu",
    checkpoint_path: str | None = None,
) -> nn.Module:
    torch_device = torch.device(device)
    model = model.to(torch_device)
    model = maybe_wrap_data_parallel(model, device=device)
    train_loader = build_loader(train_dataset, batch_size=config.batch_size, shuffle=True)
    valid_loader = build_loader(valid_dataset, batch_size=config.batch_size, shuffle=False)
    optimizer_params: list[dict[str, Any]] | Any
    if optimizer_group_builder is None:
        optimizer_params = model.parameters()
    else:
        optimizer_params = optimizer_group_builder(unwrap_model(model), config)
    optimizer = torch.optim.AdamW(optimizer_params, lr=config.lr, weight_decay=config.weight_decay)

    best_state = copy.deepcopy(model.state_dict())
    best_valid = float("inf")
    patience = 0
    start_epoch = 0
    logged_first_batch = False
    
    import os
    import logging
    import signal

    manual_save_requested = False
    def handle_sigusr1(signum, frame):
        nonlocal manual_save_requested
        logging.info("收到手动保存检查点信号 (SIGUSR1)！")
        manual_save_requested = True

    try:
        signal.signal(signal.SIGUSR1, handle_sigusr1)
    except Exception:
        pass

    if checkpoint_path and os.path.exists(checkpoint_path):
        try:
            # 完整性校验：不仅能 load，还要检查关键 key 是否都在
            checkpoint = torch.load(checkpoint_path, map_location=torch_device)
            required_keys = ['epoch', 'model_state', 'optimizer_state', 'best_state', 'best_valid', 'patience']
            if not all(k in checkpoint for k in required_keys):
                raise ValueError("检查点文件不完整，缺少关键状态字段。")
            model.load_state_dict(checkpoint['model_state'])
            optimizer.load_state_dict(checkpoint['optimizer_state'])
            best_state = checkpoint['best_state']
            best_valid = checkpoint['best_valid']
            patience = checkpoint['patience']
            start_epoch = checkpoint['epoch'] + 1
            logging.info(f"✅ 成功从 {checkpoint_path} 恢复训练，从第 {start_epoch} 轮继续。")
        except Exception as e:
            logging.warning(f"⚠️ 检查点加载失败: {e}，将从头开始训练。")

    for epoch in range(start_epoch, config.n_epochs):
        model.train()
        for batch in train_loader:
            batch = to_device(batch, torch_device)
            if not logged_first_batch and hasattr(unwrap_model(model), "concept_encoder"):
                logged_first_batch = True
            optimizer.zero_grad()
            raw_pred = model(*extract_model_inputs(batch))
            pred = extract_prediction_tensor(raw_pred)
            loss = compute_supervised_loss(
                pred.squeeze(-1),
                extract_target_tensor(batch).squeeze(-1),
                extract_date_group_tensor(batch),
                supervised_loss_config,
            )
            if extra_loss_fn is not None:
                # extra_loss_fn 用于把“迁移约束 / 机理保持约束”附加到通用训练循环，
                # 这样普通基线和主模型都能复用同一套训练入口。
                loss = loss + extra_loss_fn(unwrap_model(model), batch, raw_pred)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

        model.eval()
        valid_losses: list[float] = []
        with torch.no_grad():
            for batch in valid_loader:
                batch = to_device(batch, torch_device)
                raw_pred = model(*extract_model_inputs(batch))
                pred = extract_prediction_tensor(raw_pred)
                loss = compute_supervised_loss(
                    pred.squeeze(-1),
                    extract_target_tensor(batch).squeeze(-1),
                    extract_date_group_tensor(batch),
                    supervised_loss_config,
                )
                if extra_loss_fn is not None:
                    loss = loss + extra_loss_fn(unwrap_model(model), batch, raw_pred)
                valid_losses.append(float(loss.item()))
        valid_loss = float(np.mean(valid_losses)) if valid_losses else float("inf")

        if valid_loss + 1e-8 < best_valid:
            best_valid = valid_loss
            best_state = copy.deepcopy(model.state_dict())
            patience = 0
        else:
            patience += 1
            
        if checkpoint_path or manual_save_requested:
            try:
                save_path = checkpoint_path if checkpoint_path else "manual_checkpoint.pt"
                os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
                # 先保存到临时文件，再原子替换，避免保存过程中断导致损坏
                temp_path = save_path + ".tmp"
                torch.save({
                    'epoch': epoch,
                    'model_state': model.state_dict(),
                    'optimizer_state': optimizer.state_dict(),
                    'best_state': best_state,
                    'best_valid': best_valid,
                    'patience': patience,
                    'valid_loss': valid_loss
                }, temp_path)
                os.replace(temp_path, save_path)
                manual_save_requested = False
                logging.info(f"✅ 成功保存检查点至 {save_path}")
            except Exception as e:
                logging.warning(f"⚠️ 保存检查点失败: {e}")
                
        if patience >= config.early_stop_rounds:
            break

    model.load_state_dict(best_state)
    return model


def predict_torch_regressor(model: nn.Module, dataset: SequencePanelDataset, batch_size: int = 1024, device: str = "cpu") -> np.ndarray:
    torch_device = torch.device(device)
    model = model.to(torch_device)
    model = maybe_wrap_data_parallel(model, device=device)
    loader = build_loader(dataset, batch_size=batch_size, shuffle=False)
    preds: list[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for batch in loader:
            batch = to_device(batch, torch_device)
            raw_pred = model(*extract_model_inputs(batch))
            pred = extract_prediction_tensor(raw_pred).squeeze(-1).detach().cpu().numpy()
            preds.append(pred)
    return np.concatenate(preds, axis=0) if preds else np.empty(shape=(0,), dtype=np.float32)


class LassoWrapper:
    def __init__(self, alpha: float = 0.0005) -> None:
        self.model = Lasso(alpha=alpha, max_iter=3000)

    def fit(self, x_train: np.ndarray, y_train: np.ndarray) -> "LassoWrapper":
        self.model.fit(x_train, y_train)
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        return self.model.predict(x)


class XGBoostWrapper:
    def __init__(self, device: str = "cpu") -> None:
        booster_device = "cuda" if str(device).startswith("cuda") else "cpu"
        self.model = XGBRegressor(
            n_estimators=220,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.85,
            colsample_bytree=0.85,
            objective="reg:squarederror",
            random_state=42,
            n_jobs=4,
            tree_method="hist",
            device=booster_device,
        )

    def fit(self, x_train: np.ndarray, y_train: np.ndarray, x_valid: np.ndarray, y_valid: np.ndarray) -> "XGBoostWrapper":
        self.model.fit(
            x_train,
            y_train,
            eval_set=[(x_valid, y_valid)],
            verbose=False,
        )
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        return self.model.predict(x)


class LSTMRanker(nn.Module):
    def __init__(self, seq_dim: int, tab_dim: int, hidden_dim: int = 48) -> None:
        super().__init__()
        self.seq_encoder = nn.LSTM(input_size=seq_dim, hidden_size=hidden_dim, batch_first=True)
        self.tab_encoder = nn.Sequential(nn.Linear(tab_dim, hidden_dim), nn.ReLU(), nn.LayerNorm(hidden_dim))
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        concept_x: torch.Tensor,
        regime_x: torch.Tensor,
        alpha_x: torch.Tensor,
    ) -> torch.Tensor:
        _, (hidden, _) = self.seq_encoder(sequence_x)
        seq_repr = hidden[-1]
        tab_repr = self.tab_encoder(tabular_x)
        return self.head(torch.cat([seq_repr, tab_repr], dim=-1))


class TransformerRanker(nn.Module):
    def __init__(self, seq_dim: int, tab_dim: int, hidden_dim: int = 48, n_heads: int = 4) -> None:
        super().__init__()
        self.input_proj = nn.Linear(seq_dim, hidden_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=n_heads,
            dim_feedforward=hidden_dim * 2,
            dropout=0.1,
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=2)
        self.tab_encoder = nn.Sequential(nn.Linear(tab_dim, hidden_dim), nn.ReLU(), nn.LayerNorm(hidden_dim))
        self.head = nn.Sequential(nn.Linear(hidden_dim * 2, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1))

    def forward(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        concept_x: torch.Tensor,
        regime_x: torch.Tensor,
        alpha_x: torch.Tensor,
    ) -> torch.Tensor:
        hidden = self.encoder(self.input_proj(sequence_x))
        seq_repr = hidden[:, -1, :]
        tab_repr = self.tab_encoder(tabular_x)
        return self.head(torch.cat([seq_repr, tab_repr], dim=-1))


class TRALikeRanker(nn.Module):
    """
    该实现保留 TRA 的核心思想: 用时间编码器 + 路由门控选择更合适的专家头。
    """

    def __init__(self, seq_dim: int, tab_dim: int, hidden_dim: int = 48, n_experts: int = 3) -> None:
        super().__init__()
        self.seq_encoder = nn.GRU(input_size=seq_dim, hidden_size=hidden_dim, batch_first=True)
        self.context_proj = nn.Sequential(
            nn.Linear(tab_dim, hidden_dim),
            nn.ReLU(),
            nn.LayerNorm(hidden_dim),
        )
        self.experts = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(hidden_dim * 2, hidden_dim),
                    nn.ReLU(),
                    nn.Linear(hidden_dim, 1),
                )
                for _ in range(n_experts)
            ]
        )
        self.router = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, n_experts),
        )

    def forward(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        concept_x: torch.Tensor,
        regime_x: torch.Tensor,
        alpha_x: torch.Tensor,
    ) -> torch.Tensor:
        _, hidden = self.seq_encoder(sequence_x)
        seq_repr = hidden[-1]
        tab_repr = self.context_proj(tabular_x)
        fused = torch.cat([seq_repr, tab_repr], dim=-1)
        # router 输出的是“当前样本更适合由哪个专家头负责”的概率分布。
        gate = torch.softmax(self.router(fused), dim=-1)
        expert_outputs = torch.cat([expert(fused) for expert in self.experts], dim=-1)
        return (gate * expert_outputs).sum(dim=-1, keepdim=True)


class HISTLikeRanker(nn.Module):
    """
    HIST-like 的核心在于概念/关系增强。这里用静态超图概念向量替代原论文中的股票概念矩阵。
    """

    def __init__(self, seq_dim: int, tab_dim: int, concept_dim: int, hidden_dim: int = 48) -> None:
        super().__init__()
        self.seq_encoder = nn.LSTM(input_size=seq_dim, hidden_size=hidden_dim, batch_first=True)
        self.tab_encoder = nn.Sequential(nn.Linear(tab_dim, hidden_dim), nn.ReLU())
        self.concept_encoder = nn.Sequential(
            nn.Linear(concept_dim, hidden_dim),
            nn.ReLU(),
            nn.LayerNorm(hidden_dim),
        )
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        concept_x: torch.Tensor,
        regime_x: torch.Tensor,
        alpha_x: torch.Tensor,
    ) -> torch.Tensor:
        _, (hidden, _) = self.seq_encoder(sequence_x)
        seq_repr = hidden[-1]
        tab_repr = self.tab_encoder(tabular_x)
        concept_repr = self.concept_encoder(concept_x)
        return self.head(torch.cat([seq_repr, tab_repr, concept_repr], dim=-1))


class MechanismPreservingHypergraphTransferModel(nn.Module):
    """
    主模型:
    1. 使用 LSTM 对个股时序序列编码。
    2. 使用静态超图概念向量做关系增强。
    3. 用因子机理投影层提取公式 alpha 的金融语义。
    4. 用注意力门控决定目标域中哪些 alpha 参数块最值得更新。
    5. 通过小规模适配器生成参数增量, 体现参数高效迁移。
    """

    def __init__(
        self,
        seq_dim: int,
        tab_dim: int,
        concept_dim: int,
        alpha_dim: int,
        hidden_dim: int = 64,
        top_r: int = 3,
        scoring_config: AMTScoringConfig | None = None,
    ) -> None:
        super().__init__()
        self.scoring_config = scoring_config or AMTScoringConfig(hidden_dim=hidden_dim, top_r=top_r)
        self.top_r = int(self.scoring_config.top_r)
        # 共享主干: 负责学习源域和目标域都应保留的共性表示。
        self.seq_encoder = nn.LSTM(input_size=seq_dim, hidden_size=hidden_dim, batch_first=True)
        self.tab_encoder = nn.Sequential(nn.Linear(tab_dim, hidden_dim), nn.ReLU(), nn.LayerNorm(hidden_dim))
        self.concept_encoder = nn.Sequential(nn.Linear(concept_dim, hidden_dim), nn.ReLU(), nn.LayerNorm(hidden_dim))
        self.alpha_input_norm = nn.LayerNorm(alpha_dim)
        self.factor_projector = nn.Sequential(
            nn.Linear(alpha_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.regime_embedding = nn.Embedding(num_embeddings=4, embedding_dim=hidden_dim)
        # 基础打分模块: 将共享表示映射为源域 alpha 打分。
        # 它与时序编码器、关系编码器和因子投影层共同构成源域策略主干，
        # 因此在标准目标域适配阶段默认被冻结。
        self.base_head = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        # source_alpha_weight 表示源域学到的“alpha 因子线性重要性”，
        # 目标域阶段只在其附近做小幅偏移，而不是完全重学。
        self.source_alpha_weight = nn.Parameter(torch.zeros(alpha_dim))
        # 注意力门控 + 小适配器共同构成参数高效迁移模块。
        self.att_query = nn.Parameter(torch.randn(alpha_dim, hidden_dim) * 0.02)
        self.att_key = nn.Linear(hidden_dim * 4, hidden_dim)
        self.adapter = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, alpha_dim),
        )
        self.target_mode = False
        self.cached_source_weight: torch.Tensor | None = None

    def configure_target_adaptation(
        self,
        freeze_backbone: bool = True,
        freeze_factor_projector: bool = True,
        freeze_base_scoring_module: bool = True,
        unfreeze_base_scoring_last_layer: bool = False,
        freeze_source_alpha_weight: bool = True,
    ) -> None:
        import copy
        self.target_mode = True
        self.cached_source_weight = self.source_alpha_weight.detach().clone()
        
        # Save a frozen copy of the backbone for topology penalty
        self.frozen_seq_encoder = copy.deepcopy(self.seq_encoder)
        self.frozen_tab_encoder = copy.deepcopy(self.tab_encoder)
        self.frozen_concept_encoder = copy.deepcopy(self.concept_encoder)
        for module in [self.frozen_seq_encoder, self.frozen_tab_encoder, self.frozen_concept_encoder]:
            for param in module.parameters():
                param.requires_grad = False
                
        # 先显式放开全部参数，再按当前消融/正式配置逐项冻结，
        # 便于在同一实现里复用“标准 AMT / 无结构冻结 / 解冻基础打分模块最后一层”等变体。
        for param in self.parameters():
            param.requires_grad = True
        if freeze_backbone:
            for module in [self.seq_encoder, self.tab_encoder, self.concept_encoder]:
                for param in module.parameters():
                    param.requires_grad = False
        if freeze_factor_projector:
            for module in [self.alpha_input_norm, self.factor_projector]:
                for param in module.parameters():
                    param.requires_grad = False
        if freeze_base_scoring_module:
            for param in self.base_head.parameters():
                param.requires_grad = False
        if unfreeze_base_scoring_last_layer:
            last_layer = self.base_head[-1]
            if hasattr(last_layer, "parameters"):
                for param in last_layer.parameters():
                    param.requires_grad = True
        if freeze_source_alpha_weight:
            self.source_alpha_weight.requires_grad = False

    def switch_to_target_adaptation(self) -> None:
        # 标准 AMT: 冻结共享主干、因子投影层和基础打分模块，仅开放局部门控与适配器。
        self.configure_target_adaptation()

    def _build_context(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        concept_x: torch.Tensor,
        regime_x: torch.Tensor,
        alpha_x: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        _, (hidden, _) = self.seq_encoder(sequence_x)
        seq_repr = hidden[-1]
        tab_repr = self.tab_encoder(tabular_x)
        concept_repr = self.concept_encoder(concept_x)
        factor_repr = self.factor_projector(alpha_x)
        regime_repr = self.regime_embedding(regime_x)
        # common_repr 服务于基础打分模块；
        # context 服务于“当前状态下应该调整哪些 alpha 参数”的迁移决策。
        common_repr = torch.cat([seq_repr, tab_repr, concept_repr], dim=-1)
        context = torch.cat([seq_repr, concept_repr, factor_repr, regime_repr], dim=-1)
        return common_repr, factor_repr, context

    def _normalize_alpha_input(self, alpha_x: torch.Tensor) -> torch.Tensor:
        return self.alpha_input_norm(alpha_x)

    def _get_source_weight(self, device: torch.device | str) -> torch.Tensor:
        if self.cached_source_weight is not None:
            return self.cached_source_weight.to(device)
        return self.source_alpha_weight.detach().to(device)

    def _compute_sparse_gate(self, context: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        att_key = self.att_key(context)
        raw_scores = (self.att_query.unsqueeze(0) * att_key.unsqueeze(1)).sum(dim=-1) / math.sqrt(att_key.shape[-1])
        raw_scores = raw_scores / max(float(self.scoring_config.gate_temperature), 1e-6)
        gate = torch.softmax(raw_scores, dim=-1)
        effective_top_r = max(1, min(self.top_r, int(gate.shape[-1])))
        _, top_k_indices = torch.topk(gate, k=effective_top_r, dim=-1)
        mask = torch.zeros_like(gate).scatter_(-1, top_k_indices, 1.0)
        sparse_gate = gate * mask
        sparse_gate = sparse_gate / sparse_gate.sum(dim=-1, keepdim=True).clamp_min(float(self.scoring_config.min_gate_mass))
        return att_key, gate, sparse_gate

    def _compose_target_alpha_weight(self, alpha_x: torch.Tensor, context: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        _att_key, _gate, sparse_gate = self._compute_sparse_gate(context)
        delta_w = torch.tanh(self.adapter(context)) * float(self.scoring_config.delta_clip)
        active_delta = delta_w * sparse_gate
        source_weight = self._get_source_weight(alpha_x.device)
        target_alpha_weight = source_weight.unsqueeze(0) + float(self.scoring_config.alpha_residual_scale) * active_delta
        return target_alpha_weight, sparse_gate, active_delta

    def encode_similarity_representation(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        concept_x: torch.Tensor,
        regime_x: torch.Tensor,
        alpha_x: torch.Tensor,
    ) -> torch.Tensor:
        """
        导出用于市场相似度估计的样本级表征。

        说明:
        1. 这里拼接共享表示、因子表示、迁移上下文以及源域 alpha 暴露，
           让相似度模块同时感知“市场输入分布”和“源域机理在当前样本上的投影方式”。
        2. 该接口只做前向表征导出, 不改变训练路径, 便于在外部独立模块中复用。
        """
        common_repr, factor_repr, context = self._build_context(sequence_x, tabular_x, concept_x, regime_x, alpha_x)
        normalized_alpha_x = self._normalize_alpha_input(alpha_x)
        source_weight = self._get_source_weight(alpha_x.device)
        alpha_exposure = normalized_alpha_x * source_weight.unsqueeze(0)
        return torch.cat([common_repr, factor_repr, context, alpha_exposure], dim=-1)

    def forward(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        concept_x: torch.Tensor,
        regime_x: torch.Tensor,
        alpha_x: torch.Tensor,
    ) -> torch.Tensor:
        common_repr, factor_repr, context = self._build_context(sequence_x, tabular_x, concept_x, regime_x, alpha_x)
        base_score = self.base_head(common_repr).squeeze(-1)
        normalized_alpha_x = self._normalize_alpha_input(alpha_x)
        if not self.target_mode:
            # 源域预训练阶段直接学习一个稳定的 alpha 权重基准。
            alpha_score = (normalized_alpha_x * self.source_alpha_weight.unsqueeze(0)).sum(dim=-1)
            return (base_score + alpha_score).unsqueeze(-1), factor_repr

        target_alpha_weight, _sparse_gate, _active_delta = self._compose_target_alpha_weight(alpha_x, context)
        alpha_score = (normalized_alpha_x * target_alpha_weight).sum(dim=-1)
        return (base_score + alpha_score).unsqueeze(-1), factor_repr

    def extra_transfer_loss(self, alpha_x: torch.Tensor, tabular_x: torch.Tensor, sequence_x: torch.Tensor, concept_x: torch.Tensor, regime_x: torch.Tensor, weight_param: float = 0.01, weight_mech: float = 0.01, weight_topo: float = 0.0) -> torch.Tensor:
        if not self.target_mode:
            return torch.tensor(0.0, device=alpha_x.device)
        common_repr, factor_repr, context = self._build_context(sequence_x, tabular_x, concept_x, regime_x, alpha_x)
        target_alpha_weight, _sparse_gate, active_delta = self._compose_target_alpha_weight(alpha_x, context)
        normalized_alpha_x = self._normalize_alpha_input(alpha_x)
        source_weight = self._get_source_weight(alpha_x.device)

        # L_param
        param_loss = (active_delta ** 2).mean() * weight_param

        # L_weight_cosine
        source_exposure = normalized_alpha_x * source_weight.unsqueeze(0)
        target_exposure = normalized_alpha_x * target_alpha_weight
        weight_cosine_loss = (1 - torch.nn.functional.cosine_similarity(target_exposure, source_exposure, dim=-1)).mean()

        # L_graph_topology = KL(H^s_com || H^t_com)
        topo_loss = torch.tensor(0.0, device=alpha_x.device)
        if weight_topo > 0.0 and hasattr(self, 'frozen_seq_encoder'):
            with torch.no_grad():
                _, (hidden_s, _) = self.frozen_seq_encoder(sequence_x)
                seq_repr_s = hidden_s[-1]
                tab_repr_s = self.frozen_tab_encoder(tabular_x)
                concept_repr_s = self.frozen_concept_encoder(concept_x)
                source_common_repr = torch.cat([seq_repr_s, tab_repr_s, concept_repr_s], dim=-1)
            
            # Normalize representations for KL divergence
            log_target = torch.nn.functional.log_softmax(common_repr, dim=-1)
            prob_source = torch.nn.functional.softmax(source_common_repr, dim=-1)
            topo_loss = torch.nn.functional.kl_div(log_target, prob_source, reduction='batchmean')

        mech_loss = weight_cosine_loss * weight_mech + topo_loss * weight_topo
        return param_loss + mech_loss


def build_torch_model(
    model_name: str,
    seq_dim: int,
    tab_dim: int,
    concept_dim: int,
    alpha_dim: int,
    scoring_config: AMTScoringConfig | None = None,
) -> nn.Module:
    normalized = model_name.lower()
    if normalized == "lstm":
        return LSTMRanker(seq_dim=seq_dim, tab_dim=tab_dim)
    if normalized == "transformer":
        return TransformerRanker(seq_dim=seq_dim, tab_dim=tab_dim)
    if normalized == "tra":
        return TRALikeRanker(seq_dim=seq_dim, tab_dim=tab_dim)
    if normalized == "hist":
        return HISTLikeRanker(seq_dim=seq_dim, tab_dim=tab_dim, concept_dim=concept_dim)
    if normalized == "main":
        return MechanismPreservingHypergraphTransferModel(
            seq_dim=seq_dim,
            tab_dim=tab_dim,
            concept_dim=concept_dim,
            alpha_dim=alpha_dim,
            scoring_config=scoring_config,
        )
    raise ValueError(f"未知模型名: {model_name}")
