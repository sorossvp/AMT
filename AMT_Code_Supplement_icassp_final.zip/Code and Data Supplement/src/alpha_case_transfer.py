"""
文件功能:
1. 基于 `DataToSever/processed_data` 中的面板缓存, 构建可复现的 `alpha_case` 案例实验数据。
2. 围绕公式 `a_A * (A + delta_A) + a_B * (B + delta_B)` 执行跨市场迁移案例实验, 其中 `A/B` 为案例型量价子项。
3. 输出“源域直接迁移 / 目标域从头搜索 / 扩展参数微调 / 参数适配 / 参数适配+机理约束 / 连续参数适配 / 连续参数适配+机理约束”七类方案的量化结果。
4. 额外导出每个方案经验证的最优 alpha 公式、展开式、排序等价式及其核心效果指标, 便于论文与报告直接引用。

代码逻辑:
1. 从缓存面板中抽取案例实验所需字段, 统一切分 train/valid/test 并标准化保存到 `DataToSever/alpha_case`。
2. 在源市场与目标市场上搜索最优案例参数, 其中案例公式统一写成 `a_A * (A + delta_A) + a_B * (B + delta_B)`。
3. 在目标市场上分别执行直接迁移、从头搜索、扩展参数微调、参数适配、参数适配+机理约束。
4. 将七种方案在测试集上的 `IC / RankIC / NDCG@10 / 收益类指标 / 分状态指标` 统一落盘到 `results/alpha_case`。
5. 基于选择集(valid)与验证集(test)指标, 结构化输出“可读最优公式 + 关键指标 + 最佳方案”摘要。

代码结构:
1. 配置、路径与基础工具函数。
2. 案例信号构造与评价函数。
3. 参数搜索、适配与机理约束实现。
4. 公式导出与结构化结果落盘。
5. 命令行入口。
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from alpha_formula_exporter import build_validated_formula_record, choose_best_formula_record
from data_pipeline import MarketDataConfig, SplitConfig, prepare_market_artifacts
from experiment_workspace import get_categorized_result_path, write_dataframe, write_json
from experiment_runner import compute_prediction_metrics, run_fast_topk_backtest


ROOT_DIR = Path(__file__).resolve().parents[1]
PROCESSED_DIR = ROOT_DIR / "DataToSever" / "processed_data"
CASE_DATA_DIR = ROOT_DIR / "DataToSever" / "alpha_case"
CASE_RESULT_DIR = get_categorized_result_path("main", "alpha_case")
EPS = 1e-8


@dataclass
class AlphaCaseConfig:
    source_market: str = "US"
    target_market: str = "CN"
    top_k: int = 10
    split: SplitConfig = field(default_factory=SplitConfig)
    core_w1_values: tuple[int, ...] = (3, 5, 10, 20, 40)
    core_w2_values: tuple[int, ...] = (5, 10, 20, 40, 60)
    affine_scale_values: tuple[float, ...] = (0.85, 1.00, 1.15)
    affine_offset_values: tuple[float, ...] = (-0.10, 0.00, 0.10)
    clip_q_values: tuple[float, ...] = (0.9, 1.0)
    continuous_scale_values: tuple[float, ...] = (
        0.70,
        0.75,
        0.80,
        0.85,
        0.90,
        0.95,
        1.00,
        1.05,
        1.10,
        1.15,
        1.20,
        1.25,
        1.30,
    )
    distance_penalty: float = 0.010
    mechanism_penalty: float = 0.025
    adaptation_radius: int = 1

    @property
    def direction_key(self) -> str:
        return f"{self.source_market.lower()}_to_{self.target_market.lower()}"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def infer_split(date_value: pd.Timestamp, split: SplitConfig) -> str | None:
    if pd.Timestamp(split.train_start) <= date_value <= pd.Timestamp(split.train_end):
        return "train"
    if pd.Timestamp(split.valid_start) <= date_value <= pd.Timestamp(split.valid_end):
        return "valid"
    if pd.Timestamp(split.test_start) <= date_value <= pd.Timestamp(split.test_end):
        return "test"
    return None


def load_market_panel(market: str) -> pd.DataFrame:
    panel_path = PROCESSED_DIR / market.lower() / "panel.pkl"
    artifacts = prepare_market_artifacts(MarketDataConfig(market=market.upper()), force_rebuild=False)
    df = artifacts["panel_df"].copy()
    if df.empty:
        raise FileNotFoundError(f"缺少案例实验面板缓存或自动恢复失败: {panel_path}")
    df["date"] = pd.to_datetime(df["date"])
    df["split"] = df["date"].map(lambda x: infer_split(pd.Timestamp(x), SplitConfig()))
    keep_cols = [
        "date",
        "symbol",
        "market",
        "regime",
        "close",
        "volume",
        "future_return",
        "alpha_momentum",
        "alpha_reversal",
        "alpha_volume_price",
        "alpha_breakout",
        "alpha_liquidity",
        "alpha_intraday",
        "split",
    ]
    available_cols = [col for col in keep_cols if col in df.columns]
    df = df[available_cols].copy()
    df["symbol"] = df["symbol"].astype(str).str.upper()
    df = df.dropna(subset=["date", "symbol", "close", "volume", "future_return", "split"]).reset_index(drop=True)
    return df


def save_standardized_case_data(config: AlphaCaseConfig, source_df: pd.DataFrame, target_df: pd.DataFrame) -> dict[str, str]:
    case_dir = CASE_DATA_DIR / config.direction_key
    ensure_dir(case_dir)
    source_path = case_dir / f"{config.source_market.lower()}_case_panel.csv"
    target_path = case_dir / f"{config.target_market.lower()}_case_panel.csv"
    actual_source_path = write_dataframe(source_df, source_path, index=False, encoding="utf-8-sig")
    actual_target_path = write_dataframe(target_df, target_path, index=False, encoding="utf-8-sig")
    manifest = {
        "source_market": config.source_market,
        "target_market": config.target_market,
        "source_path": str(actual_source_path),
        "target_path": str(actual_target_path),
    }
    write_json(case_dir / "dataset_manifest.json", manifest)
    return manifest


def compute_case_signal(df: pd.DataFrame, w1: int, w2: int, sign: int = 1, clip_q: float = 1.0) -> pd.DataFrame:
    legacy_a_scale = float(sign)
    return compute_case_signal_affine(
        df=df,
        w1=w1,
        w2=w2,
        a_scale=legacy_a_scale,
        b_scale=1.0,
        a_offset=0.0,
        b_offset=0.0,
        clip_q=clip_q,
    )


def compute_case_signal_affine(
    df: pd.DataFrame,
    w1: int,
    w2: int,
    a_scale: float = 1.0,
    b_scale: float = 1.0,
    a_offset: float = 0.0,
    b_offset: float = 0.0,
    clip_q: float = 1.0,
) -> pd.DataFrame:
    work_df = df.sort_values(["symbol", "date"]).copy()
    close_delta = work_df.groupby("symbol")["close"].diff(w1)
    volume_std = (
        work_df.groupby("symbol")["volume"]
        .rolling(window=w2, min_periods=w2)
        .std()
        .reset_index(level=0, drop=True)
    )
    term_a = close_delta.groupby(work_df["date"]).rank(pct=True) - 0.5
    term_b = -(volume_std.groupby(work_df["date"]).rank(pct=True) - 0.5)
    raw_score = float(a_scale) * (term_a + float(a_offset)) + float(b_scale) * (term_b + float(b_offset))
    if clip_q < 1.0:
        clip_bound = float(raw_score.abs().quantile(clip_q))
        if clip_bound > 0:
            raw_score = raw_score.clip(lower=-clip_bound, upper=clip_bound)
    score = raw_score.groupby(work_df["date"]).rank(pct=True) - 0.5
    pred_df = work_df[["date", "symbol", "future_return", "regime", "split"]].copy()
    pred_df["prediction"] = score.astype(float)
    pred_df["label"] = pred_df["future_return"].astype(float)
    pred_df["raw_score"] = raw_score.astype(float)
    pred_df["w1"] = int(w1)
    pred_df["w2"] = int(w2)
    pred_df["a_scale"] = float(a_scale)
    pred_df["b_scale"] = float(b_scale)
    pred_df["a_offset"] = float(a_offset)
    pred_df["b_offset"] = float(b_offset)
    pred_df["clip_q"] = float(clip_q)
    pred_df = pred_df.replace([np.inf, -np.inf], np.nan).dropna(subset=["prediction", "label", "future_return"])
    return pred_df.reset_index(drop=True)


def compute_case_signal_continuous(
    df: pd.DataFrame,
    w1_real: float,
    w2_real: float,
    a_scale: float = 1.0,
    b_scale: float = 1.0,
    a_offset: float = 0.0,
    b_offset: float = 0.0,
    clip_q: float = 1.0,
) -> pd.DataFrame:
    w1_low = max(2, int(np.floor(w1_real)))
    w1_high = max(w1_low, int(np.ceil(w1_real)))
    w2_low = max(2, int(np.floor(w2_real)))
    w2_high = max(w2_low, int(np.ceil(w2_real)))
    alpha_w1 = float(w1_real - w1_low)
    alpha_w2 = float(w2_real - w2_low)

    signal_ll = compute_case_signal_affine(df, w1=w1_low, w2=w2_low, a_scale=a_scale, b_scale=b_scale, a_offset=a_offset, b_offset=b_offset, clip_q=clip_q)
    signal_lh = compute_case_signal_affine(df, w1=w1_low, w2=w2_high, a_scale=a_scale, b_scale=b_scale, a_offset=a_offset, b_offset=b_offset, clip_q=clip_q)
    signal_hl = compute_case_signal_affine(df, w1=w1_high, w2=w2_low, a_scale=a_scale, b_scale=b_scale, a_offset=a_offset, b_offset=b_offset, clip_q=clip_q)
    signal_hh = compute_case_signal_affine(df, w1=w1_high, w2=w2_high, a_scale=a_scale, b_scale=b_scale, a_offset=a_offset, b_offset=b_offset, clip_q=clip_q)

    merge_keys = ["date", "symbol", "future_return", "regime", "split", "label"]
    merged = signal_ll[merge_keys + ["raw_score"]].rename(columns={"raw_score": "score_ll"})
    merged = merged.merge(signal_lh[merge_keys + ["raw_score"]].rename(columns={"raw_score": "score_lh"}), on=merge_keys, how="inner")
    merged = merged.merge(signal_hl[merge_keys + ["raw_score"]].rename(columns={"raw_score": "score_hl"}), on=merge_keys, how="inner")
    merged = merged.merge(signal_hh[merge_keys + ["raw_score"]].rename(columns={"raw_score": "score_hh"}), on=merge_keys, how="inner")
    merged["raw_score"] = (
        (1.0 - alpha_w1) * (1.0 - alpha_w2) * merged["score_ll"]
        + (1.0 - alpha_w1) * alpha_w2 * merged["score_lh"]
        + alpha_w1 * (1.0 - alpha_w2) * merged["score_hl"]
        + alpha_w1 * alpha_w2 * merged["score_hh"]
    )
    merged["prediction"] = merged.groupby("date")["raw_score"].rank(pct=True) - 0.5
    merged["w1"] = float(w1_real)
    merged["w2"] = float(w2_real)
    merged["a_scale"] = float(a_scale)
    merged["b_scale"] = float(b_scale)
    merged["a_offset"] = float(a_offset)
    merged["b_offset"] = float(b_offset)
    merged["clip_q"] = float(clip_q)
    return merged[merge_keys + ["prediction", "raw_score", "w1", "w2", "a_scale", "b_scale", "a_offset", "b_offset", "clip_q"]].reset_index(drop=True)


def summarize_prediction_frame(pred_df: pd.DataFrame, top_k: int) -> tuple[dict[str, float], pd.DataFrame]:
    metrics = compute_prediction_metrics(pred_df, top_k=top_k)
    curve_df, backtest_metrics = run_fast_topk_backtest(pred_df, top_k=top_k)
    return {**metrics, **backtest_metrics}, curve_df


def compute_mechanism_vector(pred_df: pd.DataFrame, top_k: int) -> np.ndarray:
    if pred_df.empty:
        return np.zeros(6, dtype=float)
    corr_value = float(np.corrcoef(pred_df["raw_score"], pred_df["future_return"])[0, 1]) if len(pred_df) > 1 else 0.0
    top_group = pred_df.sort_values("prediction", ascending=False).groupby("date").head(top_k)
    bottom_group = pred_df.sort_values("prediction", ascending=True).groupby("date").head(top_k)
    top_mean = float(top_group["future_return"].mean()) if not top_group.empty else 0.0
    bottom_mean = float(bottom_group["future_return"].mean()) if not bottom_group.empty else 0.0
    vector = np.array(
        [
            float(pred_df["raw_score"].mean()),
            float(pred_df["raw_score"].std(ddof=0)),
            float(pred_df["future_return"].mean()),
            corr_value if np.isfinite(corr_value) else 0.0,
            top_mean,
            bottom_mean,
        ],
        dtype=float,
    )
    return np.nan_to_num(vector, nan=0.0, posinf=0.0, neginf=0.0)


def cosine_distance(vec_a: np.ndarray, vec_b: np.ndarray) -> float:
    denom = float(np.linalg.norm(vec_a) * np.linalg.norm(vec_b))
    if denom <= EPS:
        return 1.0
    cosine = float(np.dot(vec_a, vec_b) / denom)
    return 1.0 - max(min(cosine, 1.0), -1.0)


def score_candidate(metrics: dict[str, float]) -> float:
    rank_ic = float(metrics.get("RankIC", np.nan))
    ndcg = float(metrics.get("NDCG@10", np.nan))
    ann_ret = float(metrics.get("AnnualizedReturn", metrics.get("Annualized Return", np.nan)))
    rank_ic = 0.0 if not np.isfinite(rank_ic) else rank_ic
    ndcg = 0.0 if not np.isfinite(ndcg) else ndcg
    ann_ret = 0.0 if not np.isfinite(ann_ret) else ann_ret
    return rank_ic + 0.20 * ndcg + 0.05 * ann_ret


def format_window_value(value: float | int) -> str:
    numeric_value = float(value)
    if abs(numeric_value - round(numeric_value)) < 1e-9:
        return str(int(round(numeric_value)))
    return f"{numeric_value:.4f}".rstrip("0").rstrip(".")


def build_case_formula_record(
    *,
    method_name: str,
    params: dict[str, float | int],
    selection_metrics: dict[str, float] | None,
    validation_metrics: dict[str, float] | None,
    selection_split: str = "valid",
    validation_split: str = "test",
) -> dict[str, Any]:
    w1_value = params.get("w1_real", params["w1"])
    w2_value = params.get("w2_real", params["w2"])
    term_a_definition = f"A = RankCS(Delta(close, {format_window_value(w1_value)})) - 0.5"
    term_b_definition = f"B = -(RankCS(Std(volume, {format_window_value(w2_value)})) - 0.5)"
    selection_objective = None if not selection_metrics else score_candidate(selection_metrics)
    validation_objective = None if not validation_metrics else score_candidate(validation_metrics)
    return build_validated_formula_record(
        method_name=method_name,
        params=params,
        selection_metrics=selection_metrics,
        validation_metrics=validation_metrics,
        term_a_definition=term_a_definition,
        term_b_definition=term_b_definition,
        selection_split=selection_split,
        validation_split=validation_split,
        template_formula="a_A * (A + delta_A) + a_B * (B + delta_B)",
        rank_normalized_output=True,
        selection_objective=selection_objective,
        validation_objective=validation_objective,
    )


def extract_formula_core_metrics(metrics: dict[str, Any], top_k: int) -> dict[str, float]:
    allowed_keys = {
        "IC",
        "RankIC",
        f"NDCG@{top_k}",
        "AnnualizedReturn",
        "Sharpe",
        "MaxDrawdown",
        "EndNAV",
        "TotalReturn",
        "Volatility",
        "Calmar",
        "WinRate",
    }
    return {
        key: float(value)
        for key, value in metrics.items()
        if key in allowed_keys and value is not None and np.isfinite(float(value))
    }


def evaluate_method(
    method_name: str,
    df: pd.DataFrame,
    split_name: str,
    params: dict[str, float | int],
    top_k: int,
) -> tuple[dict[str, Any], pd.DataFrame, pd.DataFrame]:
    if "w1_real" in params or "w2_real" in params:
        pred_df = compute_case_signal_continuous(
            df=df,
            w1_real=float(params.get("w1_real", params["w1"])),
            w2_real=float(params.get("w2_real", params["w2"])),
            a_scale=float(params.get("a_scale", 1.0)),
            b_scale=float(params.get("b_scale", 1.0)),
            a_offset=float(params.get("a_offset", 0.0)),
            b_offset=float(params.get("b_offset", 0.0)),
            clip_q=float(params.get("clip_q", 1.0)),
        )
    else:
        pred_df = compute_case_signal_affine(
            df=df,
            w1=int(params["w1"]),
            w2=int(params["w2"]),
            a_scale=float(params.get("a_scale", 1.0)),
            b_scale=float(params.get("b_scale", 1.0)),
            a_offset=float(params.get("a_offset", 0.0)),
            b_offset=float(params.get("b_offset", 0.0)),
            clip_q=float(params.get("clip_q", 1.0)),
        )
    pred_df = pred_df.loc[pred_df["split"] == split_name].copy()
    metrics, curve_df = summarize_prediction_frame(pred_df, top_k=top_k)
    regime_rows: list[dict[str, Any]] = []
    for regime_name, regime_df in pred_df.groupby("regime"):
        regime_metrics = compute_prediction_metrics(regime_df, top_k=top_k)
        regime_rows.append(
            {
                "method": method_name,
                "split": split_name,
                "regime": regime_name,
                "IC": regime_metrics.get("IC"),
                "RankIC": regime_metrics.get("RankIC"),
                f"NDCG@{top_k}": regime_metrics.get(f"NDCG@{top_k}"),
                "sample_count": int(len(regime_df)),
            }
        )
    result_row = {
        "method": method_name,
        "split": split_name,
        **params,
        **metrics,
    }
    regime_df = pd.DataFrame(regime_rows)
    return result_row, pred_df, curve_df.merge(pd.DataFrame({"method": [method_name] * len(curve_df)}), left_index=True, right_index=True)


def build_core_candidate_grid(config: AlphaCaseConfig) -> list[dict[str, float | int]]:
    return [
        {"w1": w1, "w2": w2, "a_scale": 1.0, "b_scale": 1.0, "a_offset": 0.0, "b_offset": 0.0, "clip_q": 1.0}
        for w1 in config.core_w1_values
        for w2 in config.core_w2_values
    ]


def build_extended_candidate_grid(config: AlphaCaseConfig) -> list[dict[str, float | int]]:
    candidates: list[dict[str, float | int]] = []
    for w1 in config.core_w1_values:
        for w2 in config.core_w2_values:
            for a_scale in config.affine_scale_values:
                for b_scale in config.affine_scale_values:
                    for a_offset in config.affine_offset_values:
                        for b_offset in config.affine_offset_values:
                            for clip_q in config.clip_q_values:
                                candidates.append(
                                    {
                                        "w1": w1,
                                        "w2": w2,
                                        "a_scale": a_scale,
                                        "b_scale": b_scale,
                                        "a_offset": a_offset,
                                        "b_offset": b_offset,
                                        "clip_q": clip_q,
                                    }
                                )
    return candidates


def build_local_adaptation_grid(config: AlphaCaseConfig, source_params: dict[str, float | int]) -> list[dict[str, float | int]]:
    source_w1 = int(source_params["w1"])
    source_w2 = int(source_params["w2"])
    idx_map_w1 = {value: idx for idx, value in enumerate(config.core_w1_values)}
    idx_map_w2 = {value: idx for idx, value in enumerate(config.core_w2_values)}
    center_w1 = idx_map_w1[source_w1]
    center_w2 = idx_map_w2[source_w2]
    candidates: list[dict[str, float | int]] = []
    for w1 in config.core_w1_values[max(0, center_w1 - config.adaptation_radius) : center_w1 + config.adaptation_radius + 1]:
        for w2 in config.core_w2_values[max(0, center_w2 - config.adaptation_radius) : center_w2 + config.adaptation_radius + 1]:
            for a_scale in config.affine_scale_values:
                for b_scale in config.affine_scale_values:
                    for a_offset in config.affine_offset_values:
                        for b_offset in config.affine_offset_values:
                            candidates.append(
                                {
                                    "w1": w1,
                                    "w2": w2,
                                    "a_scale": float(source_params.get("a_scale", 1.0)) * float(a_scale),
                                    "b_scale": float(source_params.get("b_scale", 1.0)) * float(b_scale),
                                    "a_offset": float(source_params.get("a_offset", 0.0)) + float(a_offset),
                                    "b_offset": float(source_params.get("b_offset", 0.0)) + float(b_offset),
                                    "clip_q": float(source_params.get("clip_q", 1.0)),
                                }
                            )
    return candidates


def build_continuous_adaptation_grid(config: AlphaCaseConfig, source_params: dict[str, float | int]) -> list[dict[str, float | int]]:
    base_w1 = float(source_params["w1"])
    base_w2 = float(source_params["w2"])
    candidates: list[dict[str, float | int]] = []
    for scale_w1 in config.continuous_scale_values:
        for scale_w2 in config.continuous_scale_values:
            candidates.append(
                {
                    "w1": base_w1,
                    "w2": base_w2,
                    "w1_real": max(2.0, base_w1 * scale_w1),
                    "w2_real": max(2.0, base_w2 * scale_w2),
                    "a_scale": float(source_params.get("a_scale", 1.0)),
                    "b_scale": float(source_params.get("b_scale", 1.0)),
                    "a_offset": float(source_params.get("a_offset", 0.0)),
                    "b_offset": float(source_params.get("b_offset", 0.0)),
                    "clip_q": float(source_params.get("clip_q", 1.0)),
                }
            )
    return candidates


def find_best_candidate(
    df: pd.DataFrame,
    split_name: str,
    top_k: int,
    candidates: list[dict[str, float | int]],
    source_reference: dict[str, float | int] | None = None,
    source_mechanism: np.ndarray | None = None,
    distance_penalty: float = 0.0,
    mechanism_penalty: float = 0.0,
) -> tuple[dict[str, float | int], dict[str, float], pd.DataFrame]:
    best_params: dict[str, float | int] | None = None
    best_metrics: dict[str, float] | None = None
    best_pred_df = pd.DataFrame()
    best_objective = -np.inf

    for params in candidates:
        if "w1_real" in params or "w2_real" in params:
            pred_df = compute_case_signal_continuous(
                df=df,
                w1_real=float(params.get("w1_real", params["w1"])),
                w2_real=float(params.get("w2_real", params["w2"])),
                a_scale=float(params.get("a_scale", 1.0)),
                b_scale=float(params.get("b_scale", 1.0)),
                a_offset=float(params.get("a_offset", 0.0)),
                b_offset=float(params.get("b_offset", 0.0)),
                clip_q=float(params.get("clip_q", 1.0)),
            )
        else:
            pred_df = compute_case_signal_affine(
                df=df,
                w1=int(params["w1"]),
                w2=int(params["w2"]),
                a_scale=float(params.get("a_scale", 1.0)),
                b_scale=float(params.get("b_scale", 1.0)),
                a_offset=float(params.get("a_offset", 0.0)),
                b_offset=float(params.get("b_offset", 0.0)),
                clip_q=float(params.get("clip_q", 1.0)),
            )
        pred_df = pred_df.loc[pred_df["split"] == split_name].copy()
        if pred_df.empty:
            continue
        metrics, _ = summarize_prediction_frame(pred_df, top_k=top_k)
        objective = score_candidate(metrics)

        if source_reference is not None:
            delta = (
                abs(float(params.get("w1_real", params["w1"])) - float(source_reference.get("w1_real", source_reference["w1"])))
                + abs(float(params.get("w2_real", params["w2"])) - float(source_reference.get("w2_real", source_reference["w2"])))
                + abs(float(params.get("a_scale", 1.0)) - float(source_reference.get("a_scale", 1.0)))
                + abs(float(params.get("b_scale", 1.0)) - float(source_reference.get("b_scale", 1.0)))
                + abs(float(params.get("a_offset", 0.0)) - float(source_reference.get("a_offset", 0.0)))
                + abs(float(params.get("b_offset", 0.0)) - float(source_reference.get("b_offset", 0.0)))
            )
            objective -= distance_penalty * float(delta)
        if source_mechanism is not None:
            target_mechanism = compute_mechanism_vector(pred_df, top_k=top_k)
            objective -= mechanism_penalty * cosine_distance(source_mechanism, target_mechanism)

        if objective > best_objective:
            best_objective = objective
            best_params = params.copy()
            best_metrics = metrics.copy()
            best_pred_df = pred_df.copy()

    if best_params is None or best_metrics is None:
        raise RuntimeError(f"在 split={split_name} 上未找到可用案例参数。")
    return best_params, best_metrics, best_pred_df


def save_method_outputs(
    result_dir: Path,
    method_name: str,
    summary_row: dict[str, Any],
    pred_df: pd.DataFrame,
    curve_df: pd.DataFrame,
    regime_df: pd.DataFrame,
) -> None:
    method_dir = result_dir / method_name
    ensure_dir(method_dir)
    write_dataframe(pred_df, method_dir / "test_predictions.csv", index=False, encoding="utf-8-sig")
    write_dataframe(curve_df, method_dir / "equity_curve.csv", index=False, encoding="utf-8-sig")
    write_dataframe(regime_df, method_dir / "regime_breakdown.csv", index=False, encoding="utf-8-sig")
    write_json(method_dir / "summary.json", summary_row)


def run_alpha_case_transfer(config: AlphaCaseConfig) -> dict[str, Any]:
    source_df = load_market_panel(config.source_market)
    target_df = load_market_panel(config.target_market)
    dataset_manifest = save_standardized_case_data(config, source_df, target_df)

    case_result_dir = CASE_RESULT_DIR / config.direction_key
    ensure_dir(case_result_dir)

    core_candidates = build_core_candidate_grid(config)
    extended_candidates = build_extended_candidate_grid(config)

    log("[INFO] 搜索源域参考参数...")
    source_params, source_valid_metrics, source_valid_pred = find_best_candidate(
        df=source_df,
        split_name="valid",
        top_k=config.top_k,
        candidates=core_candidates,
    )
    source_mechanism = compute_mechanism_vector(source_valid_pred, top_k=config.top_k)

    log("[INFO] 搜索目标域从头参数...")
    target_scratch_params, target_scratch_valid_metrics, _ = find_best_candidate(
        df=target_df,
        split_name="valid",
        top_k=config.top_k,
        candidates=core_candidates,
    )

    log("[INFO] 搜索目标域扩展参数微调方案...")
    full_ft_params, full_ft_valid_metrics, _ = find_best_candidate(
        df=target_df,
        split_name="valid",
        top_k=config.top_k,
        candidates=extended_candidates,
    )

    local_candidates = build_local_adaptation_grid(config, source_params=source_params)
    continuous_candidates = build_continuous_adaptation_grid(config, source_params=source_params)
    log("[INFO] 搜索目标域参数适配方案...")
    param_adapt_params, param_adapt_valid_metrics, _ = find_best_candidate(
        df=target_df,
        split_name="valid",
        top_k=config.top_k,
        candidates=local_candidates,
        source_reference=source_params,
        distance_penalty=config.distance_penalty,
    )

    log("[INFO] 搜索目标域参数适配 + 机理约束方案...")
    mech_adapt_params, mech_adapt_valid_metrics, _ = find_best_candidate(
        df=target_df,
        split_name="valid",
        top_k=config.top_k,
        candidates=local_candidates,
        source_reference=source_params,
        source_mechanism=source_mechanism,
        distance_penalty=config.distance_penalty,
        mechanism_penalty=config.mechanism_penalty,
    )
    log("[INFO] 搜索目标域连续参数适配方案...")
    continuous_adapt_params, continuous_adapt_valid_metrics, _ = find_best_candidate(
        df=target_df,
        split_name="valid",
        top_k=config.top_k,
        candidates=continuous_candidates,
        source_reference=source_params,
        distance_penalty=config.distance_penalty,
    )
    log("[INFO] 搜索目标域连续参数适配 + 机理约束方案...")
    continuous_mech_params, continuous_mech_valid_metrics, _ = find_best_candidate(
        df=target_df,
        split_name="valid",
        top_k=config.top_k,
        candidates=continuous_candidates,
        source_reference=source_params,
        source_mechanism=source_mechanism,
        distance_penalty=config.distance_penalty,
        mechanism_penalty=config.mechanism_penalty,
    )

    method_params_map = {
        "source_transfer": source_params,
        "target_scratch": target_scratch_params,
        "full_finetune": full_ft_params,
        "parameter_adapt": param_adapt_params,
        "parameter_adapt_mech": mech_adapt_params,
        "continuous_adapt": continuous_adapt_params,
        "continuous_adapt_mech": continuous_mech_params,
    }
    method_selection_metrics_map = {
        "source_transfer": source_valid_metrics,
        "target_scratch": target_scratch_valid_metrics,
        "full_finetune": full_ft_valid_metrics,
        "parameter_adapt": param_adapt_valid_metrics,
        "parameter_adapt_mech": mech_adapt_valid_metrics,
        "continuous_adapt": continuous_adapt_valid_metrics,
        "continuous_adapt_mech": continuous_mech_valid_metrics,
    }

    summary_rows: list[dict[str, Any]] = []
    param_rows: list[dict[str, Any]] = []
    regime_frames: list[pd.DataFrame] = []
    formula_records: list[dict[str, Any]] = []

    for method_name, params in method_params_map.items():
        summary_row, pred_df, curve_df = evaluate_method(
            method_name=method_name,
            df=target_df,
            split_name="test",
            params=params,
            top_k=config.top_k,
        )
        selection_metrics = method_selection_metrics_map.get(method_name)
        formula_record = build_case_formula_record(
            method_name=method_name,
            params=params,
            selection_metrics=extract_formula_core_metrics(selection_metrics or {}, top_k=config.top_k),
            validation_metrics=extract_formula_core_metrics(summary_row, top_k=config.top_k),
            selection_split="valid",
            validation_split="test",
        )
        summary_row.update(
            {
                "alpha_formula_pretty": formula_record["formula_pretty"],
                "alpha_formula_compact": formula_record["formula_compact"],
                "alpha_formula_expanded": formula_record["formula_expanded"],
                "alpha_formula_ranking_equivalent": formula_record.get("formula_ranking_equivalent", ""),
                "alpha_formula_constant_shift": formula_record["constant_shift"],
                "selection_objective": formula_record["selection_objective"],
                "validation_objective": formula_record["validation_objective"],
                "selection_RankIC": formula_record.get("selection_RankIC"),
                f"selection_NDCG@{config.top_k}": formula_record.get(f"selection_NDCG@{config.top_k}"),
                "selection_AnnualizedReturn": formula_record.get("selection_AnnualizedReturn"),
            }
        )
        regime_rows: list[dict[str, Any]] = []
        for regime_name, regime_pred_df in pred_df.groupby("regime"):
            regime_metrics = compute_prediction_metrics(regime_pred_df, top_k=config.top_k)
            regime_rows.append(
                {
                    "method": method_name,
                    "regime": regime_name,
                    "RankIC": regime_metrics.get("RankIC"),
                    f"NDCG@{config.top_k}": regime_metrics.get(f"NDCG@{config.top_k}"),
                    "sample_count": int(len(regime_pred_df)),
                }
            )
        regime_df = pd.DataFrame(regime_rows)
        regime_frames.append(regime_df)
        save_method_outputs(case_result_dir, method_name, summary_row, pred_df, curve_df, regime_df)
        summary_rows.append(summary_row)
        formula_records.append(formula_record)
        param_rows.append(
            {
                "method": method_name,
                "source_w1": int(source_params["w1"]),
                "source_w2": int(source_params["w2"]),
                "target_w1": int(params["w1"]),
                "target_w2": int(params["w2"]),
                "target_w1_real": float(params.get("w1_real", params["w1"])),
                "target_w2_real": float(params.get("w2_real", params["w2"])),
                "a_scale": float(params.get("a_scale", 1.0)),
                "b_scale": float(params.get("b_scale", 1.0)),
                "a_offset": float(params.get("a_offset", 0.0)),
                "b_offset": float(params.get("b_offset", 0.0)),
                "clip_q": float(params.get("clip_q", 1.0)),
                "abs_delta_w1": abs(float(params.get("w1_real", params["w1"])) - float(source_params["w1"])),
                "abs_delta_w2": abs(float(params.get("w2_real", params["w2"])) - float(source_params["w2"])),
                "abs_delta_a_scale": abs(float(params.get("a_scale", 1.0)) - float(source_params.get("a_scale", 1.0))),
                "abs_delta_b_scale": abs(float(params.get("b_scale", 1.0)) - float(source_params.get("b_scale", 1.0))),
                "abs_delta_a_offset": abs(float(params.get("a_offset", 0.0)) - float(source_params.get("a_offset", 0.0))),
                "abs_delta_b_offset": abs(float(params.get("b_offset", 0.0)) - float(source_params.get("b_offset", 0.0))),
                "formula_pretty": formula_record["formula_pretty"],
                "formula_compact": formula_record["formula_compact"],
                "formula_expanded": formula_record["formula_expanded"],
                "formula_ranking_equivalent": formula_record.get("formula_ranking_equivalent", ""),
                "selection_objective": formula_record["selection_objective"],
                "validation_objective": formula_record["validation_objective"],
            }
        )

    summary_df = pd.DataFrame(summary_rows)
    write_dataframe(summary_df, case_result_dir / "alpha_case_summary.csv", index=False, encoding="utf-8-sig")
    param_df = pd.DataFrame(param_rows)
    write_dataframe(param_df, case_result_dir / "alpha_case_param_paths.csv", index=False, encoding="utf-8-sig")
    if regime_frames:
        write_dataframe(
            pd.concat(regime_frames, axis=0, ignore_index=True),
            case_result_dir / "alpha_case_regime_breakdown.csv",
            index=False,
            encoding="utf-8-sig",
        )
    if formula_records:
        formula_df = pd.DataFrame(formula_records)
        write_dataframe(formula_df, case_result_dir / "alpha_case_formula_registry.csv", index=False, encoding="utf-8-sig")
        best_formula_record = choose_best_formula_record(formula_records, objective_field="validation_objective")
        write_json(case_result_dir / "validated_best_formula.json", best_formula_record)
    else:
        best_formula_record = {}

    analysis_payload = {
        "config": asdict(config),
        "dataset_manifest": dataset_manifest,
        "source_reference_params": source_params,
        "source_valid_metrics": source_valid_metrics,
        "method_count": len(method_params_map),
        "methods": list(method_params_map.keys()),
        "validated_best_formula": best_formula_record,
    }
    write_json(case_result_dir / "alpha_case_analysis.json", analysis_payload)
    return analysis_payload


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行 alpha_case 跨市场迁移案例实验")
    parser.add_argument("--source-market", default="US")
    parser.add_argument("--target-market", default="CN")
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--distance-penalty", type=float, default=0.010)
    parser.add_argument("--mechanism-penalty", type=float, default=0.025)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = AlphaCaseConfig(
        source_market=args.source_market.upper(),
        target_market=args.target_market.upper(),
        top_k=args.top_k,
        distance_penalty=args.distance_penalty,
        mechanism_penalty=args.mechanism_penalty,
    )
    log(f"[INFO] 运行 alpha_case 案例实验: {config.source_market}->{config.target_market}")
    payload = run_alpha_case_transfer(config)
    log("[SUCCESS] alpha_case 案例实验完成")
    log(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
