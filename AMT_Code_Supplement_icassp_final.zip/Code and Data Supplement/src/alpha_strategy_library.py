"""
文件功能:
1. 维护跨市场迁移实验可复用的基础 alpha 策略库, 统一管理量价型公式与数据需求说明。
2. 为 AMT / 直接迁移 / 其他迁移方法提供一致的基准策略候选, 避免论文实验在基准定义上反复漂移。
3. 输出适合股票与期货市场共同使用的 OHLCV 级别公式, 便于后续直接绑定到迁移实验配置。

代码逻辑:
1. 用结构化字典登记每个 alpha 的公式、经济含义、所需字段和适用市场。
2. 保证所有策略都只依赖 open/high/low/close/volume 等基础量价字段或其滚动统计。
3. 提供查询接口, 供实验脚本或论文材料直接读取统一策略定义。

代码结构:
1. Alpha 策略注册表。
2. 策略查询与导出函数。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class AlphaParameterRange:
    default: float
    min_value: float
    max_value: float
    step: float
    note: str

    def to_dict(self) -> dict[str, float | str]:
        return asdict(self)


@dataclass(frozen=True)
class AffineAlphaTransformConfig:
    a_scale: float = 1.0
    b_scale: float = 1.0
    a_offset: float = 0.0
    b_offset: float = 0.0


@dataclass(frozen=True)
class AlphaStrategySpec:
    name: str
    formula: str
    intuition: str
    required_fields: tuple[str, ...]
    supported_markets: tuple[str, ...]
    holding_hint: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


ALPHA_STRATEGY_LIBRARY: dict[str, AlphaStrategySpec] = {
    "alpha_ret_5": AlphaStrategySpec(
        name="alpha_ret_5",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=close / Ref(close, 5) - 1, B=close / Ref(close, 1) - 1",
        intuition="5 日动量, 适合作为最基础的跨市场价格趋势基准。",
        required_fields=("close",),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="short-term momentum",
    ),
    "alpha_reversal_5": AlphaStrategySpec(
        name="alpha_reversal_5",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=-(close / Ref(close, 5) - 1), B=-(close / Ref(close, 1) - 1)",
        intuition="5 日反转, 检验短期过度反应是否在目标市场延续。",
        required_fields=("close",),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="short-term reversal",
    ),
    "alpha_gap_open_close": AlphaStrategySpec(
        name="alpha_gap_open_close",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=(close - open) / open, B=(high - low) / open",
        intuition="日内开收到收盘偏移, 捕捉 intraday drift。",
        required_fields=("open", "close"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="intraday drift",
    ),
    "alpha_breakout_20": AlphaStrategySpec(
        name="alpha_breakout_20",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=close / Max(high, 20) - 1, B=close / Mean(high, 20) - 1",
        intuition="20 日突破强度, 检验趋势延续与价格创新高效应。",
        required_fields=("close", "high"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="breakout",
    ),
    "alpha_range_position": AlphaStrategySpec(
        name="alpha_range_position",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=(close - low) / (high - low + eps), B=(high - close) / (high - low + eps)",
        intuition="收盘在当日波动区间中的位置, 反映尾盘买盘/卖盘主导程度。",
        required_fields=("close", "high", "low"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="intraday positioning",
    ),
    "alpha_volume_momentum_20": AlphaStrategySpec(
        name="alpha_volume_momentum_20",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=volume / Mean(volume, 20) - 1, B=volume / Mean(volume, 5) - 1",
        intuition="成交量相对 20 日均量偏离, 检验放量趋势与换手扩散效应。",
        required_fields=("volume",),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="volume expansion",
    ),
    "alpha_price_volume_corr_10": AlphaStrategySpec(
        name="alpha_price_volume_corr_10",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=Corr(ret_1, volume_ratio_10, 10), B=Rank(ret_1) - Rank(volume_ratio_10)",
        intuition="价格变化与成交量变化的耦合程度, 常用于确认趋势质量。",
        required_fields=("close", "volume"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="price-volume confirmation",
    ),
    "alpha_amihud_proxy_20": AlphaStrategySpec(
        name="alpha_amihud_proxy_20",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=Mean(Abs(ret_1) / (close * volume + eps), 20), B=Abs(ret_1) / Mean(volume, 20)",
        intuition="Amihud 非流动性代理, 反映价格冲击与交易拥挤程度。",
        required_fields=("close", "volume"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="liquidity",
    ),
    "alpha_high_low_spread": AlphaStrategySpec(
        name="alpha_high_low_spread",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=(high - low) / close, B=Abs(close - open) / close",
        intuition="高低价振幅, 衡量短期不确定性与波动扩散程度。",
        required_fields=("high", "low", "close"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="volatility spread",
    ),
    "alpha_vwap_proxy_deviation": AlphaStrategySpec(
        name="alpha_vwap_proxy_deviation",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=close / typical_price - 1, B=(high - low) / typical_price",
        intuition="收盘价相对典型价偏离, 用于刻画尾盘冲击与收盘强弱。",
        required_fields=("high", "low", "close"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="close strength",
    ),
    "alpha_ma_ratio_5_20": AlphaStrategySpec(
        name="alpha_ma_ratio_5_20",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=Mean(close, 5) / Mean(close, 20) - 1, B=Mean(close, 3) / Mean(close, 5) - 1",
        intuition="短中期均线斜率, 是跨市场最稳定的一类趋势 alpha。",
        required_fields=("close",),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="moving-average trend",
    ),
    "alpha_volume_breakout_price_follow": AlphaStrategySpec(
        name="alpha_volume_breakout_price_follow",
        formula="a_A * (A + delta_A) + a_B * (B + delta_B), A=close / Ref(close, 1) - 1, B=volume / Mean(volume, 20) - 1",
        intuition="价格突破与放量共振, 用于统一构造趋势型基础策略。",
        required_fields=("close", "volume"),
        supported_markets=("CN", "US", "FUTURE"),
        holding_hint="breakout confirmation",
    ),
}


DEFAULT_AFFINE_RANGE_ENTRIES: dict[str, AlphaParameterRange] = {
    "a_scale": AlphaParameterRange(default=1.0, min_value=0.7, max_value=1.3, step=0.05, note="A 项前置系数局部微调"),
    "b_scale": AlphaParameterRange(default=1.0, min_value=0.7, max_value=1.3, step=0.05, note="B 项前置系数局部微调"),
    "a_offset": AlphaParameterRange(default=0.0, min_value=-0.2, max_value=0.2, step=0.05, note="A 项内偏移量局部微调"),
    "b_offset": AlphaParameterRange(default=0.0, min_value=-0.2, max_value=0.2, step=0.05, note="B 项内偏移量局部微调"),
}


def build_affine_tuning_space(extra_ranges: dict[str, AlphaParameterRange]) -> dict[str, AlphaParameterRange]:
    return {**DEFAULT_AFFINE_RANGE_ENTRIES, **extra_ranges}


ALPHA_STRATEGY_TRANSFORM_DEFAULTS: dict[str, AffineAlphaTransformConfig] = {
    strategy_name: AffineAlphaTransformConfig()
    for strategy_name in ALPHA_STRATEGY_LIBRARY.keys()
}


ALPHA_STRATEGY_TUNING_SPACE: dict[str, dict[str, AlphaParameterRange]] = {
    "alpha_ret_5": build_affine_tuning_space({
        "lookback": AlphaParameterRange(default=5, min_value=3, max_value=20, step=1, note="控制动量回看长度"),
    }),
    "alpha_reversal_5": build_affine_tuning_space({
        "lookback": AlphaParameterRange(default=5, min_value=3, max_value=20, step=1, note="控制反转回看长度"),
    }),
    "alpha_gap_open_close": build_affine_tuning_space({
        "intraday_window": AlphaParameterRange(default=1, min_value=1, max_value=3, step=1, note="控制日内差值窗口"),
    }),
    "alpha_breakout_20": build_affine_tuning_space({
        "breakout_window": AlphaParameterRange(default=20, min_value=10, max_value=80, step=5, note="控制突破窗口"),
    }),
    "alpha_range_position": build_affine_tuning_space({
        "range_floor": AlphaParameterRange(default=1e-12, min_value=1e-14, max_value=1e-6, step=1e-12, note="控制区间分母稳定项"),
    }),
    "alpha_volume_momentum_20": build_affine_tuning_space({
        "volume_window": AlphaParameterRange(default=20, min_value=5, max_value=60, step=5, note="控制均量参考窗口"),
    }),
    "alpha_price_volume_corr_10": build_affine_tuning_space({
        "corr_window": AlphaParameterRange(default=10, min_value=5, max_value=30, step=1, note="控制相关系数统计窗口"),
        "volume_window": AlphaParameterRange(default=10, min_value=5, max_value=30, step=1, note="控制均量参考窗口"),
    }),
    "alpha_amihud_proxy_20": build_affine_tuning_space({
        "lookback": AlphaParameterRange(default=20, min_value=5, max_value=60, step=5, note="控制非流动性均值窗口"),
    }),
    "alpha_high_low_spread": build_affine_tuning_space({
        "spread_window": AlphaParameterRange(default=1, min_value=1, max_value=3, step=1, note="控制高低价振幅观测窗口"),
    }),
    "alpha_vwap_proxy_deviation": build_affine_tuning_space({
        "typical_window": AlphaParameterRange(default=1, min_value=1, max_value=3, step=1, note="控制典型价观测窗口"),
    }),
    "alpha_ma_ratio_5_20": build_affine_tuning_space({
        "short_window": AlphaParameterRange(default=5, min_value=3, max_value=15, step=1, note="控制短均线窗口"),
        "long_window": AlphaParameterRange(default=20, min_value=10, max_value=80, step=5, note="控制长均线窗口"),
    }),
    "alpha_volume_breakout_price_follow": build_affine_tuning_space({
        "price_window": AlphaParameterRange(default=1, min_value=1, max_value=10, step=1, note="控制价格确认回看长度"),
        "volume_window": AlphaParameterRange(default=20, min_value=5, max_value=60, step=5, note="控制放量参考窗口"),
    }),
}


def compose_affine_alpha_signal(
    term_a: pd.Series,
    term_b: pd.Series,
    transform: AffineAlphaTransformConfig | None = None,
) -> pd.Series:
    cfg = transform or AffineAlphaTransformConfig()
    a = pd.to_numeric(term_a, errors="coerce")
    b = pd.to_numeric(term_b, errors="coerce")
    return float(cfg.a_scale) * (a + float(cfg.a_offset)) + float(cfg.b_scale) * (b + float(cfg.b_offset))


def list_alpha_strategies() -> list[AlphaStrategySpec]:
    return [ALPHA_STRATEGY_LIBRARY[key] for key in sorted(ALPHA_STRATEGY_LIBRARY.keys())]


def get_alpha_strategy(name: str) -> AlphaStrategySpec:
    normalized = str(name).strip().lower()
    if normalized not in ALPHA_STRATEGY_LIBRARY:
        raise ValueError(f"未知 alpha 策略: {name}")
    return ALPHA_STRATEGY_LIBRARY[normalized]


def alpha_library_to_dict() -> list[dict[str, Any]]:
    return [spec.to_dict() for spec in list_alpha_strategies()]


def alpha_strategy_tuning_space_to_dict() -> dict[str, dict[str, dict[str, float | str]]]:
    return {
        strategy_name: {
            param_name: spec.to_dict()
            for param_name, spec in param_ranges.items()
        }
        for strategy_name, param_ranges in ALPHA_STRATEGY_TUNING_SPACE.items()
    }


def normalize_alpha_strategy_names(raw_value: str | list[str] | tuple[str, ...] | None) -> list[str]:
    if raw_value is None:
        return []
    if isinstance(raw_value, str):
        values = [item.strip() for item in raw_value.split(",") if item.strip()]
    else:
        values = [str(item).strip() for item in raw_value if str(item).strip()]
    normalized: list[str] = []
    for item in values:
        name = get_alpha_strategy(item).name
        if name not in normalized:
            normalized.append(name)
    return normalized


def _rolling_feature_by_symbol(
    panel_df: pd.DataFrame,
    builder: callable,
) -> pd.Series:
    outputs: list[pd.Series] = []
    for _, symbol_df in panel_df.groupby("symbol", sort=False):
        ordered_df = symbol_df.sort_values("date").copy()
        values = builder(ordered_df)
        series = pd.Series(values, index=ordered_df.index, dtype=float)
        outputs.append(series)
    if not outputs:
        return pd.Series(index=panel_df.index, dtype=float)
    merged = pd.concat(outputs).sort_index()
    return merged.reindex(panel_df.index)


def compute_alpha_strategy_signal(panel_df: pd.DataFrame, strategy_name: str) -> pd.Series:
    normalized = get_alpha_strategy(strategy_name).name
    transform = ALPHA_STRATEGY_TRANSFORM_DEFAULTS.get(normalized, AffineAlphaTransformConfig())
    work_df = panel_df.copy()
    for column in ["open", "high", "low", "close", "volume"]:
        if column in work_df.columns:
            work_df[column] = pd.to_numeric(work_df[column], errors="coerce")

    if normalized == "alpha_ret_5":
        return compose_affine_alpha_signal(
            pd.to_numeric(work_df["ret_5"], errors="coerce"),
            pd.to_numeric(work_df["ret_1"], errors="coerce"),
            transform,
        )
    if normalized == "alpha_reversal_5":
        return compose_affine_alpha_signal(
            pd.to_numeric(work_df["reversal_5"], errors="coerce"),
            -pd.to_numeric(work_df["ret_1"], errors="coerce"),
            transform,
        )
    if normalized == "alpha_gap_open_close":
        return compose_affine_alpha_signal(
            pd.to_numeric(work_df["oc_return"], errors="coerce"),
            (pd.to_numeric(work_df["high"], errors="coerce") - pd.to_numeric(work_df["low"], errors="coerce"))
            / (pd.to_numeric(work_df["open"], errors="coerce") + 1e-12),
            transform,
        )
    if normalized == "alpha_breakout_20":
        high_roll_max = _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["high"].rolling(20).max())
        high_roll_mean = _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["high"].rolling(20).mean())
        close = pd.to_numeric(work_df["close"], errors="coerce")
        term_a = close / (high_roll_max + 1e-12) - 1.0
        term_b = close / (high_roll_mean + 1e-12) - 1.0
        return compose_affine_alpha_signal(term_a, term_b, transform)
    if normalized == "alpha_range_position":
        numerator = pd.to_numeric(work_df["close"], errors="coerce") - pd.to_numeric(work_df["low"], errors="coerce")
        denominator = pd.to_numeric(work_df["high"], errors="coerce") - pd.to_numeric(work_df["low"], errors="coerce")
        term_a = numerator / (denominator + 1e-12)
        term_b = (pd.to_numeric(work_df["high"], errors="coerce") - pd.to_numeric(work_df["close"], errors="coerce")) / (denominator + 1e-12)
        return compose_affine_alpha_signal(term_a, term_b, transform)
    if normalized == "alpha_volume_momentum_20":
        volume = pd.to_numeric(work_df["volume"], errors="coerce")
        volume_mean_20 = _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["volume"].rolling(20).mean())
        volume_mean_5 = _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["volume"].rolling(5).mean())
        term_a = volume / (volume_mean_20 + 1e-12) - 1.0
        term_b = volume / (volume_mean_5 + 1e-12) - 1.0
        return compose_affine_alpha_signal(term_a, term_b, transform)
    if normalized == "alpha_price_volume_corr_10":
        term_a = _rolling_feature_by_symbol(
            work_df,
            lambda symbol_df: symbol_df["ret_1"].rolling(10).corr(symbol_df["volume"] / (symbol_df["volume"].rolling(10).mean() + 1e-12)),
        )
        term_b = (
            pd.to_numeric(work_df["ret_1"], errors="coerce").groupby(work_df["date"]).rank(pct=True)
            - (pd.to_numeric(work_df["volume"], errors="coerce") / (_rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["volume"].rolling(10).mean()) + 1e-12)).groupby(work_df["date"]).rank(pct=True)
        )
        return compose_affine_alpha_signal(term_a, term_b, transform)
    if normalized == "alpha_amihud_proxy_20":
        term_a = _rolling_feature_by_symbol(
            work_df,
            lambda symbol_df: (symbol_df["ret_1"].abs() / (symbol_df["close"] * symbol_df["volume"] + 1e-12)).rolling(20).mean(),
        )
        term_b = pd.to_numeric(work_df["ret_1"], errors="coerce").abs() / (
            _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["volume"].rolling(20).mean()) + 1e-12
        )
        return compose_affine_alpha_signal(term_a, term_b, transform)
    if normalized == "alpha_high_low_spread":
        return compose_affine_alpha_signal(
            pd.to_numeric(work_df["hl_spread"], errors="coerce"),
            (pd.to_numeric(work_df["close"], errors="coerce") - pd.to_numeric(work_df["open"], errors="coerce")).abs()
            / (pd.to_numeric(work_df["close"], errors="coerce") + 1e-12),
            transform,
        )
    if normalized == "alpha_vwap_proxy_deviation":
        typical_price = (
            pd.to_numeric(work_df["high"], errors="coerce")
            + pd.to_numeric(work_df["low"], errors="coerce")
            + pd.to_numeric(work_df["close"], errors="coerce")
        ) / 3.0
        term_a = pd.to_numeric(work_df["close"], errors="coerce") / (typical_price + 1e-12) - 1.0
        term_b = (pd.to_numeric(work_df["high"], errors="coerce") - pd.to_numeric(work_df["low"], errors="coerce")) / (typical_price + 1e-12)
        return compose_affine_alpha_signal(term_a, term_b, transform)
    if normalized == "alpha_ma_ratio_5_20":
        ma_short = _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["close"].rolling(5).mean())
        ma_mid = _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["close"].rolling(20).mean())
        ma_fast = _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["close"].rolling(3).mean())
        term_a = ma_short / (ma_mid + 1e-12) - 1.0
        term_b = ma_fast / (ma_short + 1e-12) - 1.0
        return compose_affine_alpha_signal(term_a, term_b, transform)
    if normalized == "alpha_volume_breakout_price_follow":
        term_a = pd.to_numeric(work_df["ret_1"], errors="coerce")
        term_b = pd.to_numeric(work_df["volume"], errors="coerce") / (
            _rolling_feature_by_symbol(work_df, lambda symbol_df: symbol_df["volume"].rolling(20).mean()) + 1e-12
        ) - 1.0
        return compose_affine_alpha_signal(term_a, term_b, transform)
    raise ValueError(f"暂未实现的 alpha 策略信号: {strategy_name}")


def inject_base_alpha_features(
    panel_df: pd.DataFrame,
    strategy_names: str | list[str] | tuple[str, ...],
    target_feature_names: list[str] | tuple[str, ...],
) -> pd.DataFrame:
    selected_names = normalize_alpha_strategy_names(strategy_names)
    if not selected_names:
        raise ValueError("至少需要指定一个基础 alpha 策略。")
    feature_names = list(target_feature_names)
    if not feature_names:
        raise ValueError("target_feature_names 不能为空。")

    signal_map: dict[str, pd.Series] = {}
    for strategy_name in selected_names:
        signal = compute_alpha_strategy_signal(panel_df, strategy_name)
        signal = pd.to_numeric(signal, errors="coerce").replace([np.inf, -np.inf], np.nan)
        signal_map[strategy_name] = signal

    work_df = panel_df.copy()
    ordered_signals = [signal_map[name] for name in selected_names]
    for idx, feature_name in enumerate(feature_names):
        source_signal = ordered_signals[idx % len(ordered_signals)]
        work_df[feature_name] = source_signal.to_numpy(dtype=float)

    work_df["base_alpha_strategy"] = "+".join(selected_names)
    work_df = work_df.replace([np.inf, -np.inf], np.nan)
    return work_df
