"""
文件功能:
1. 在与主实验相同的数据切分、训练配置和评估协议下, 运行 `AMT` 的关键消融实验。
2. 覆盖完整 `AMT` 参考项以及 4 组决定性消融: 无机理约束、无结构冻结、结构冻结但解冻基础打分模块最后一层、只保留局部适配。
3. 将结果统一保存到 `results/full_<timestamp>/消融实验/amt_ablation/` 下, 便于论文正文、附录和答辩材料直接引用。

代码逻辑:
1. 复用主实验的数据入口, 保证消融与主实验使用同一套源域/目标域样本和指标口径。
2. 先在源域执行预训练, 再根据不同消融配置切换到目标域适配模式。
3. 通过结构冻结开关、基础打分模块解冻开关以及迁移约束权重开关实现不同变体。
4. 统一输出每个变体的预测文件、净值曲线、summary.json 和方向级总表。

代码结构:
1. 消融配置定义。
2. 单个 AMT 变体训练与评估函数。
3. 单方向消融驱动。
4. CLI 入口与运行配置落盘。
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import os
from pathlib import Path
import sys
import time
from typing import Any

import pandas as pd
import torch

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parent))

from data_pipeline import SplitConfig, prepare_transfer_artifacts
from experiment_profiles import get_profile, profile_to_dict, resolve_max_symbols
from experiment_runner import (
    DIRECTION_SPECS,
    ModelHeartbeat,
    align_transfer_concept_arrays,
    amt_scoring_config_to_dict,
    amt_supervised_loss_config_to_dict,
    cap_market_artifacts_for_quick_mode,
    build_adaptation_policy_config,
    build_amt_scoring_config,
    build_amt_supervised_loss_config,
    build_market_similarity_config,
    build_threshold_update_config,
    build_split_arrays,
    evaluate_and_save,
    format_progress,
    format_seconds,
    log,
    make_dataset,
    normalize_direction,
    parse_csv_args,
    read_existing_summary,
    scale_epoch_count,
    summarize_metrics,
)
from experiment_workspace import get_categorized_result_path, write_dataframe, write_json
from market_similarity import (
    AdaptationPolicy,
    AdaptationPolicyConfig,
    MarketSimilarityConfig,
    ThresholdUpdateConfig,
    build_adaptation_param_groups,
    collect_optimizer_group_summary,
    compute_market_similarity,
    recommend_similarity_threshold,
    render_similarity_report_markdown,
    resolve_adaptation_policy,
    update_threshold_history,
)
from models import AMTScoringConfig, SupervisedLossConfig, TorchTrainingConfig, build_torch_model, fit_torch_regressor, predict_torch_regressor, unwrap_model


ABLATION_RESULT_ROOT = get_categorized_result_path("ablation", "amt_ablation")


@dataclass(frozen=True)
class AblationVariant:
    key: str
    display_name: str
    freeze_backbone: bool
    freeze_factor_projector: bool
    freeze_base_scoring_module: bool
    unfreeze_base_scoring_last_layer: bool
    weight_param: float
    weight_mech: float
    description: str


ABLATION_VARIANTS = [
    AblationVariant(
        key="amt_reference",
        display_name="AMT-Reference",
        freeze_backbone=True,
        freeze_factor_projector=True,
        freeze_base_scoring_module=True,
        unfreeze_base_scoring_last_layer=False,
        weight_param=0.002,
        weight_mech=0.0005,
        description="完整 AMT 参考项: 结构冻结 + 局部适配 + 参数偏移约束 + 机理偏移约束",
    ),
    AblationVariant(
        key="no_mechanism_constraint",
        display_name="No-Mechanism-Constraint",
        freeze_backbone=True,
        freeze_factor_projector=True,
        freeze_base_scoring_module=True,
        unfreeze_base_scoring_last_layer=False,
        weight_param=0.002,
        weight_mech=0.0,
        description="无机理约束: 去掉机理偏移约束, 仅保留监督损失与参数偏移约束",
    ),
    AblationVariant(
        key="no_structure_freezing",
        display_name="No-Structure-Freezing",
        freeze_backbone=False,
        freeze_factor_projector=False,
        freeze_base_scoring_module=False,
        unfreeze_base_scoring_last_layer=False,
        weight_param=0.002,
        weight_mech=0.0005,
        description="无结构冻结: 在目标域允许共享主干和基础打分模块共同更新",
    ),
    AblationVariant(
        key="unfreeze_base_scoring_last_layer",
        display_name="Unfreeze-Base-Scoring-Last-Layer",
        freeze_backbone=True,
        freeze_factor_projector=True,
        freeze_base_scoring_module=True,
        unfreeze_base_scoring_last_layer=True,
        weight_param=0.002,
        weight_mech=0.0005,
        description="结构冻结但解冻基础打分模块最后一层, 用于验证输出映射是否是主要瓶颈",
    ),
    AblationVariant(
        key="local_adaptation_only",
        display_name="Local-Adaptation-Only",
        freeze_backbone=True,
        freeze_factor_projector=True,
        freeze_base_scoring_module=True,
        unfreeze_base_scoring_last_layer=False,
        weight_param=0.0,
        weight_mech=0.0,
        description="只保留局部适配: 冻结主干并保留 adapter + gate, 但不施加额外迁移约束",
    ),
]


def normalize_variant_names(raw_value: str | None) -> list[str]:
    values = parse_csv_args(raw_value)
    if not values:
        return [item.key for item in ABLATION_VARIANTS]
    supported = {item.key for item in ABLATION_VARIANTS}
    normalized: list[str] = []
    for item in values:
        key = str(item).strip().lower()
        if key not in supported:
            raise ValueError(f"不支持的消融变体: {item}")
        if key not in normalized:
            normalized.append(key)
    return normalized


def get_variant(key: str) -> AblationVariant:
    for item in ABLATION_VARIANTS:
        if item.key == key:
            return item
    raise KeyError(key)


def run_amt_variant(
    variant: AblationVariant,
    source_arrays: dict[str, dict[str, Any]],
    target_arrays: dict[str, dict[str, Any]],
    target_meta: dict[str, pd.DataFrame],
    experiment_dir: Path,
    top_k: int,
    device: str,
    mode: str,
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    source_market: str,
    target_market: str,
    base_policy: AdaptationPolicy | None,
    threshold_config: ThresholdUpdateConfig | None,
    similarity_history_path: Path | None,
) -> dict[str, float]:
    source_train = make_dataset(source_arrays["train"])
    source_valid = make_dataset(source_arrays["valid"])
    target_train = make_dataset(target_arrays["train"])
    target_valid = make_dataset(target_arrays["valid"])
    target_test = make_dataset(target_arrays["test"])

    model = build_torch_model(
        model_name="main",
        seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=source_arrays["train"]["concept_x"].shape[-1],
        alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
        scoring_config=scoring_config,
    )
    pretrain_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(12, mode=mode, minimum_epochs=4),
        batch_size=512,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=3,
    )
    model = fit_torch_regressor(
        model,
        source_train,
        source_valid,
        config=pretrain_cfg,
        supervised_loss_config=supervised_loss_config,
        device=device,
    )
    model = unwrap_model(model)
    adaptation_kwargs = {
        "freeze_backbone": variant.freeze_backbone,
        "freeze_factor_projector": variant.freeze_factor_projector,
        "freeze_base_scoring_module": variant.freeze_base_scoring_module,
        "unfreeze_base_scoring_last_layer": variant.unfreeze_base_scoring_last_layer,
        "freeze_source_alpha_weight": True,
    }
    optimizer_group_builder = None
    similarity_payload: dict[str, Any] | None = None
    report_markdown: str | None = None
    if base_policy is not None:
        adaptation_kwargs = base_policy.to_adaptation_kwargs()
        if variant.key == "no_structure_freezing":
            adaptation_kwargs = {
                "freeze_backbone": False,
                "freeze_factor_projector": False,
                "freeze_base_scoring_module": False,
                "unfreeze_base_scoring_last_layer": False,
                "freeze_source_alpha_weight": False,
            }
        elif variant.key == "unfreeze_base_scoring_last_layer":
            adaptation_kwargs = {
                **adaptation_kwargs,
                "freeze_base_scoring_module": True,
                "unfreeze_base_scoring_last_layer": True,
            }
        model.configure_target_adaptation(**adaptation_kwargs)
    else:
        model.configure_target_adaptation(**adaptation_kwargs)

    def transfer_penalty(model_obj: torch.nn.Module, batch: tuple[torch.Tensor, ...], pred: Any) -> torch.Tensor:
        _ = pred
        return model_obj.extra_transfer_loss(
            batch[4],
            batch[1],
            batch[0],
            batch[2],
            batch[3],
            weight_param=variant.weight_param,
            weight_mech=variant.weight_mech,
        )

    adapt_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(8, mode=mode, minimum_epochs=3),
        batch_size=512,
        lr=1e-3,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    if base_policy is not None:
        optimizer_group_builder = lambda model_obj, cfg: build_adaptation_param_groups(model_obj, cfg, base_policy)
        optimizer_groups = collect_optimizer_group_summary(model, base_lr=float(adapt_cfg.lr), policy=base_policy)
        similarity_payload = {
            "direction": f"{source_market}->{target_market}",
            "variant": variant.key,
            "base_policy": base_policy.to_dict(),
            "optimizer_groups": optimizer_groups,
            "history_path": str(similarity_history_path) if similarity_history_path is not None else "",
        }
        report_markdown = (
            f"# 消融相似度策略报告: {source_market}->{target_market} / {variant.key}\n\n"
            f"- 继承策略: `{base_policy.policy_name}`\n"
            f"- 相似度分数: `{base_policy.similarity_score:.4f}`\n"
            f"- 相似度阈值: `{base_policy.similarity_threshold:.4f}`\n"
            f"- 说明: {base_policy.description}\n"
        )
    model = fit_torch_regressor(
        model,
        target_train,
        target_valid,
        config=adapt_cfg,
        supervised_loss_config=supervised_loss_config,
        extra_loss_fn=transfer_penalty,
        optimizer_group_builder=optimizer_group_builder,
        device=device,
    )
    prediction = predict_torch_regressor(model, target_test, batch_size=1024, device=device)
    metrics = evaluate_and_save(variant.display_name, experiment_dir / variant.key, target_meta["test"], prediction, top_k=top_k)
    if similarity_payload is not None:
        similarity_payload["post_run_metrics"] = {
            "Annualized Return": float(metrics.get("Annualized Return", metrics.get("AnnualizedReturn", 0.0))),
            "Sharpe": float(metrics.get("Sharpe Ratio", metrics.get("Sharpe", 0.0))),
            "RankIC": float(metrics.get("RankIC", 0.0)),
        }
        if similarity_history_path is not None and threshold_config is not None:
            similarity_payload["post_run_threshold_recommendation"] = update_threshold_history(
                history_path=similarity_history_path,
                record={
                    "direction": f"{source_market}->{target_market}",
                    "variant": variant.key,
                    "similarity_score": float(base_policy.similarity_score),
                    "threshold_used": float(base_policy.similarity_threshold),
                    "policy_name": str(base_policy.policy_name),
                    "supervised_metric": float(metrics.get("Annualized Return", metrics.get("AnnualizedReturn", 0.0))),
                    "rankic": float(metrics.get("RankIC", 0.0)),
                },
                config=threshold_config,
            )
        write_json(experiment_dir / variant.key / "market_similarity_report.json", similarity_payload)
        if report_markdown is not None:
            (experiment_dir / variant.key / "market_similarity_report.md").write_text(report_markdown, encoding="utf-8")
    return metrics


def run_one_direction(
    source_market: str,
    target_market: str,
    max_symbols: int,
    lookback: int,
    top_k: int,
    device: str,
    force_rebuild: bool,
    mode: str,
    variant_keys: list[str],
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    enable_similarity_policy: bool,
    similarity_config: MarketSimilarityConfig,
    threshold_config: ThresholdUpdateConfig,
    policy_config: AdaptationPolicyConfig,
    similarity_history_path: Path,
    skip_existing: bool = True,
) -> pd.DataFrame:
    direction_name = f"{source_market}->{target_market}"
    experiment_dir = ABLATION_RESULT_ROOT / f"{source_market.lower()}_to_{target_market.lower()}"
    experiment_dir.mkdir(parents=True, exist_ok=True)
    summary_rows: list[dict[str, Any]] = []
    runnable_variants: list[AblationVariant] = []

    for variant_key in variant_keys:
        variant = get_variant(variant_key)
        existing_summary = read_existing_summary(experiment_dir / variant.key)
        if existing_summary is not None and skip_existing:
            summary_rows.append(
                {
                    "direction": direction_name,
                    "variant": variant.key,
                    "display_name": variant.display_name,
                    **existing_summary,
                }
            )
            continue
        runnable_variants.append(variant)

    if not runnable_variants:
        summary_df = pd.DataFrame(summary_rows)
        if not summary_df.empty:
            write_dataframe(summary_df, experiment_dir / "summary.csv", index=False, encoding="utf-8-sig")
        return summary_df

    source_max_symbols = resolve_max_symbols(get_profile(mode), source_market, max_symbols)
    target_max_symbols = resolve_max_symbols(get_profile(mode), target_market, max_symbols)
    effective_max_symbols = min(source_max_symbols, target_max_symbols)
    transfer = prepare_transfer_artifacts(
        source_market=source_market,
        target_market=target_market,
        max_symbols=effective_max_symbols,
        horizon=5,
        force_rebuild=force_rebuild,
    )
    if str(mode).lower() in {"smoke", "medium"}:
        transfer["source"] = cap_market_artifacts_for_quick_mode(transfer["source"], source_max_symbols)
        transfer["target"] = cap_market_artifacts_for_quick_mode(transfer["target"], target_max_symbols)
    source_panel = transfer["source"]["panel_df"]
    target_panel = transfer["target"]["panel_df"]
    source_incidence = transfer["source"]["incidence_df"]
    target_incidence = transfer["target"]["incidence_df"]
    split = SplitConfig()
    source_arrays, _source_meta = build_split_arrays(source_panel, source_incidence, split=split, lookback=lookback)
    target_arrays, target_meta = build_split_arrays(target_panel, target_incidence, split=split, lookback=lookback)
    source_arrays, target_arrays, _shared_dim = align_transfer_concept_arrays(source_arrays, target_arrays)
    base_policy: AdaptationPolicy | None = None
    if enable_similarity_policy:
        prototype_model = build_torch_model(
            model_name="main",
            seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
            tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
            concept_dim=source_arrays["train"]["concept_x"].shape[-1],
            alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
            scoring_config=scoring_config,
        )
        pretrain_cfg = TorchTrainingConfig(
            n_epochs=scale_epoch_count(12, mode=mode, minimum_epochs=4),
            batch_size=512,
            lr=8e-4,
            weight_decay=1e-5,
            early_stop_rounds=3,
        )
        prototype_model = fit_torch_regressor(
            prototype_model,
            make_dataset(source_arrays["train"]),
            make_dataset(source_arrays["valid"]),
            config=pretrain_cfg,
            supervised_loss_config=supervised_loss_config,
            device=device,
        )
        prototype_model = unwrap_model(prototype_model)
        similarity_result = compute_market_similarity(
            source_arrays=source_arrays["train"],
            target_arrays=target_arrays["train"],
            model=prototype_model,
            device=device,
            config=similarity_config,
        )
        threshold_summary = recommend_similarity_threshold(similarity_history_path, config=threshold_config)
        base_policy = resolve_adaptation_policy(
            similarity_score=float(similarity_result.final_similarity),
            similarity_threshold=float(threshold_summary["threshold"]),
            config=policy_config,
        )
        write_json(
            experiment_dir / "market_similarity_direction_report.json",
            {
                "direction": direction_name,
                "similarity_result": similarity_result.to_dict(),
                "threshold_summary": threshold_summary,
                "base_policy": base_policy.to_dict(),
            },
        )
        (experiment_dir / "market_similarity_direction_report.md").write_text(
            render_similarity_report_markdown(
                source_market=source_market,
                target_market=target_market,
                similarity_result=similarity_result,
                threshold_summary=threshold_summary,
                policy=base_policy,
                optimizer_groups=[],
            ),
            encoding="utf-8",
        )

    total_variants = len(variant_keys)
    completed_count = len(summary_rows)
    log(
        f"[EXP-LOG][ABLATION] direction started | 当前方向={direction_name} | "
        f"待运行变体数={len(runnable_variants)} | 已跳过变体数={len(summary_rows)} | 状态=BUILDING_ARRAYS"
    )
    for variant in runnable_variants:
        progress_before = format_progress(completed_count, total_variants)
        heartbeat = ModelHeartbeat(direction_name=direction_name, model_name=variant.key, progress_text=progress_before)
        heartbeat.start()
        variant_start_time = time.perf_counter()
        try:
            metrics = run_amt_variant(
                variant=variant,
                source_arrays=source_arrays,
                target_arrays=target_arrays,
                target_meta=target_meta,
                experiment_dir=experiment_dir,
                top_k=top_k,
                device=device,
                mode=mode,
                scoring_config=scoring_config,
                supervised_loss_config=supervised_loss_config,
                source_market=source_market,
                target_market=target_market,
                base_policy=base_policy,
                threshold_config=threshold_config if enable_similarity_policy else None,
                similarity_history_path=similarity_history_path if enable_similarity_policy else None,
            )
        finally:
            heartbeat.stop()
        summary_rows.append(
            {
                "direction": direction_name,
                "variant": variant.key,
                "display_name": variant.display_name,
                "description": variant.description,
                **metrics,
            }
        )
        completed_count += 1
        log(
            f"[EXP-DONE][ABLATION] variant finished | 当前方向={direction_name} | 当前变体={variant.key} | "
            f"方向内完成百分比={format_progress(completed_count, total_variants)} | "
            f"完成摘要={summarize_metrics(metrics)} | 用时={format_seconds(time.perf_counter() - variant_start_time)}"
        )

    summary_df = pd.DataFrame(summary_rows)
    write_dataframe(summary_df, experiment_dir / "summary.csv", index=False, encoding="utf-8-sig")
    return summary_df


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行 AMT 的关键消融实验")
    parser.add_argument("--mode", default="full", choices=["full", "medium", "smoke"], help="实验运行模式")
    parser.add_argument("--max-symbols", type=int, default=160, help="每个市场参与训练的流动性股票数")
    parser.add_argument("--lookback", type=int, default=20, help="时序模型回看窗口")
    parser.add_argument("--top-k", type=int, default=20, help="轻量回测的 Top-k 持仓数")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true", help="强制重建中间缓存")
    parser.add_argument("--direction", default="us_to_cn,cn_to_us", help="实验方向, 多个方向用逗号分隔")
    parser.add_argument(
        "--variants",
        default=",".join(item.key for item in ABLATION_VARIANTS),
        help="指定要运行的消融变体, 多个变体用逗号分隔",
    )
    parser.add_argument("--rerun-existing", action="store_true", help="即使已有结果也重新训练并覆盖")
    parser.add_argument("--amt-top-r", type=int, default=3, help="AMT 稀疏门控保留的 alpha 参数块数量")
    parser.add_argument("--amt-gate-temperature", type=float, default=0.70, help="AMT 门控 softmax 温度")
    parser.add_argument("--amt-alpha-residual-scale", type=float, default=0.35, help="AMT 目标域增量注入到源域权重时的残差缩放")
    parser.add_argument("--amt-delta-clip", type=float, default=0.75, help="AMT 适配器输出增量的裁剪上界")
    parser.add_argument("--amt-min-gate-mass", type=float, default=1e-6, help="AMT 稀疏门控重归一化时的最小分母")
    parser.add_argument("--amt-supervised-objective", choices=["mse", "rank_return"], default="rank_return", help="AMT 主监督项类型")
    parser.add_argument("--amt-rank-loss-weight", type=float, default=1.0, help="AMT 排序损失权重")
    parser.add_argument("--amt-return-loss-weight", type=float, default=2.0, help="AMT 年化收益代理损失权重")
    parser.add_argument("--amt-mse-anchor-weight", type=float, default=0.05, help="AMT 回归锚点损失权重")
    parser.add_argument("--amt-pairwise-label-threshold", type=float, default=1e-4, help="AMT 排序损失中忽略微小标签差异的阈值")
    parser.add_argument("--amt-return-temperature", type=float, default=0.35, help="AMT 收益代理中的 softmax 温度")
    parser.add_argument("--amt-annualization-factor", type=float, default=252.0, help="AMT 收益代理的年化放大系数")
    parser.add_argument("--disable-market-similarity-policy", action="store_true", help="关闭相似度驱动的消融冻结与学习率策略")
    parser.add_argument("--market-similarity-threshold", type=float, default=0.70, help="市场相似度统一阈值")
    parser.add_argument("--market-similarity-sample-size", type=int, default=2048, help="计算市场嵌入时每个市场最多采样的样本数")
    parser.add_argument("--market-similarity-batch-size", type=int, default=512, help="计算市场嵌入时的批大小")
    parser.add_argument("--market-similarity-rbf-gamma", type=float, default=0.50, help="MMD RBF 核的 gamma 参数")
    parser.add_argument("--market-similarity-medium-gap", type=float, default=0.15, help="低于阈值后进入第一档宽松策略的相似度间隔")
    parser.add_argument("--market-similarity-low-gap", type=float, default=0.35, help="低于阈值后进入更宽松策略的相似度间隔")
    parser.add_argument("--market-threshold-update-method", choices=["ema_quantile", "supervised_gain"], default="ema_quantile", help="相似度阈值动态更新方法")
    parser.add_argument("--market-threshold-quantile", type=float, default=0.65, help="无监督阈值更新时使用的历史相似度分位数")
    parser.add_argument("--market-threshold-ema-decay", type=float, default=0.80, help="动态阈值更新时的 EMA 衰减系数")
    parser.add_argument(
        "--market-similarity-history-path",
        default=str(Path(__file__).resolve().parents[1] / "results" / "market_similarity_threshold_history.json"),
        help="市场相似度阈值历史文件路径",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    os.environ["AMT_ARCHIVE_PREFIX"] = str(args.mode).strip().lower()
    ABLATION_RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    direction_keys = [normalize_direction(item) for item in parse_csv_args(args.direction)]
    variant_keys = normalize_variant_names(args.variants)
    scoring_config = build_amt_scoring_config(args)
    supervised_loss_config = build_amt_supervised_loss_config(args)
    market_similarity_config = build_market_similarity_config(args)
    threshold_update_config = build_threshold_update_config(args)
    adaptation_policy_config = build_adaptation_policy_config(args)
    similarity_history_path = Path(args.market_similarity_history_path).expanduser().resolve()
    summary_frames: list[pd.DataFrame] = []
    for direction_key in direction_keys:
        source_market, target_market = DIRECTION_SPECS[direction_key]
        summary_df = run_one_direction(
            source_market=source_market,
            target_market=target_market,
            max_symbols=args.max_symbols,
            lookback=args.lookback,
            top_k=args.top_k,
            device=args.device,
            force_rebuild=args.force_rebuild,
            mode=args.mode,
            variant_keys=variant_keys,
            scoring_config=scoring_config,
            supervised_loss_config=supervised_loss_config,
            enable_similarity_policy=not args.disable_market_similarity_policy,
            similarity_config=market_similarity_config,
            threshold_config=threshold_update_config,
            policy_config=adaptation_policy_config,
            similarity_history_path=similarity_history_path,
            skip_existing=not args.rerun_existing,
        )
        if not summary_df.empty:
            summary_frames.append(summary_df)
    all_summary_df = pd.concat(summary_frames, axis=0, ignore_index=True) if summary_frames else pd.DataFrame()
    write_dataframe(all_summary_df, ABLATION_RESULT_ROOT / "all_summary.csv", index=False, encoding="utf-8-sig")
    write_json(
        ABLATION_RESULT_ROOT / "run_config.json",
        {
            "mode": args.mode,
            "max_symbols": args.max_symbols,
            "lookback": args.lookback,
            "top_k": args.top_k,
            "device": args.device,
            "direction_keys": direction_keys,
            "variant_keys": variant_keys,
            "profile": profile_to_dict(get_profile(args.mode)),
            "result_root": str(ABLATION_RESULT_ROOT),
            "amt_scoring": amt_scoring_config_to_dict(scoring_config),
            "amt_supervised_loss": amt_supervised_loss_config_to_dict(supervised_loss_config),
            "market_similarity": {
                "enabled": not args.disable_market_similarity_policy,
                "history_path": str(similarity_history_path),
                "feature_config": {
                    "sample_size": int(market_similarity_config.sample_size),
                    "batch_size": int(market_similarity_config.batch_size),
                    "rbf_gamma": float(market_similarity_config.rbf_gamma),
                },
                "threshold_update": {
                    "base_threshold": float(threshold_update_config.base_threshold),
                    "update_method": threshold_update_config.update_method,
                    "quantile": float(threshold_update_config.quantile),
                    "ema_decay": float(threshold_update_config.ema_decay),
                },
                "policy_gap": {
                    "medium_gap": float(adaptation_policy_config.medium_gap),
                    "low_gap": float(adaptation_policy_config.low_gap),
                },
            },
            "variants": [
                {
                    "key": item.key,
                    "display_name": item.display_name,
                    "description": item.description,
                    "freeze_backbone": item.freeze_backbone,
                    "freeze_factor_projector": item.freeze_factor_projector,
                    "freeze_base_scoring_module": item.freeze_base_scoring_module,
                    "unfreeze_base_scoring_last_layer": item.unfreeze_base_scoring_last_layer,
                    "weight_param": item.weight_param,
                    "weight_mech": item.weight_mech,
                }
                for item in ABLATION_VARIANTS
                if item.key in variant_keys
            ],
        },
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
