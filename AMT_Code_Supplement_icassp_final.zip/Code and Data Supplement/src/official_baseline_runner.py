"""
文件功能:
1. 统一登记 AlphaMechTransfer 论文使用的第三方官方 baseline 目录、入口脚本与最小适配边界。
2. 基于当前项目的统一数据缓存, 生成 baseline 运行清单、环境依赖清单、外围资产构建命令与结果输出约定。
3. 仅负责外层调度与适配, 不修改任何官方 baseline 的核心模型实现。

代码逻辑:
1. 维护官方 baseline 注册表, 明确 repo 路径、入口命令、适用任务与数据约束。
2. 读取统一数据目录与结果目录协议, 为不同迁移方向生成标准化运行计划。
3. 将运行计划写出为 JSON/Markdown, 便于本地执行或服务器调度。

代码结构:
1. 项目常量与路径定义。
2. Baseline 规格定义与注册表。
3. 迁移方向与运行计划生成。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path

from experiment_workspace import get_categorized_result_path


ROOT_DIR = Path(__file__).resolve().parents[1]
OFFICIAL_DIR = ROOT_DIR / "third_party" / "official_baselines"
RESULT_DIR = get_categorized_result_path("other", "baseline_run_plans")
PROJECT_NAME = "AlphaMechTransfer"
PROJECT_TITLE = "AlphaMechTransfer: A Mechanism-Fused Hypergraph Framework for Quantitative Strategy Transfer"


@dataclass(frozen=True)
class BaselineSpec:
    name: str
    category: str
    repo_dir: str
    entrypoint: str
    official_source: str
    data_style: str
    supports_cross_market: bool
    supports_cross_asset: bool
    notes: str


BASELINES: tuple[BaselineSpec, ...] = (
    BaselineSpec(
        name="TRA",
        category="transfer",
        repo_dir="qlib-main  TRA/qlib-main",
        entrypoint="examples/benchmarks/TRA",
        official_source="Microsoft Qlib official benchmark",
        data_style="qlib",
        supports_cross_market=True,
        supports_cross_asset=True,
        notes="作为统一迁移强基线；仅修改数据入口、路径和结果导出。",
    ),
    BaselineSpec(
        name="DoubleAdapt",
        category="transfer",
        repo_dir="DoubleAdapt-main/DoubleAdapt-main",
        entrypoint="main.py",
        official_source="DoubleAdapt official code",
        data_style="qlib",
        supports_cross_market=True,
        supports_cross_asset=True,
        notes="官方实现要求自定义 _load_data/_evaluate_metrics；本项目仅在外层提供数据适配。",
    ),
    BaselineSpec(
        name="QuantNet",
        category="transfer",
        repo_dir="quantnet-main/quantnet-main",
        entrypoint="quantnet",
        official_source="QuantNet official code",
        data_style="numpy/pandas",
        supports_cross_market=True,
        supports_cross_asset=True,
        notes="用于策略迁移对比；可先在股票跨市场方向验证，再扩展到跨资产方向。",
    ),
    BaselineSpec(
        name="HIST",
        category="relation",
        repo_dir="HIST-main/HIST-main",
        entrypoint="learn.py",
        official_source="HIST official code",
        data_style="custom_pickles",
        supports_cross_market=True,
        supports_cross_asset=True,
        notes="官方仓库同时可跑 LSTM/Transformer；使用外层结果导出接口汇总。",
    ),
    BaselineSpec(
        name="MASTER",
        category="sequence",
        repo_dir="MASTER-master/MASTER-master",
        entrypoint="main.py",
        official_source="MASTER official code",
        data_style="custom_pickles",
        supports_cross_market=True,
        supports_cross_asset=True,
        notes="保留官方模型主体，仅适配数据与输出目录。",
    ),
    BaselineSpec(
        name="ADGAT",
        category="relation",
        repo_dir="ADGAT-main/ADGAT-main",
        entrypoint="main.py",
        official_source="ADGAT official code",
        data_style="custom_data",
        supports_cross_market=True,
        supports_cross_asset=False,
        notes="原论文依赖专有新闻与公司关系数据；当前作为附录级关系基线保留官方代码目录。",
    ),
    BaselineSpec(
        name="StockFormer",
        category="sequence",
        repo_dir="StockFormer-main/StockFormer-main",
        entrypoint="code/Transformer/main.py",
        official_source="StockFormer official code",
        data_style="csv",
        supports_cross_market=False,
        supports_cross_asset=False,
        notes="当前更适合作为补充时序强基线，不进入迁移主表。",
    ),
)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def build_command(spec: BaselineSpec, direction: str) -> str:
    repo_path = OFFICIAL_DIR / spec.repo_dir
    if spec.name == "TRA":
        return f"python run_baseline_adapter.py --baseline TRA --direction {direction} --repo \"{repo_path}\""
    if spec.name == "DoubleAdapt":
        return f"python run_baseline_adapter.py --baseline DoubleAdapt --direction {direction} --repo \"{repo_path}\""
    if spec.name == "QuantNet":
        return f"python run_baseline_adapter.py --baseline QuantNet --direction {direction} --repo \"{repo_path}\""
    if spec.name == "HIST":
        return f"python run_baseline_adapter.py --baseline HIST --direction {direction} --repo \"{repo_path}\""
    if spec.name == "MASTER":
        return f"python run_baseline_adapter.py --baseline MASTER --direction {direction} --repo \"{repo_path}\""
    if spec.name == "ADGAT":
        return f"python run_baseline_adapter.py --baseline ADGAT --direction {direction} --repo \"{repo_path}\" --appendix-only"
    return f"python run_baseline_adapter.py --baseline {spec.name} --direction {direction} --repo \"{repo_path}\" --supplementary"


def build_plan(direction: str) -> dict[str, object]:
    direction_key = direction.lower().replace(" ", "")
    tasks: list[dict[str, object]] = []
    for spec in BASELINES:
        if "future" in direction_key and not spec.supports_cross_asset:
            continue
        if "future" not in direction_key and not spec.supports_cross_market:
            continue
        tasks.append(
            {
                "baseline": spec.name,
                "category": spec.category,
                "repo_path": str(OFFICIAL_DIR / spec.repo_dir),
                "entrypoint": spec.entrypoint,
                "official_source": spec.official_source,
                "data_style": spec.data_style,
                "command": build_command(spec, direction),
                "artifact_builder": f"python official_baseline_artifact_builder.py --baseline {spec.name} --direction {direction}",
                "result_dir": str(get_categorized_result_path("baseline", "compare_models", direction_key, spec.name.lower())),
                "adaptation_boundary": [
                    "data_loader",
                    "path_config",
                    "label_generator",
                    "result_export",
                ],
                "notes": spec.notes,
            }
        )
    return {
        "project_name": PROJECT_NAME,
        "project_title": PROJECT_TITLE,
        "direction": direction,
        "task_count": len(tasks),
        "tasks": tasks,
    }


def write_plan(direction: str) -> dict[str, str]:
    ensure_dir(RESULT_DIR)
    payload = build_plan(direction)
    direction_key = direction.lower().replace(" ", "")
    json_path = RESULT_DIR / f"{direction_key}_baseline_plan.json"
    md_path = RESULT_DIR / f"{direction_key}_baseline_plan.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        f"# {PROJECT_NAME} baseline plan: {direction}",
        "",
        f"- Project title: `{PROJECT_TITLE}`",
        f"- Direction: `{direction}`",
        f"- Task count: `{payload['task_count']}`",
        "",
        "## Tasks",
        "",
    ]
    for task in payload["tasks"]:
        lines.extend(
            [
                f"### {task['baseline']}",
                f"- Category: `{task['category']}`",
                f"- Repo path: `{task['repo_path']}`",
                f"- Entrypoint: `{task['entrypoint']}`",
                f"- Official source: `{task['official_source']}`",
                f"- Data style: `{task['data_style']}`",
                f"- Result dir: `{task['result_dir']}`",
                f"- Artifact builder: `{task['artifact_builder']}`",
                f"- Command: `{task['command']}`",
                f"- Adaptation boundary: `{', '.join(task['adaptation_boundary'])}`",
                f"- Notes: {task['notes']}",
                "",
            ]
        )
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return {"json_path": str(json_path), "md_path": str(md_path)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成 AlphaMechTransfer 官方 baseline 运行计划")
    parser.add_argument(
        "--direction",
        default="CN_TO_US",
        choices=["CN_TO_US", "US_TO_CN", "CN_TO_FUTURE", "FUTURE_TO_CN"],
        help="需要生成计划的迁移方向",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    payload = write_plan(args.direction)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

