"""
文件功能:
1. 统一调度本项目的本地 demo、主实验、baseline 外层适配与结果同步流程。
2. 尽量复用根目录已验证的 `v1` 实验脚本, 在 `code/` 下提供新的部署层与批处理入口, 而不重复改写既有核心实现。
3. 将日志稳定写入 `resultsFromSSH/<server_name>/log`, 并把关键结果镜像到 `resultsFromSSH/<server_name>/results`。
4. 注意: 本文件中的 `stage=full` 指“主链 full”, 即 `demo/main/baseline_assets/(optional baseline_full_trial/future)`；
   若要满足论文级 full（额外包含关键消融与 multi-alpha），应使用 `run_unified_paper_full.sh`。

代码逻辑:
1. 根据 `stage` 选择执行分布式 demo、主实验、baseline 资产构建、baseline medium trial、期货实验或主链全流程。
2. 所有外部脚本都通过子进程调用, 并将 stdout/stderr 同步追加到统一日志文件, 便于服务器排障。
3. baseline 侧严格执行“最小适配”边界: 仅构建数据资产和适配 manifest, 不修改第三方仓库核心模型逻辑。
4. 执行结束后自动同步 `results/` 下关键结果到 `resultsFromSSH/<server_name>/results`, 满足论文取证与服务器回传需要。

代码结构:
1. 常量、baseline 注册表与命令执行工具。
2. 各阶段执行函数。
3. 结果同步与执行清单导出。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Any
import csv

import torch

from experiment_workspace import (
    append_log,
    build_runtime_paths,
    copy_path,
    ensure_dir,
    find_latest_output_path,
    get_categorized_result_path,
    get_run_timestamp,
    now_string,
    write_json,
)


ROOT_DIR = Path(__file__).resolve().parents[1]
CODE_DIR = Path(__file__).resolve().parent
PROCESS_PREFIX = "[EXP-LOG][PIPELINE]"
DONE_PREFIX = "[EXP-DONE][PIPELINE]"


@dataclass(frozen=True)
class BaselineTask:
    name: str
    repo_dir: str
    comparison_layer: str
    paper_role: str
    appendix_only: bool = False
    supplementary: bool = False


BASELINE_TASKS: tuple[BaselineTask, ...] = (
    BaselineTask(
        name="TRA",
        repo_dir="qlib-main  TRA/qlib-main",
        comparison_layer="adjacent_strong",
        paper_role="扩展对比",
    ),
    BaselineTask(
        name="DoubleAdapt",
        repo_dir="DoubleAdapt-main/DoubleAdapt-main",
        comparison_layer="adjacent_strong",
        paper_role="扩展对比",
    ),
    BaselineTask(
        name="HIST",
        repo_dir="HIST-main/HIST-main",
        comparison_layer="generic_predictor",
        paper_role="主表候选",
    ),
    BaselineTask(
        name="MASTER",
        repo_dir="MASTER-master/MASTER-master",
        comparison_layer="appendix_only",
        paper_role="附录",
    ),
    BaselineTask(
        name="QuantNet",
        repo_dir="quantnet-main/quantnet-main",
        comparison_layer="direct_transfer",
        paper_role="主表",
    ),
    BaselineTask(
        name="ADGAT",
        repo_dir="ADGAT-main/ADGAT-main",
        comparison_layer="appendix_only",
        paper_role="附录",
        appendix_only=True,
    ),
)


def normalize_directions(raw_value: str, uppercase: bool) -> list[str]:
    normalized: list[str] = []
    for item in str(raw_value).split(","):
        token = item.strip()
        if not token:
            continue
        normalized.append(token.upper() if uppercase else token.lower())
    return normalized


def normalize_model_list(raw_value: str) -> str:
    return ",".join([item.strip() for item in str(raw_value).split(",") if item.strip()])


def resolve_default_python_bin() -> str:
    """
    优先选择当前机器上已经验证可用的 qmt 环境，避免 `python` 落到缺少实验依赖的基础解释器。
    若用户显式传入 `--python-bin`，argparse 会覆盖这里的默认值。
    """
    candidate_values = [
        os.environ.get("AMT_PYTHON_BIN", "").strip(),
        "/data/zhoutm/miniconda3/envs/qmt/bin/python",
        sys.executable,
    ]
    for value in candidate_values:
        if value and Path(value).exists():
            return value
    return sys.executable


def resolve_torchrun(python_bin: str) -> str:
    python_path = Path(python_bin)
    if os.name == "nt":
        candidate = python_path.with_name("torchrun.exe")
        if candidate.exists():
            return str(candidate)
    else:
        candidate = python_path.with_name("torchrun")
        if candidate.exists():
            return str(candidate)
    return "torchrun"


def command_to_text(command: list[str]) -> str:
    return " ".join([f'"{item}"' if " " in item else item for item in command])


def normalize_gpu_devices(raw_value: str) -> str:
    return ",".join([item.strip() for item in str(raw_value).split(",") if item.strip() != ""])


def build_subprocess_env(args: argparse.Namespace) -> dict[str, str]:
    env = os.environ.copy()
    gpu_devices = normalize_gpu_devices(args.gpu_devices)
    if gpu_devices:
        env["CUDA_VISIBLE_DEVICES"] = gpu_devices
    env["AMT_RUN_TIMESTAMP"] = get_run_timestamp()
    env["AMT_ARCHIVE_PREFIX"] = "demo" if args.stage == "demo" else args.mode
    return env


def format_seconds(seconds: float) -> str:
    total_seconds = max(0, int(round(seconds)))
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def emit_pipeline_message(log_path: Path, prefix: str, message: str) -> None:
    text = f"{prefix} {message}"
    append_log(log_path, text)
    print(text, flush=True)


def validate_gpu_selection(args: argparse.Namespace) -> None:
    gpu_devices = normalize_gpu_devices(args.gpu_devices)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise ValueError("当前 --device=cuda，但环境未检测到可用 CUDA。请检查 PyTorch CUDA 安装或改为 --device=cpu。")
    if not gpu_devices:
        if args.stage in {"demo", "full"} and args.device.startswith("cuda") and args.demo_world_size > 1:
            visible_gpu_count = torch.cuda.device_count()
            if visible_gpu_count > 0 and args.demo_world_size > visible_gpu_count:
                raise ValueError(
                    f"demo_world_size={args.demo_world_size} 超过当前可见 GPU 数量 {visible_gpu_count}，"
                    "请减少 --demo-world-size 或显式指定 --gpu-devices。"
                )
        return
    selected_devices = gpu_devices.split(",")
    if args.device.startswith("cpu"):
        raise ValueError("指定了 --gpu-devices，但当前 --device=cpu，请改为 --device=cuda 或移除 --gpu-devices。")
    if args.stage in {"demo", "full"} and args.demo_world_size > len(selected_devices):
        raise ValueError(
            f"demo_world_size={args.demo_world_size} 超过了可见 GPU 数量 {len(selected_devices)}，"
            "请减少 --demo-world-size 或增加 --gpu-devices。"
        )


def run_command(
    command: list[str],
    log_path: Path,
    cwd: Path,
    env: dict[str, str] | None = None,
    stage_label: str = "subprocess",
) -> None:
    emit_pipeline_message(log_path, PROCESS_PREFIX, f"{stage_label} RUN {command_to_text(command)}")
    if env and env.get("CUDA_VISIBLE_DEVICES"):
        emit_pipeline_message(log_path, PROCESS_PREFIX, f"{stage_label} CUDA_VISIBLE_DEVICES={env['CUDA_VISIBLE_DEVICES']}")
    with log_path.open("a", encoding="utf-8") as fp:
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert process.stdout is not None
        for line in process.stdout:
            fp.write(line)
            fp.flush()
            print(f"{PROCESS_PREFIX} [{stage_label}] {line.rstrip()}", flush=True)
        process.wait()
    if process.returncode != 0:
        raise RuntimeError(f"命令执行失败: {command_to_text(command)}")


def build_demo_command(args: argparse.Namespace) -> list[str]:
    demo_script = CODE_DIR / "distributed_transfer_demo.py"
    base_command = [
        args.python_bin,
        str(demo_script),
        "--source-market",
        args.demo_source_market.upper(),
        "--target-market",
        args.demo_target_market.upper(),
        "--lookback",
        str(args.demo_lookback),
        "--max-symbols",
        str(args.demo_max_symbols),
        "--train-dates",
        str(args.demo_train_dates),
        "--valid-dates",
        str(args.demo_valid_dates),
        "--test-dates",
        str(args.demo_test_dates),
        "--batch-size",
        str(args.demo_batch_size),
        "--pretrain-epochs",
        str(args.demo_pretrain_epochs),
        "--adapt-epochs",
        str(args.demo_adapt_epochs),
        "--output-name",
        args.demo_output_name,
        "--device",
        args.device,
    ]
    if args.server_name:
        base_command.extend(["--server-name", args.server_name])
    if args.demo_world_size <= 1:
        return base_command
    torchrun_bin = resolve_torchrun(args.python_bin)
    command = [
        torchrun_bin,
        "--standalone",
        "--nproc_per_node",
        str(args.demo_world_size),
        str(demo_script),
        "--source-market",
        args.demo_source_market.upper(),
        "--target-market",
        args.demo_target_market.upper(),
        "--lookback",
        str(args.demo_lookback),
        "--max-symbols",
        str(args.demo_max_symbols),
        "--train-dates",
        str(args.demo_train_dates),
        "--valid-dates",
        str(args.demo_valid_dates),
        "--test-dates",
        str(args.demo_test_dates),
        "--batch-size",
        str(args.demo_batch_size),
        "--pretrain-epochs",
        str(args.demo_pretrain_epochs),
        "--adapt-epochs",
        str(args.demo_adapt_epochs),
        "--output-name",
        args.demo_output_name,
        "--device",
        args.device,
    ]
    if args.server_name:
        command.extend(["--server-name", args.server_name])
    return command


def run_demo(args: argparse.Namespace, log_path: Path) -> list[str]:
    command = build_demo_command(args)
    run_command(command, log_path=log_path, cwd=ROOT_DIR, env=build_subprocess_env(args), stage_label="demo")
    return [command_to_text(command)]


def run_main_experiment(args: argparse.Namespace, log_path: Path) -> list[str]:
    command = [
        args.python_bin,
        str(CODE_DIR / "experiment_runner.py"),
        "--mode",
        args.mode,
        "--direction",
        ",".join(normalize_directions(args.directions, uppercase=False)),
        "--models",
        normalize_model_list(args.models),
        "--max-symbols",
        str(args.max_symbols),
        "--lookback",
        str(args.lookback),
        "--top-k",
        str(args.top_k),
        "--amt-top-r",
        str(args.amt_top_r),
        "--amt-gate-temperature",
        str(args.amt_gate_temperature),
        "--amt-alpha-residual-scale",
        str(args.amt_alpha_residual_scale),
        "--amt-delta-clip",
        str(args.amt_delta_clip),
        "--amt-min-gate-mass",
        str(args.amt_min_gate_mass),
        "--amt-weight-param",
        str(args.amt_weight_param),
        "--amt-weight-mech",
        str(args.amt_weight_mech),
        "--device",
        args.device,
    ]
    if args.force_rebuild:
        command.append("--force-rebuild")
    if args.rerun_existing:
        command.append("--rerun-existing")
    run_command(command, log_path=log_path, cwd=ROOT_DIR, env=build_subprocess_env(args), stage_label="main")
    return [command_to_text(command)]


def run_future_experiment(args: argparse.Namespace, log_path: Path) -> list[str]:
    command = [
        args.python_bin,
        str(CODE_DIR / "future_hgnn_experiment_runner.py"),
        "--top-k",
        str(args.top_k),
        "--device",
        args.device,
    ]
    if args.force_rebuild:
        command.append("--force-rebuild")
    run_command(command, log_path=log_path, cwd=ROOT_DIR, env=build_subprocess_env(args), stage_label="future")
    return [command_to_text(command)]


def run_baseline_assets(args: argparse.Namespace, log_path: Path) -> list[str]:
    commands: list[str] = []
    direction_list = normalize_directions(args.directions, uppercase=True)
    requested_baselines = {item.strip().upper() for item in args.baselines.split(",") if item.strip()}
    for direction in direction_list:
        for task in BASELINE_TASKS:
            if task.name.upper() not in requested_baselines:
                continue
            if "FUTURE" in direction and task.name.upper() == "ADGAT":
                emit_pipeline_message(
                    log_path,
                    PROCESS_PREFIX,
                    f"baseline_assets SKIP {task.name} {direction} because ADGAT does not support cross-asset mode.",
                )
                continue
            build_command = [
                args.python_bin,
                str(CODE_DIR / "official_baseline_artifact_builder.py"),
                "--baseline",
                task.name,
                "--direction",
                direction,
                "--mode",
                args.mode,
            ]
            run_command(
                build_command,
                log_path=log_path,
                cwd=ROOT_DIR,
                env=build_subprocess_env(args),
                stage_label=f"baseline_assets:{task.name}:{direction}:build",
            )
            commands.append(command_to_text(build_command))

            adapter_command = [
                args.python_bin,
                str(CODE_DIR / "run_baseline_adapter.py"),
                "--baseline",
                task.name,
                "--direction",
                direction,
                "--repo",
                str(ROOT_DIR / "third_party" / "official_baselines" / task.repo_dir),
                "--skip-build-assets",
            ]
            if task.appendix_only:
                adapter_command.append("--appendix-only")
            if task.supplementary:
                adapter_command.append("--supplementary")
            run_command(
                adapter_command,
                log_path=log_path,
                cwd=ROOT_DIR,
                env=build_subprocess_env(args),
                stage_label=f"baseline_assets:{task.name}:{direction}:adapter",
            )
            commands.append(command_to_text(adapter_command))
    return commands


def run_baseline_trial(args: argparse.Namespace, log_path: Path) -> list[str]:
    command = [
        args.python_bin,
        str(CODE_DIR / "official_baseline_medium_trial_runner.py"),
        "--phase",
        "all",
    ]
    run_command(command, log_path=log_path, cwd=ROOT_DIR, env=build_subprocess_env(args), stage_label="baseline_trial")
    return [command_to_text(command)]


def run_baseline_full_trial(args: argparse.Namespace, log_path: Path) -> list[str]:
    command = [
        args.python_bin,
        str(CODE_DIR / "official_baseline_full_trial_runner.py"),
        "--mode",
        args.mode,
        "--directions",
        ",".join(normalize_directions(args.directions, uppercase=True)),
        "--baselines",
        normalize_model_list(args.baselines),
        "--lookback",
        str(args.lookback),
        "--top-k",
        str(args.top_k),
        "--max-symbols",
        str(args.max_symbols),
        "--device",
        args.device,
    ]
    if args.force_rebuild:
        command.append("--force-rebuild")
    if args.rerun_existing:
        command.append("--rerun-existing")
    run_command(
        command,
        log_path=log_path,
        cwd=ROOT_DIR,
        env=build_subprocess_env(args),
        stage_label="baseline_full_trial",
    )
    return [command_to_text(command)]


def sync_outputs(server_name: str) -> dict[str, str]:
    runtime_paths = build_runtime_paths(server_name)
    copied: dict[str, str] = {}
    path_pairs = [
        (get_categorized_result_path("main", "phase1_transfer"), runtime_paths.mirror_result_dir / "主实验" / "phase1_transfer"),
        (get_categorized_result_path("main", "alpha_case"), runtime_paths.mirror_result_dir / "主实验" / "alpha_case"),
        (get_categorized_result_path("baseline", "official_baseline_artifacts"), runtime_paths.mirror_result_dir / "对比实验" / "official_baseline_artifacts"),
        (get_categorized_result_path("baseline", "baseline_adapter"), runtime_paths.mirror_result_dir / "对比实验" / "baseline_adapter"),
        (get_categorized_result_path("baseline", "medium_trial"), runtime_paths.mirror_result_dir / "对比实验" / "medium_trial"),
        (get_categorized_result_path("baseline", "baseline_full_trial"), runtime_paths.mirror_result_dir / "对比实验" / "baseline_full_trial"),
        (get_categorized_result_path("ablation", "regime_ablation"), runtime_paths.mirror_result_dir / "消融实验" / "regime_ablation"),
        (get_categorized_result_path("other", "future_hgnn_time_report.json"), runtime_paths.mirror_result_dir / "其他" / "future_hgnn_time_report.json"),
        (get_categorized_result_path("other", "future_experiment_time_report.json"), runtime_paths.mirror_result_dir / "其他" / "future_experiment_time_report.json"),
    ]
    for src, dst in path_pairs:
        if src.exists():
            copy_path(src, dst)
            copied[str(src)] = str(dst)
    demo_root = runtime_paths.result_dir / "ddp_demo"
    if demo_root.exists():
        demo_dst = runtime_paths.mirror_result_dir / "demo" / demo_root.name
        copy_path(demo_root, demo_dst)
        copied[str(demo_root)] = str(demo_dst)
    if runtime_paths.log_dir.exists():
        for log_file in runtime_paths.log_dir.iterdir():
            if log_file.is_file():
                mirrored_log = runtime_paths.mirror_log_dir / log_file.name
                copy_path(log_file, mirrored_log)
                copied[str(log_file)] = str(mirrored_log)
    return copied


def summarize_demo_results(args: argparse.Namespace) -> dict[str, Any]:
    summary_path = find_latest_output_path(build_runtime_paths(args.server_name).result_dir / args.demo_output_name / "summary.json")
    if not summary_path.exists():
        return {"summary_path": str(summary_path), "status": "missing"}
    payload = json.loads(summary_path.read_text(encoding="utf-8"))
    metrics = payload.get("metrics", {})
    return {
        "summary_path": str(summary_path),
        "mse": metrics.get("mse"),
        "rank_ic_mean": metrics.get("rank_ic_mean"),
        "sample_count": metrics.get("sample_count"),
        "date_count": metrics.get("date_count"),
    }


def summarize_main_results() -> dict[str, Any]:
    summary_path = find_latest_output_path(get_categorized_result_path("main", "phase1_transfer", "all_summary.csv"))
    if not summary_path.exists():
        return {"summary_path": str(summary_path), "status": "missing"}
    with summary_path.open("r", encoding="utf-8-sig", newline="") as fp:
        rows = list(csv.DictReader(fp))
    summary: dict[str, Any] = {
        "summary_path": str(summary_path),
        "row_count": len(rows),
    }
    if rows:
        def rankic_value(row: dict[str, str]) -> float:
            try:
                return float(row.get("RankIC", "nan"))
            except ValueError:
                return float("-inf")

        best_row = max(rows, key=rankic_value)
        summary["best_row"] = {
            "direction": best_row.get("direction"),
            "model": best_row.get("model"),
            "RankIC": best_row.get("RankIC"),
            "IC": best_row.get("IC"),
        }
    return summary


def summarize_baseline_assets() -> dict[str, Any]:
    artifact_root = get_categorized_result_path("baseline", "official_baseline_artifacts")
    manifests = list(artifact_root.rglob("artifact_manifest.json")) if artifact_root.exists() else []
    return {"artifact_root": str(artifact_root), "artifact_manifest_count": len(manifests)}


def summarize_baseline_full_trial() -> dict[str, Any]:
    summary_path = find_latest_output_path(get_categorized_result_path("baseline", "baseline_full_trial", "all_full_trial_summary.csv"))
    if not summary_path.exists():
        return {"summary_path": str(summary_path), "status": "missing"}
    with summary_path.open("r", encoding="utf-8-sig", newline="") as fp:
        rows = list(csv.DictReader(fp))
    return {
        "summary_path": str(summary_path),
        "row_count": len(rows),
        "completed_baselines": sorted({str(row.get("baseline", "")) for row in rows if row.get("baseline")}),
    }


def summarize_future_results() -> dict[str, Any]:
    report_path = find_latest_output_path(get_categorized_result_path("other", "future_hgnn_time_report.json"))
    if not report_path.exists():
        return {"report_path": str(report_path), "status": "missing"}
    payload = json.loads(report_path.read_text(encoding="utf-8"))
    return {"report_path": str(report_path), "keys": sorted(payload.keys())[:8]}


def build_core_result_summary(args: argparse.Namespace) -> dict[str, Any]:
    if args.stage == "demo":
        return {"demo": summarize_demo_results(args)}
    if args.stage == "main":
        return {"main": summarize_main_results()}
    if args.stage == "future":
        return {"future": summarize_future_results()}
    if args.stage == "baseline_assets":
        return {"baseline_assets": summarize_baseline_assets()}
    if args.stage == "baseline_trial":
        return {"baseline_assets": summarize_baseline_assets()}
    if args.stage == "baseline_full_trial":
        return {"baseline_full_trial": summarize_baseline_full_trial()}
    if args.stage == "sync":
        return {"sync": "completed"}
    summary: dict[str, Any] = {
        "demo": summarize_demo_results(args),
        "main": summarize_main_results(),
        "baseline_assets": summarize_baseline_assets(),
    }
    if args.with_future:
        summary["future"] = summarize_future_results()
    if args.with_baseline_full_trial:
        summary["baseline_full_trial"] = summarize_baseline_full_trial()
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AlphaMechTransfer 实验部署总控脚本")
    parser.add_argument(
        "--stage",
        default="full",
        choices=["demo", "main", "future", "baseline_assets", "baseline_trial", "baseline_full_trial", "sync", "full"],
        help="选择当前要执行的阶段",
    )
    parser.add_argument(
        "--server-name",
        default="",
        help="可选运行标签。为空时自动使用 `AMT_SERVER_NAME` 或当前主机名作为结果输出目录名。",
    )
    parser.add_argument("--python-bin", default=resolve_default_python_bin())
    parser.add_argument("--mode", default="medium", choices=["medium", "full"])
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--gpu-devices",
        default="",
        help="指定要使用的 GPU 卡号列表，例如 `0,1,2,3`。为空时保持当前系统默认可见卡。",
    )
    parser.add_argument("--directions", default="cn_to_us,us_to_cn")
    parser.add_argument("--models", default="lasso,xgboost,lstm,transformer,tra,hist,main_transfer")
    parser.add_argument("--baselines", default="TRA,DoubleAdapt,HIST,MASTER,QuantNet,ADGAT")
    parser.add_argument("--lookback", type=int, default=12)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--max-symbols", type=int, default=64)
    parser.add_argument("--amt-top-r", type=int, default=3)
    parser.add_argument("--amt-gate-temperature", type=float, default=0.70)
    parser.add_argument("--amt-alpha-residual-scale", type=float, default=0.35)
    parser.add_argument("--amt-delta-clip", type=float, default=0.75)
    parser.add_argument("--amt-min-gate-mass", type=float, default=1e-6)
    parser.add_argument("--amt-weight-param", type=float, default=0.002)
    parser.add_argument("--amt-weight-mech", type=float, default=0.0005)
    parser.add_argument("--force-rebuild", action="store_true")
    parser.add_argument("--rerun-existing", action="store_true")
    parser.add_argument("--with-baseline-trial", action="store_true")
    parser.add_argument("--with-baseline-full-trial", action="store_true")
    parser.add_argument("--with-future", action="store_true")
    parser.add_argument("--demo-world-size", type=int, default=1)
    parser.add_argument("--demo-source-market", default="CN")
    parser.add_argument("--demo-target-market", default="US")
    parser.add_argument("--demo-lookback", type=int, default=12)
    parser.add_argument("--demo-max-symbols", type=int, default=6)
    parser.add_argument("--demo-train-dates", type=int, default=120)
    parser.add_argument("--demo-valid-dates", type=int, default=40)
    parser.add_argument("--demo-test-dates", type=int, default=60)
    parser.add_argument("--demo-batch-size", type=int, default=64)
    parser.add_argument("--demo-pretrain-epochs", type=int, default=2)
    parser.add_argument("--demo-adapt-epochs", type=int, default=2)
    parser.add_argument("--demo-output-name", default="ddp_demo")
    args = parser.parse_args()
    # `full` 模式若继续沿用默认 `64`，会把股票池规模错误限制在 `medium` 口径。
    # 这里仅在未显式改动默认值的情况下提升到全量上限。
    if args.mode == "full" and int(args.max_symbols) == 64:
        args.max_symbols = 160
    return args


def main() -> int:
    args = parse_args()
    os.environ["AMT_ARCHIVE_PREFIX"] = "demo" if args.stage == "demo" else args.mode
    validate_gpu_selection(args)
    runtime_paths = build_runtime_paths(args.server_name)
    args.server_name = runtime_paths.server_name
    log_path = runtime_paths.log_dir / f"experiment_pipeline_{args.stage}.log"
    manifest_path = runtime_paths.result_dir / f"experiment_pipeline_{args.stage}_manifest.json"
    executed_commands: list[str] = []
    stage_failures: list[dict[str, Any]] = []
    run_timestamp = get_run_timestamp()
    started_at = now_string()
    start_perf = time.perf_counter()
    emit_pipeline_message(
        log_path,
        PROCESS_PREFIX,
        (
            f"pipeline started | stage={args.stage} | mode={args.mode} | device={args.device} | "
            f"gpu_devices={normalize_gpu_devices(args.gpu_devices) or 'system-default'} | "
            f"run_timestamp={run_timestamp} | started_at={started_at}"
        ),
    )

    stage_plan: list[tuple[str, Any]] = []
    if args.stage == "demo":
        stage_plan = [("demo", run_demo)]
    elif args.stage == "main":
        stage_plan = [("main", run_main_experiment)]
    elif args.stage == "future":
        stage_plan = [("future", run_future_experiment)]
    elif args.stage == "baseline_assets":
        stage_plan = [("baseline_assets", run_baseline_assets)]
    elif args.stage == "baseline_trial":
        stage_plan = [("baseline_trial", run_baseline_trial)]
    elif args.stage == "baseline_full_trial":
        stage_plan = [("baseline_full_trial", run_baseline_full_trial)]
    elif args.stage == "sync":
        stage_plan = []
    else:
        stage_plan = [
            ("demo", run_demo),
            ("main", run_main_experiment),
            ("baseline_assets", run_baseline_assets),
        ]
        if args.with_baseline_trial:
            stage_plan.append(("baseline_trial", run_baseline_trial))
        if args.with_baseline_full_trial:
            stage_plan.append(("baseline_full_trial", run_baseline_full_trial))
        if args.with_future:
            stage_plan.append(("future", run_future_experiment))

    total_steps = max(1, len(stage_plan))
    for index, (stage_name, runner) in enumerate(stage_plan, start=1):
        start_percent = 100.0 * (index - 1) / total_steps
        emit_pipeline_message(
            log_path,
            PROCESS_PREFIX,
            f"stage entering | current_stage={stage_name} | progress={start_percent:.1f}% | step={index}/{total_steps}",
        )
        try:
            executed_commands.extend(runner(args, log_path))
        except Exception as exc:
            stage_failures.append(
                {
                    "stage": stage_name,
                    "step_index": index,
                    "error_type": exc.__class__.__name__,
                    "error_message": str(exc),
                }
            )
            emit_pipeline_message(
                log_path,
                PROCESS_PREFIX,
                f"stage failed | current_stage={stage_name} | error_type={exc.__class__.__name__} | error={str(exc)}",
            )
            if args.stage == "full" and stage_name == "main":
                emit_pipeline_message(
                    log_path,
                    PROCESS_PREFIX,
                    "stage continue | current_stage=main | reason=allow baseline stages to continue after main failure",
                )
                continue
            raise
        end_percent = 100.0 * index / total_steps
        emit_pipeline_message(
            log_path,
            PROCESS_PREFIX,
            f"stage finished | current_stage={stage_name} | progress={end_percent:.1f}% | step={index}/{total_steps}",
        )

    synced_outputs = sync_outputs(args.server_name)
    elapsed_seconds = float(time.perf_counter() - start_perf)
    ended_at = now_string()
    core_result_summary = build_core_result_summary(args)
    payload = {
        "stage": args.stage,
        "server_name": args.server_name,
        "mode": args.mode,
        "device": args.device,
        "gpu_devices": normalize_gpu_devices(args.gpu_devices),
        "started_at": started_at,
        "run_timestamp": run_timestamp,
        "ended_at": ended_at,
        "elapsed_seconds": elapsed_seconds,
        "elapsed_human": format_seconds(elapsed_seconds),
        "final_status": "PARTIAL_SUCCESS" if stage_failures else "SUCCESS",
        "archive_dir": str(runtime_paths.result_dir),
        "archive_log_dir": str(runtime_paths.log_dir),
        "mirror_root_dir": str(runtime_paths.mirror_root_dir),
        "executed_commands": executed_commands,
        "stage_failures": stage_failures,
        "synced_outputs": synced_outputs,
        "core_result_summary": core_result_summary,
        "log_path": str(log_path),
        "fairness_note": "baseline 仅做数据入口与结果接口最小适配，不人为压低任何第三方模型指标。",
    }
    write_json(manifest_path, payload)
    emit_pipeline_message(
        log_path,
        DONE_PREFIX,
        (
            f"pipeline finished | ended_at={ended_at} | elapsed={format_seconds(elapsed_seconds)} | "
            f"status={payload['final_status']} | stage={args.stage} | "
            f"summary={json.dumps(core_result_summary, ensure_ascii=False)}"
        ),
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
