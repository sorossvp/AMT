"""
文件功能:
1. 统一驱动 `CN -> US` 与 `US -> CN` 两个方向的第一阶段实验。
2. 基于 `data_pipeline.py` 生成的数据底座, 训练基线模型和主模型并输出预测结果。
3. 计算 `IC / RankIC / NDCG@K / Annualized Return / Sharpe / Max Drawdown` 等核心指标。
4. 将结果、预测文件与回测曲线统一保存到 `results/phase1_transfer` 下。

代码逻辑:
1. 先加载源市场与目标市场面板数据和静态超图。
2. 构造序列样本、表格特征、alpha 特征、概念向量和 regime 编码。
3. 对目标市场训练非迁移基线, 对主模型执行“源域预训练 + 目标域轻量适配”。
4. 在目标市场测试集上统一评估并做轻量化 Top-k 回测。
5. 生成模型级文件夹与总汇总表, 便于论文写作和后续严谨回测复核。

代码结构:
1. 常量定义与指标函数。
2. 样本构造与标准化。
3. 基线训练与主模型迁移训练。
4. 结果落盘与命令行入口。
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
import threading
import time
from typing import Any

import numpy as np
import random
import pandas as pd
import torch
from scipy.stats import rankdata, spearmanr
from sklearn.preprocessing import StandardScaler

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parent))

from data_pipeline import MAX_REASONABLE_FUTURE_RETURN, SplitConfig, prepare_transfer_artifacts
from experiment_profiles import get_profile, profile_to_dict, resolve_max_symbols
from experiment_workspace import find_latest_output_path, get_categorized_result_path, write_dataframe, write_json
from market_similarity import (
    AdaptationPolicyConfig,
    MarketSimilarityConfig,
    ThresholdUpdateConfig,
    build_adaptation_param_groups,
    collect_optimizer_group_summary,
    compute_market_similarity,
    recommend_similarity_threshold,
    render_similarity_report_markdown,
    resolve_adaptation_policy,
    update_threshold_history,
)
from models import (
    AMTScoringConfig,
    ALPHA_FEATURES,
    LassoWrapper,
    SequencePanelDataset,
    SupervisedLossConfig,
    TorchTrainingConfig,
    XGBoostWrapper,
    build_torch_model,
    fit_torch_regressor,
    predict_torch_regressor,
    unwrap_model,
)


ROOT_DIR = Path(__file__).resolve().parents[1]
ALL_MODEL_NAMES = ["lasso", "xgboost", "lstm", "transformer", "tra", "hist", "main_transfer"]
DIRECTION_SPECS = {
    "cn_to_us": ("CN", "US"),
    "us_to_cn": ("US", "CN"),
}
SEQ_FEATURES = [
    "open",
    "high",
    "low",
    "close",
    "volume",
    "ret_1",
    "ret_5",
    "vol_20",
    "ma_ratio_5_20",
    "turnover_proxy",
]
TABULAR_FEATURES = [
    "ret_1",
    "ret_5",
    "ret_10",
    "ret_20",
    "vol_5",
    "vol_20",
    "vol_60",
    "ma_ratio_5_20",
    "ma_ratio_20_60",
    "hl_spread",
    "oc_return",
    "turnover_proxy",
    "log_dollar_volume",
    "volume_momentum_20",
    "reversal_5",
    *ALPHA_FEATURES,
]
REGIME_TO_ID = {"bear": 0, "neutral": 1, "bull": 2, "shock": 3}
PROCESS_PREFIX = "[EXP-LOG][MAIN]"
DONE_PREFIX = "[EXP-DONE][MAIN]"
HEARTBEAT_SECONDS = 300


def get_phase1_result_dir() -> Path:
    return get_categorized_result_path("main", "phase1_transfer")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def format_seconds(seconds: float) -> str:
    total_seconds = max(0, int(round(seconds)))
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def format_progress(current: int, total: int) -> str:
    if total <= 0:
        return "0.0%"
    return f"{100.0 * current / total:.1f}%"


def summarize_metrics(metrics: dict[str, float]) -> str:
    ordered_keys = ["IC", "RankIC", "NDCG@20", "Annualized Return", "AnnualizedReturn", "Sharpe", "Max Drawdown", "Calmar Ratio"]
    parts: list[str] = []
    for key in ordered_keys:
        if key not in metrics:
            continue
        value = metrics.get(key)
        if value is None or (isinstance(value, float) and np.isnan(value)):
            continue
        try:
            parts.append(f"{key}={float(value):.6f}")
        except (TypeError, ValueError):
            continue
    return " | ".join(parts[:5]) if parts else "no-metrics"


class ModelHeartbeat:
    def __init__(self, direction_name: str, model_name: str, progress_text: str) -> None:
        self.direction_name = direction_name
        self.model_name = model_name
        self.progress_text = progress_text
        self.start_time = time.perf_counter()
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        self._thread.join(timeout=0.5)

    def _run(self) -> None:
        while not self._stop_event.wait(HEARTBEAT_SECONDS):
            elapsed = format_seconds(time.perf_counter() - self.start_time)
            log(
                f"{PROCESS_PREFIX} heartbeat | 当前方向={self.direction_name} | 当前模型={self.model_name} | "
                f"方向内完成百分比={self.progress_text} | 已运行={elapsed} | 状态=RUNNING"
            )


def parse_csv_args(raw_value: str | None) -> list[str]:
    if raw_value is None:
        return []
    return [item.strip() for item in raw_value.split(",") if item.strip()]


def normalize_direction(value: str) -> str:
    normalized = value.strip().lower().replace("-", "_").replace("->", "_to_")
    if normalized not in DIRECTION_SPECS:
        raise ValueError(f"不支持的方向参数: {value}")
    return normalized


def normalize_model_name(value: str) -> str:
    normalized = value.strip().lower()
    alias_map = {
        "main": "main_transfer",
        "maintransfer": "main_transfer",
        "main_transfer": "main_transfer",
    }
    normalized = alias_map.get(normalized, normalized)
    if normalized not in ALL_MODEL_NAMES:
        raise ValueError(f"不支持的模型参数: {value}")
    return normalized


def scale_epoch_count(base_epochs: int, mode: str, minimum_epochs: int = 2) -> int:
    profile = get_profile(mode)
    return max(minimum_epochs, int(round(base_epochs * profile.torch_epoch_scale)))


def build_amt_scoring_config(args: argparse.Namespace) -> AMTScoringConfig:
    return AMTScoringConfig(
        top_r=int(args.amt_top_r),
        gate_temperature=float(args.amt_gate_temperature),
        alpha_residual_scale=float(args.amt_alpha_residual_scale),
        delta_clip=float(args.amt_delta_clip),
        min_gate_mass=float(args.amt_min_gate_mass),
    )


def amt_scoring_config_to_dict(config: AMTScoringConfig) -> dict[str, float | int]:
    return {
        "hidden_dim": int(config.hidden_dim),
        "top_r": int(config.top_r),
        "gate_temperature": float(config.gate_temperature),
        "alpha_residual_scale": float(config.alpha_residual_scale),
        "delta_clip": float(config.delta_clip),
        "min_gate_mass": float(config.min_gate_mass),
    }


def build_amt_supervised_loss_config(args: argparse.Namespace) -> SupervisedLossConfig:
    return SupervisedLossConfig(
        objective=str(args.amt_supervised_objective),
        rank_weight=float(args.amt_rank_loss_weight),
        return_weight=float(args.amt_return_loss_weight),
        mse_weight=float(args.amt_mse_anchor_weight),
        pairwise_label_threshold=float(args.amt_pairwise_label_threshold),
        return_temperature=float(args.amt_return_temperature),
        annualization_factor=float(args.amt_annualization_factor),
    )


def amt_supervised_loss_config_to_dict(config: SupervisedLossConfig) -> dict[str, float | str]:
    return {
        "objective": str(config.objective),
        "rank_weight": float(config.rank_weight),
        "return_weight": float(config.return_weight),
        "mse_weight": float(config.mse_weight),
        "pairwise_label_threshold": float(config.pairwise_label_threshold),
        "return_temperature": float(config.return_temperature),
        "annualization_factor": float(config.annualization_factor),
    }


def build_market_similarity_config(args: argparse.Namespace) -> MarketSimilarityConfig:
    return MarketSimilarityConfig(
        sample_size=int(args.market_similarity_sample_size),
        batch_size=int(args.market_similarity_batch_size),
        rbf_gamma=float(args.market_similarity_rbf_gamma),
    )


def build_threshold_update_config(args: argparse.Namespace) -> ThresholdUpdateConfig:
    return ThresholdUpdateConfig(
        base_threshold=float(args.market_similarity_threshold),
        update_method=str(args.market_threshold_update_method),
        quantile=float(args.market_threshold_quantile),
        ema_decay=float(args.market_threshold_ema_decay),
    )


def build_adaptation_policy_config(args: argparse.Namespace) -> AdaptationPolicyConfig:
    return AdaptationPolicyConfig(
        medium_gap=float(args.market_similarity_medium_gap),
        low_gap=float(args.market_similarity_low_gap),
    )


def read_existing_summary(result_dir: Path) -> dict[str, float] | None:
    summary_path = find_latest_output_path(result_dir / "summary.json")
    prediction_path = find_latest_output_path(result_dir / "test_predictions.csv")
    curve_path = find_latest_output_path(result_dir / "equity_curve.csv")
    if not summary_path.exists() or not prediction_path.exists() or not curve_path.exists():
        return None
    return json.loads(summary_path.read_text(encoding="utf-8"))


def gather_direction_summary(direction_key: str) -> pd.DataFrame:
    if direction_key not in DIRECTION_SPECS:
        raise ValueError(direction_key)
    source_market, target_market = DIRECTION_SPECS[direction_key]
    experiment_dir = get_phase1_result_dir() / direction_key
    rows: list[dict[str, Any]] = []
    for model_name in ALL_MODEL_NAMES:
        # 汇总阶段不重新训练，而是直接读取模型目录里的 summary.json，
        # 这样可以支持断点续跑和跨多次会话累积实验结果。
        summary = read_existing_summary(experiment_dir / model_name)
        if summary is None:
            continue
        rows.append({"direction": f"{source_market}->{target_market}", "model": model_name, **summary})
    summary_df = pd.DataFrame(rows)
    if not summary_df.empty:
        write_dataframe(summary_df, experiment_dir / "summary.csv", index=False, encoding="utf-8-sig")
    return summary_df


def gather_all_summaries(direction_keys: list[str]) -> pd.DataFrame:
    summary_frames = [gather_direction_summary(direction_key) for direction_key in direction_keys]
    summary_frames = [frame for frame in summary_frames if not frame.empty]
    return pd.concat(summary_frames, axis=0, ignore_index=True) if summary_frames else pd.DataFrame()


def infer_split(date_value: pd.Timestamp, split: SplitConfig) -> str | None:
    if pd.Timestamp(split.train_start) <= date_value <= pd.Timestamp(split.train_end):
        return "train"
    if pd.Timestamp(split.valid_start) <= date_value <= pd.Timestamp(split.valid_end):
        return "valid"
    if pd.Timestamp(split.test_start) <= date_value <= pd.Timestamp(split.test_end):
        return "test"
    return None


def ndcg_at_k(labels: np.ndarray, scores: np.ndarray, k: int = 20) -> float:
    if labels.size == 0:
        return np.nan
    k = int(min(k, labels.size))
    order = np.argsort(scores)[::-1][:k]
    ideal = np.argsort(labels)[::-1][:k]
    clipped_labels = np.clip(labels, -10.0, 10.0)
    gains = (2 ** clipped_labels[order] - 1.0) / np.log2(np.arange(2, k + 2))
    ideal_gains = (2 ** clipped_labels[ideal] - 1.0) / np.log2(np.arange(2, k + 2))
    denom = float(np.sum(ideal_gains))
    if denom == 0.0:
        return np.nan
    return float(np.sum(gains) / denom)


def sanitize_prediction_frame(pred_df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, int]]:
    work_df = pred_df.copy()
    original_count = int(len(work_df))
    for column in ["prediction", "label", "future_return"]:
        work_df[column] = pd.to_numeric(work_df[column], errors="coerce")
    work_df = work_df.replace([np.inf, -np.inf], np.nan)
    extreme_label_count = int((work_df["label"].abs() > MAX_REASONABLE_FUTURE_RETURN).fillna(False).sum())
    extreme_return_count = int((work_df["future_return"].abs() > MAX_REASONABLE_FUTURE_RETURN).fillna(False).sum())
    work_df.loc[work_df["label"].abs() > MAX_REASONABLE_FUTURE_RETURN, "label"] = np.nan
    work_df.loc[work_df["future_return"].abs() > MAX_REASONABLE_FUTURE_RETURN, "future_return"] = np.nan
    invalid_date_count = int(work_df["date"].isna().sum())
    invalid_symbol_count = int(work_df["symbol"].isna().sum())
    invalid_label_count = int(work_df["label"].isna().sum())
    invalid_prediction_count = int(work_df["prediction"].isna().sum())
    invalid_return_count = int(work_df["future_return"].isna().sum())
    work_df = work_df.dropna(subset=["date", "symbol", "label", "future_return"]).copy()
    stats = {
        "original_row_count": original_count,
        "invalid_date_count": invalid_date_count,
        "invalid_symbol_count": invalid_symbol_count,
        "invalid_label_count": invalid_label_count,
        "invalid_prediction_count": invalid_prediction_count,
        "invalid_return_count": invalid_return_count,
        "extreme_label_count": extreme_label_count,
        "extreme_return_count": extreme_return_count,
        "kept_row_count": int(len(work_df)),
    }
    return work_df.sort_values(["date", "symbol"]).reset_index(drop=True), stats


def zero_metric_summary(top_k: int) -> dict[str, float]:
    ndcg_key = f"NDCG@{top_k}"
    return {
        "IC": 0.0,
        "ICIR": 0.0,
        "RankIC": 0.0,
        "RankICIR": 0.0,
        ndcg_key: 0.0,
    }


def compute_prediction_metrics(pred_df: pd.DataFrame, top_k: int = 20) -> dict[str, float]:
    pred_df, _ = sanitize_prediction_frame(pred_df)
    ic_values: list[float] = []
    rankic_values: list[float] = []
    ndcg_values: list[float] = []

    for _, raw_daily_df in pred_df.groupby("date"):
        daily_df = raw_daily_df.replace([np.inf, -np.inf], np.nan).dropna(subset=["label", "prediction"]).copy()
        if len(daily_df) < 5:
            continue
        y = daily_df["label"].to_numpy(dtype=float)
        pred = daily_df["prediction"].to_numpy(dtype=float)
        y_std = float(np.std(y))
        pred_std = float(np.std(pred))
        if y_std < 1e-12:
            continue
        if pred_std < 1e-12:
            continue
        # 这里的指标全部是“日横截面”定义，再对测试期按天取均值，
        # 与量化选股论文常见的 IC / RankIC 报告方式保持一致。
        ic_values.append(float(np.corrcoef(y, pred)[0, 1]))
        rankic_values.append(float(spearmanr(y, pred, nan_policy="omit").statistic))
        ndcg_values.append(ndcg_at_k(rankdata(y), pred, k=top_k))

    ic_series = pd.Series(ic_values, dtype=float).dropna()
    rankic_series = pd.Series(rankic_values, dtype=float).dropna()
    ndcg_series = pd.Series(ndcg_values, dtype=float).dropna()
    ndcg_key = f"NDCG@{top_k}"
    if ic_series.empty and rankic_series.empty and ndcg_series.empty:
        return zero_metric_summary(top_k=top_k)
    return {
        "IC": float(ic_series.mean()) if not ic_series.empty else 0.0,
        "ICIR": float(ic_series.mean() / (ic_series.std(ddof=0) + 1e-12)) if len(ic_series) > 1 else 0.0,
        "RankIC": float(rankic_series.mean()) if not rankic_series.empty else 0.0,
        "RankICIR": float(rankic_series.mean() / (rankic_series.std(ddof=0) + 1e-12)) if len(rankic_series) > 1 else 0.0,
        ndcg_key: float(ndcg_series.mean()) if not ndcg_series.empty else 0.0,
    }


def run_fast_topk_backtest(pred_df: pd.DataFrame, top_k: int = 20) -> tuple[pd.DataFrame, dict[str, float]]:
    pred_df, sanitize_stats = sanitize_prediction_frame(pred_df)
    rows: list[dict[str, Any]] = []
    nav = 1.0
    max_nav = 1.0
    max_abs_daily_ret = 0.0
    max_abs_future_return = 0.0
    extreme_daily_date = ""
    adjusted_days = 0
    effective_topk_values: list[int] = []
    daily_universe_sizes: list[int] = []
    empty_position_days = 0
    skipped_invalid_rows = max(
        0,
        int(sanitize_stats["original_row_count"] - sanitize_stats["kept_row_count"]),
    )

    for date_value, raw_daily_df in pred_df.groupby("date"):
        # 这是论文筛参与首轮比较用的轻量回测：
        # 只按预测分数选 Top-k，然后直接用 future_return 近似下一期持有收益。
        # 当截面股票数过少且 top_k 覆盖了全市场时，不同模型会退化为“全买组合”，
        # 收益曲线失去区分度。因此这里在可行时至少保留一个未持有标的。
        daily_df = raw_daily_df.replace([np.inf, -np.inf], np.nan).dropna(subset=["prediction", "future_return"]).copy()
        daily_count = int(len(daily_df))
        daily_universe_sizes.append(daily_count)
        if daily_count <= 0:
            empty_position_days += 1
            rows.append(
                {
                    "date": date_value,
                    "portfolio_return": 0.0,
                    "nav": nav,
                    "drawdown": nav / max_nav - 1.0,
                    "effective_top_k": 0,
                    "position_status": "empty_after_sanitize",
                }
            )
            continue
        effective_top_k = min(top_k, daily_count)
        if daily_count > 1 and effective_top_k >= daily_count:
            effective_top_k = daily_count - 1
            adjusted_days += 1
        if effective_top_k <= 0:
            empty_position_days += 1
            rows.append(
                {
                    "date": date_value,
                    "portfolio_return": 0.0,
                    "nav": nav,
                    "drawdown": nav / max_nav - 1.0,
                    "effective_top_k": 0,
                    "position_status": "empty_due_to_small_universe",
                }
            )
            continue
        effective_topk_values.append(effective_top_k)
        try:
            ranked = daily_df.sort_values("prediction", ascending=False).head(effective_top_k)
            if ranked.empty:
                empty_position_days += 1
                daily_ret = 0.0
                position_status = "empty_ranked"
            else:
                max_abs_future_return = max(
                    max_abs_future_return,
                    float(pd.to_numeric(ranked["future_return"], errors="coerce").abs().max()),
                )
                # FIX: future_return is a 5-day return. To approximate a daily step backtest without
                # overlapping compounding explosion, we divide the 5-day return by 5 to get the average daily return.
                # Also we deduct a conservative transaction cost (e.g., 0.15% two-way) scaled by an assumed 20% daily turnover.
                raw_5d_ret = float(np.nan_to_num(ranked["future_return"].mean(), nan=0.0, posinf=0.0, neginf=0.0))
                daily_ret = (raw_5d_ret / 5.0) - 0.0
                position_status = "invested"
        except Exception:
            empty_position_days += 1
            daily_ret = 0.0
            position_status = "empty_due_to_exception"
        if abs(daily_ret) >= max_abs_daily_ret:
            max_abs_daily_ret = abs(daily_ret)
            extreme_daily_date = str(date_value)
        nav *= 1.0 + daily_ret
        max_nav = max(max_nav, nav)
        drawdown = nav / max_nav - 1.0
        rows.append(
            {
                "date": date_value,
                "portfolio_return": daily_ret,
                "nav": nav,
                "drawdown": drawdown,
                "effective_top_k": effective_top_k,
                "position_status": position_status,
            }
        )

    curve_df = pd.DataFrame(rows)
    ret_series = curve_df["portfolio_return"] if not curve_df.empty else pd.Series(dtype=float)
    ann_return = float((1.0 + ret_series.mean()) ** 252 - 1.0) if not ret_series.empty else np.nan
    sharpe = float(np.sqrt(252.0) * ret_series.mean() / (ret_series.std(ddof=0) + 1e-12)) if len(ret_series) > 1 else np.nan
    mdd = float(curve_df["drawdown"].min()) if not curve_df.empty else np.nan
    calmar = float(ann_return / abs(mdd)) if mdd and mdd < 0 else np.nan
    adjusted_ratio = float(adjusted_days / len(daily_universe_sizes)) if daily_universe_sizes else 0.0
    summary = {
        "Annualized Return": ann_return,
        "Sharpe Ratio": sharpe,
        "Maximum Drawdown": mdd,
        "Calmar Ratio": calmar,
        "Requested TopK": int(top_k),
        "Effective TopK Mean": float(np.mean(effective_topk_values)) if effective_topk_values else np.nan,
        "Effective TopK Min": int(min(effective_topk_values)) if effective_topk_values else 0,
        "Avg Daily Universe": float(np.mean(daily_universe_sizes)) if daily_universe_sizes else np.nan,
        "Min Daily Universe": int(min(daily_universe_sizes)) if daily_universe_sizes else 0,
        "Adjusted TopK Day Ratio": adjusted_ratio,
        "Empty Position Day Ratio": float(empty_position_days / len(daily_universe_sizes)) if daily_universe_sizes else 0.0,
        "Sanitized Invalid Row Count": int(skipped_invalid_rows),
    }
    # #region debug-point B:backtest-extremes
    try:
        if abs(float(ann_return)) > 1e6 or float(max_nav) > 1e6 or float(max_abs_daily_ret) > 1.0:
            debug_url = "http://127.0.0.1:7777/event"
            debug_session_id = "multi-alpha-overflow"
            env_path = ROOT_DIR / ".dbg" / "multi-alpha-overflow.env"
            if env_path.exists():
                for line in env_path.read_text(encoding="utf-8").splitlines():
                    if line.startswith("DEBUG_SERVER_URL="):
                        debug_url = line.split("=", 1)[1].strip() or debug_url
                    elif line.startswith("DEBUG_SESSION_ID="):
                        debug_session_id = line.split("=", 1)[1].strip() or debug_session_id
            payload = {
                "sessionId": debug_session_id,
                "runId": "pre-fix",
                "hypothesisId": "B",
                "location": "experiment_runner.py:run_fast_topk_backtest",
                "msg": "[DEBUG] extreme backtest metrics detected",
                "data": {
                    "top_k": int(top_k),
                    "annualized_return": float(ann_return),
                    "sharpe_ratio": float(sharpe) if pd.notna(sharpe) else None,
                    "max_drawdown": float(mdd) if pd.notna(mdd) else None,
                    "max_nav": float(max_nav),
                    "max_abs_daily_ret": float(max_abs_daily_ret),
                    "max_abs_future_return": float(max_abs_future_return),
                    "extreme_daily_date": extreme_daily_date,
                    "avg_daily_universe": float(np.mean(daily_universe_sizes)) if daily_universe_sizes else None,
                    "effective_topk_mean": float(np.mean(effective_topk_values)) if effective_topk_values else None,
                },
                "ts": int(time.time() * 1000),
            }
            import urllib.request

            urllib.request.urlopen(
                urllib.request.Request(
                    debug_url,
                    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                ),
                timeout=2.0,
            ).read()
    except Exception:
        pass
    # #endregion
    return curve_df, summary


def build_split_arrays(
    panel_df: pd.DataFrame,
    incidence_df: pd.DataFrame,
    split: SplitConfig,
    lookback: int,
) -> tuple[dict[str, dict[str, np.ndarray]], dict[str, pd.DataFrame]]:
    incidence_df = incidence_df.sort_index()
    symbol_to_concept = {symbol: row.to_numpy(dtype=np.float32) for symbol, row in incidence_df.iterrows()}
    concept_dim = incidence_df.shape[1]
    samples: list[dict[str, Any]] = []

    for symbol, symbol_df in panel_df.groupby("symbol"):
        symbol_df = symbol_df.sort_values("date").reset_index(drop=True)
        if symbol_df.shape[0] <= lookback:
            continue
        # 一个样本由五部分组成：
        # 1) sequence_x: 个股时序窗口
        # 2) tabular_x: 当日截面统计特征
        # 3) concept_x: 静态超图概念向量
        # 4) regime_x: 市场状态编码
        # 5) alpha_x: 公式 alpha 风格特征
        sequence_base = symbol_df[SEQ_FEATURES].to_numpy(dtype=np.float32)
        tabular_base = symbol_df[TABULAR_FEATURES].to_numpy(dtype=np.float32)
        alpha_base = symbol_df[ALPHA_FEATURES].to_numpy(dtype=np.float32)
        concept_vec = symbol_to_concept.get(symbol, np.zeros(shape=(concept_dim,), dtype=np.float32))
        for idx in range(lookback - 1, len(symbol_df)):
            date_value = symbol_df.loc[idx, "date"]
            split_name = infer_split(date_value, split)
            if split_name is None:
                continue
            window = sequence_base[idx - lookback + 1 : idx + 1]
            target = symbol_df.loc[idx, "label_rank_proxy"]
            future_return = float(symbol_df.loc[idx, "future_return"])
            if (
                not np.isfinite(window).all()
                or not np.isfinite(tabular_base[idx]).all()
                or not np.isfinite(alpha_base[idx]).all()
                or not np.isfinite(target)
                or not np.isfinite(future_return)
                or abs(float(target)) > MAX_REASONABLE_FUTURE_RETURN
                or abs(future_return) > MAX_REASONABLE_FUTURE_RETURN
            ):
                continue
            samples.append(
                {
                    "split": split_name,
                    "date": date_value,
                    "symbol": symbol,
                    "sequence_x": window,
                    "tabular_x": tabular_base[idx],
                    "concept_x": concept_vec,
                    "regime_x": REGIME_TO_ID.get(str(symbol_df.loc[idx, "regime"]).lower(), 1),
                    "alpha_x": alpha_base[idx],
                    "y": float(target),
                    "future_return": future_return,
                    "label": float(symbol_df.loc[idx, "label_rank_proxy"]),
                }
            )

    if not samples:
        raise RuntimeError("样本构建结果为空, 请降低股票池规模或检查数据完整性。")

    sample_df = pd.DataFrame(samples)
    train_df = sample_df[sample_df["split"] == "train"].sort_values(["date", "symbol"]).reset_index(drop=True)
    valid_df = sample_df[sample_df["split"] == "valid"].sort_values(["date", "symbol"]).reset_index(drop=True)
    test_df = sample_df[sample_df["split"] == "test"].sort_values(["date", "symbol"]).reset_index(drop=True)

    seq_scaler = StandardScaler()
    tab_scaler = StandardScaler()
    alpha_scaler = StandardScaler()

    # 标准化器只在训练集拟合，验证/测试严格沿用训练期统计量，防止未来信息泄露。
    train_seq_flat = np.vstack(train_df["sequence_x"].to_list()).reshape(-1, len(SEQ_FEATURES))
    train_tab = np.vstack(train_df["tabular_x"].to_list())
    train_alpha = np.vstack(train_df["alpha_x"].to_list())
    seq_scaler.fit(train_seq_flat)
    tab_scaler.fit(train_tab)
    alpha_scaler.fit(train_alpha)

    def transform_frame(frame: pd.DataFrame) -> dict[str, np.ndarray]:
        seq_array = np.stack(frame["sequence_x"].to_list()).astype(np.float32)
        seq_shape = seq_array.shape
        seq_array = seq_scaler.transform(seq_array.reshape(-1, seq_shape[-1])).reshape(seq_shape)
        tab_array = tab_scaler.transform(np.vstack(frame["tabular_x"].to_list())).astype(np.float32)
        alpha_array = alpha_scaler.transform(np.vstack(frame["alpha_x"].to_list())).astype(np.float32)
        date_group = pd.factorize(pd.to_datetime(frame["date"]), sort=True)[0].astype(np.int64)
        return {
            "sequence_x": seq_array,
            "tabular_x": tab_array,
            "concept_x": np.vstack(frame["concept_x"].to_list()).astype(np.float32),
            "regime_x": frame["regime_x"].to_numpy(dtype=np.int64),
            "alpha_x": alpha_array,
            "y": frame["y"].to_numpy(dtype=np.float32),
            "date_group": date_group,
        }

    arrays = {
        "train": transform_frame(train_df),
        "valid": transform_frame(valid_df),
        "test": transform_frame(test_df),
    }
    meta_frames = {
        "train": train_df[["date", "symbol", "future_return", "label"]].copy(),
        "valid": valid_df[["date", "symbol", "future_return", "label"]].copy(),
        "test": test_df[["date", "symbol", "future_return", "label"]].copy(),
    }
    return arrays, meta_frames


def make_dataset(split_arrays: dict[str, np.ndarray]) -> SequencePanelDataset:
    return SequencePanelDataset(
        sequence_x=split_arrays["sequence_x"],
        tabular_x=split_arrays["tabular_x"],
        concept_x=split_arrays["concept_x"],
        regime_x=split_arrays["regime_x"],
        alpha_x=split_arrays["alpha_x"],
        y=split_arrays["y"],
        date_group=split_arrays.get("date_group"),
    )


def pad_feature_width(array: np.ndarray, target_width: int) -> np.ndarray:
    current_width = int(array.shape[-1])
    if current_width >= target_width:
        return array
    pad_width = [(0, 0)] * array.ndim
    pad_width[-1] = (0, target_width - current_width)
    return np.pad(array, pad_width=pad_width, mode="constant", constant_values=0.0).astype(np.float32)


def cap_market_artifacts_for_quick_mode(market_artifacts: dict[str, Any], max_symbols: int) -> dict[str, Any]:
    """
    在 `smoke / medium` 下对缓存产物做运行时后置裁剪。

    说明:
    1. 数据层为了正式实验会对 US 保留更大的股票池，但这会让快速验证模式失去“快速”意义。
    2. 这里不改变 full 的正式口径，只在 runner 里对非 full 模式额外裁剪样本规模。
    """
    if max_symbols <= 0:
        return market_artifacts
    panel_df = market_artifacts["panel_df"]
    unique_symbols = panel_df["symbol"].astype(str).str.upper().drop_duplicates().tolist()
    if len(unique_symbols) <= max_symbols:
        return market_artifacts
    meta_df = market_artifacts.get("meta_df")
    if isinstance(meta_df, pd.DataFrame) and not meta_df.empty and "symbol" in meta_df.columns:
        ranked_symbols = meta_df["symbol"].astype(str).str.upper().drop_duplicates().tolist()[:max_symbols]
    else:
        ranked_symbols = unique_symbols[:max_symbols]
    capped: dict[str, Any] = dict(market_artifacts)
    capped["panel_df"] = (
        panel_df.loc[panel_df["symbol"].astype(str).str.upper().isin(ranked_symbols)]
        .copy()
        .sort_values(["date", "symbol"])
        .reset_index(drop=True)
    )
    if isinstance(meta_df, pd.DataFrame) and not meta_df.empty and "symbol" in meta_df.columns:
        capped["meta_df"] = meta_df.loc[meta_df["symbol"].astype(str).str.upper().isin(ranked_symbols)].copy().reset_index(drop=True)
    incidence_df = market_artifacts.get("incidence_df")
    if isinstance(incidence_df, pd.DataFrame) and not incidence_df.empty:
        matched_symbols = [symbol for symbol in ranked_symbols if symbol in incidence_df.index.astype(str).tolist()]
        capped["incidence_df"] = incidence_df.loc[matched_symbols].copy()
    symbol_stats_df = market_artifacts.get("symbol_stats_df")
    if isinstance(symbol_stats_df, pd.DataFrame) and not symbol_stats_df.empty and "symbol" in symbol_stats_df.columns:
        capped["symbol_stats_df"] = (
            symbol_stats_df.loc[symbol_stats_df["symbol"].astype(str).str.upper().isin(ranked_symbols)]
            .copy()
            .reset_index(drop=True)
        )
    return capped


def align_transfer_concept_arrays(
    source_arrays: dict[str, dict[str, np.ndarray]],
    target_arrays: dict[str, dict[str, np.ndarray]],
) -> tuple[dict[str, dict[str, np.ndarray]], dict[str, dict[str, np.ndarray]], int]:
    source_dim = int(source_arrays["train"]["concept_x"].shape[-1])
    target_dim = int(target_arrays["train"]["concept_x"].shape[-1])
    shared_dim = max(source_dim, target_dim)
    if source_dim == target_dim:
        return source_arrays, target_arrays, shared_dim

    def clone_with_aligned_concept(split_arrays: dict[str, dict[str, np.ndarray]]) -> dict[str, dict[str, np.ndarray]]:
        cloned: dict[str, dict[str, np.ndarray]] = {}
        for split_name, payload in split_arrays.items():
            cloned[split_name] = dict(payload)
            cloned[split_name]["concept_x"] = pad_feature_width(payload["concept_x"], shared_dim)
        return cloned

    return clone_with_aligned_concept(source_arrays), clone_with_aligned_concept(target_arrays), shared_dim


def evaluate_and_save(
    model_name: str,
    result_dir: Path,
    meta_df: pd.DataFrame,
    prediction: np.ndarray,
    top_k: int,
) -> dict[str, float]:
    ensure_dir(result_dir)
    pred_df = meta_df.copy()
    pred_df["prediction"] = np.asarray(prediction, dtype=np.float32)
    pred_df, sanitize_stats = sanitize_prediction_frame(pred_df)
    if pred_df.empty:
        metrics = zero_metric_summary(top_k=top_k)
        curve_df = pd.DataFrame(
            [
                {
                    "date": "empty",
                    "portfolio_return": 0.0,
                    "nav": 1.0,
                    "drawdown": 0.0,
                    "effective_top_k": 0,
                    "position_status": "empty_all_invalid",
                }
            ]
        )
        backtest_metrics = {
            "Annualized Return": 0.0,
            "Sharpe Ratio": 0.0,
            "Maximum Drawdown": 0.0,
            "Requested TopK": int(top_k),
            "Effective TopK Mean": 0.0,
            "Effective TopK Min": 0,
            "Avg Daily Universe": 0.0,
            "Min Daily Universe": 0,
            "Adjusted TopK Day Ratio": 0.0,
            "Empty Position Day Ratio": 1.0,
            "Sanitized Invalid Row Count": int(sanitize_stats["original_row_count"]),
        }
    else:
        metrics = compute_prediction_metrics(pred_df, top_k=top_k)
        curve_df, backtest_metrics = run_fast_topk_backtest(pred_df, top_k=top_k)
    summary = {**metrics, **backtest_metrics}
    summary["Sanitized Invalid Prediction Count"] = int(sanitize_stats["invalid_prediction_count"])
    summary["Sanitized Invalid Label Count"] = int(sanitize_stats["invalid_label_count"])
    summary["Sanitized Invalid Return Count"] = int(sanitize_stats["invalid_return_count"])
    summary["Sanitized Extreme Label Count"] = int(sanitize_stats["extreme_label_count"])
    summary["Sanitized Extreme Return Count"] = int(sanitize_stats["extreme_return_count"])
    # #region debug-point C:summary-write
    try:
        annualized_return = float(summary.get("Annualized Return", 0.0))
        curve_nav_max = float(pd.to_numeric(curve_df["nav"], errors="coerce").max()) if not curve_df.empty else 1.0
        curve_ret_max = float(pd.to_numeric(curve_df["portfolio_return"], errors="coerce").abs().max()) if not curve_df.empty else 0.0
        if abs(annualized_return) > 1e6 or curve_nav_max > 1e6 or curve_ret_max > 1.0:
            debug_url = "http://127.0.0.1:7777/event"
            debug_session_id = "multi-alpha-overflow"
            env_path = ROOT_DIR / ".dbg" / "multi-alpha-overflow.env"
            if env_path.exists():
                for line in env_path.read_text(encoding="utf-8").splitlines():
                    if line.startswith("DEBUG_SERVER_URL="):
                        debug_url = line.split("=", 1)[1].strip() or debug_url
                    elif line.startswith("DEBUG_SESSION_ID="):
                        debug_session_id = line.split("=", 1)[1].strip() or debug_session_id
            payload = {
                "sessionId": debug_session_id,
                "runId": "pre-fix",
                "hypothesisId": "C",
                "location": "experiment_runner.py:evaluate_and_save",
                "msg": "[DEBUG] summary contains extreme annualized return or nav",
                "data": {
                    "model_name": model_name,
                    "result_dir": str(result_dir),
                    "annualized_return": annualized_return,
                    "sharpe_ratio": float(summary.get("Sharpe Ratio", 0.0)),
                    "max_drawdown": float(summary.get("Maximum Drawdown", 0.0)),
                    "curve_nav_max": curve_nav_max,
                    "curve_ret_max": curve_ret_max,
                    "row_count": int(len(curve_df)),
                },
                "ts": int(time.time() * 1000),
            }
            import urllib.request

            urllib.request.urlopen(
                urllib.request.Request(
                    debug_url,
                    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                ),
                timeout=2.0,
            ).read()
    except Exception:
        pass
    # #endregion
    actual_prediction_path = write_dataframe(pred_df, result_dir / "test_predictions.csv", index=False, encoding="utf-8-sig")
    actual_curve_path = write_dataframe(curve_df, result_dir / "equity_curve.csv", index=False, encoding="utf-8-sig")
    actual_summary_path = write_json(result_dir / "summary.json", summary)
    summary["prediction_path"] = str(actual_prediction_path)
    summary["equity_curve_path"] = str(actual_curve_path)
    summary["summary_path"] = str(actual_summary_path)
    log(f"[done] {model_name} -> {result_dir}")
    return summary


def run_tabular_baseline(
    model_name: str,
    target_arrays: dict[str, dict[str, np.ndarray]],
    target_meta: dict[str, pd.DataFrame],
    experiment_dir: Path,
    top_k: int,
    device: str,
) -> dict[str, float]:
    if model_name == "lasso":
        model = LassoWrapper()
        model.fit(target_arrays["train"]["tabular_x"], target_arrays["train"]["y"])
    elif model_name == "xgboost":
        model = XGBoostWrapper(device=device)
        model.fit(
            target_arrays["train"]["tabular_x"],
            target_arrays["train"]["y"],
            target_arrays["valid"]["tabular_x"],
            target_arrays["valid"]["y"],
        )
    else:
        raise ValueError(model_name)
    prediction = model.predict(target_arrays["test"]["tabular_x"])
    return evaluate_and_save(model_name, experiment_dir / model_name, target_meta["test"], prediction, top_k=top_k)


def run_torch_baseline(
    model_name: str,
    target_arrays: dict[str, dict[str, np.ndarray]],
    target_meta: dict[str, pd.DataFrame],
    experiment_dir: Path,
    top_k: int,
    device: str,
    mode: str,
) -> dict[str, float]:
    train_dataset = make_dataset(target_arrays["train"])
    valid_dataset = make_dataset(target_arrays["valid"])
    test_dataset = make_dataset(target_arrays["test"])
    # 所有神经基线共享统一的数据接口与训练配置，减少“因为工程实现不同导致不公平比较”的风险。
    model = build_torch_model(
        model_name=model_name,
        seq_dim=target_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=target_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=target_arrays["train"]["concept_x"].shape[-1],
        alpha_dim=target_arrays["train"]["alpha_x"].shape[-1],
    )
    config = TorchTrainingConfig(
        n_epochs=scale_epoch_count(10, mode=mode, minimum_epochs=3),
        batch_size=4096,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    checkpoint_path = str(experiment_dir / model_name / f"{model_name}_checkpoint.pt")
    model = fit_torch_regressor(model, train_dataset, valid_dataset, config=config, device=device, checkpoint_path=checkpoint_path)
    prediction = predict_torch_regressor(model, test_dataset, batch_size=1024, device=device)
    return evaluate_and_save(model_name, experiment_dir / model_name, target_meta["test"], prediction, top_k=top_k)


def run_main_transfer_model(
    source_arrays: dict[str, dict[str, np.ndarray]],
    target_arrays: dict[str, dict[str, np.ndarray]],
    target_meta: dict[str, pd.DataFrame],
    experiment_dir: Path,
    top_k: int,
    device: str,
    mode: str,
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    weight_param: float,
    weight_mech: float,
    source_market: str,
    target_market: str,
    enable_similarity_policy: bool,
    similarity_config: MarketSimilarityConfig,
    threshold_config: ThresholdUpdateConfig,
    policy_config: AdaptationPolicyConfig,
    similarity_history_path: Path,
) -> dict[str, float]:
    source_arrays, target_arrays, shared_concept_dim = align_transfer_concept_arrays(source_arrays, target_arrays)
    source_train = make_dataset(source_arrays["train"])
    source_valid = make_dataset(source_arrays["valid"])
    target_train = make_dataset(target_arrays["train"])
    target_valid = make_dataset(target_arrays["valid"])
    target_test = make_dataset(target_arrays["test"])

    model = build_torch_model(
        model_name="main",
        seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=shared_concept_dim,
        alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
        scoring_config=scoring_config,
    )
    # 第一步：在源域学一个可迁移的共性表示与 alpha 权重基准。
    pretrain_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(12, mode=mode, minimum_epochs=4),
        batch_size=4096,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=3,
    )
    pretrain_ckpt = str(experiment_dir / "main_transfer" / "pretrain_checkpoint.pt")
    model = fit_torch_regressor(
        model,
        source_train,
        source_valid,
        config=pretrain_cfg,
        supervised_loss_config=supervised_loss_config,
        device=device,
        checkpoint_path=pretrain_ckpt,
    )
    model = unwrap_model(model)

    def transfer_penalty(model_obj: torch.nn.Module, batch: tuple[torch.Tensor, ...], pred: Any) -> torch.Tensor:
        _ = pred
        return model_obj.extra_transfer_loss(
            batch[4],
            batch[1],
            batch[0],
            batch[2],
            batch[3],
            weight_param=weight_param,
            weight_mech=weight_mech,
        )

    # 第二步：冻结共享主干，只让目标域小规模适配器学习参数偏移。
    adapt_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(8, mode=mode, minimum_epochs=3),
        batch_size=4096,
        lr=1e-3,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    model_result_dir = experiment_dir / "main_transfer"
    optimizer_group_builder = None
    similarity_payload: dict[str, Any] | None = None
    report_markdown: str | None = None
    if enable_similarity_policy:
        similarity_result = compute_market_similarity(
            source_arrays=source_arrays["train"],
            target_arrays=target_arrays["train"],
            model=model,
            device=device,
            config=similarity_config,
        )
        threshold_summary = recommend_similarity_threshold(similarity_history_path, config=threshold_config)
        adaptation_policy = resolve_adaptation_policy(
            similarity_score=float(similarity_result.final_similarity),
            similarity_threshold=float(threshold_summary["threshold"]),
            config=policy_config,
        )
        model.configure_target_adaptation(**adaptation_policy.to_adaptation_kwargs())
        optimizer_group_builder = lambda model_obj, cfg: build_adaptation_param_groups(model_obj, cfg, adaptation_policy)
        optimizer_groups = collect_optimizer_group_summary(model, base_lr=float(adapt_cfg.lr), policy=adaptation_policy)
        similarity_payload = {
            "direction": f"{source_market}->{target_market}",
            "similarity_result": similarity_result.to_dict(),
            "threshold_summary": threshold_summary,
            "adaptation_policy": adaptation_policy.to_dict(),
            "optimizer_groups": optimizer_groups,
            "history_path": str(similarity_history_path),
        }
        report_markdown = render_similarity_report_markdown(
            source_market=source_market,
            target_market=target_market,
            similarity_result=similarity_result,
            threshold_summary=threshold_summary,
            policy=adaptation_policy,
            optimizer_groups=optimizer_groups,
        )
    else:
        model.switch_to_target_adaptation()

    adapt_ckpt = str(experiment_dir / "main_transfer" / "adapt_checkpoint.pt")
    model = fit_torch_regressor(
        model,
        target_train,
        target_valid,
        config=adapt_cfg,
        supervised_loss_config=supervised_loss_config,
        extra_loss_fn=transfer_penalty,
        optimizer_group_builder=optimizer_group_builder,
        device=device,
        checkpoint_path=adapt_ckpt,
    )
    prediction = predict_torch_regressor(model, target_test, batch_size=1024, device=device)
    metrics = evaluate_and_save("main_transfer", model_result_dir, target_meta["test"], prediction, top_k=top_k)
    if similarity_payload is not None:
        similarity_payload["post_run_metrics"] = {
            "Annualized Return": float(metrics.get("Annualized Return", metrics.get("AnnualizedReturn", 0.0))),
            "Sharpe": float(metrics.get("Sharpe Ratio", metrics.get("Sharpe", 0.0))),
            "RankIC": float(metrics.get("RankIC", 0.0)),
        }
        similarity_payload["post_run_threshold_recommendation"] = update_threshold_history(
            history_path=similarity_history_path,
            record={
                "direction": f"{source_market}->{target_market}",
                "similarity_score": float(similarity_payload["similarity_result"]["final_similarity"]),
                "threshold_used": float(similarity_payload["threshold_summary"]["threshold"]),
                "policy_name": str(similarity_payload["adaptation_policy"]["policy_name"]),
                "supervised_metric": float(metrics.get("Annualized Return", metrics.get("AnnualizedReturn", 0.0))),
                "rankic": float(metrics.get("RankIC", 0.0)),
            },
            config=threshold_config,
        )
        write_json(model_result_dir / "market_similarity_report.json", similarity_payload)
        if report_markdown is not None:
            (model_result_dir / "market_similarity_report.md").write_text(report_markdown, encoding="utf-8")
    return metrics


def run_one_direction(
    source_market: str,
    target_market: str,
    max_symbols: int,
    lookback: int,
    top_k: int,
    device: str,
    force_rebuild: bool,
    mode: str,
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    weight_param: float,
    weight_mech: float,
    enable_similarity_policy: bool,
    similarity_config: MarketSimilarityConfig,
    threshold_config: ThresholdUpdateConfig,
    policy_config: AdaptationPolicyConfig,
    similarity_history_path: Path,
    selected_models: list[str] | None = None,
    skip_existing: bool = True,
) -> pd.DataFrame:
    requested_models = selected_models or list(ALL_MODEL_NAMES)
    direction_name = f"{source_market}->{target_market}"
    experiment_dir = get_phase1_result_dir() / f"{source_market.lower()}_to_{target_market.lower()}"
    ensure_dir(experiment_dir)
    summary_rows: list[dict[str, Any]] = []
    runnable_models: list[str] = []

    for model_name in requested_models:
        existing_summary = read_existing_summary(experiment_dir / model_name)
        if existing_summary is not None and skip_existing:
            summary_rows.append({"direction": direction_name, "model": model_name, **existing_summary})
            done_count = len(summary_rows)
            log(
                f"{PROCESS_PREFIX} skip | 当前方向={direction_name} | 当前模型={model_name} | "
                f"方向内完成百分比={format_progress(done_count, len(requested_models))} | "
                f"模型完成摘要=复用已有结果"
            )
            continue
        runnable_models.append(model_name)

    if not runnable_models:
        summary_df = pd.DataFrame(summary_rows)
        if not summary_df.empty:
            write_dataframe(summary_df, experiment_dir / "summary.csv", index=False, encoding="utf-8-sig")
        return summary_df

    source_max_symbols = resolve_max_symbols(get_profile(mode), source_market, max_symbols)
    target_max_symbols = resolve_max_symbols(get_profile(mode), target_market, max_symbols)
    effective_max_symbols = min(source_max_symbols, target_max_symbols)

    transfer = prepare_transfer_artifacts(
        source_market=source_market,
        target_market=target_market,
        max_symbols=effective_max_symbols,
        horizon=5,
        force_rebuild=force_rebuild,
    )
    if str(mode).lower() in {"smoke", "medium"}:
        transfer["source"] = cap_market_artifacts_for_quick_mode(transfer["source"], source_max_symbols)
        transfer["target"] = cap_market_artifacts_for_quick_mode(transfer["target"], target_max_symbols)
    source_panel = transfer["source"]["panel_df"]
    target_panel = transfer["target"]["panel_df"]
    source_incidence = transfer["source"]["incidence_df"]
    target_incidence = transfer["target"]["incidence_df"]
    split = SplitConfig()

    log(
        f"{PROCESS_PREFIX} direction started | 当前方向={direction_name} | "
        f"待运行模型数={len(runnable_models)} | 已跳过模型数={len(summary_rows)} | 状态=BUILDING_ARRAYS"
    )
    source_arrays, _source_meta = build_split_arrays(source_panel, source_incidence, split=split, lookback=lookback)
    target_arrays, target_meta = build_split_arrays(target_panel, target_incidence, split=split, lookback=lookback)

    total_models = len(requested_models)
    completed_count = len(summary_rows)
    for model_name in runnable_models:
        progress_before = format_progress(completed_count, total_models)
        log(
            f"{PROCESS_PREFIX} model started | 当前方向={direction_name} | 当前模型={model_name} | "
            f"方向内完成百分比={progress_before} | 状态=RUNNING"
        )
        heartbeat = ModelHeartbeat(direction_name=direction_name, model_name=model_name, progress_text=progress_before)
        heartbeat.start()
        model_start_time = time.perf_counter()
        try:
            if model_name in {"lasso", "xgboost"}:
                metrics = run_tabular_baseline(model_name, target_arrays, target_meta, experiment_dir, top_k=top_k, device=device)
            elif model_name in {"lstm", "transformer", "tra", "hist"}:
                metrics = run_torch_baseline(
                    model_name,
                    target_arrays,
                    target_meta,
                    experiment_dir,
                    top_k=top_k,
                    device=device,
                    mode=mode,
                )
            elif model_name == "main_transfer":
                metrics = run_main_transfer_model(
                    source_arrays=source_arrays,
                    target_arrays=target_arrays,
                    target_meta=target_meta,
                    experiment_dir=experiment_dir,
                    top_k=top_k,
                    device=device,
                    mode=mode,
                    scoring_config=scoring_config,
                    supervised_loss_config=supervised_loss_config,
                    weight_param=weight_param,
                    weight_mech=weight_mech,
                    source_market=source_market,
                    target_market=target_market,
                    enable_similarity_policy=enable_similarity_policy,
                    similarity_config=similarity_config,
                    threshold_config=threshold_config,
                    policy_config=policy_config,
                    similarity_history_path=similarity_history_path,
                )
            else:
                raise ValueError(model_name)
        finally:
            heartbeat.stop()
        summary_rows.append({"direction": direction_name, "model": model_name, **metrics})
        completed_count += 1
        log(
            f"{DONE_PREFIX} model finished | 当前方向={direction_name} | 当前模型={model_name} | "
            f"方向内完成百分比={format_progress(completed_count, total_models)} | "
            f"模型完成摘要={summarize_metrics(metrics)} | 用时={format_seconds(time.perf_counter() - model_start_time)}"
        )

    summary_df = pd.DataFrame(summary_rows)
    write_dataframe(summary_df, experiment_dir / "summary.csv", index=False, encoding="utf-8-sig")
    log(
        f"{DONE_PREFIX} direction finished | 当前方向={direction_name} | 当前模型=ALL | "
        f"方向内完成百分比=100.0% | 模型完成摘要=summary.csv 已写出"
    )
    return summary_df


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行第一阶段跨市场迁移实验")
    parser.add_argument("--mode", default="full", choices=["full", "medium", "smoke"], help="实验运行模式")
    parser.add_argument("--max-symbols", type=int, default=160, help="每个市场参与训练的流动性股票数")
    parser.add_argument("--lookback", type=int, default=20, help="时序模型回看窗口")
    parser.add_argument("--top-k", type=int, default=20, help="轻量回测的 Top-k 持仓数")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true", help="强制重建中间缓存")
    parser.add_argument(
        "--direction",
        default="cn_to_us,us_to_cn",
        help="实验方向, 支持 `cn_to_us` / `us_to_cn`, 多个方向用逗号分隔",
    )
    parser.add_argument(
        "--models",
        default=",".join(ALL_MODEL_NAMES),
        help="指定要运行的模型, 多个模型用逗号分隔; `main` 会映射到 `main_transfer`",
    )
    parser.add_argument("--rerun-existing", action="store_true", help="即使已有结果也重新训练并覆盖")
    parser.add_argument("--amt-top-r", type=int, default=3, help="AMT 稀疏门控保留的 alpha 参数块数量")
    parser.add_argument("--amt-gate-temperature", type=float, default=0.70, help="AMT 门控 softmax 温度")
    parser.add_argument("--amt-alpha-residual-scale", type=float, default=0.35, help="AMT 目标域增量注入到源域权重时的残差缩放")
    parser.add_argument("--amt-delta-clip", type=float, default=0.75, help="AMT 适配器输出增量的裁剪上界")
    parser.add_argument("--amt-min-gate-mass", type=float, default=1e-6, help="AMT 稀疏门控重归一化时的最小分母")
    parser.add_argument("--amt-supervised-objective", choices=["mse", "rank_return"], default="rank_return", help="AMT 主监督项类型")
    parser.add_argument("--amt-rank-loss-weight", type=float, default=1.0, help="AMT 排序损失权重")
    parser.add_argument("--amt-return-loss-weight", type=float, default=2.0, help="AMT 年化收益代理损失权重")
    parser.add_argument("--amt-mse-anchor-weight", type=float, default=0.05, help="AMT 回归锚点损失权重")
    parser.add_argument("--amt-pairwise-label-threshold", type=float, default=1e-4, help="AMT 排序损失中忽略微小标签差异的阈值")
    parser.add_argument("--amt-return-temperature", type=float, default=0.35, help="AMT 收益代理中的 softmax 温度")
    parser.add_argument("--amt-annualization-factor", type=float, default=252.0, help="AMT 收益代理的年化放大系数")
    parser.add_argument("--amt-weight-param", type=float, default=0.002, help="AMT 参数偏移约束权重")
    parser.add_argument("--amt-weight-mech", type=float, default=0.0005, help="AMT 机理偏移约束权重")
    parser.add_argument("--disable-market-similarity-policy", action="store_true", help="关闭相似度驱动的自适应冻结与学习率策略")
    parser.add_argument("--market-similarity-threshold", type=float, default=0.70, help="市场相似度统一阈值")
    parser.add_argument("--market-similarity-sample-size", type=int, default=2048, help="计算市场嵌入时每个市场最多采样的样本数")
    parser.add_argument("--market-similarity-batch-size", type=int, default=512, help="计算市场嵌入时的批大小")
    parser.add_argument("--market-similarity-rbf-gamma", type=float, default=0.50, help="MMD RBF 核的 gamma 参数")
    parser.add_argument("--market-similarity-medium-gap", type=float, default=0.15, help="低于阈值后进入第一档宽松策略的相似度间隔")
    parser.add_argument("--market-similarity-low-gap", type=float, default=0.35, help="低于阈值后进入更宽松策略的相似度间隔")
    parser.add_argument("--market-threshold-update-method", choices=["ema_quantile", "supervised_gain"], default="ema_quantile", help="相似度阈值动态更新方法")
    parser.add_argument("--market-threshold-quantile", type=float, default=0.65, help="无监督阈值更新时使用的历史相似度分位数")
    parser.add_argument("--market-threshold-ema-decay", type=float, default=0.80, help="动态阈值更新时的 EMA 衰减系数")
    parser.add_argument(
        "--market-similarity-history-path",
        default=str(ROOT_DIR / "results" / "market_similarity_threshold_history.json"),
        help="市场相似度阈值历史文件路径",
    )
    return parser.parse_args()



def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False



import hashlib
import json
from datetime import datetime

def check_code_changes_and_log(experiment_dir: Path) -> bool:
    # 核心文件白名单（修改这些必须重训）
    core_files = ['models.py', 'experiment_runner.py', 'data_pipeline.py', 'experiment_profiles.py']
    
    code_dir = Path('/data/zhoutm/exp2/code')
    current_hashes = {}
    for f in core_files:
        p = code_dir / f
        if p.exists():
            with open(p, 'rb') as file:
                current_hashes[f] = hashlib.md5(file.read()).hexdigest()
                
    hash_file = experiment_dir / 'code_hashes.json'
    change_log_file = experiment_dir.parent / 'change_log.jsonl'
    
    needs_retrain = False
    changes = []
    
    if hash_file.exists():
        with open(hash_file, 'r') as file:
            old_hashes = json.load(file)
        
        for f, h in current_hashes.items():
            if f not in old_hashes or old_hashes[f] != h:
                needs_retrain = True
                changes.append(f)
                
        if needs_retrain:
            log_entry = {
                "timestamp": datetime.now().isoformat(),
                "changed_files": changes,
                "action": "triggered_retrain",
                "reason": "core_logic_modified"
            }
            with open(change_log_file, 'a') as log_f:
                log_f.write(json.dumps(log_entry) + "\n")
            print(f"⚠️ 检测到核心代码变更: {changes}，触发强制重训！")
    
    with open(hash_file, 'w') as file:
        json.dump(current_hashes, file)
        
    return needs_retrain


def main() -> int:
    set_seed(42)
    args = parse_args()
    os.environ["AMT_ARCHIVE_PREFIX"] = str(args.mode).strip().lower()
    phase1_result_dir = get_phase1_result_dir()
    ensure_dir(phase1_result_dir)
    needs_retrain = check_code_changes_and_log(phase1_result_dir)
    if needs_retrain:
        args.skip_existing = False
    direction_keys = [normalize_direction(item) for item in parse_csv_args(args.direction)]
    if not direction_keys:
        raise ValueError("至少需要指定一个实验方向")
    model_names = [normalize_model_name(item) for item in parse_csv_args(args.models)]
    if not model_names:
        raise ValueError("至少需要指定一个模型")
    scoring_config = build_amt_scoring_config(args)
    supervised_loss_config = build_amt_supervised_loss_config(args)
    market_similarity_config = build_market_similarity_config(args)
    threshold_update_config = build_threshold_update_config(args)
    adaptation_policy_config = build_adaptation_policy_config(args)
    similarity_history_path = Path(args.market_similarity_history_path).expanduser().resolve()

    for direction_key in direction_keys:
        source_market, target_market = DIRECTION_SPECS[direction_key]
        # 支持只跑一个方向、只跑某个模型，是为了大实验长时间运行时可以断点恢复。
        run_one_direction(
            source_market=source_market,
            target_market=target_market,
            max_symbols=args.max_symbols,
            lookback=args.lookback,
            top_k=args.top_k,
            device=args.device,
            force_rebuild=args.force_rebuild,
            mode=args.mode,
            scoring_config=scoring_config,
            supervised_loss_config=supervised_loss_config,
            weight_param=args.amt_weight_param,
            weight_mech=args.amt_weight_mech,
            enable_similarity_policy=not args.disable_market_similarity_policy,
            similarity_config=market_similarity_config,
            threshold_config=threshold_update_config,
            policy_config=adaptation_policy_config,
            similarity_history_path=similarity_history_path,
            selected_models=model_names,
            skip_existing=not args.rerun_existing,
        )

    all_summary_df = gather_all_summaries(direction_keys)
    write_dataframe(all_summary_df, phase1_result_dir / "all_summary.csv", index=False, encoding="utf-8-sig")
    write_json(
        phase1_result_dir / "run_config.json",
        {
            "max_symbols": args.max_symbols,
            "lookback": args.lookback,
            "top_k": args.top_k,
            "device": args.device,
            "mode": args.mode,
            "profile": profile_to_dict(get_profile(args.mode)),
            "direction": direction_keys,
            "models": model_names,
            "rerun_existing": args.rerun_existing,
            "amt_scoring": amt_scoring_config_to_dict(scoring_config),
            "amt_supervised_loss": amt_supervised_loss_config_to_dict(supervised_loss_config),
            "amt_transfer_loss": {
                "weight_param": float(args.amt_weight_param),
                "weight_mech": float(args.amt_weight_mech),
            },
            "market_similarity": {
                "enabled": not args.disable_market_similarity_policy,
                "history_path": str(similarity_history_path),
                "feature_config": {
                    "sample_size": int(market_similarity_config.sample_size),
                    "batch_size": int(market_similarity_config.batch_size),
                    "rbf_gamma": float(market_similarity_config.rbf_gamma),
                },
                "threshold_update": {
                    "base_threshold": float(threshold_update_config.base_threshold),
                    "update_method": threshold_update_config.update_method,
                    "quantile": float(threshold_update_config.quantile),
                    "ema_decay": float(threshold_update_config.ema_decay),
                },
                "policy_gap": {
                    "medium_gap": float(adaptation_policy_config.medium_gap),
                    "low_gap": float(adaptation_policy_config.low_gap),
                },
            },
        },
    )
    if all_summary_df.empty:
        log("当前未收集到任何结果，请检查模型运行日志。")
    else:
        print(all_summary_df.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
