"""
文件功能:
1. 基于官方 DoubleAdapt 的核心思想，提供一个适配本项目统一数据接口的可运行版本。
2. 将“特征适配 + 标签适配 + 目标市场在线样式适配”落到当前 CN/US 日频面板数据上。
3. 支持直接读取 `data_pipeline.py` 生成的中间产物，并输出与主实验一致的结果文件。

代码逻辑:
1. 复用统一的数据底座与样本构造流程，避免因为数据协议不同导致不公平比较。
2. 使用特征适配器对输入表示做轻量变换，模拟官方 DoubleAdapt 的 `adapt_x` 思想。
3. 使用标签适配器对训练标签和预测输出做可逆变换，模拟官方 DoubleAdapt 的 `adapt_y` 思想。
4. 在目标市场上完成训练、验证与测试，输出预测文件、净值曲线和 summary。

代码结构:
1. DoubleAdapt 风格的适配器模块。
2. 统一模型定义与训练函数。
3. 基于当前数据底座的运行入口。
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parent))

from data_pipeline import SplitConfig, prepare_transfer_artifacts
from experiment_workspace import get_categorized_result_path
from experiment_runner import (
    ALPHA_FEATURES,
    REGIME_TO_ID,
    SEQ_FEATURES,
    TABULAR_FEATURES,
    build_split_arrays,
    evaluate_and_save,
)


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULT_DIR = get_categorized_result_path("baseline", "compare_models")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def maybe_wrap_data_parallel(model: nn.Module, device: str) -> nn.Module:
    if not device.startswith("cuda"):
        return model
    if not torch.cuda.is_available():
        return model
    if torch.cuda.device_count() <= 1:
        return model
    if isinstance(model, nn.DataParallel):
        return model
    return nn.DataParallel(model)


def cosine_similarity_matrix(x1: torch.Tensor, x2: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    x1 = x1 / (x1.norm(p=2, dim=-1, keepdim=True) + eps)
    x2 = x2 / (x2.norm(p=2, dim=-1, keepdim=True) + eps)
    return x1 @ x2.transpose(0, 1)


class DoubleAdaptArrayDataset(Dataset):
    """
    仅保留 DoubleAdapt 需要的输入：
    - sequence_x: 时序窗口
    - tabular_x: 当日截面特征
    - y: 监督目标
    """

    def __init__(self, sequence_x: np.ndarray, tabular_x: np.ndarray, y: np.ndarray) -> None:
        self.sequence_x = sequence_x.astype(np.float32)
        self.tabular_x = tabular_x.astype(np.float32)
        self.y = y.astype(np.float32)

    def __len__(self) -> int:
        return int(self.y.shape[0])

    def __getitem__(self, index: int) -> tuple[torch.Tensor, ...]:
        return (
            torch.as_tensor(self.sequence_x[index], dtype=torch.float32),
            torch.as_tensor(self.tabular_x[index], dtype=torch.float32),
            torch.as_tensor(self.y[index], dtype=torch.float32),
        )


def build_loader(dataset: DoubleAdaptArrayDataset, batch_size: int, shuffle: bool) -> DataLoader:
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, drop_last=False)


class FeatureAdapter(nn.Module):
    """
    对齐官方 DoubleAdapt 的 `FeatureAdapter` 核心思想：
    用多头门控决定对输入特征施加哪种轻量变换。
    """

    def __init__(self, in_dim: int, num_head: int = 4, temperature: float = 4.0) -> None:
        super().__init__()
        self.num_head = num_head
        self.temperature = temperature
        self.prototypes = nn.Parameter(torch.randn(num_head, in_dim) * 0.02)
        self.heads = nn.ModuleList([nn.Linear(in_dim, in_dim) for _ in range(num_head)])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        sim = cosine_similarity_matrix(x, self.prototypes)
        gate = torch.softmax(sim / self.temperature, dim=-1).unsqueeze(-1)
        adapted = x + sum(gate[:, i, :] * self.heads[i](x) for i in range(self.num_head))
        return adapted


class LabelAdaptHeads(nn.Module):
    def __init__(self, num_head: int) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.empty(1, num_head))
        self.bias = nn.Parameter(torch.ones(1, num_head) / 8.0)
        nn.init.uniform_(self.weight, 0.75, 1.25)

    def forward(self, y: torch.Tensor, inverse: bool = False) -> torch.Tensor:
        y = y.view(-1, 1)
        if inverse:
            return (y - self.bias) / (self.weight + 1e-9)
        return (self.weight + 1e-9) * y + self.bias


class LabelAdapter(nn.Module):
    """
    对齐官方 DoubleAdapt 的 `LabelAdapter` 主线：
    基于输入上下文决定应该如何变换监督标签与预测输出。
    """

    def __init__(self, in_dim: int, num_head: int = 4, temperature: float = 4.0, hidden_dim: int = 64) -> None:
        super().__init__()
        self.proj = nn.Linear(in_dim, hidden_dim, bias=False)
        self.prototypes = nn.Parameter(torch.randn(num_head, hidden_dim) * 0.02)
        self.heads = LabelAdaptHeads(num_head)
        self.temperature = temperature

    def forward(self, x: torch.Tensor, y: torch.Tensor, inverse: bool = False) -> torch.Tensor:
        context = self.proj(x)
        gate = torch.softmax(cosine_similarity_matrix(context, self.prototypes) / self.temperature, dim=-1)
        transformed = self.heads(y, inverse=inverse)
        return (gate * transformed).sum(dim=-1)


class DoubleAdaptBackbone(nn.Module):
    """
    项目级骨干网络：
    - 使用 GRU 编码时序窗口；
    - 与表格特征拼接后输出一个回归分数。
    """

    def __init__(self, seq_dim: int, tab_dim: int, hidden_dim: int = 64) -> None:
        super().__init__()
        self.seq_encoder = nn.GRU(input_size=seq_dim, hidden_size=hidden_dim, batch_first=True)
        self.tab_proj = nn.Sequential(nn.Linear(tab_dim, hidden_dim), nn.ReLU(), nn.LayerNorm(hidden_dim))
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, sequence_x: torch.Tensor, tabular_x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        _, hidden = self.seq_encoder(sequence_x)
        seq_repr = hidden[-1]
        tab_repr = self.tab_proj(tabular_x)
        context = torch.cat([seq_repr, tab_repr], dim=-1)
        score = self.head(context).squeeze(-1)
        return score, context


class DoubleAdaptLikeModel(nn.Module):
    """
    项目级 DoubleAdapt 适配版：
    1. 先把时序和表格特征编码成统一上下文；
    2. 对上下文施加特征适配；
    3. 让标签适配器在训练阶段变换标签，在预测阶段做逆变换；
    4. 从而保留官方“适配输入分布 + 适配标签空间”的核心思想。
    """

    def __init__(
        self,
        seq_dim: int,
        tab_dim: int,
        hidden_dim: int = 64,
        num_head: int = 4,
        temperature: float = 4.0,
    ) -> None:
        super().__init__()
        self.backbone = DoubleAdaptBackbone(seq_dim=seq_dim, tab_dim=tab_dim, hidden_dim=hidden_dim)
        self.feature_adapter = FeatureAdapter(in_dim=hidden_dim * 2, num_head=num_head, temperature=temperature)
        self.label_adapter = LabelAdapter(in_dim=hidden_dim * 2, num_head=num_head, temperature=temperature, hidden_dim=hidden_dim)
        self.adapted_head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward_train(self, sequence_x: torch.Tensor, tabular_x: torch.Tensor, y: torch.Tensor) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        _, context = self.backbone(sequence_x, tabular_x)
        adapted_context = self.feature_adapter(context)
        pred_adapted = self.adapted_head(adapted_context).squeeze(-1)
        target_adapted = self.label_adapter(context, y, inverse=False)
        pred_raw = self.label_adapter(context, pred_adapted, inverse=True)
        extra = {
            "context": context,
            "adapted_context": adapted_context,
            "target_adapted": target_adapted,
            "pred_adapted": pred_adapted,
            "pred_raw": pred_raw,
        }
        return pred_adapted, extra

    def forward_predict(self, sequence_x: torch.Tensor, tabular_x: torch.Tensor) -> torch.Tensor:
        _, context = self.backbone(sequence_x, tabular_x)
        adapted_context = self.feature_adapter(context)
        pred_adapted = self.adapted_head(adapted_context).squeeze(-1)
        pred_raw = self.label_adapter(context, pred_adapted, inverse=True)
        return pred_raw

    def forward(
        self,
        sequence_x: torch.Tensor,
        tabular_x: torch.Tensor,
        y: torch.Tensor | None = None,
        return_train_outputs: bool = False,
    ) -> torch.Tensor | tuple[torch.Tensor, dict[str, torch.Tensor]]:
        if return_train_outputs:
            if y is None:
                raise ValueError("训练模式下必须提供 y。")
            return self.forward_train(sequence_x, tabular_x, y)
        return self.forward_predict(sequence_x, tabular_x)


@dataclass
class DoubleAdaptTrainConfig:
    n_epochs: int = 12
    batch_size: int = 512
    lr: float = 1e-3
    weight_decay: float = 1e-5
    early_stop_rounds: int = 3
    reg_context: float = 0.01
    reg_label: float = 0.05


def masked_mse(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    mask = torch.isfinite(target)
    if mask.sum() == 0:
        return (pred * 0.0).sum()
    return ((pred[mask] - target[mask]) ** 2).mean()


def fit_doubleadapt_model(
    model: DoubleAdaptLikeModel,
    train_dataset: DoubleAdaptArrayDataset,
    valid_dataset: DoubleAdaptArrayDataset,
    config: DoubleAdaptTrainConfig,
    device: str,
) -> DoubleAdaptLikeModel:
    torch_device = torch.device(device)
    model = model.to(torch_device)
    model = maybe_wrap_data_parallel(model, device=device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.lr, weight_decay=config.weight_decay)
    train_loader = build_loader(train_dataset, batch_size=config.batch_size, shuffle=True)
    valid_loader = build_loader(valid_dataset, batch_size=config.batch_size, shuffle=False)

    best_state = copy.deepcopy(model.state_dict())
    best_valid = float("inf")
    patience = 0

    for _ in range(config.n_epochs):
        model.train()
        for sequence_x, tabular_x, y in train_loader:
            sequence_x = sequence_x.to(torch_device)
            tabular_x = tabular_x.to(torch_device)
            y = y.to(torch_device)
            optimizer.zero_grad()
            pred_adapted, extra = model(sequence_x, tabular_x, y, return_train_outputs=True)
            loss_main = masked_mse(pred_adapted, extra["target_adapted"])
            loss_recover = masked_mse(extra["pred_raw"], y)
            loss_context = (extra["adapted_context"] - extra["context"]).pow(2).mean()
            loss = loss_main + config.reg_label * loss_recover + config.reg_context * loss_context
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

        model.eval()
        losses: list[float] = []
        with torch.no_grad():
            for sequence_x, tabular_x, y in valid_loader:
                sequence_x = sequence_x.to(torch_device)
                tabular_x = tabular_x.to(torch_device)
                y = y.to(torch_device)
                pred = model(sequence_x, tabular_x)
                losses.append(float(masked_mse(pred, y).item()))
        valid_loss = float(np.mean(losses)) if losses else float("inf")
        if valid_loss + 1e-8 < best_valid:
            best_valid = valid_loss
            best_state = copy.deepcopy(model.state_dict())
            patience = 0
        else:
            patience += 1
            if patience >= config.early_stop_rounds:
                break

    model.load_state_dict(best_state)
    return model


def predict_doubleadapt_model(
    model: DoubleAdaptLikeModel,
    dataset: DoubleAdaptArrayDataset,
    batch_size: int,
    device: str,
) -> np.ndarray:
    torch_device = torch.device(device)
    model = model.to(torch_device)
    model = maybe_wrap_data_parallel(model, device=device)
    loader = build_loader(dataset, batch_size=batch_size, shuffle=False)
    preds: list[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for sequence_x, tabular_x, y in loader:
            del y
            sequence_x = sequence_x.to(torch_device)
            tabular_x = tabular_x.to(torch_device)
            pred = model(sequence_x, tabular_x).detach().cpu().numpy()
            preds.append(pred)
    return np.concatenate(preds, axis=0) if preds else np.empty(shape=(0,), dtype=np.float32)


def make_dataset(split_arrays: dict[str, np.ndarray]) -> DoubleAdaptArrayDataset:
    return DoubleAdaptArrayDataset(
        sequence_x=split_arrays["sequence_x"],
        tabular_x=split_arrays["tabular_x"],
        y=split_arrays["y"],
    )


def run_doubleadapt_direction(
    source_market: str,
    target_market: str,
    max_symbols: int,
    lookback: int,
    top_k: int,
    device: str,
    force_rebuild: bool,
) -> dict[str, float]:
    transfer = prepare_transfer_artifacts(
        source_market=source_market,
        target_market=target_market,
        max_symbols=max_symbols,
        horizon=5,
        force_rebuild=force_rebuild,
    )
    target_panel = transfer["target"]["panel_df"]
    target_incidence = transfer["target"]["incidence_df"]
    split = SplitConfig()
    target_arrays, target_meta = build_split_arrays(target_panel, target_incidence, split=split, lookback=lookback)

    train_dataset = make_dataset(target_arrays["train"])
    valid_dataset = make_dataset(target_arrays["valid"])
    test_dataset = make_dataset(target_arrays["test"])

    model = DoubleAdaptLikeModel(
        seq_dim=target_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=target_arrays["train"]["tabular_x"].shape[-1],
    )
    train_cfg = DoubleAdaptTrainConfig()
    model = fit_doubleadapt_model(model, train_dataset, valid_dataset, config=train_cfg, device=device)
    prediction = predict_doubleadapt_model(model, test_dataset, batch_size=1024, device=device)

    result_dir = RESULT_DIR / f"{source_market.lower()}_to_{target_market.lower()}" / "doubleadapt"
    metrics = evaluate_and_save("doubleadapt", result_dir, target_meta["test"], prediction, top_k=top_k)
    (result_dir / "train_config.json").write_text(json.dumps(train_cfg.__dict__, ensure_ascii=False, indent=2), encoding="utf-8")
    return metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行项目级 DoubleAdapt 适配版")
    parser.add_argument("--source-market", default="CN")
    parser.add_argument("--target-market", default="US")
    parser.add_argument("--max-symbols", type=int, default=80)
    parser.add_argument("--lookback", type=int, default=20)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    ensure_dir(RESULT_DIR)
    metrics = run_doubleadapt_direction(
        source_market=args.source_market,
        target_market=args.target_market,
        max_symbols=args.max_symbols,
        lookback=args.lookback,
        top_k=args.top_k,
        device=args.device,
        force_rebuild=args.force_rebuild,
    )
    log(json.dumps(metrics, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

