"""
文件功能:
1. 为 AAAIV3 附录执行两类关键补实验: 扩展消融的 mechanism preservation 指标重跑, 以及 similarity policy 敏感性小网格实验。
2. 在不改动模型核心逻辑的前提下, 复用现有 AMT 训练与评估链路, 导出 `ECR / FAR@3 / FDR / Policy` 等附录必需指标。
3. 统一落盘实验原始结果、扩展总表、热力图与 manifest, 保证实验过程与结果可追溯。

代码逻辑:
1. 每个方向只做一次源域预训练, 再将同一个预训练状态复用于不同消融变体和不同 policy 阈值配置, 降低 24 小时窗口内的运行成本。
2. 在目标域适配完成后, 基于模型内部现成的 source/target alpha exposure 计算 `ECR / FAR@3`, 并通过预训练前后参数漂移计算 `FDR`。
3. 额外围绕 `0.997` 附近的相似度阈值执行小网格 sensitivity, 观察 policy 是否切换及其对 `RankIC / Ann.Ret.` 的影响。
4. 将实验总表、热力图和解释性 Markdown 写入当前附录批次目录, 供 appendix 直接引用。

代码结构:
1. 结果路径与通用工具函数。
2. 数据准备、预训练与目标域适配函数。
3. mechanism metrics 计算与热力图生成。
4. sensitivity 小网格实验。
5. CLI 入口。
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from data_pipeline import SplitConfig, prepare_transfer_artifacts
from experiment_profiles import get_profile, resolve_max_symbols
from experiment_runner import (
    align_transfer_concept_arrays,
    build_amt_scoring_config,
    build_amt_supervised_loss_config,
    build_market_similarity_config,
    build_split_arrays,
    build_threshold_update_config,
    cap_market_artifacts_for_quick_mode,
    evaluate_and_save,
    make_dataset,
    normalize_direction,
    parse_csv_args,
    scale_epoch_count,
)
from experiment_workspace import get_archive_root, get_categorized_result_path, get_paper_asset_path, write_dataframe, write_json
from market_similarity import (
    AdaptationPolicy,
    AdaptationPolicyConfig,
    MarketSimilarityConfig,
    ThresholdUpdateConfig,
    build_adaptation_param_groups,
    compute_market_similarity,
    recommend_similarity_threshold,
    resolve_adaptation_policy,
)
from models import (
    ALPHA_FEATURES,
    AMTScoringConfig,
    SupervisedLossConfig,
    TorchTrainingConfig,
    build_torch_model,
    fit_torch_regressor,
    predict_torch_regressor,
    unwrap_model,
)


RESULT_ROOT = get_categorized_result_path("other", "appendix_mechanism_pack")
SENSITIVITY_ROOT = get_categorized_result_path("other", "appendix_similarity_sensitivity")

ABLATION_VARIANTS = [
    {
        "key": "amt_reference",
        "display_name": "AMT-Reference",
        "freeze_backbone": True,
        "freeze_factor_projector": True,
        "freeze_base_scoring_module": True,
        "unfreeze_base_scoring_last_layer": False,
        "freeze_source_alpha_weight": True,
        "weight_param": 0.002,
        "weight_mech": 0.0005,
    },
    {
        "key": "no_mechanism_constraint",
        "display_name": "No-Mechanism-Constraint",
        "freeze_backbone": True,
        "freeze_factor_projector": True,
        "freeze_base_scoring_module": True,
        "unfreeze_base_scoring_last_layer": False,
        "freeze_source_alpha_weight": True,
        "weight_param": 0.002,
        "weight_mech": 0.0,
    },
    {
        "key": "no_structure_freezing",
        "display_name": "No-Structure-Freezing",
        "freeze_backbone": False,
        "freeze_factor_projector": False,
        "freeze_base_scoring_module": False,
        "unfreeze_base_scoring_last_layer": False,
        "freeze_source_alpha_weight": False,
        "weight_param": 0.002,
        "weight_mech": 0.0005,
    },
    {
        "key": "unfreeze_base_scoring_last_layer",
        "display_name": "Unfreeze-Base-Scoring-Last-Layer",
        "freeze_backbone": True,
        "freeze_factor_projector": True,
        "freeze_base_scoring_module": True,
        "unfreeze_base_scoring_last_layer": True,
        "freeze_source_alpha_weight": True,
        "weight_param": 0.002,
        "weight_mech": 0.0005,
    },
    {
        "key": "local_adaptation_only",
        "display_name": "Local-Adaptation-Only",
        "freeze_backbone": True,
        "freeze_factor_projector": True,
        "freeze_base_scoring_module": True,
        "unfreeze_base_scoring_last_layer": False,
        "freeze_source_alpha_weight": True,
        "weight_param": 0.0,
        "weight_mech": 0.0,
    },
]

SENSITIVITY_GRID = [
    {"threshold": 0.9960, "medium_gap": 0.0010, "low_gap": 0.0030},
    {"threshold": 0.9975, "medium_gap": 0.0010, "low_gap": 0.0030},
    {"threshold": 0.9990, "medium_gap": 0.0010, "low_gap": 0.0030},
    {"threshold": 0.9960, "medium_gap": 0.0030, "low_gap": 0.0050},
    {"threshold": 0.9975, "medium_gap": 0.0030, "low_gap": 0.0050},
    {"threshold": 0.9990, "medium_gap": 0.0030, "low_gap": 0.0050},
]


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    view = df.copy()
    for column in view.columns:
        if pd.api.types.is_float_dtype(view[column]):
            view[column] = view[column].map(lambda value: f"{value:.6f}")
    headers = [str(column) for column in view.columns.tolist()]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in view.iterrows():
        lines.append("| " + " | ".join(str(value) for value in row.tolist()) + " |")
    return "\n".join(lines)


def clone_named_parameters(model: torch.nn.Module) -> dict[str, torch.Tensor]:
    base_model = unwrap_model(model)
    return {name: param.detach().cpu().clone() for name, param in base_model.named_parameters()}


def is_frozen_parameter(name: str, config: dict[str, Any]) -> bool:
    if name.startswith(("seq_encoder.", "tab_encoder.", "concept_encoder.")):
        return bool(config["freeze_backbone"])
    if name.startswith(("alpha_input_norm.", "factor_projector.")):
        return bool(config["freeze_factor_projector"])
    if name.startswith("base_head."):
        if not bool(config["freeze_base_scoring_module"]):
            return False
        if bool(config["unfreeze_base_scoring_last_layer"]) and name.startswith("base_head.2."):
            return False
        return True
    if name == "source_alpha_weight":
        return bool(config["freeze_source_alpha_weight"])
    return False


def compute_frozen_drift_ratio(model: torch.nn.Module, pre_state: dict[str, torch.Tensor], config: dict[str, Any]) -> float:
    base_model = unwrap_model(model)
    frozen_drift = 0.0
    total_drift = 0.0
    for name, param in base_model.named_parameters():
        before = pre_state[name]
        after = param.detach().cpu()
        drift = float(torch.norm(after - before, p=2).item())
        total_drift += drift
        if is_frozen_parameter(name, config):
            frozen_drift += drift
    if total_drift <= 1e-12:
        return 0.0
    return float(frozen_drift / total_drift)


def build_direction_arrays(source_market: str, target_market: str, max_symbols: int, lookback: int, mode: str, force_rebuild: bool) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]], dict[str, pd.DataFrame]]:
    source_max_symbols = resolve_max_symbols(get_profile(mode), source_market, max_symbols)
    target_max_symbols = resolve_max_symbols(get_profile(mode), target_market, max_symbols)
    effective_max_symbols = min(source_max_symbols, target_max_symbols)
    transfer = prepare_transfer_artifacts(
        source_market=source_market,
        target_market=target_market,
        max_symbols=effective_max_symbols,
        horizon=5,
        force_rebuild=force_rebuild,
    )
    if str(mode).lower() in {"smoke", "medium"}:
        transfer["source"] = cap_market_artifacts_for_quick_mode(transfer["source"], source_max_symbols)
        transfer["target"] = cap_market_artifacts_for_quick_mode(transfer["target"], target_max_symbols)
    split = SplitConfig()
    source_arrays, _ = build_split_arrays(transfer["source"]["panel_df"], transfer["source"]["incidence_df"], split=split, lookback=lookback)
    target_arrays, target_meta = build_split_arrays(transfer["target"]["panel_df"], transfer["target"]["incidence_df"], split=split, lookback=lookback)
    source_arrays, target_arrays, _ = align_transfer_concept_arrays(source_arrays, target_arrays)
    return source_arrays, target_arrays, target_meta


def pretrain_source_model(
    source_arrays: dict[str, dict[str, Any]],
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    device: str,
    mode: str,
) -> tuple[dict[str, Any], torch.nn.Module]:
    model = build_torch_model(
        model_name="main",
        seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=source_arrays["train"]["concept_x"].shape[-1],
        alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
        scoring_config=scoring_config,
    )
    pretrain_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(12, mode=mode, minimum_epochs=4),
        batch_size=512,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=3,
    )
    model = fit_torch_regressor(
        model,
        make_dataset(source_arrays["train"]),
        make_dataset(source_arrays["valid"]),
        config=pretrain_cfg,
        supervised_loss_config=supervised_loss_config,
        device=device,
    )
    model = unwrap_model(model)
    state = copy.deepcopy(model.state_dict())
    return state, model


def instantiate_pretrained_model(
    pretrained_state: dict[str, Any],
    source_arrays: dict[str, dict[str, Any]],
    scoring_config: AMTScoringConfig,
) -> torch.nn.Module:
    model = build_torch_model(
        model_name="main",
        seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=source_arrays["train"]["concept_x"].shape[-1],
        alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
        scoring_config=scoring_config,
    )
    model.load_state_dict(pretrained_state)
    return unwrap_model(model)


def build_base_policy(
    pretrained_model: torch.nn.Module,
    source_arrays: dict[str, dict[str, Any]],
    target_arrays: dict[str, dict[str, Any]],
    similarity_config: MarketSimilarityConfig,
    threshold_config: ThresholdUpdateConfig,
    history_path: Path,
    policy_config: AdaptationPolicyConfig,
    device: str,
) -> tuple[AdaptationPolicy, dict[str, Any]]:
    similarity_result = compute_market_similarity(
        source_arrays=source_arrays["train"],
        target_arrays=target_arrays["train"],
        model=pretrained_model,
        device=device,
        config=similarity_config,
    )
    threshold_summary = recommend_similarity_threshold(history_path, config=threshold_config)
    policy = resolve_adaptation_policy(
        similarity_score=float(similarity_result.final_similarity),
        similarity_threshold=float(threshold_summary["threshold"]),
        config=policy_config,
    )
    payload = {
        "similarity_result": similarity_result.to_dict(),
        "threshold_summary": threshold_summary,
        "policy": policy.to_dict(),
    }
    return policy, payload


def mechanism_metrics(
    model: torch.nn.Module,
    split_arrays: dict[str, Any],
    top_k: int,
    device: str,
) -> tuple[dict[str, float], dict[str, list[float]]]:
    base_model = unwrap_model(model).to(device)
    base_model.eval()
    batch_size = 512
    count = int(split_arrays["sequence_x"].shape[0])
    source_top_idx = None
    cosine_values: list[float] = []
    far_values: list[float] = []
    mean_source_exposure = np.zeros(len(ALPHA_FEATURES), dtype=np.float64)
    mean_target_exposure = np.zeros(len(ALPHA_FEATURES), dtype=np.float64)
    seen = 0
    with torch.no_grad():
        for start in range(0, count, batch_size):
            end = min(start + batch_size, count)
            sequence_x = torch.as_tensor(split_arrays["sequence_x"][start:end], dtype=torch.float32, device=device)
            tabular_x = torch.as_tensor(split_arrays["tabular_x"][start:end], dtype=torch.float32, device=device)
            concept_x = torch.as_tensor(split_arrays["concept_x"][start:end], dtype=torch.float32, device=device)
            regime_x = torch.as_tensor(split_arrays["regime_x"][start:end], dtype=torch.int64, device=device)
            alpha_x = torch.as_tensor(split_arrays["alpha_x"][start:end], dtype=torch.float32, device=device)

            _common_repr, _factor_repr, context = base_model._build_context(sequence_x, tabular_x, concept_x, regime_x, alpha_x)
            normalized_alpha_x = base_model._normalize_alpha_input(alpha_x)
            source_weight = base_model._get_source_weight(device)
            target_alpha_weight, _sparse_gate, _active_delta = base_model._compose_target_alpha_weight(alpha_x, context)
            source_exposure = normalized_alpha_x * source_weight.unsqueeze(0)
            target_exposure = normalized_alpha_x * target_alpha_weight
            cosine_values.extend(F.cosine_similarity(target_exposure, source_exposure, dim=-1).detach().cpu().numpy().astype(float).tolist())
            if source_top_idx is None:
                source_top_idx = torch.topk(source_weight.abs(), k=min(top_k, int(source_weight.numel()))).indices.detach().cpu().tolist()
            target_top_indices = torch.topk(target_alpha_weight.abs(), k=min(top_k, int(target_alpha_weight.shape[-1])), dim=-1).indices.detach().cpu().tolist()
            for indices in target_top_indices:
                overlap = len(set(source_top_idx).intersection(set(indices)))
                far_values.append(float(overlap) / float(min(top_k, len(source_top_idx))))
            batch_count = end - start
            mean_source_exposure += source_exposure.detach().cpu().numpy().mean(axis=0) * batch_count
            mean_target_exposure += target_exposure.detach().cpu().numpy().mean(axis=0) * batch_count
            seen += batch_count
    if seen > 0:
        mean_source_exposure = mean_source_exposure / float(seen)
        mean_target_exposure = mean_target_exposure / float(seen)
    metrics = {
        "ECR": float(np.mean(cosine_values)) if cosine_values else np.nan,
        "FAR@3": float(np.mean(far_values)) if far_values else np.nan,
    }
    payload = {
        "alpha_features": list(ALPHA_FEATURES),
        "mean_source_exposure": mean_source_exposure.tolist(),
        "mean_target_exposure": mean_target_exposure.tolist(),
    }
    return metrics, payload


def build_transfer_penalty(weight_param: float, weight_mech: float):
    def _transfer_penalty(model_obj: torch.nn.Module, batch: tuple[torch.Tensor, ...], pred: Any) -> torch.Tensor:
        _ = pred
        return model_obj.extra_transfer_loss(
            batch[4],
            batch[1],
            batch[0],
            batch[2],
            batch[3],
            weight_param=weight_param,
            weight_mech=weight_mech,
        )

    return _transfer_penalty


def run_target_adaptation(
    model: torch.nn.Module,
    target_arrays: dict[str, dict[str, Any]],
    target_meta: dict[str, pd.DataFrame],
    experiment_dir: Path,
    record_name: str,
    top_k: int,
    device: str,
    mode: str,
    supervised_loss_config: SupervisedLossConfig,
    extra_loss_fn,
    optimizer_group_builder=None,
) -> dict[str, float]:
    adapt_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(8, mode=mode, minimum_epochs=3),
        batch_size=512,
        lr=1e-3,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    model = fit_torch_regressor(
        model,
        make_dataset(target_arrays["train"]),
        make_dataset(target_arrays["valid"]),
        config=adapt_cfg,
        supervised_loss_config=supervised_loss_config,
        extra_loss_fn=extra_loss_fn,
        optimizer_group_builder=optimizer_group_builder,
        device=device,
    )
    prediction = predict_torch_regressor(model, make_dataset(target_arrays["test"]), batch_size=1024, device=device)
    metrics = evaluate_and_save(record_name, experiment_dir, target_meta["test"], prediction, top_k=top_k)
    return metrics


def plot_exposure_heatmap(records: list[dict[str, Any]], output_path: Path) -> None:
    ref_records = [item for item in records if item["variant"] == "amt_reference"]
    if not ref_records:
        return
    fig, axes = plt.subplots(len(ref_records), 1, figsize=(8, 2.8 * len(ref_records)), squeeze=False)
    for row_idx, record in enumerate(ref_records):
        matrix = np.vstack(
            [
                np.asarray(record["exposure_payload"]["mean_source_exposure"], dtype=float),
                np.asarray(record["exposure_payload"]["mean_target_exposure"], dtype=float),
            ]
        )
        ax = axes[row_idx, 0]
        im = ax.imshow(matrix, aspect="auto", cmap="coolwarm")
        ax.set_yticks([0, 1], labels=["Source", "Target"])
        ax.set_xticks(range(len(record["exposure_payload"]["alpha_features"])), labels=record["exposure_payload"]["alpha_features"], rotation=45, ha="right")
        ax.set_title(f"{record['direction']} | AMT-Reference exposure heatmap")
        fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    fig.tight_layout()
    fig.savefig(output_path, dpi=220)
    plt.close(fig)


def build_mechanism_markdown(summary_df: pd.DataFrame, sensitivity_df: pd.DataFrame) -> str:
    return (
        "# AAAIV3 mechanism pack\n\n"
        "## 1. Extended ablation with mechanism metrics\n\n"
        f"{render_markdown_table(summary_df)}\n\n"
        "## 2. Similarity sensitivity\n\n"
        f"{render_markdown_table(sensitivity_df)}\n"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="执行 AAAIV3 附录 mechanism 指标包与相似度敏感性实验")
    parser.add_argument("--mode", default="full", choices=["full", "medium", "smoke"])
    parser.add_argument("--max-symbols", type=int, default=160)
    parser.add_argument("--lookback", type=int, default=20)
    parser.add_argument("--top-k", type=int, default=20)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true")
    parser.add_argument("--direction", default="cn_to_us,us_to_cn")
    parser.add_argument("--amt-top-r", type=int, default=3)
    parser.add_argument("--amt-gate-temperature", type=float, default=0.70)
    parser.add_argument("--amt-alpha-residual-scale", type=float, default=0.35)
    parser.add_argument("--amt-delta-clip", type=float, default=0.75)
    parser.add_argument("--amt-min-gate-mass", type=float, default=1e-6)
    parser.add_argument("--amt-supervised-objective", choices=["mse", "rank_return"], default="rank_return")
    parser.add_argument("--amt-rank-loss-weight", type=float, default=1.0)
    parser.add_argument("--amt-return-loss-weight", type=float, default=2.0)
    parser.add_argument("--amt-mse-anchor-weight", type=float, default=0.05)
    parser.add_argument("--amt-pairwise-label-threshold", type=float, default=1e-4)
    parser.add_argument("--amt-return-temperature", type=float, default=0.35)
    parser.add_argument("--amt-annualization-factor", type=float, default=252.0)
    parser.add_argument("--market-similarity-threshold", type=float, default=0.70)
    parser.add_argument("--market-similarity-sample-size", type=int, default=2048)
    parser.add_argument("--market-similarity-batch-size", type=int, default=512)
    parser.add_argument("--market-similarity-rbf-gamma", type=float, default=0.50)
    parser.add_argument("--market-threshold-update-method", choices=["ema_quantile", "supervised_gain"], default="ema_quantile")
    parser.add_argument("--market-threshold-quantile", type=float, default=0.65)
    parser.add_argument("--market-threshold-ema-decay", type=float, default=0.80)
    parser.add_argument("--market-similarity-history-path", default=str(Path(__file__).resolve().parents[1] / "results" / "market_similarity_threshold_history.json"))
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    archive_root = get_archive_root()
    result_root = ensure_dir(RESULT_ROOT)
    sensitivity_root = ensure_dir(SENSITIVITY_ROOT)
    asset_dir = ensure_dir(get_paper_asset_path(archive_root, "appendix_support", "mechanism_pack", paper_name="AAAIV3"))

    scoring_config = build_amt_scoring_config(args)
    supervised_loss_config = build_amt_supervised_loss_config(args)
    similarity_config = build_market_similarity_config(args)
    threshold_config = build_threshold_update_config(args)
    history_path = Path(args.market_similarity_history_path).resolve()
    direction_keys = [normalize_direction(item) for item in parse_csv_args(args.direction)]

    ablation_records: list[dict[str, Any]] = []
    sensitivity_records: list[dict[str, Any]] = []

    for direction_key in direction_keys:
        source_market, target_market = ("CN", "US") if direction_key == "cn_to_us" else ("US", "CN")
        source_arrays, target_arrays, target_meta = build_direction_arrays(
            source_market=source_market,
            target_market=target_market,
            max_symbols=int(args.max_symbols),
            lookback=int(args.lookback),
            mode=str(args.mode),
            force_rebuild=bool(args.force_rebuild),
        )
        pretrained_state, pretrained_model = pretrain_source_model(
            source_arrays=source_arrays,
            scoring_config=scoring_config,
            supervised_loss_config=supervised_loss_config,
            device=str(args.device),
            mode=str(args.mode),
        )
        base_policy, policy_payload = build_base_policy(
            pretrained_model=pretrained_model,
            source_arrays=source_arrays,
            target_arrays=target_arrays,
            similarity_config=similarity_config,
            threshold_config=threshold_config,
            history_path=history_path,
            policy_config=AdaptationPolicyConfig(medium_gap=0.15, low_gap=0.35),
            device=str(args.device),
        )
        direction_dir = ensure_dir(result_root / f"{source_market.lower()}_to_{target_market.lower()}")
        write_json(direction_dir / "base_policy_report.json", policy_payload)

        for variant in ABLATION_VARIANTS:
            model = instantiate_pretrained_model(pretrained_state=pretrained_state, source_arrays=source_arrays, scoring_config=scoring_config)
            if variant["key"] == "no_structure_freezing":
                adaptation_kwargs = {
                    "freeze_backbone": False,
                    "freeze_factor_projector": False,
                    "freeze_base_scoring_module": False,
                    "unfreeze_base_scoring_last_layer": False,
                    "freeze_source_alpha_weight": False,
                }
            elif variant["key"] == "unfreeze_base_scoring_last_layer":
                adaptation_kwargs = {
                    **base_policy.to_adaptation_kwargs(),
                    "freeze_base_scoring_module": True,
                    "unfreeze_base_scoring_last_layer": True,
                }
            else:
                adaptation_kwargs = {
                    "freeze_backbone": bool(variant["freeze_backbone"]),
                    "freeze_factor_projector": bool(variant["freeze_factor_projector"]),
                    "freeze_base_scoring_module": bool(variant["freeze_base_scoring_module"]),
                    "unfreeze_base_scoring_last_layer": bool(variant["unfreeze_base_scoring_last_layer"]),
                    "freeze_source_alpha_weight": bool(variant["freeze_source_alpha_weight"]),
                }
            model.configure_target_adaptation(**adaptation_kwargs)
            pre_state = clone_named_parameters(model)
            optimizer_group_builder = lambda model_obj, cfg, policy=base_policy: build_adaptation_param_groups(model_obj, cfg, policy)
            variant_dir = ensure_dir(direction_dir / variant["key"])
            metrics = run_target_adaptation(
                model=model,
                target_arrays=target_arrays,
                target_meta=target_meta,
                experiment_dir=variant_dir,
                record_name=variant["display_name"],
                top_k=int(args.top_k),
                device=str(args.device),
                mode=str(args.mode),
                supervised_loss_config=supervised_loss_config,
                extra_loss_fn=build_transfer_penalty(float(variant["weight_param"]), float(variant["weight_mech"])),
                optimizer_group_builder=optimizer_group_builder,
            )
            metric_pack, exposure_payload = mechanism_metrics(model, target_arrays["test"], top_k=3, device=str(args.device))
            fdr = compute_frozen_drift_ratio(model=model, pre_state=pre_state, config=adaptation_kwargs)
            record = {
                "direction": f"{source_market}->{target_market}",
                "variant": variant["key"],
                "display_name": variant["display_name"],
                "policy_name": str(base_policy.policy_name),
                "similarity_score": float(base_policy.similarity_score),
                "similarity_threshold": float(base_policy.similarity_threshold),
                "RankIC": float(metrics.get("RankIC", 0.0)),
                "Annualized Return": float(metrics.get("Annualized Return", 0.0)),
                "Sharpe Ratio": float(metrics.get("Sharpe Ratio", 0.0)),
                "Maximum Drawdown": float(metrics.get("Maximum Drawdown", 0.0)),
                "ECR": float(metric_pack["ECR"]),
                "FAR@3": float(metric_pack["FAR@3"]),
                "FDR": float(fdr),
                "prediction_path": str(variant_dir / "test_predictions.csv"),
                "summary_path": str(variant_dir / "summary.json"),
            }
            ablation_records.append({**record, "exposure_payload": exposure_payload})
            write_json(variant_dir / "mechanism_metrics.json", {**record, "exposure_payload": exposure_payload})

        sensitivity_direction_dir = ensure_dir(sensitivity_root / f"{source_market.lower()}_to_{target_market.lower()}")
        similarity_result = policy_payload["similarity_result"]
        for grid_id, grid in enumerate(SENSITIVITY_GRID, start=1):
            model = instantiate_pretrained_model(pretrained_state=pretrained_state, source_arrays=source_arrays, scoring_config=scoring_config)
            policy = resolve_adaptation_policy(
                similarity_score=float(similarity_result["final_similarity"]),
                similarity_threshold=float(grid["threshold"]),
                config=AdaptationPolicyConfig(medium_gap=float(grid["medium_gap"]), low_gap=float(grid["low_gap"])),
            )
            model.configure_target_adaptation(**policy.to_adaptation_kwargs())
            optimizer_group_builder = lambda model_obj, cfg, policy=policy: build_adaptation_param_groups(model_obj, cfg, policy)
            run_name = f"policy_grid_{grid_id:02d}"
            run_dir = ensure_dir(sensitivity_direction_dir / run_name)
            metrics = run_target_adaptation(
                model=model,
                target_arrays=target_arrays,
                target_meta=target_meta,
                experiment_dir=run_dir,
                record_name=f"AMT-Reference-{run_name}",
                top_k=int(args.top_k),
                device=str(args.device),
                mode=str(args.mode),
                supervised_loss_config=supervised_loss_config,
                extra_loss_fn=build_transfer_penalty(0.002, 0.0005),
                optimizer_group_builder=optimizer_group_builder,
            )
            sensitivity_record = {
                "direction": f"{source_market}->{target_market}",
                "config_id": run_name,
                "threshold": float(grid["threshold"]),
                "medium_gap": float(grid["medium_gap"]),
                "low_gap": float(grid["low_gap"]),
                "similarity_score": float(similarity_result["final_similarity"]),
                "policy_name": str(policy.policy_name),
                "RankIC": float(metrics.get("RankIC", 0.0)),
                "Annualized Return": float(metrics.get("Annualized Return", 0.0)),
                "Sharpe Ratio": float(metrics.get("Sharpe Ratio", 0.0)),
                "Maximum Drawdown": float(metrics.get("Maximum Drawdown", 0.0)),
                "prediction_path": str(run_dir / "test_predictions.csv"),
                "summary_path": str(run_dir / "summary.json"),
            }
            sensitivity_records.append(sensitivity_record)
            write_json(run_dir / "policy_summary.json", sensitivity_record)

    summary_df = pd.DataFrame([{key: value for key, value in item.items() if key != "exposure_payload"} for item in ablation_records])
    sensitivity_df = pd.DataFrame(sensitivity_records)
    mechanism_csv = write_dataframe(summary_df, asset_dir / "extended_ablation_mechanism_table.csv", index=False, encoding="utf-8-sig")
    sensitivity_csv = write_dataframe(sensitivity_df, asset_dir / "policy_sensitivity_table.csv", index=False, encoding="utf-8-sig")
    heatmap_path = asset_dir / "factor_exposure_heatmap.png"
    plot_exposure_heatmap(ablation_records, heatmap_path)
    markdown_path = asset_dir / "mechanism_pack.md"
    markdown_path.write_text(build_mechanism_markdown(summary_df, sensitivity_df), encoding="utf-8")

    manifest = {
        "archive_root": str(archive_root),
        "result_root": str(result_root),
        "sensitivity_root": str(sensitivity_root),
        "generated_files": {
            "mechanism_table_csv": str(mechanism_csv),
            "sensitivity_table_csv": str(sensitivity_csv),
            "heatmap_png": str(heatmap_path),
            "markdown": str(markdown_path),
        },
        "directions": direction_keys,
        "variants": [item["key"] for item in ABLATION_VARIANTS],
        "sensitivity_grid": SENSITIVITY_GRID,
    }
    write_json(asset_dir / "manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
