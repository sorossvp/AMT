"""
文件功能:
1. 提供一个可直接运行的跨市场迁移分布式 demo, 用于验证 `DataToSever` 数据、PyTorch 环境和多卡通信链路是否正常。
2. 复用项目现有 `processed_data` 面板缓存, 构造源域预训练 + 目标域适配的轻量示例, 输出日志、预测与指标摘要。
3. 支持 `python` 单进程启动, 也支持 `torchrun --nproc_per_node=N` 方式启动 DDP, 作为服务器多 GPU 正式实验前的 smoke test。

代码逻辑:
1. 从 `DataToSever/processed_data/{market}/panel.pkl` 读取面板, 自动补齐 `train/valid/test` 划分并截取小规模样本。
2. 构造时序特征、横截面特征与 alpha 风格特征, 先在源域训练共享编码器, 再冻结主干做目标域小适配。
3. 若检测到 `RANK/WORLD_SIZE` 环境变量, 则初始化 DDP、使用 `DistributedSampler` 防止样本重复和进程卡死。
4. 仅由主进程落盘日志、预测结果和指标, 并统一写入 `resultsFromSSH/<server_name>/log` 与 `resultsFromSSH/<server_name>/results`。

代码结构:
1. 配置、数据准备与标准化函数。
2. 轻量迁移模型定义。
3. DDP 初始化、训练与评估函数。
4. CLI 入口与结果导出。
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from datetime import timedelta
import json
import os
import random
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.distributed as dist
from torch import nn
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, Dataset
from torch.utils.data.distributed import DistributedSampler

from data_pipeline import read_pickle_with_recovery
from experiment_workspace import append_log, build_runtime_paths, ensure_dir, resolve_server_name, write_dataframe, write_json


SPLIT_DATES = {
    "train": ("2008-01-01", "2021-12-31"),
    "valid": ("2022-01-01", "2022-12-31"),
    "test": ("2023-01-01", "2025-12-31"),
}
SEQUENCE_CANDIDATES = [
    "open",
    "high",
    "low",
    "close",
    "volume",
    "ret_1",
    "ret_5",
    "ret_10",
    "ret_20",
    "vol_5",
    "vol_20",
]
TABULAR_CANDIDATES = [
    "ret_1",
    "ret_5",
    "ret_10",
    "ret_20",
    "vol_5",
    "vol_20",
    "vol_60",
    "ma_ratio_5_20",
    "ma_ratio_20_60",
    "hl_spread",
    "oc_return",
    "turnover_proxy",
    "log_dollar_volume",
]
LABEL_CANDIDATES = ["label_rank_proxy", "future_return", "label"]
PROCESS_PREFIX = "[EXP-LOG][DEMO]"
DONE_PREFIX = "[EXP-DONE][DEMO]"


@dataclass(frozen=True)
class DemoConfig:
    source_market: str = "CN"
    target_market: str = "US"
    lookback: int = 12
    max_symbols: int = 8
    train_dates: int = 180
    valid_dates: int = 60
    test_dates: int = 80
    batch_size: int = 64
    pretrain_epochs: int = 3
    adapt_epochs: int = 2
    lr: float = 1e-3
    weight_decay: float = 1e-5
    num_workers: int = 0
    seed: int = 42
    server_name: str = ""
    output_name: str = "ddp_demo"
    device: str = "cuda"


@dataclass(frozen=True)
class DistEnv:
    rank: int
    local_rank: int
    world_size: int
    distributed: bool
    device: torch.device
    device_name: str


class TransferDataset(Dataset):
    def __init__(self, payload: dict[str, Any]) -> None:
        self.sequence_x = torch.tensor(payload["sequence_x"], dtype=torch.float32)
        self.tabular_x = torch.tensor(payload["tabular_x"], dtype=torch.float32)
        self.alpha_x = torch.tensor(payload["alpha_x"], dtype=torch.float32)
        self.label_y = torch.tensor(payload["label_y"], dtype=torch.float32)
        self.meta = payload["meta"].reset_index(drop=True).copy()

    def __len__(self) -> int:
        return int(self.label_y.shape[0])

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        return (
            self.sequence_x[index],
            self.tabular_x[index],
            self.alpha_x[index],
            self.label_y[index],
        )


class TransferDemoNet(nn.Module):
    """
    轻量示例模型:
    1. `seq_encoder` 提取时间序列局部动态。
    2. `tab_encoder` 与 `alpha_encoder` 负责横截面静态特征压缩。
    3. `adapter` 在目标域阶段补充小尺度偏移, 模拟 parameter-efficient adaptation。
    """

    def __init__(self, seq_dim: int, tab_dim: int, alpha_dim: int, hidden_dim: int = 48) -> None:
        super().__init__()
        self.seq_encoder = nn.LSTM(input_size=seq_dim, hidden_size=hidden_dim, batch_first=True)
        self.tab_encoder = nn.Sequential(nn.Linear(tab_dim, hidden_dim), nn.ReLU(), nn.LayerNorm(hidden_dim))
        self.alpha_encoder = nn.Sequential(nn.Linear(alpha_dim, hidden_dim), nn.ReLU(), nn.LayerNorm(hidden_dim))
        self.adapter = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        self.target_mode = False

    def switch_to_target_adaptation(self) -> None:
        self.target_mode = True
        for module in [self.seq_encoder, self.tab_encoder]:
            for param in module.parameters():
                param.requires_grad = False

    def forward(self, sequence_x: torch.Tensor, tabular_x: torch.Tensor, alpha_x: torch.Tensor) -> torch.Tensor:
        _, (hidden, _) = self.seq_encoder(sequence_x)
        seq_repr = hidden[-1]
        tab_repr = self.tab_encoder(tabular_x)
        alpha_repr = self.alpha_encoder(alpha_x)
        if self.target_mode:
            alpha_repr = alpha_repr + 0.15 * torch.tanh(self.adapter(torch.cat([tab_repr, alpha_repr], dim=-1)))
        fused = torch.cat([seq_repr, tab_repr, alpha_repr], dim=-1)
        return self.head(fused).squeeze(-1)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def rank0_only(env: DistEnv) -> bool:
    return env.rank == 0


def format_seconds(seconds: float) -> str:
    total_seconds = max(0, int(round(seconds)))
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def emit_demo_message(log_path: Path, env: DistEnv, prefix: str, message: str) -> None:
    if not rank0_only(env):
        return
    text = f"{prefix} {message}"
    append_log(log_path, text)
    print(text, flush=True)


def init_dist_env(requested_device: str) -> DistEnv:
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    distributed = world_size > 1
    use_cuda = requested_device.startswith("cuda") and torch.cuda.is_available()
    if distributed:
        backend = "nccl" if use_cuda else "gloo"
        if use_cuda:
            torch.cuda.set_device(local_rank)
        dist.init_process_group(backend=backend, timeout=timedelta(minutes=10))
    if use_cuda:
        device = torch.device(f"cuda:{local_rank}" if distributed else "cuda")
        device_name = str(device)
    else:
        device = torch.device("cpu")
        device_name = "cpu"
    return DistEnv(
        rank=rank,
        local_rank=local_rank,
        world_size=world_size,
        distributed=distributed,
        device=device,
        device_name=device_name,
    )


def cleanup_dist() -> None:
    if dist.is_available() and dist.is_initialized():
        dist.barrier()
        dist.destroy_process_group()


def resolve_label_column(panel_df: pd.DataFrame) -> str:
    for column in LABEL_CANDIDATES:
        if column in panel_df.columns:
            return column
    raise ValueError("未找到可用标签列，至少需要 `label_rank_proxy` 或 `future_return`。")


def assign_split_if_missing(panel_df: pd.DataFrame) -> pd.DataFrame:
    if "split" in panel_df.columns:
        return panel_df.copy()
    df = panel_df.copy()
    df["split"] = None
    for split_name, (start_date, end_date) in SPLIT_DATES.items():
        mask = (df["date"] >= pd.Timestamp(start_date)) & (df["date"] <= pd.Timestamp(end_date))
        df.loc[mask, "split"] = split_name
    return df[df["split"].notna()].copy()


def pick_feature_columns(panel_df: pd.DataFrame) -> tuple[list[str], list[str], list[str], str]:
    seq_cols = [column for column in SEQUENCE_CANDIDATES if column in panel_df.columns]
    tab_cols = [column for column in TABULAR_CANDIDATES if column in panel_df.columns]
    alpha_cols = [column for column in panel_df.columns if str(column).startswith("alpha_")]
    if not seq_cols:
        raise ValueError("当前面板无法构造时序特征。")
    if not tab_cols:
        tab_cols = seq_cols[: min(6, len(seq_cols))]
    if not alpha_cols:
        alpha_cols = tab_cols[: min(4, len(tab_cols))]
    label_col = resolve_label_column(panel_df)
    return seq_cols, tab_cols, alpha_cols, label_col


def restrict_by_dates(split_df: pd.DataFrame, keep_dates: int) -> pd.DataFrame:
    unique_dates = sorted(pd.to_datetime(split_df["date"]).drop_duplicates().tolist())
    if keep_dates <= 0 or len(unique_dates) <= keep_dates:
        return split_df.copy()
    chosen_dates = set(unique_dates[-keep_dates:])
    return split_df[split_df["date"].isin(chosen_dates)].copy()


def build_market_payload(config: DemoConfig, market: str) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    runtime_paths = build_runtime_paths(config.server_name)
    panel_path = runtime_paths.data_dir / "processed_data" / market.lower() / "panel.pkl"
    panel_df = read_pickle_with_recovery(panel_path).copy()
    panel_df["date"] = pd.to_datetime(panel_df["date"])
    panel_df = assign_split_if_missing(panel_df)
    seq_cols, tab_cols, alpha_cols, label_col = pick_feature_columns(panel_df)
    if "dollar_volume" in panel_df.columns:
        liquidity = panel_df.groupby("symbol")["dollar_volume"].mean()
    else:
        liquidity = (panel_df["close"].astype(float) * panel_df["volume"].astype(float)).groupby(panel_df["symbol"]).mean()
    split_counts = panel_df.groupby(["symbol", "split"]).size().unstack(fill_value=0)
    required_count = max(config.lookback, 8)
    eligible_symbols = split_counts[
        (split_counts.get("train", 0) >= required_count)
        & (split_counts.get("valid", 0) >= required_count)
        & (split_counts.get("test", 0) >= required_count)
    ].index.astype(str).tolist()
    liquidity_rank = liquidity.sort_values(ascending=False).index.astype(str).tolist()
    if eligible_symbols:
        symbol_order = [symbol for symbol in liquidity_rank if symbol in set(eligible_symbols)][: config.max_symbols]
    else:
        symbol_order = liquidity_rank[: config.max_symbols]
    panel_df = panel_df[panel_df["symbol"].astype(str).isin(symbol_order)].copy()
    panel_df = panel_df.sort_values(["symbol", "date"]).reset_index(drop=True)

    date_budget = {
        "train": config.train_dates,
        "valid": config.valid_dates,
        "test": config.test_dates,
    }
    bundle: dict[str, dict[str, Any]] = {}
    for split_name in ("train", "valid", "test"):
        split_df = restrict_by_dates(panel_df[panel_df["split"] == split_name].copy(), date_budget[split_name])
        rows: list[dict[str, Any]] = []
        for symbol, symbol_df in split_df.groupby("symbol"):
            symbol_df = symbol_df.sort_values("date").reset_index(drop=True)
            if len(symbol_df) < config.lookback:
                continue
            for idx in range(config.lookback - 1, len(symbol_df)):
                row = symbol_df.iloc[idx]
                seq_frame = symbol_df.loc[idx - config.lookback + 1 : idx, seq_cols]
                if seq_frame.isna().any().any():
                    continue
                tabular_x = row[tab_cols].to_numpy(dtype=np.float32)
                alpha_x = row[alpha_cols].to_numpy(dtype=np.float32)
                label_y = np.float32(row[label_col])
                if not np.isfinite(tabular_x).all():
                    continue
                if not np.isfinite(alpha_x).all():
                    continue
                if not np.isfinite(label_y):
                    continue
                rows.append(
                    {
                        "date": row["date"],
                        "symbol": str(symbol),
                        "sequence_x": seq_frame.to_numpy(dtype=np.float32),
                        "tabular_x": tabular_x,
                        "alpha_x": alpha_x,
                        "label_y": float(label_y),
                    }
                )
        if not rows:
            raise RuntimeError(f"{market} / {split_name} 未能构造出可训练样本。")
        meta_df = pd.DataFrame({"date": [item["date"] for item in rows], "symbol": [item["symbol"] for item in rows]})
        bundle[split_name] = {
            "sequence_x": np.stack([item["sequence_x"] for item in rows]).astype(np.float32),
            "tabular_x": np.stack([item["tabular_x"] for item in rows]).astype(np.float32),
            "alpha_x": np.stack([item["alpha_x"] for item in rows]).astype(np.float32),
            "label_y": np.array([item["label_y"] for item in rows], dtype=np.float32),
            "meta": meta_df,
        }
    meta_payload = {
        "panel_path": str(panel_path),
        "markets": market,
        "selected_symbols": symbol_order,
        "sequence_columns": seq_cols,
        "tabular_columns": tab_cols,
        "alpha_columns": alpha_cols,
        "label_column": label_col,
    }
    return normalize_bundle(bundle), meta_payload


def normalize_bundle(bundle: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    train_payload = bundle["train"]
    seq_mean = train_payload["sequence_x"].mean(axis=(0, 1), keepdims=True)
    seq_std = train_payload["sequence_x"].std(axis=(0, 1), keepdims=True) + 1e-6
    tab_mean = train_payload["tabular_x"].mean(axis=0, keepdims=True)
    tab_std = train_payload["tabular_x"].std(axis=0, keepdims=True) + 1e-6
    alpha_mean = train_payload["alpha_x"].mean(axis=0, keepdims=True)
    alpha_std = train_payload["alpha_x"].std(axis=0, keepdims=True) + 1e-6
    label_mean = float(train_payload["label_y"].mean())
    label_std = float(train_payload["label_y"].std() + 1e-6)

    normalized: dict[str, dict[str, Any]] = {}
    for split_name, payload in bundle.items():
        normalized[split_name] = {
            "sequence_x": ((payload["sequence_x"] - seq_mean) / seq_std).astype(np.float32),
            "tabular_x": ((payload["tabular_x"] - tab_mean) / tab_std).astype(np.float32),
            "alpha_x": ((payload["alpha_x"] - alpha_mean) / alpha_std).astype(np.float32),
            "label_y": ((payload["label_y"] - label_mean) / label_std).astype(np.float32),
            "meta": payload["meta"].copy(),
        }
    normalized["_stats"] = {
        "seq_mean_shape": list(seq_mean.shape),
        "tab_feature_dim": int(tab_mean.shape[-1]),
        "alpha_feature_dim": int(alpha_mean.shape[-1]),
        "label_mean": label_mean,
        "label_std": label_std,
    }
    return normalized


def build_loader(dataset: TransferDataset, batch_size: int, is_train: bool, env: DistEnv, num_workers: int) -> tuple[DataLoader, DistributedSampler | None]:
    sampler: DistributedSampler | None = None
    if env.distributed:
        sampler = DistributedSampler(dataset, num_replicas=env.world_size, rank=env.rank, shuffle=is_train, drop_last=False)
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=is_train and sampler is None,
        sampler=sampler,
        drop_last=False,
        num_workers=num_workers,
        pin_memory=env.device.type == "cuda",
    )
    return loader, sampler


def unwrap_model(model: nn.Module) -> nn.Module:
    return model.module if isinstance(model, DDP) else model


def move_batch(batch: tuple[torch.Tensor, ...], device: torch.device) -> tuple[torch.Tensor, ...]:
    return tuple(tensor.to(device, non_blocking=True) for tensor in batch)


def reduce_scalar(value: float, device: torch.device, env: DistEnv) -> float:
    tensor = torch.tensor([value], dtype=torch.float32, device=device)
    if env.distributed:
        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
        tensor = tensor / float(env.world_size)
    return float(tensor.item())


def train_stage(
    model: nn.Module,
    train_dataset: TransferDataset,
    valid_dataset: TransferDataset,
    epochs: int,
    batch_size: int,
    lr: float,
    weight_decay: float,
    env: DistEnv,
    num_workers: int,
    log_path: Path,
    stage_name: str,
) -> dict[str, float]:
    optimizer = torch.optim.AdamW(filter(lambda param: param.requires_grad, model.parameters()), lr=lr, weight_decay=weight_decay)
    criterion = nn.MSELoss()
    train_loader, train_sampler = build_loader(train_dataset, batch_size=batch_size, is_train=True, env=env, num_workers=num_workers)
    valid_loader, valid_sampler = build_loader(valid_dataset, batch_size=batch_size, is_train=False, env=env, num_workers=num_workers)
    history: dict[str, float] = {}
    emit_demo_message(
        log_path,
        env,
        PROCESS_PREFIX,
        (
            f"{stage_name} started | epochs={epochs} | train_samples={len(train_dataset)} | "
            f"valid_samples={len(valid_dataset)} | train_batches={len(train_loader)} | valid_batches={len(valid_loader)}"
        ),
    )
    for epoch in range(epochs):
        if train_sampler is not None:
            train_sampler.set_epoch(epoch)
        if valid_sampler is not None:
            valid_sampler.set_epoch(epoch)
        model.train()
        train_losses: list[float] = []
        train_progress_interval = max(1, len(train_loader) // 4)
        for batch_idx, batch in enumerate(train_loader, start=1):
            sequence_x, tabular_x, alpha_x, label_y = move_batch(batch, env.device)
            prediction = model(sequence_x, tabular_x, alpha_x)
            loss = criterion(prediction, label_y)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            loss_value = float(loss.detach().item())
            train_losses.append(loss_value)
            if batch_idx % train_progress_interval == 0 or batch_idx == len(train_loader):
                progress = 100.0 * batch_idx / max(1, len(train_loader))
                emit_demo_message(
                    log_path,
                    env,
                    PROCESS_PREFIX,
                    (
                        f"{stage_name} train | epoch={epoch + 1}/{epochs} | "
                        f"batch={batch_idx}/{len(train_loader)} | progress={progress:.1f}% | "
                        f"current_loss={loss_value:.6f}"
                    ),
                )
        model.eval()
        valid_losses: list[float] = []
        valid_progress_interval = max(1, len(valid_loader) // 2)
        with torch.no_grad():
            for batch_idx, batch in enumerate(valid_loader, start=1):
                sequence_x, tabular_x, alpha_x, label_y = move_batch(batch, env.device)
                prediction = model(sequence_x, tabular_x, alpha_x)
                loss = criterion(prediction, label_y)
                loss_value = float(loss.detach().item())
                valid_losses.append(loss_value)
                if batch_idx % valid_progress_interval == 0 or batch_idx == len(valid_loader):
                    progress = 100.0 * batch_idx / max(1, len(valid_loader))
                    emit_demo_message(
                        log_path,
                        env,
                        PROCESS_PREFIX,
                        (
                            f"{stage_name} valid | epoch={epoch + 1}/{epochs} | "
                            f"batch={batch_idx}/{len(valid_loader)} | progress={progress:.1f}% | "
                            f"current_loss={loss_value:.6f}"
                        ),
                    )
        train_loss = reduce_scalar(float(np.mean(train_losses)), env.device, env)
        valid_loss = reduce_scalar(float(np.mean(valid_losses)), env.device, env)
        history[f"epoch_{epoch + 1}_train_loss"] = train_loss
        history[f"epoch_{epoch + 1}_valid_loss"] = valid_loss
        epoch_progress = 100.0 * (epoch + 1) / max(1, epochs)
        emit_demo_message(
            log_path,
            env,
            PROCESS_PREFIX,
            (
                f"{stage_name} epoch done | epoch={epoch + 1}/{epochs} | progress={epoch_progress:.1f}% | "
                f"train_loss={train_loss:.6f} | valid_loss={valid_loss:.6f}"
            ),
        )
    return history


def evaluate_model(model: nn.Module, dataset: TransferDataset, batch_size: int, env: DistEnv) -> tuple[pd.DataFrame, dict[str, float]]:
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=env.device.type == "cuda")
    predictions: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for batch in loader:
            sequence_x, tabular_x, alpha_x, label_y = move_batch(batch, env.device)
            pred = model(sequence_x, tabular_x, alpha_x)
            predictions.append(pred.detach().cpu().numpy())
            labels.append(label_y.detach().cpu().numpy())
    pred_array = np.concatenate(predictions).astype(float)
    label_array = np.concatenate(labels).astype(float)
    result_df = dataset.meta.copy()
    result_df["score"] = pred_array
    result_df["label"] = label_array
    mse = float(np.mean((pred_array - label_array) ** 2))
    daily_rank_ic: list[float] = []
    for _, group in result_df.groupby("date"):
        if len(group) < 2:
            continue
        corr = group["score"].corr(group["label"], method="spearman")
        if pd.notna(corr):
            daily_rank_ic.append(float(corr))
    metrics = {
        "mse": mse,
        "rank_ic_mean": float(np.mean(daily_rank_ic)) if daily_rank_ic else 0.0,
        "rank_ic_std": float(np.std(daily_rank_ic)) if daily_rank_ic else 0.0,
        "sample_count": int(len(result_df)),
        "date_count": int(result_df["date"].nunique()),
    }
    return result_df, metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行 AlphaMechTransfer 分布式迁移 demo")
    parser.add_argument("--source-market", default="CN", choices=["CN", "US", "FUTURE"])
    parser.add_argument("--target-market", default="US", choices=["CN", "US", "FUTURE"])
    parser.add_argument("--lookback", type=int, default=12)
    parser.add_argument("--max-symbols", type=int, default=8)
    parser.add_argument("--train-dates", type=int, default=180)
    parser.add_argument("--valid-dates", type=int, default=60)
    parser.add_argument("--test-dates", type=int, default=80)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--pretrain-epochs", type=int, default=3)
    parser.add_argument("--adapt-epochs", type=int, default=2)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-5)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--server-name",
        default="",
        help="可选运行标签。为空时自动使用 `AMT_SERVER_NAME` 或当前主机名。",
    )
    parser.add_argument("--output-name", default="ddp_demo")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = DemoConfig(
        source_market=args.source_market.upper(),
        target_market=args.target_market.upper(),
        lookback=args.lookback,
        max_symbols=args.max_symbols,
        train_dates=args.train_dates,
        valid_dates=args.valid_dates,
        test_dates=args.test_dates,
        batch_size=args.batch_size,
        pretrain_epochs=args.pretrain_epochs,
        adapt_epochs=args.adapt_epochs,
        lr=args.lr,
        weight_decay=args.weight_decay,
        num_workers=args.num_workers,
        seed=args.seed,
        server_name=resolve_server_name(args.server_name),
        output_name=args.output_name,
        device=args.device,
    )
    env = init_dist_env(config.device)
    runtime_paths = build_runtime_paths(config.server_name)
    log_path = runtime_paths.log_dir / f"{config.output_name}.log"
    result_root = ensure_dir(runtime_paths.result_dir / config.output_name)
    start_time = time.perf_counter()
    try:
        set_seed(config.seed + env.rank)
        emit_demo_message(
            log_path,
            env,
            PROCESS_PREFIX,
            (
                f"demo started | rank={env.rank} | world_size={env.world_size} | device={env.device_name} | "
                f"source={config.source_market} | target={config.target_market}"
            ),
        )
        source_bundle, source_meta = build_market_payload(config, config.source_market)
        target_bundle, target_meta = build_market_payload(config, config.target_market)
        emit_demo_message(
            log_path,
            env,
            PROCESS_PREFIX,
            (
                f"data prepared | source_train={len(source_bundle['train']['label_y'])} | "
                f"source_valid={len(source_bundle['valid']['label_y'])} | "
                f"target_train={len(target_bundle['train']['label_y'])} | "
                f"target_valid={len(target_bundle['valid']['label_y'])} | "
                f"target_test={len(target_bundle['test']['label_y'])}"
            ),
        )

        model = TransferDemoNet(
            seq_dim=source_bundle["train"]["sequence_x"].shape[-1],
            tab_dim=source_bundle["train"]["tabular_x"].shape[-1],
            alpha_dim=source_bundle["train"]["alpha_x"].shape[-1],
        ).to(env.device)
        if env.distributed:
            # `adapter` is intentionally inactive during source pretrain, so DDP must tolerate
            # temporarily unused parameters in the multi-GPU smoke stage.
            model = DDP(model, device_ids=[env.local_rank] if env.device.type == "cuda" else None, find_unused_parameters=True)

        source_train = TransferDataset(source_bundle["train"])
        source_valid = TransferDataset(source_bundle["valid"])
        target_train = TransferDataset(target_bundle["train"])
        target_valid = TransferDataset(target_bundle["valid"])
        target_test = TransferDataset(target_bundle["test"])

        pretrain_history = train_stage(
            model=model,
            train_dataset=source_train,
            valid_dataset=source_valid,
            epochs=config.pretrain_epochs,
            batch_size=config.batch_size,
            lr=config.lr,
            weight_decay=config.weight_decay,
            env=env,
            num_workers=config.num_workers,
            log_path=log_path,
            stage_name="pretrain",
        )
        unwrap_model(model).switch_to_target_adaptation()
        emit_demo_message(log_path, env, PROCESS_PREFIX, "switch_to_target_adaptation completed")
        adapt_history = train_stage(
            model=model,
            train_dataset=target_train,
            valid_dataset=target_valid,
            epochs=config.adapt_epochs,
            batch_size=config.batch_size,
            lr=config.lr,
            weight_decay=config.weight_decay,
            env=env,
            num_workers=config.num_workers,
            log_path=log_path,
            stage_name="adapt",
        )
        if env.distributed:
            dist.barrier()

        if rank0_only(env):
            result_df, metrics = evaluate_model(unwrap_model(model), target_test, batch_size=config.batch_size, env=env)
            prediction_path = result_root / "test_predictions.csv"
            summary_path = result_root / "summary.json"
            manifest_path = result_root / "manifest.json"
            result_df = result_df.sort_values(["date", "symbol"]).reset_index(drop=True)
            result_df["date"] = pd.to_datetime(result_df["date"]).dt.strftime("%Y-%m-%d")
            actual_prediction_path = write_dataframe(result_df, prediction_path, index=False, encoding="utf-8-sig")
            payload = {
                "config": asdict(config),
                "distributed": {
                    "rank": env.rank,
                    "local_rank": env.local_rank,
                    "world_size": env.world_size,
                    "distributed": env.distributed,
                    "device": env.device_name,
                },
                "source_meta": source_meta,
                "target_meta": target_meta,
                "pretrain_history": pretrain_history,
                "adapt_history": adapt_history,
                "metrics": metrics,
                "elapsed_seconds": float(time.perf_counter() - start_time),
                "prediction_path": str(actual_prediction_path),
            }
            actual_summary_path = write_json(summary_path, payload)
            actual_manifest_path = write_json(
                manifest_path,
                {
                    "prediction_path": str(actual_prediction_path),
                    "summary_path": str(actual_summary_path),
                    "log_path": str(log_path),
                    "server_name": config.server_name,
                    "note": "该 demo 只用于验证分布式训练链路与结果落盘规范，不用于正式论文主表。",
                },
            )
            emit_demo_message(
                log_path,
                env,
                DONE_PREFIX,
                (
                    f"demo finished | elapsed={format_seconds(payload['elapsed_seconds'])} | "
                    f"status=SUCCESS | mse={metrics['mse']:.6f} | rank_ic_mean={metrics['rank_ic_mean']:.6f} | "
                    f"samples={metrics['sample_count']} | dates={metrics['date_count']} | "
                    f"ended_summary={Path(actual_summary_path).name} | manifest={Path(actual_manifest_path).name}"
                ),
            )
            print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
        return 0
    finally:
        cleanup_dist()


if __name__ == "__main__":
    raise SystemExit(main())
