"""
文件功能：
1. 基于当前 AMT 主实验使用的历史中间数据，做四类输入模态的代理归因分析：
   - 时序量价信息（sequence_x）
   - 表格统计特征（tabular_x，不含重复注入的 alpha 尾部）
   - 超图/概念关系（concept_x）
   - 公式 alpha 特征（alpha_x）
2. 使用“单模态 probe + 留一法 leave-one-out”的方式，量化各模态对排序指标与轻量回测指标的边际影响。
3. 输出 JSON 结果，供论文文档补写、实验复核与后续调参参考。

代码逻辑：
1. 直接复用正式实验的数据准备链路，构建与主实验一致的 split arrays。
2. 为避免把 alpha 信息在 tabular_x 和 alpha_x 中重复计算，本脚本对“四类模态”做解释性去重：
   - tabular 分支只保留纯统计特征前 15 维；
   - alpha 分支单独使用 alpha_x 的 6 维。
3. 在每个迁移方向上，抽取按日期均匀覆盖的样本子集，训练线性 SGD probe。
4. 对 full / loo / single 三组实验统一计算 RankIC、NDCG@20、年化收益、夏普和最大回撤。

代码结构：
1. 数据抽样与模态构造函数。
2. 预测评估函数。
3. 单方向代理实验主流程。
4. 双方向汇总与结果落盘。
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import SGDRegressor


ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR / "code") not in sys.path:
    sys.path.append(str(ROOT_DIR / "code"))

from data_pipeline import SplitConfig, prepare_transfer_artifacts
from experiment_runner import (
    align_transfer_concept_arrays,
    build_split_arrays,
    compute_prediction_metrics,
    run_fast_topk_backtest,
)


TOP_K = 20
TABULAR_PURE_DIM = 15


def pick_date_subset(meta_df: pd.DataFrame, max_rows: int) -> np.ndarray:
    """
    按日期均匀抽样，保证横截面排序评估仍保留“按天分组”的结构。
    """
    if len(meta_df) <= max_rows:
        return np.arange(len(meta_df), dtype=int)
    counts = meta_df.groupby("date", sort=True).size()
    dates = counts.index.to_numpy()
    step = max(1, math.ceil(len(meta_df) / max_rows))
    chosen_dates = dates[::step]
    chosen = meta_df.index[meta_df["date"].isin(chosen_dates)].to_numpy(dtype=int)
    if len(chosen) > max_rows:
        chosen = chosen[:max_rows]
    return np.sort(chosen)


def build_modalities(split_arrays: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    """
    构造四类可解释模态矩阵。

    注：当前正式实验里，tabular_x 的最后 6 维与 alpha_x 完全重复。
    为了避免在“表格统计特征”和“公式 alpha 特征”之间重复记账，
    这里把 tabular 模态截断为纯统计特征前 15 维。
    """
    return {
        "sequence": split_arrays["sequence_x"].reshape(split_arrays["sequence_x"].shape[0], -1).astype(np.float32),
        "tabular": split_arrays["tabular_x"][:, :TABULAR_PURE_DIM].astype(np.float32),
        "concept": split_arrays["concept_x"].astype(np.float32),
        "alpha": split_arrays["alpha_x"].astype(np.float32),
    }


def concat_modalities(modalities: dict[str, np.ndarray], names: list[str]) -> np.ndarray:
    return np.concatenate([modalities[name] for name in names], axis=1).astype(np.float32)


def evaluate_prediction(meta_df: pd.DataFrame, prediction: np.ndarray) -> dict[str, float]:
    """
    统一复用主实验已有的指标定义，避免分析口径漂移。
    """
    frame = meta_df.copy()
    frame["prediction"] = np.asarray(prediction, dtype=np.float32)
    metrics = compute_prediction_metrics(frame, top_k=TOP_K)
    _curve_df, backtest = run_fast_topk_backtest(frame, top_k=TOP_K)
    return {
        "RankIC": float(metrics.get("RankIC", np.nan)),
        "IC": float(metrics.get("IC", np.nan)),
        f"NDCG@{TOP_K}": float(metrics.get(f"NDCG@{TOP_K}", np.nan)),
        "Annualized Return": float(backtest.get("Annualized Return", np.nan)),
        "Sharpe Ratio": float(backtest.get("Sharpe Ratio", np.nan)),
        "Maximum Drawdown": float(backtest.get("Maximum Drawdown", np.nan)),
        "rows": int(len(frame)),
        "days": int(frame["date"].nunique()),
    }


def run_probe_for_direction(
    source_market: str,
    target_market: str,
    train_max_rows: int,
    valid_max_rows: int,
    test_max_rows: int,
) -> dict[str, object]:
    transfer = prepare_transfer_artifacts(
        source_market=source_market,
        target_market=target_market,
        max_symbols=160,
        horizon=5,
        force_rebuild=False,
    )
    split = SplitConfig()
    source_arrays, _ = build_split_arrays(
        transfer["source"]["panel_df"],
        transfer["source"]["incidence_df"],
        split=split,
        lookback=20,
    )
    target_arrays, target_meta = build_split_arrays(
        transfer["target"]["panel_df"],
        transfer["target"]["incidence_df"],
        split=split,
        lookback=20,
    )
    _source_arrays, target_arrays, _shared_dim = align_transfer_concept_arrays(source_arrays, target_arrays)

    sampled_arrays: dict[str, dict[str, np.ndarray]] = {}
    sampled_meta: dict[str, pd.DataFrame] = {}
    max_rows_by_split = {
        "train": int(train_max_rows),
        "valid": int(valid_max_rows),
        "test": int(test_max_rows),
    }
    for split_name, max_rows in max_rows_by_split.items():
        meta_frame = target_meta[split_name].reset_index(drop=True)
        row_index = pick_date_subset(meta_frame, max_rows=max_rows)
        sampled_arrays[split_name] = {key: value[row_index] for key, value in target_arrays[split_name].items()}
        sampled_meta[split_name] = meta_frame.iloc[row_index].reset_index(drop=True)

    train_modalities = build_modalities(sampled_arrays["train"])
    test_modalities = build_modalities(sampled_arrays["test"])
    y_train = sampled_arrays["train"]["y"]

    alpha_dim = int(sampled_arrays["train"]["alpha_x"].shape[1])
    overlap_max_abs = float(
        np.max(
            np.abs(
                sampled_arrays["train"]["tabular_x"][:, -alpha_dim:]
                - sampled_arrays["train"]["alpha_x"]
            )
        )
    )

    experiments = {
        "full": ["sequence", "tabular", "concept", "alpha"],
        "loo_sequence": ["tabular", "concept", "alpha"],
        "loo_tabular": ["sequence", "concept", "alpha"],
        "loo_concept": ["sequence", "tabular", "alpha"],
        "loo_alpha": ["sequence", "tabular", "concept"],
        "single_sequence": ["sequence"],
        "single_tabular": ["tabular"],
        "single_concept": ["concept"],
        "single_alpha": ["alpha"],
    }

    result = {
        "sample_sizes": {split_name: int(sampled_arrays[split_name]["y"].shape[0]) for split_name in sampled_arrays},
        "date_counts": {split_name: int(sampled_meta[split_name]["date"].nunique()) for split_name in sampled_meta},
        "feature_dims": {
            "sequence": int(train_modalities["sequence"].shape[1]),
            "tabular_pure": int(train_modalities["tabular"].shape[1]),
            "concept": int(train_modalities["concept"].shape[1]),
            "alpha": int(train_modalities["alpha"].shape[1]),
        },
        "alpha_overlap_check": {
            "tabular_tail_vs_alpha_max_abs_diff": overlap_max_abs,
            "note": "0 表示 tabular_x 的尾部 alpha 特征与 alpha_x 完全重复。",
        },
        "runs": {},
    }

    for experiment_name, feature_groups in experiments.items():
        x_train = concat_modalities(train_modalities, feature_groups)
        x_test = concat_modalities(test_modalities, feature_groups)
        # 这里用线性 SGD probe，是为了在百万级样本上稳定、快速地得到统一归因口径。
        model = SGDRegressor(
            loss="squared_error",
            penalty="l2",
            alpha=1e-4,
            random_state=42,
            max_iter=30,
            tol=1e-3,
        )
        model.fit(x_train, y_train)
        prediction = model.predict(x_test)
        run_result = evaluate_prediction(sampled_meta["test"], prediction)
        run_result["feature_groups"] = feature_groups
        run_result["feature_dim"] = int(x_train.shape[1])
        result["runs"][experiment_name] = run_result

    full_rankic = float(result["runs"]["full"]["RankIC"])
    full_ann_return = float(result["runs"]["full"]["Annualized Return"])
    leave_one_out_drop: dict[str, dict[str, float]] = {}
    for modality_name in ["sequence", "tabular", "concept", "alpha"]:
        loo_result = result["runs"][f"loo_{modality_name}"]
        leave_one_out_drop[modality_name] = {
            "rankic_drop": float(full_rankic - float(loo_result["RankIC"])),
            "ann_return_drop": float(full_ann_return - float(loo_result["Annualized Return"])),
        }
    result["leave_one_out_drop"] = leave_one_out_drop
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AMT 四模态代理归因分析脚本")
    parser.add_argument(
        "--output",
        type=str,
        default=str(ROOT_DIR / "results" / "full_20260726_210238" / "主实验" / "phase1_transfer" / "modality_impact_probe.json"),
        help="结果 JSON 输出路径",
    )
    parser.add_argument("--train-max-rows", type=int, default=200000, help="训练集最大抽样行数")
    parser.add_argument("--valid-max-rows", type=int, default=100000, help="验证集最大抽样行数")
    parser.add_argument("--test-max-rows", type=int, default=200000, help="测试集最大抽样行数")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    results = {
        "analysis_protocol": {
            "type": "proxy_modality_attribution",
            "note": "该结果基于 split arrays 的代理 probe，不是对已训练 AMT checkpoint 的严格因果分解。",
            "top_k": TOP_K,
            "tabular_pure_dim": TABULAR_PURE_DIM,
        }
    }
    for source_market, target_market in [("CN", "US"), ("US", "CN")]:
        direction_key = f"{source_market}->{target_market}"
        results[direction_key] = run_probe_for_direction(
            source_market=source_market,
            target_market=target_market,
            train_max_rows=int(args.train_max_rows),
            valid_max_rows=int(args.valid_max_rows),
            test_max_rows=int(args.test_max_rows),
        )

    output_path = Path(args.output).expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(output_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
