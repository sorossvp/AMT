"""
文件功能:
1. 落地 `idea20260526.md` 中预设的状态切分消融实验, 比较 `No-Regime`、`Quantile-3`、
   `HMM-3` 与 `Cluster-4` 四套评估协议。
2. 复用已经训练完成的模型预测文件, 避免为“评估协议消融”重复训练模型主体。
3. 输出样本分布、分状态指标、状态原型画像与跨市场语义一致性结果, 便于论文直接引用。

代码逻辑:
1. 从 `processed_data` 读取目标市场面板, 在训练集日期上拟合状态切分器。
2. 对全样本日期生成四套 regime 标签, 其中 HMM-3 使用“高斯发射 + Viterbi 解码”的轻量实现。
3. 将现有模型的测试期预测与各套 regime 标签对齐, 计算状态内 `IC/RankIC/NDCG@K/Top-k收益`。
4. 统计样本均衡性、状态稳定性、可解释性与跨市场语义一致性, 并统一保存到 `results/regime_ablation`。

代码结构:
1. 路径、配置与基础工具函数。
2. 四类状态切分协议实现。
3. 指标评估、语义画像与一致性分析。
4. 命令行入口。
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler

from data_pipeline import SplitConfig, read_pickle_with_recovery
from experiment_runner import compute_prediction_metrics
from experiment_workspace import get_categorized_result_path


ROOT_DIR = Path(__file__).resolve().parents[1]
PROCESSED_DIR = ROOT_DIR / "DataToSever" / "processed_data"
RESULTS_DIR = get_categorized_result_path("ablation", "regime_ablation")
FEATURE_COLS = ["ew_ret_1", "ew_vol_20", "ew_turnover"]
DIRECTION_TO_TARGET = {
    "us_to_cn": "CN",
    "cn_to_us": "US",
}
DIRECTION_RESULT_CANDIDATES = {
    "us_to_cn": ["phase1_transfer_us_to_cn_topk10", "phase1_transfer"],
    "cn_to_us": ["phase1_transfer_cn_to_us_topk10", "phase1_transfer"],
}


@dataclass
class RegimeAblationConfig:
    directions: tuple[str, ...] = ("us_to_cn", "cn_to_us")
    models: tuple[str, ...] = ("transformer", "hist", "main_transfer")
    top_k: int = 10
    random_state: int = 42
    split: SplitConfig = field(default_factory=SplitConfig)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def infer_split(date_value: pd.Timestamp, split: SplitConfig) -> str | None:
    if pd.Timestamp(split.train_start) <= date_value <= pd.Timestamp(split.train_end):
        return "train"
    if pd.Timestamp(split.valid_start) <= date_value <= pd.Timestamp(split.valid_end):
        return "valid"
    if pd.Timestamp(split.test_start) <= date_value <= pd.Timestamp(split.test_end):
        return "test"
    return None


def entropy_from_shares(shares: np.ndarray) -> float:
    valid = shares[shares > 0]
    if valid.size == 0:
        return 0.0
    return float(-(valid * np.log(valid)).sum())


def cosine_similarity(vec_a: np.ndarray, vec_b: np.ndarray) -> float:
    denom = float(np.linalg.norm(vec_a) * np.linalg.norm(vec_b))
    if denom <= 1e-12:
        return 0.0
    value = float(np.dot(vec_a, vec_b) / denom)
    return max(min(value, 1.0), -1.0)


def load_target_panel(target_market: str, split: SplitConfig) -> pd.DataFrame:
    panel_path = PROCESSED_DIR / target_market.lower() / "panel.pkl"
    if not panel_path.exists():
        raise FileNotFoundError(f"缺少目标市场面板缓存: {panel_path}")
    panel_df = read_pickle_with_recovery(panel_path).copy()
    panel_df["date"] = pd.to_datetime(panel_df["date"])
    panel_df["split"] = panel_df["date"].map(lambda x: infer_split(pd.Timestamp(x), split))
    keep_cols = ["date", "symbol", "ret_1", "vol_20", "turnover_proxy", "split"]
    panel_df = panel_df[keep_cols].dropna(subset=["date", "symbol", "split"]).reset_index(drop=True)
    return panel_df


def build_market_daily(panel_df: pd.DataFrame) -> pd.DataFrame:
    market_daily = (
        panel_df.groupby("date")
        .agg(
            ew_ret_1=("ret_1", "mean"),
            ew_vol_20=("vol_20", "mean"),
            ew_turnover=("turnover_proxy", "mean"),
        )
        .reset_index()
        .sort_values("date")
    )
    market_daily["split"] = panel_df.groupby("date")["split"].first().reindex(market_daily["date"]).to_list()
    market_daily = market_daily.replace([np.inf, -np.inf], np.nan)
    for col in FEATURE_COLS:
        market_daily[col] = market_daily[col].astype(float).interpolate(limit_direction="both")
        market_daily[col] = market_daily[col].fillna(float(market_daily[col].median()))
    return market_daily


def semantic_map_three_state(centers_df: pd.DataFrame) -> dict[int, str]:
    ordered = centers_df.sort_values("ew_ret_1").index.tolist()
    labels = ["bear", "neutral", "bull"]
    return {state_id: label for state_id, label in zip(ordered, labels, strict=False)}


def semantic_map_four_state(centers_df: pd.DataFrame) -> dict[int, str]:
    shock_id = int(centers_df["ew_vol_20"].idxmax())
    remain = centers_df.drop(index=shock_id).sort_values("ew_ret_1").index.tolist()
    mapping = {shock_id: "shock"}
    ordered_labels = ["bear", "neutral", "bull"]
    for state_id, label in zip(remain, ordered_labels, strict=False):
        mapping[int(state_id)] = label
    return mapping


def assign_no_regime(market_daily: pd.DataFrame) -> tuple[pd.Series, dict[str, Any], pd.DataFrame]:
    labels = pd.Series(["all"] * len(market_daily), index=market_daily.index, dtype="object")
    profile_df = pd.DataFrame(
        [
            {
                "state": "all",
                "ew_ret_1": float(market_daily["ew_ret_1"].mean()),
                "ew_vol_20": float(market_daily["ew_vol_20"].mean()),
                "ew_turnover": float(market_daily["ew_turnover"].mean()),
            }
        ]
    )
    return labels, {"protocol": "No-Regime"}, profile_df


def assign_quantile_three(market_daily: pd.DataFrame) -> tuple[pd.Series, dict[str, Any], pd.DataFrame]:
    train_df = market_daily.loc[market_daily["split"] == "train"].copy()
    q_low = float(train_df["ew_ret_1"].quantile(1.0 / 3.0))
    q_high = float(train_df["ew_ret_1"].quantile(2.0 / 3.0))

    def classify(value: float) -> str:
        if value <= q_low:
            return "bear"
        if value >= q_high:
            return "bull"
        return "neutral"

    labels = market_daily["ew_ret_1"].map(classify)
    profile_df = (
        market_daily.assign(state=labels)
        .groupby("state")[FEATURE_COLS]
        .mean()
        .reset_index()
        .rename(columns={"state": "state"})
    )
    return labels, {"ret_q33": q_low, "ret_q67": q_high}, profile_df


def _fit_standardized_features(market_daily: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, StandardScaler]:
    train_df = market_daily.loc[market_daily["split"] == "train"].copy()
    scaler = StandardScaler()
    scaler.fit(train_df[FEATURE_COLS].to_numpy(dtype=np.float64))
    x_all = scaler.transform(market_daily[FEATURE_COLS].to_numpy(dtype=np.float64))
    x_train = scaler.transform(train_df[FEATURE_COLS].to_numpy(dtype=np.float64))
    return x_train, x_all, scaler


def assign_cluster_four(market_daily: pd.DataFrame, random_state: int) -> tuple[pd.Series, dict[str, Any], pd.DataFrame]:
    x_train, x_all, scaler = _fit_standardized_features(market_daily)
    clusterer = KMeans(n_clusters=4, n_init=20, random_state=random_state)
    clusterer.fit(x_train)
    raw_state = clusterer.predict(x_all)
    centers = scaler.inverse_transform(clusterer.cluster_centers_)
    centers_df = pd.DataFrame(centers, columns=FEATURE_COLS)
    centers_df.index.name = "raw_state"
    mapping = semantic_map_four_state(centers_df)
    labels = pd.Series([mapping[int(state)] for state in raw_state], index=market_daily.index, dtype="object")
    profile_df = (
        market_daily.assign(state=labels)
        .groupby("state")[FEATURE_COLS]
        .mean()
        .reset_index()
        .rename(columns={"state": "state"})
    )
    return labels, {"cluster_centers": centers_df.reset_index().to_dict(orient="records")}, profile_df


def gaussian_logpdf_diag(x: np.ndarray, mean: np.ndarray, var: np.ndarray) -> np.ndarray:
    var = np.clip(var, 1e-6, None)
    return -0.5 * (
        np.log(2.0 * np.pi * var).sum()
        + (((x - mean) ** 2) / var).sum(axis=1)
    )


def viterbi_decode(log_emission: np.ndarray, log_init: np.ndarray, log_trans: np.ndarray) -> np.ndarray:
    n_steps, n_states = log_emission.shape
    dp = np.full((n_steps, n_states), -np.inf, dtype=np.float64)
    prev = np.zeros((n_steps, n_states), dtype=np.int64)
    dp[0] = log_init + log_emission[0]
    for t in range(1, n_steps):
        for state in range(n_states):
            scores = dp[t - 1] + log_trans[:, state]
            prev[t, state] = int(np.argmax(scores))
            dp[t, state] = scores[prev[t, state]] + log_emission[t, state]
    states = np.zeros(n_steps, dtype=np.int64)
    states[-1] = int(np.argmax(dp[-1]))
    for t in range(n_steps - 2, -1, -1):
        states[t] = prev[t + 1, states[t + 1]]
    return states


def assign_hmm_three(market_daily: pd.DataFrame, random_state: int) -> tuple[pd.Series, dict[str, Any], pd.DataFrame]:
    x_train, x_all, scaler = _fit_standardized_features(market_daily)
    gmm = GaussianMixture(
        n_components=3,
        covariance_type="diag",
        reg_covar=1e-4,
        random_state=random_state,
    )
    gmm.fit(x_train)
    train_states = gmm.predict(x_train)

    trans_counts = np.ones((3, 3), dtype=np.float64)
    for prev_state, next_state in zip(train_states[:-1], train_states[1:], strict=False):
        trans_counts[int(prev_state), int(next_state)] += 1.0
    trans_prob = trans_counts / trans_counts.sum(axis=1, keepdims=True)
    init_counts = np.bincount(train_states, minlength=3).astype(np.float64) + 1.0
    init_prob = init_counts / init_counts.sum()

    means = gmm.means_
    variances = np.asarray(gmm.covariances_, dtype=np.float64)
    log_emission = np.column_stack(
        [gaussian_logpdf_diag(x_all, means[state_id], variances[state_id]) for state_id in range(3)]
    )
    decoded_states = viterbi_decode(log_emission, np.log(init_prob), np.log(trans_prob))
    centers = scaler.inverse_transform(means)
    centers_df = pd.DataFrame(centers, columns=FEATURE_COLS)
    centers_df.index.name = "raw_state"
    mapping = semantic_map_three_state(centers_df)
    labels = pd.Series([mapping[int(state)] for state in decoded_states], index=market_daily.index, dtype="object")
    profile_df = (
        market_daily.assign(state=labels)
        .groupby("state")[FEATURE_COLS]
        .mean()
        .reset_index()
        .rename(columns={"state": "state"})
    )
    metadata = {
        "transition_matrix": trans_prob.tolist(),
        "initial_prob": init_prob.tolist(),
        "centers": centers_df.reset_index().to_dict(orient="records"),
    }
    return labels, metadata, profile_df


def build_protocol_labels(market_daily: pd.DataFrame, random_state: int) -> dict[str, dict[str, Any]]:
    protocols: dict[str, dict[str, Any]] = {}
    for protocol_name, builder in [
        ("No-Regime", lambda df: assign_no_regime(df)),
        ("Quantile-3", lambda df: assign_quantile_three(df)),
        ("HMM-3", lambda df: assign_hmm_three(df, random_state=random_state)),
        ("Cluster-4", lambda df: assign_cluster_four(df, random_state=random_state)),
    ]:
        labels, metadata, profile_df = builder(market_daily.copy())
        protocols[protocol_name] = {
            "labels": labels,
            "metadata": metadata,
            "profile_df": profile_df,
        }
    return protocols


def resolve_prediction_path(direction: str, model_name: str) -> tuple[Path, str]:
    for result_subdir in DIRECTION_RESULT_CANDIDATES[direction]:
        prediction_path = get_categorized_result_path("main", result_subdir, direction, model_name, "test_predictions.csv")
        if prediction_path.exists():
            return prediction_path, result_subdir
    raise FileNotFoundError(f"未找到 {direction}/{model_name} 的预测文件。")


def compute_daily_topk_returns(pred_df: pd.DataFrame, top_k: int) -> list[float]:
    values: list[float] = []
    for _, daily_df in pred_df.groupby("date"):
        ranked = daily_df.sort_values("prediction", ascending=False).head(top_k)
        if not ranked.empty:
            values.append(float(ranked["future_return"].mean()))
    return values


def evaluate_one_protocol(
    direction: str,
    target_market: str,
    model_name: str,
    result_subdir: str,
    pred_df: pd.DataFrame,
    regime_series: pd.Series,
    market_daily: pd.DataFrame,
    top_k: int,
) -> tuple[dict[str, Any], pd.DataFrame]:
    merged = pred_df.merge(
        pd.DataFrame({"date": market_daily["date"], "regime": regime_series}),
        on="date",
        how="left",
    )
    overall_metrics = compute_prediction_metrics(
        merged[["date", "symbol", "future_return", "label", "prediction"]].copy(),
        top_k=top_k,
    )
    day_counts = merged.groupby("regime")["date"].nunique().sort_values(ascending=False)
    day_shares = (day_counts / day_counts.sum()).to_numpy(dtype=np.float64) if not day_counts.empty else np.array([], dtype=np.float64)

    state_rows: list[dict[str, Any]] = []
    rankic_values: list[float] = []
    ndcg_values: list[float] = []
    topk_return_values: list[float] = []
    ndcg_key = f"NDCG@{top_k}"
    for regime_name, one_df in merged.groupby("regime"):
        metrics = compute_prediction_metrics(
            one_df[["date", "symbol", "future_return", "label", "prediction"]].copy(),
            top_k=top_k,
        )
        daily_topk = compute_daily_topk_returns(one_df, top_k=top_k)
        avg_topk = float(np.mean(daily_topk)) if daily_topk else np.nan
        state_rows.append(
            {
                "direction": direction,
                "target_market": target_market,
                "model": model_name,
                "result_subdir": result_subdir,
                "protocol": "",
                "regime": regime_name,
                "sample_rows": int(len(one_df)),
                "days": int(one_df["date"].nunique()),
                "IC": metrics.get("IC"),
                "RankIC": metrics.get("RankIC"),
                ndcg_key: metrics.get(ndcg_key),
                "avg_topk_future_return": avg_topk,
                "positive_day_ratio": float(np.mean([value > 0 for value in daily_topk])) if daily_topk else np.nan,
            }
        )
        rankic_values.append(float(metrics.get("RankIC", np.nan)))
        ndcg_values.append(float(metrics.get(ndcg_key, np.nan)))
        topk_return_values.append(avg_topk)

    summary_row = {
        "direction": direction,
        "target_market": target_market,
        "model": model_name,
        "result_subdir": result_subdir,
        "protocol": "",
        "overall_IC": overall_metrics.get("IC"),
        "overall_RankIC": overall_metrics.get("RankIC"),
        ndcg_key: overall_metrics.get(ndcg_key),
        "regime_count": int(len(day_counts)),
        "total_days": int(merged["date"].nunique()),
        "largest_state_share": float(day_shares.max()) if day_shares.size else np.nan,
        "smallest_state_share": float(day_shares.min()) if day_shares.size else np.nan,
        "day_share_entropy": entropy_from_shares(day_shares),
        "rankic_state_std": float(pd.Series(rankic_values, dtype=float).std(ddof=0)) if rankic_values else np.nan,
        "ndcg_state_std": float(pd.Series(ndcg_values, dtype=float).std(ddof=0)) if ndcg_values else np.nan,
        "topk_return_state_std": float(pd.Series(topk_return_values, dtype=float).std(ddof=0)) if topk_return_values else np.nan,
    }
    state_df = pd.DataFrame(state_rows)
    return summary_row, state_df


def build_cross_market_consistency(profile_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    feature_cols = ["ew_ret_1", "ew_vol_20", "ew_turnover"]
    for protocol_name, one_protocol_df in profile_df.groupby("protocol"):
        cn_df = one_protocol_df.loc[one_protocol_df["market"] == "CN"].copy()
        us_df = one_protocol_df.loc[one_protocol_df["market"] == "US"].copy()
        shared_states = sorted(set(cn_df["state"]) & set(us_df["state"]))
        if not shared_states:
            rows.append({"protocol": protocol_name, "shared_states": 0, "avg_semantic_cosine": np.nan})
            continue
        cosine_values: list[float] = []
        for state_name in shared_states:
            cn_vec = cn_df.loc[cn_df["state"] == state_name, feature_cols].iloc[0].to_numpy(dtype=np.float64)
            us_vec = us_df.loc[us_df["state"] == state_name, feature_cols].iloc[0].to_numpy(dtype=np.float64)
            cn_norm = (cn_vec - cn_vec.mean()) / (cn_vec.std() + 1e-12)
            us_norm = (us_vec - us_vec.mean()) / (us_vec.std() + 1e-12)
            cosine_values.append(cosine_similarity(cn_norm, us_norm))
        rows.append(
            {
                "protocol": protocol_name,
                "shared_states": int(len(shared_states)),
                "avg_semantic_cosine": float(np.mean(cosine_values)) if cosine_values else np.nan,
            }
        )
    return pd.DataFrame(rows)


def build_markdown_report(
    output_dir: Path,
    summary_df: pd.DataFrame,
    consistency_df: pd.DataFrame,
    profile_df: pd.DataFrame,
    config: RegimeAblationConfig,
) -> None:
    lines = [
        "# Regime Ablation Report",
        "",
        "## 1. Scope",
        "",
        f"- Directions: `{', '.join(config.directions)}`",
        f"- Models: `{', '.join(config.models)}`",
        f"- Top-k: `{config.top_k}`",
        "",
        "## 2. Key Observations",
        "",
    ]
    ndcg_key = f"NDCG@{config.top_k}"
    if not summary_df.empty:
        for direction in config.directions:
            for model_name in config.models:
                one = summary_df.loc[(summary_df["direction"] == direction) & (summary_df["model"] == model_name)].copy()
                if one.empty:
                    continue
                evaluated = one.loc[one["protocol"] != "No-Regime"].copy()
                if evaluated.empty:
                    continue
                best_balance = evaluated.sort_values("day_share_entropy", ascending=False).iloc[0]
                best_stable = evaluated.sort_values("rankic_state_std", ascending=True).iloc[0]
                lines.append(
                    f"- `{direction}/{model_name}`: overall metrics remain invariant across protocols by design; "
                    f"best-balanced split = `{best_balance['protocol']}` (entropy = {best_balance['day_share_entropy']:.4f}), "
                    f"most stable split = `{best_stable['protocol']}` (state std = {best_stable['rankic_state_std']:.4f})."
                )
    if not consistency_df.empty:
        evaluated_consistency = consistency_df.loc[consistency_df["protocol"] != "No-Regime"].copy()
        best_consistency = evaluated_consistency.sort_values("avg_semantic_cosine", ascending=False).iloc[0] if not evaluated_consistency.empty else consistency_df.sort_values("avg_semantic_cosine", ascending=False).iloc[0]
        lines.append(
            f"- Cross-market semantic consistency is highest under `{best_consistency['protocol']}` "
            f"(avg cosine = {best_consistency['avg_semantic_cosine']:.4f})."
        )
    lines.extend(
        [
            "",
            "## 3. Output Files",
            "",
            "- `regime_ablation_summary.csv`",
            "- `regime_ablation_state_metrics.csv`",
            "- `regime_ablation_state_profiles.csv`",
            "- `regime_ablation_consistency.csv`",
            "",
            "## 4. Interpretation",
            "",
            "- `No-Regime` 用于衡量不做状态切分时的整体结果。",
            "- `Quantile-3` 是透明、可复现的主文协议候选。",
            "- `HMM-3` 检验引入时序转移约束后, 是否带来更稳定的状态划分。",
            "- `Cluster-4` 检验更复杂的四状态无监督切分是否真正优于简单规则法。",
            "",
            "## 5. State Profiles Snapshot",
            "",
        ]
    )
    if not profile_df.empty:
        snapshot = profile_df.sort_values(["protocol", "market", "state"]).head(24)
        lines.append(snapshot.to_markdown(index=False))
    (output_dir / "regime_ablation_report.md").write_text("\n".join(lines), encoding="utf-8")


def run_regime_ablation(config: RegimeAblationConfig) -> dict[str, Any]:
    ensure_dir(RESULTS_DIR)
    summary_rows: list[dict[str, Any]] = []
    state_frames: list[pd.DataFrame] = []
    profile_rows: list[dict[str, Any]] = []
    protocol_metadata: dict[str, dict[str, Any]] = {}

    for direction in config.directions:
        target_market = DIRECTION_TO_TARGET[direction]
        panel_df = load_target_panel(target_market=target_market, split=config.split)
        market_daily = build_market_daily(panel_df)
        protocols = build_protocol_labels(market_daily, random_state=config.random_state)
        protocol_metadata[target_market] = {}

        for protocol_name, payload in protocols.items():
            labels = payload["labels"]
            profile_df = payload["profile_df"].copy()
            profile_df["market"] = target_market
            profile_df["protocol"] = protocol_name
            profile_rows.extend(profile_df.to_dict(orient="records"))
            protocol_metadata[target_market][protocol_name] = payload["metadata"]

            for model_name in config.models:
                prediction_path, result_subdir = resolve_prediction_path(direction=direction, model_name=model_name)
                pred_df = pd.read_csv(prediction_path)
                pred_df["date"] = pd.to_datetime(pred_df["date"])
                summary_row, state_df = evaluate_one_protocol(
                    direction=direction,
                    target_market=target_market,
                    model_name=model_name,
                    result_subdir=result_subdir,
                    pred_df=pred_df,
                    regime_series=labels,
                    market_daily=market_daily,
                    top_k=config.top_k,
                )
                summary_row["protocol"] = protocol_name
                state_df["protocol"] = protocol_name
                summary_rows.append(summary_row)
                state_frames.append(state_df)

    summary_df = pd.DataFrame(summary_rows)
    state_metrics_df = pd.concat(state_frames, axis=0, ignore_index=True) if state_frames else pd.DataFrame()
    profile_df = pd.DataFrame(profile_rows)
    consistency_df = build_cross_market_consistency(profile_df) if not profile_df.empty else pd.DataFrame()

    summary_df.to_csv(RESULTS_DIR / "regime_ablation_summary.csv", index=False, encoding="utf-8-sig")
    state_metrics_df.to_csv(RESULTS_DIR / "regime_ablation_state_metrics.csv", index=False, encoding="utf-8-sig")
    profile_df.to_csv(RESULTS_DIR / "regime_ablation_state_profiles.csv", index=False, encoding="utf-8-sig")
    consistency_df.to_csv(RESULTS_DIR / "regime_ablation_consistency.csv", index=False, encoding="utf-8-sig")
    build_markdown_report(RESULTS_DIR, summary_df, consistency_df, profile_df, config)

    manifest = {
        "config": asdict(config),
        "summary_path": str(RESULTS_DIR / "regime_ablation_summary.csv"),
        "state_metrics_path": str(RESULTS_DIR / "regime_ablation_state_metrics.csv"),
        "profiles_path": str(RESULTS_DIR / "regime_ablation_state_profiles.csv"),
        "consistency_path": str(RESULTS_DIR / "regime_ablation_consistency.csv"),
        "metadata": protocol_metadata,
    }
    (RESULTS_DIR / "regime_ablation_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行状态切分消融实验")
    parser.add_argument("--directions", default="us_to_cn,cn_to_us")
    parser.add_argument("--models", default="transformer,hist,main_transfer")
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--random-state", type=int, default=42)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = RegimeAblationConfig(
        directions=tuple(item.strip() for item in args.directions.split(",") if item.strip()),
        models=tuple(item.strip() for item in args.models.split(",") if item.strip()),
        top_k=args.top_k,
        random_state=args.random_state,
    )
    log("[INFO] 开始运行状态切分消融实验")
    manifest = run_regime_ablation(config)
    log("[SUCCESS] 状态切分消融实验完成")
    log(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
