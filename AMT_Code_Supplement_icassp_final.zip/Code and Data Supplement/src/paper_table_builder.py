"""
文件功能:
1. 读取最新 `full` 主实验结果和 `baseline_full_trial` 结果，自动生成论文主表与附录表。
2. 将“同类迁移基线 + 主文相邻强基线 + 通用预测基线”的分层口径固化为可复用表格资产。
3. 为结果批次内的 `论文素材/AAAI V2/assets` 输出 Markdown、CSV 与 LaTeX 三套表格文件，减少手工拷贝造成的口径漂移。

代码逻辑:
1. 自动定位最新 `full_*` 批次中的主实验汇总和 baseline full trial 汇总。
2. 统一清洗字段名与模型显示名，将 `AMT / QuantNet / DoubleAdapt / generic baselines` 拼成主表；`TRA` 不再进入主文主表。
3. 输出主表、附录表与 manifest，供论文正文和附录直接引用。

代码结构:
1. 结果定位与字段清洗函数。
2. 主表与附录表构建函数。
3. Markdown / CSV / LaTeX 导出函数。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from experiment_workspace import get_latest_completed_batch_root, get_paper_asset_path, require_batch_artifacts


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT_DIR / "results"

MAIN_TABLE_ORDER = ["main_transfer", "QuantNet", "DoubleAdapt", "lasso", "transformer", "hist"]
DISPLAY_NAME_MAP = {
    "main_transfer": "AMT",
    "lasso": "Lasso",
    "xgboost": "XGBoost",
    "lstm": "LSTM",
    "transformer": "Transformer",
    "hist": "HIST",
    "tra": "TRA-Generic",
    "QuantNet": "QuantNet",
    "TRA": "TRA",
    "DoubleAdapt": "DoubleAdapt",
}
LAYER_MAP = {
    "main_transfer": "ours",
    "QuantNet": "direct_transfer",
    "TRA": "adjacent_strong",
    "DoubleAdapt": "adjacent_strong",
    "lasso": "generic_predictor",
    "xgboost": "generic_predictor",
    "lstm": "generic_predictor",
    "transformer": "generic_predictor",
    "hist": "generic_predictor",
    "tra": "generic_predictor",
}


def ensure_dirs(asset_dir: Path) -> None:
    asset_dir.mkdir(parents=True, exist_ok=True)


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    display_df = df.copy()
    for column in display_df.columns:
        if pd.api.types.is_float_dtype(display_df[column]):
            display_df[column] = display_df[column].map(lambda value: f"{value:.4f}")
    headers = [str(column) for column in display_df.columns.tolist()]
    rows = [[str(value) for value in row] for row in display_df.astype(object).values.tolist()]
    separator = ["---"] * len(headers)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(separator) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def find_latest_main_full_run() -> Path:
    candidates = [
        path for path in RESULTS_DIR.glob("full_*")
        if path.is_dir() and (path / "主实验" / "phase1_transfer" / "all_summary.csv").exists()
    ]
    if not candidates:
        raise FileNotFoundError("未找到包含主实验汇总的 full_* 结果目录。")
    candidates.sort(key=lambda item: item.stat().st_mtime, reverse=True)
    return candidates[0]


def find_latest_baseline_full_run() -> Path:
    candidates = [
        path for path in RESULTS_DIR.glob("full_*")
        if path.is_dir() and (path / "对比实验" / "baseline_full_trial" / "all_full_trial_summary.csv").exists()
    ]
    if not candidates:
        raise FileNotFoundError("未找到包含 baseline_full_trial 汇总的 full_* 结果目录。")
    candidates.sort(key=lambda item: item.stat().st_mtime, reverse=True)
    return candidates[0]


def find_latest_joint_full_run() -> Path:
    candidates = [
        path for path in RESULTS_DIR.glob("full_*")
        if path.is_dir()
        and (path / "主实验" / "phase1_transfer" / "all_summary.csv").exists()
        and (path / "对比实验" / "baseline_full_trial" / "all_full_trial_summary.csv").exists()
    ]
    if not candidates:
        raise FileNotFoundError("未找到同时包含主实验与 baseline_full_trial 汇总的 latest full 结果目录。")
    candidates.sort(key=lambda item: item.stat().st_mtime, reverse=True)
    return candidates[0]


def load_main_summary(main_run_dir: Path) -> pd.DataFrame:
    path = main_run_dir / "主实验" / "phase1_transfer" / "all_summary.csv"
    if not path.exists():
        raise FileNotFoundError(f"主实验汇总不存在: {path}")
    df = pd.read_csv(path)
    df["direction"] = df["direction"].astype(str)
    df["model"] = df["model"].astype(str)
    return df


def load_baseline_summary(baseline_run_dir: Path) -> pd.DataFrame:
    path = baseline_run_dir / "对比实验" / "baseline_full_trial" / "all_full_trial_summary.csv"
    if not path.exists():
        raise FileNotFoundError(f"baseline_full_trial 汇总不存在: {path}")
    df = pd.read_csv(path)
    df["direction"] = df["direction"].astype(str).str.replace("_TO_", "->", regex=False)
    return df


def resolve_ndcg_column(df: pd.DataFrame) -> str:
    for column in ["NDCG@10", "NDCG@20", "NDCG"]:
        if column in df.columns:
            return column
    raise KeyError("未找到可用的 NDCG 指标列，期望列名之一为 `NDCG@10` / `NDCG@20` / `NDCG`。")


def standardize_main_rows(df: pd.DataFrame) -> pd.DataFrame:
    ndcg_column = resolve_ndcg_column(df)
    keep_columns = ["direction", "model", "IC", "RankIC", ndcg_column, "Annualized Return", "Sharpe Ratio", "Maximum Drawdown"]
    work_df = df[keep_columns].copy()
    work_df = work_df.rename(columns={ndcg_column: "NDCG"})
    work_df["comparison_layer"] = work_df["model"].map(LAYER_MAP).fillna("generic_predictor")
    work_df["display_name"] = work_df["model"].map(DISPLAY_NAME_MAP).fillna(work_df["model"])
    work_df["source"] = "main"
    return work_df


def standardize_baseline_rows(df: pd.DataFrame) -> pd.DataFrame:
    work_df = df.copy()
    ndcg_column = resolve_ndcg_column(work_df)
    metric_columns = ["direction", "baseline", "IC", "RankIC", ndcg_column, "Annualized Return", "Sharpe Ratio", "Maximum Drawdown", "comparison_layer"]
    missing = [column for column in metric_columns if column not in work_df.columns]
    if missing:
        raise ValueError(f"baseline_full_trial 汇总缺少字段: {missing}")
    work_df = work_df[metric_columns].rename(columns={"baseline": "model", ndcg_column: "NDCG"})
    work_df["display_name"] = work_df["model"].map(DISPLAY_NAME_MAP).fillna(work_df["model"])
    work_df["source"] = "baseline_full_trial"
    return work_df


def build_main_table(main_df: pd.DataFrame, baseline_df: pd.DataFrame) -> pd.DataFrame:
    combined = pd.concat([standardize_main_rows(main_df), standardize_baseline_rows(baseline_df)], ignore_index=True)
    combined["direction_order"] = combined["direction"].map({"US->CN": 0, "CN->US": 1}).fillna(99)
    combined["model_order"] = combined["model"].apply(lambda name: MAIN_TABLE_ORDER.index(name) if name in MAIN_TABLE_ORDER else 999)
    table_df = combined[combined["model"].isin(MAIN_TABLE_ORDER)].copy()
    table_df = table_df.sort_values(["direction_order", "model_order"]).reset_index(drop=True)
    return table_df[
        ["direction", "display_name", "comparison_layer", "IC", "RankIC", "NDCG", "Annualized Return", "Sharpe Ratio", "Maximum Drawdown"]
    ].rename(columns={"direction": "Direction", "display_name": "Model", "comparison_layer": "Layer"})


def build_appendix_table(main_df: pd.DataFrame, baseline_df: pd.DataFrame) -> pd.DataFrame:
    combined = pd.concat([standardize_main_rows(main_df), standardize_baseline_rows(baseline_df)], ignore_index=True)
    combined = combined.sort_values(["direction", "comparison_layer", "display_name"]).reset_index(drop=True)
    return combined[
        ["direction", "display_name", "comparison_layer", "source", "IC", "RankIC", "NDCG", "Annualized Return", "Sharpe Ratio", "Maximum Drawdown"]
    ].rename(
        columns={
            "direction": "Direction",
            "display_name": "Model",
            "comparison_layer": "Layer",
            "source": "Source",
        }
    )


def render_tex(table_df: pd.DataFrame, caption: str, label: str) -> str:
    columns = list(table_df.columns)
    align = "l" * len(columns)
    header = (
        "\\begin{table*}[t]\n"
        f"\\caption{{{caption}}}\n"
        f"\\label{{{label}}}\n"
        "\\centering\n"
        "\\small\n"
        f"\\begin{{tabular}}{{{align}}}\n"
        "\\toprule\n"
        + " & ".join(columns)
        + " \\\\\n"
        "\\midrule\n"
    )
    body_lines: list[str] = []
    for row in table_df.itertuples(index=False):
        values: list[str] = []
        for value in row:
            if isinstance(value, float):
                values.append(f"{value:.4f}")
            else:
                values.append(str(value))
        body_lines.append(" & ".join(values) + " \\\\")
    footer = "\n".join(["\\bottomrule", "\\end{tabular}", "\\end{table*}", ""])
    return header + "\n".join(body_lines) + "\n" + footer


def export_table(table_df: pd.DataFrame, asset_dir: Path, stem: str, caption: str, label: str) -> dict[str, str]:
    csv_path = asset_dir / f"{stem}.csv"
    md_path = asset_dir / f"{stem}.md"
    tex_path = asset_dir / f"{stem}.tex"
    table_df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    md_path.write_text(f"# {stem}\n\n{render_markdown_table(table_df)}\n", encoding="utf-8")
    tex_path.write_text(render_tex(table_df, caption=caption, label=label), encoding="utf-8")
    return {"csv_path": str(csv_path), "md_path": str(md_path), "tex_path": str(tex_path)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成 AAAI V2 主表与附录表")
    parser.add_argument("--batch-root", default="", help="可选，显式指定 full 批次根目录；若为空则严格使用最新 full 批次")
    parser.add_argument("--full-run-dir", default="", help="可选，显式指定主实验 full 结果目录")
    parser.add_argument("--baseline-run-dir", default="", help="可选，显式指定 baseline_full_trial 所在 full 结果目录")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.batch_root:
        batch_root = require_batch_artifacts(
            Path(args.batch_root),
            (
                ("主实验", "phase1_transfer", "all_summary.csv"),
                ("对比实验", "baseline_full_trial", "all_full_trial_summary.csv"),
            ),
        )
        main_run_dir = batch_root
        baseline_run_dir = batch_root
    elif args.full_run_dir and args.baseline_run_dir:
        main_run_dir = Path(args.full_run_dir)
        baseline_run_dir = Path(args.baseline_run_dir)
    elif args.full_run_dir:
        main_run_dir = Path(args.full_run_dir)
        baseline_run_dir = Path(args.full_run_dir)
    elif args.baseline_run_dir:
        main_run_dir = Path(args.baseline_run_dir)
        baseline_run_dir = Path(args.baseline_run_dir)
    else:
        batch_root = require_batch_artifacts(
            get_latest_completed_batch_root(prefix="full"),
            (
                ("主实验", "phase1_transfer", "all_summary.csv"),
                ("对比实验", "baseline_full_trial", "all_full_trial_summary.csv"),
            ),
        )
        main_run_dir = batch_root
        baseline_run_dir = batch_root
    asset_dir = get_paper_asset_path(main_run_dir, "assets")
    ensure_dirs(asset_dir)
    main_df = load_main_summary(main_run_dir)
    baseline_df = load_baseline_summary(baseline_run_dir)
    main_table = build_main_table(main_df, baseline_df)
    appendix_table = build_appendix_table(main_df, baseline_df)
    main_outputs = export_table(main_table, asset_dir, "main_table", "Layered main comparison table.", "tab:main")
    appendix_outputs = export_table(appendix_table, asset_dir, "appendix_table", "Extended appendix comparison table.", "tab:appendix")
    manifest = {
        "main_run_dir": str(main_run_dir),
        "baseline_run_dir": str(baseline_run_dir),
        "asset_dir": str(asset_dir),
        "main_outputs": main_outputs,
        "appendix_outputs": appendix_outputs,
    }
    manifest_path = asset_dir / "table_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({**manifest, "manifest_path": str(manifest_path)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
