import os
import re

src_tex = "/data/zhoutm/exp2/paper/ICASSP/V0(AAAI TO ICASSP)/ICASSP_draft.tex"
dst_tex = "/data/zhoutm/exp2/paper/ICASSP/V0(AAAI TO ICASSP)/ICASSP_draft_V0.1.tex"

with open(src_tex, "r", encoding="utf-8") as f:
    content = f.read()

def repl_abs(m):
    return "The central challenge of cross-market alpha strategy transfer is preserving the fused strategy mechanism. We propose AlphaMechTransfer (AMT), a mechanism-preserving, structure-frozen framework. AMT integrates temporal, relational, and factor-mechanism projections, determines trainable scopes via similarity-guided freezing, and restricts updates using sparse parameter selection. Evaluated on CN$\\rightarrow$US, AMT outperforms QuantNet and DoubleAdapt in annualized return, demonstrating that mechanism preservation is crucial for financially interpretable transfer."

content = re.sub(
    r"The central challenge of cross-market alpha strategy transfer.*?The code is in the appendix\.",
    repl_abs,
    content, flags=re.DOTALL
)

def repl_intro(m):
    return "Formulaic alphas are rule-based scoring expressions in quantitative trading \\citep{kakushadze2016formulaic}. Transferring strategies across markets often alters their financial meaning due to differing microstructures. Existing methods focus on target-domain fit without explicitly constraining mechanism preservation. We address this with AlphaMechTransfer (AMT), which treats cross-market transfer as a controlled ranking problem. AMT learns a fused source-market mechanism and uses market-similarity to freeze structural components during adaptation, regularizing parameter and mechanism drift. Relative to prior work \\citep{feng2019temporal,koshiyama2022quantnet,zhao2023doubleadapt}, AMT strictly controls transfer to preserve strategy meaning. Our contributions include formulating mechanism-preserving transfer, proposing the AMT framework, and designing a layered evaluation protocol."

content = re.sub(
    r"Formulaic alphas are not merely prediction formulas.*?failure boundaries of mechanism-preserving transfer\.",
    repl_intro,
    content, flags=re.DOTALL
)

def repl_related(m):
    return "\\textbf{Financial Prediction \\& Hypergraphs.} Recent models move from point forecasting to ranking \\citep{feng2019temporal,sawhney2021sthan}. Hypergraphs effectively model stock co-movement and factor interactions \\citep{cheng2021adgat,li2024master,duan2025factorgcl,feng2019hgnn}. AMT inherits this but treats structure as a strategic object to preserve. \\textbf{Transfer-Oriented Models.} Methods like QuantNet \\citep{koshiyama2022quantnet} and DoubleAdapt \\citep{zhao2023doubleadapt} improve adaptation flexibility for target-domain performance. In contrast, AMT explicitly asks whether the transferred result preserves the original strategy mechanism."

content = re.sub(
    r"\\textbf\{Ranking-aware financial prediction.*?in any strict financial sense\.",
    repl_related,
    content, flags=re.DOTALL
)

content = content.replace(r"\begin{itemize}[leftmargin=*,noitemsep,topsep=0pt]", r"\begin{itemize}")

def repl_conclusion(m):
    return "\\section{Conclusion}\nThis paper proposes AMT, a cross-market alpha transfer framework combining fused mechanism representation, similarity-guided freezing, and mechanism-preserving regularization. AMT yields meaningful gains when source-target compatibility is favorable and establishes a principled boundary for financially interpretable transfer.\n\n\\bibliography"

content = re.sub(
    r"\\section\{Discussion\}.*?\\bibliography",
    repl_conclusion,
    content, flags=re.DOTALL
)

with open(dst_tex, "w", encoding="utf-8") as f:
    f.write(content)

