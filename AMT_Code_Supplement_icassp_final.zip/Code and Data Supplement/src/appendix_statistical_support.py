"""
文件功能:
1. 基于已落盘的 `test_predictions.csv` 与 `equity_curve.csv`，为 AAAIV3 附录生成零重训统计支持表。
2. 对关键 claim 计算配对 bootstrap 置信区间、Wilcoxon 检验、符号翻转 permutation 检验以及 Top-k 鲁棒性结果。
3. 输出结构化 CSV / Markdown / JSON 资产，保证附录中的统计结论可追溯到原始预测文件与净值文件。

代码逻辑:
1. 读取现有主实验、消融与 reversal case 的预测和净值曲线。
2. 以“按交易日对齐”的方式构造每日收益差异与每日 RankIC 差异。
3. 对差异序列执行 bootstrap / Wilcoxon / permutation 检验。
4. 用统一回测接口对多个 Top-k 重新回测，形成零重训鲁棒性表。

代码结构:
1. 基础统计与表格渲染工具。
2. 文件读取与按日指标计算函数。
3. 关键 claim 统计表与 Top-k 鲁棒性表生成。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from experiment_runner import run_fast_topk_backtest
from experiment_workspace import get_archive_root, get_paper_asset_path, write_dataframe, write_json


BOOTSTRAP_ROUNDS = 2000
PERMUTATION_ROUNDS = 5000
RNG_SEED = 42


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    view = df.copy()
    for column in view.columns:
        if pd.api.types.is_float_dtype(view[column]):
            view[column] = view[column].map(lambda value: f"{value:.6f}")
    headers = [str(column) for column in view.columns.tolist()]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in view.iterrows():
        lines.append("| " + " | ".join(str(value) for value in row.tolist()) + " |")
    return "\n".join(lines)


def load_prediction_frame(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values(["date", "symbol"]).reset_index(drop=True)


def load_curve_frame(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values("date").reset_index(drop=True)


def daily_rankic_series(pred_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for date_value, raw_daily_df in pred_df.groupby("date"):
        daily_df = raw_daily_df.replace([np.inf, -np.inf], np.nan).dropna(subset=["label", "prediction"]).copy()
        if len(daily_df) < 5:
            continue
        rankic = float(stats.spearmanr(daily_df["label"], daily_df["prediction"], nan_policy="omit").statistic)
        rows.append({"date": date_value, "rankic": rankic})
    return pd.DataFrame(rows)


def bootstrap_ci_from_differences(differences: np.ndarray, rounds: int = BOOTSTRAP_ROUNDS) -> tuple[float, float, float]:
    clean = np.asarray(differences, dtype=float)
    clean = clean[np.isfinite(clean)]
    if clean.size == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(RNG_SEED)
    means = np.empty(rounds, dtype=float)
    for idx in range(rounds):
        sample = rng.choice(clean, size=clean.size, replace=True)
        means[idx] = float(sample.mean())
    return float(clean.mean()), float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def permutation_pvalue_from_differences(differences: np.ndarray, rounds: int = PERMUTATION_ROUNDS) -> float:
    clean = np.asarray(differences, dtype=float)
    clean = clean[np.isfinite(clean)]
    if clean.size == 0:
        return np.nan
    observed = abs(float(clean.mean()))
    rng = np.random.default_rng(RNG_SEED)
    hits = 0
    for _ in range(rounds):
        signs = rng.choice([-1.0, 1.0], size=clean.size, replace=True)
        permuted = clean * signs
        if abs(float(permuted.mean())) >= observed:
            hits += 1
    return float((hits + 1) / (rounds + 1))


def wilcoxon_pvalue_from_differences(differences: np.ndarray) -> float:
    clean = np.asarray(differences, dtype=float)
    clean = clean[np.isfinite(clean)]
    clean = clean[np.abs(clean) > 1e-12]
    if clean.size < 2:
        return np.nan
    return float(stats.wilcoxon(clean).pvalue)


def build_claim_record(
    claim_name: str,
    left_name: str,
    right_name: str,
    left_prediction_path: Path,
    right_prediction_path: Path,
    left_curve_path: Path,
    right_curve_path: Path,
) -> dict[str, Any]:
    left_pred = load_prediction_frame(left_prediction_path)
    right_pred = load_prediction_frame(right_prediction_path)
    left_curve = load_curve_frame(left_curve_path)
    right_curve = load_curve_frame(right_curve_path)

    merged_curve = left_curve[["date", "portfolio_return"]].rename(columns={"portfolio_return": "left_return"}).merge(
        right_curve[["date", "portfolio_return"]].rename(columns={"portfolio_return": "right_return"}),
        on="date",
        how="inner",
    )
    merged_curve["return_diff"] = merged_curve["left_return"] - merged_curve["right_return"]

    left_rankic = daily_rankic_series(left_pred).rename(columns={"rankic": "left_rankic"})
    right_rankic = daily_rankic_series(right_pred).rename(columns={"rankic": "right_rankic"})
    merged_rankic = left_rankic.merge(right_rankic, on="date", how="inner")
    merged_rankic["rankic_diff"] = merged_rankic["left_rankic"] - merged_rankic["right_rankic"]

    mean_diff, ci_low, ci_high = bootstrap_ci_from_differences(merged_curve["return_diff"].to_numpy(dtype=float))
    rankic_mean_diff, rankic_ci_low, rankic_ci_high = bootstrap_ci_from_differences(merged_rankic["rankic_diff"].to_numpy(dtype=float))

    return {
        "claim": claim_name,
        "left": left_name,
        "right": right_name,
        "paired_days_return": int(len(merged_curve)),
        "paired_days_rankic": int(len(merged_rankic)),
        "daily_return_diff_mean": mean_diff,
        "daily_return_diff_ci_low": ci_low,
        "daily_return_diff_ci_high": ci_high,
        "daily_return_wilcoxon_p": wilcoxon_pvalue_from_differences(merged_curve["return_diff"].to_numpy(dtype=float)),
        "daily_return_permutation_p": permutation_pvalue_from_differences(merged_curve["return_diff"].to_numpy(dtype=float)),
        "daily_rankic_diff_mean": rankic_mean_diff,
        "daily_rankic_diff_ci_low": rankic_ci_low,
        "daily_rankic_diff_ci_high": rankic_ci_high,
        "daily_rankic_wilcoxon_p": wilcoxon_pvalue_from_differences(merged_rankic["rankic_diff"].to_numpy(dtype=float)),
        "daily_rankic_permutation_p": permutation_pvalue_from_differences(merged_rankic["rankic_diff"].to_numpy(dtype=float)),
        "left_prediction_path": str(left_prediction_path),
        "right_prediction_path": str(right_prediction_path),
        "left_curve_path": str(left_curve_path),
        "right_curve_path": str(right_curve_path),
    }


def build_topk_record(label: str, prediction_path: Path, top_k: int) -> dict[str, Any]:
    pred_df = load_prediction_frame(prediction_path)
    curve_df, metrics = run_fast_topk_backtest(pred_df, top_k=top_k)
    _ = curve_df
    return {
        "label": label,
        "top_k": int(top_k),
        "Annualized Return": float(metrics.get("Annualized Return", 0.0)),
        "Sharpe Ratio": float(metrics.get("Sharpe Ratio", 0.0)),
        "Maximum Drawdown": float(metrics.get("Maximum Drawdown", 0.0)),
        "Effective TopK Mean": float(metrics.get("Effective TopK Mean", np.nan)),
        "prediction_path": str(prediction_path),
    }


def build_markdown(stat_df: pd.DataFrame, topk_df: pd.DataFrame) -> str:
    return (
        "# AAAIV3 零重训统计支持\n\n"
        "## 1. 统计支持表\n\n"
        f"{render_markdown_table(stat_df)}\n\n"
        "## 2. Top-k 鲁棒性表\n\n"
        f"{render_markdown_table(topk_df)}\n"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成 AAAIV3 附录零重训统计支持表")
    parser.add_argument(
        "--source-batch-root",
        default="/data/zhoutm/exp2/results/full_20260729_015852",
        help="现有论文结果批次根目录",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source_batch_root = Path(args.source_batch_root).resolve()
    archive_root = get_archive_root()
    asset_dir = ensure_dir(get_paper_asset_path(archive_root, "appendix_support", "statistical_support", paper_name="AAAIV3"))

    claims = [
        {
            "claim": "CN->US main AMT vs QuantNet",
            "left": "AMT",
            "right": "QuantNet",
            "left_pred": source_batch_root / "主实验" / "phase1_transfer" / "cn_to_us" / "main_transfer" / "test_predictions.csv",
            "right_pred": source_batch_root / "对比实验" / "baseline_full_trial" / "cn_to_us" / "quantnet" / "test_predictions.csv",
            "left_curve": source_batch_root / "主实验" / "phase1_transfer" / "cn_to_us" / "main_transfer" / "equity_curve.csv",
            "right_curve": source_batch_root / "对比实验" / "baseline_full_trial" / "cn_to_us" / "quantnet" / "equity_curve.csv",
        },
        {
            "claim": "CN->US main AMT vs DoubleAdapt",
            "left": "AMT",
            "right": "DoubleAdapt",
            "left_pred": source_batch_root / "主实验" / "phase1_transfer" / "cn_to_us" / "main_transfer" / "test_predictions.csv",
            "right_pred": source_batch_root / "对比实验" / "baseline_full_trial" / "cn_to_us" / "doubleadapt" / "test_predictions.csv",
            "left_curve": source_batch_root / "主实验" / "phase1_transfer" / "cn_to_us" / "main_transfer" / "equity_curve.csv",
            "right_curve": source_batch_root / "对比实验" / "baseline_full_trial" / "cn_to_us" / "doubleadapt" / "equity_curve.csv",
        },
        {
            "claim": "Ablation CN->US AMT-Ref vs No-Structure",
            "left": "AMT-Reference",
            "right": "No-Structure-Freezing",
            "left_pred": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "amt_reference" / "test_predictions.csv",
            "right_pred": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "no_structure_freezing" / "test_predictions.csv",
            "left_curve": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "amt_reference" / "equity_curve.csv",
            "right_curve": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "no_structure_freezing" / "equity_curve.csv",
        },
        {
            "claim": "Ablation CN->US AMT-Ref vs No-Mech",
            "left": "AMT-Reference",
            "right": "No-Mechanism-Constraint",
            "left_pred": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "amt_reference" / "test_predictions.csv",
            "right_pred": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "no_mechanism_constraint" / "test_predictions.csv",
            "left_curve": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "amt_reference" / "equity_curve.csv",
            "right_curve": source_batch_root / "消融实验" / "amt_ablation" / "cn_to_us" / "no_mechanism_constraint" / "equity_curve.csv",
        },
        {
            "claim": "Reversal CN->US AMT vs Direct Transfer",
            "left": "AMT",
            "right": "Direct Transfer",
            "left_pred": source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "amt" / "test_predictions.csv",
            "right_pred": source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "direct_transfer" / "test_predictions.csv",
            "left_curve": source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "amt" / "equity_curve.csv",
            "right_curve": source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "direct_transfer" / "equity_curve.csv",
        },
    ]

    stat_rows = [
        build_claim_record(
            claim_name=item["claim"],
            left_name=item["left"],
            right_name=item["right"],
            left_prediction_path=item["left_pred"],
            right_prediction_path=item["right_pred"],
            left_curve_path=item["left_curve"],
            right_curve_path=item["right_curve"],
        )
        for item in claims
    ]
    stat_df = pd.DataFrame(stat_rows)

    topk_jobs = [
        ("Main CN->US AMT", source_batch_root / "主实验" / "phase1_transfer" / "cn_to_us" / "main_transfer" / "test_predictions.csv"),
        ("Main CN->US QuantNet", source_batch_root / "对比实验" / "baseline_full_trial" / "cn_to_us" / "quantnet" / "test_predictions.csv"),
        ("Main CN->US DoubleAdapt", source_batch_root / "对比实验" / "baseline_full_trial" / "cn_to_us" / "doubleadapt" / "test_predictions.csv"),
        ("Reversal CN->US AMT", source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "amt" / "test_predictions.csv"),
        ("Reversal CN->US Direct Transfer", source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "direct_transfer" / "test_predictions.csv"),
    ]
    topk_rows = []
    for label, pred_path in topk_jobs:
        for top_k in (5, 10, 20, 30):
            topk_rows.append(build_topk_record(label=label, prediction_path=pred_path, top_k=top_k))
    topk_df = pd.DataFrame(topk_rows)

    stat_csv = write_dataframe(stat_df, asset_dir / "statistical_support_table.csv", index=False, encoding="utf-8-sig")
    topk_csv = write_dataframe(topk_df, asset_dir / "topk_robustness_table.csv", index=False, encoding="utf-8-sig")
    md_path = asset_dir / "statistical_support_table.md"
    md_path.write_text(build_markdown(stat_df, topk_df), encoding="utf-8")
    manifest = {
        "source_batch_root": str(source_batch_root),
        "archive_root": str(archive_root),
        "generated_files": {
            "statistical_support_csv": str(stat_csv),
            "topk_robustness_csv": str(topk_csv),
            "markdown": str(md_path),
        },
        "bootstrap_rounds": BOOTSTRAP_ROUNDS,
        "permutation_rounds": PERMUTATION_ROUNDS,
    }
    write_json(asset_dir / "manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
