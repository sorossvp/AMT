"""
文件功能:
1. 读取 `results/full_20260715_070111/` 下的主实验与 future 结果汇总文件。
2. 生成适合 AAAI 论文插图风格的对比图表, 统一输出 PNG 与 PDF 版本。
3. 额外生成一份图表说明文档, 明确每张图可支撑的结论边界, 避免夸大实验结果。
4. 所有可视化都基于现有结果文件直接绘制, 不改写原始指标, 只做排版与呈现。

代码逻辑:
1. 读取主实验 `all_summary.csv`, 提取 `RankIC`、`Sharpe Ratio`、`Annualized Return` 等指标。
2. 读取 future 报告 `future_hgnn_time_report.json`, 提取 identity 与 hypergraph 的对照结果。
3. 生成主实验双方向柱状图、收益-夏普散点图、future 双方向对照柱状图。
4. 输出 `figure_manifest.json` 与 `aaai_figure_notes.md`, 便于论文引用和后续复核。

代码结构:
1. 路径配置与通用绘图样式函数。
2. 主实验结果与 future 结果加载函数。
3. 各类图表绘制函数。
4. 图表说明文档与 manifest 输出。
5. CLI 入口。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


DEFAULT_RESULT_ROOT = Path("/data/ztm/exp2/results/full_20260715_070111")
DEFAULT_OUTPUT_DIRNAME = "论文图表_v1"
MAIN_SUMMARY_PATH = Path("主实验/phase1_transfer/all_summary.csv")
FUTURE_REPORT_PATH = Path("其他/future_hgnn_time_report.json")

MAIN_METHOD = "main_transfer"
HIGHLIGHT_COLOR = "#C62828"
BASELINE_COLOR = "#90A4AE"
BEST_COLOR = "#1565C0"
IDENTITY_COLOR = "#B0BEC5"
HYPERGRAPH_COLOR = "#2E7D32"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def save_figure(fig: plt.Figure, output_dir: Path, stem: str) -> dict[str, str]:
    png_path = output_dir / f"{stem}.png"
    pdf_path = output_dir / f"{stem}.pdf"
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)
    return {"png": str(png_path), "pdf": str(pdf_path)}


def apply_aaai_style() -> None:
    plt.rcParams.update(
        {
            "figure.dpi": 150,
            "font.size": 10,
            "axes.labelsize": 10,
            "axes.titlesize": 11,
            "legend.fontsize": 9,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "grid.alpha": 0.2,
            "grid.linestyle": "--",
        }
    )


def load_main_summary(result_root: Path) -> pd.DataFrame:
    summary_path = result_root / MAIN_SUMMARY_PATH
    df = pd.read_csv(summary_path)
    numeric_columns = ["IC", "ICIR", "RankIC", "RankICIR", "NDCG@10", "Annualized Return", "Sharpe Ratio", "Maximum Drawdown"]
    for column in numeric_columns:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def load_future_summary(result_root: Path) -> pd.DataFrame:
    report_path = result_root / FUTURE_REPORT_PATH
    payload = json.loads(report_path.read_text(encoding="utf-8"))
    rows: list[dict[str, Any]] = []
    for direction, branch_payload in payload["sthgcn_bidirectional"].items():
        for variant, variant_payload in branch_payload.items():
            metrics = variant_payload["metrics"]
            rows.append(
                {
                    "direction": direction,
                    "variant": variant,
                    "Annualized Return": metrics.get("Annualized Return"),
                    "Sharpe Ratio": metrics.get("Sharpe Ratio"),
                    "RankIC": metrics.get("RankIC"),
                    "IC": metrics.get("IC"),
                }
            )
    future_df = pd.DataFrame(rows)
    for column in ["Annualized Return", "Sharpe Ratio", "RankIC", "IC"]:
        future_df[column] = pd.to_numeric(future_df[column], errors="coerce")
    return future_df


def get_method_colors(frame: pd.DataFrame, metric: str) -> list[str]:
    best_idx = frame[metric].idxmax()
    colors: list[str] = []
    for row_idx, method_name in zip(frame.index, frame["model"]):
        if method_name == MAIN_METHOD:
            colors.append(HIGHLIGHT_COLOR)
        elif row_idx == best_idx:
            colors.append(BEST_COLOR)
        else:
            colors.append(BASELINE_COLOR)
    return colors


def annotate_bars(ax: plt.Axes, values: np.ndarray) -> None:
    value_range = np.nanmax(values) - np.nanmin(values) if len(values) else 0.0
    offset = 0.02 * max(1.0, abs(value_range))
    for patch, value in zip(ax.patches, values):
        if np.isnan(value):
            continue
        y = value + offset if value >= 0 else value - offset
        va = "bottom" if value >= 0 else "top"
        ax.text(
            patch.get_x() + patch.get_width() / 2.0,
            y,
            f"{value:.3f}",
            ha="center",
            va=va,
            fontsize=8,
        )


def plot_main_metric_bars(main_df: pd.DataFrame, metric: str, output_dir: Path, stem: str, ylabel: str) -> dict[str, str]:
    directions = ["CN->US", "US->CN"]
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 4.8), sharey=True)
    for axis, direction in zip(axes, directions):
        sub_df = main_df[main_df["direction"] == direction].copy()
        sub_df = sub_df.sort_values(metric, ascending=False).reset_index(drop=True)
        colors = get_method_colors(sub_df, metric)
        axis.bar(sub_df["model"], sub_df[metric].to_numpy(), color=colors, edgecolor="black", linewidth=0.5)
        annotate_bars(axis, sub_df[metric].to_numpy())
        axis.set_title(direction)
        axis.set_xlabel("Methods")
        axis.set_ylabel(ylabel)
        axis.tick_params(axis="x", rotation=35)
    fig.suptitle(f"Main Experiment Comparison by {metric}")
    fig.tight_layout()
    return save_figure(fig, output_dir, stem)


def plot_main_scatter(main_df: pd.DataFrame, output_dir: Path) -> dict[str, str]:
    fig, ax = plt.subplots(figsize=(7.2, 5.6))
    markers = {"CN->US": "o", "US->CN": "s"}
    for direction, direction_df in main_df.groupby("direction"):
        for _, row in direction_df.iterrows():
            color = HIGHLIGHT_COLOR if row["model"] == MAIN_METHOD else BASELINE_COLOR
            size = 150 if row["model"] == MAIN_METHOD else 90
            ax.scatter(
                row["Annualized Return"],
                row["Sharpe Ratio"],
                c=color,
                s=size,
                marker=markers.get(direction, "o"),
                edgecolors="black",
                linewidths=0.6,
                alpha=0.9,
            )
            ax.text(
                row["Annualized Return"],
                row["Sharpe Ratio"],
                f"{direction}:{row['model']}",
                fontsize=7.5,
                ha="left",
                va="bottom",
            )
    ax.set_title("Return-Sharpe Trade-off in Main Experiment")
    ax.set_xlabel("Annualized Return")
    ax.set_ylabel("Sharpe Ratio")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_3_main_return_sharpe_scatter")


def plot_future_comparison(future_df: pd.DataFrame, output_dir: Path) -> dict[str, str]:
    directions = ["cn_to_future", "future_to_cn"]
    metrics = ["Annualized Return", "Sharpe Ratio", "RankIC"]
    fig, axes = plt.subplots(1, 3, figsize=(15.0, 4.8))
    x = np.arange(len(directions))
    width = 0.34
    direction_labels = ["CN->FUTURE", "FUTURE->CN"]
    for axis, metric in zip(axes, metrics):
        identity_values = []
        hypergraph_values = []
        for direction in directions:
            direction_df = future_df[future_df["direction"] == direction]
            identity_values.append(float(direction_df[direction_df["variant"] == "identity"][metric].iloc[0]))
            hypergraph_values.append(float(direction_df[direction_df["variant"] == "hypergraph"][metric].iloc[0]))
        axis.bar(x - width / 2.0, identity_values, width=width, color=IDENTITY_COLOR, edgecolor="black", linewidth=0.5, label="Identity")
        axis.bar(x + width / 2.0, hypergraph_values, width=width, color=HYPERGRAPH_COLOR, edgecolor="black", linewidth=0.5, label="Hypergraph")
        axis.set_title(metric)
        axis.set_xticks(x)
        axis.set_xticklabels(direction_labels, rotation=10)
        if metric == "RankIC":
            axis.axhline(0.0, color="black", linewidth=0.8, alpha=0.5)
    axes[0].set_ylabel("Metric Value")
    axes[0].legend(frameon=False)
    fig.suptitle("Future Transfer: Hypergraph vs. Identity")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_4_future_hypergraph_vs_identity")


def build_notes(main_df: pd.DataFrame, future_df: pd.DataFrame, figure_files: dict[str, dict[str, str]], output_dir: Path) -> Path:
    cn_us_main = main_df[(main_df["direction"] == "CN->US") & (main_df["model"] == MAIN_METHOD)].iloc[0]
    us_cn_main = main_df[(main_df["direction"] == "US->CN") & (main_df["model"] == MAIN_METHOD)].iloc[0]
    best_cn_us_rankic = main_df[main_df["direction"] == "CN->US"].sort_values("RankIC", ascending=False).iloc[0]
    best_us_cn_rankic = main_df[main_df["direction"] == "US->CN"].sort_values("RankIC", ascending=False).iloc[0]
    future_cn_identity = future_df[(future_df["direction"] == "cn_to_future") & (future_df["variant"] == "identity")].iloc[0]
    future_cn_hypergraph = future_df[(future_df["direction"] == "cn_to_future") & (future_df["variant"] == "hypergraph")].iloc[0]

    lines = [
        "# AAAI 图表说明",
        "",
        "## 1. 使用边界",
        "",
        "- 所有图表均直接基于 `full_20260715_070111` 结果文件绘制，不改写原始指标。",
        "- 图表可用于论文正文或附录，但不能据此宣称 `main_transfer` 在当前 full 批次中全面优于全部 baseline。",
        "- 可以明确支撑的结论是：`main_transfer` 已稳定跑通；future 的 `hypergraph` 结构在 `CN->FUTURE` 上优于 `identity` 对照。",
        "",
        "## 2. 主实验图表解读",
        "",
        f"- `CN->US` 中，`main_transfer` 的 `RankIC={cn_us_main['RankIC']:.4f}`，当前最优 `RankIC` 来自 `{best_cn_us_rankic['model']}` (`{best_cn_us_rankic['RankIC']:.4f}`)。",
        f"- `US->CN` 中，`main_transfer` 的 `RankIC={us_cn_main['RankIC']:.4f}`，当前最优 `RankIC` 来自 `{best_us_cn_rankic['model']}` (`{best_us_cn_rankic['RankIC']:.4f}`)。",
        f"- `US->CN` 中，`main_transfer` 的 `Sharpe Ratio={us_cn_main['Sharpe Ratio']:.4f}`，表明其风险调整收益仍处于可接受区间。",
        "",
        "## 3. future 图表解读",
        "",
        f"- `CN->FUTURE` 上，`hypergraph` 的 `Annualized Return={future_cn_hypergraph['Annualized Return']:.4f}`，高于 `identity` 的 `{future_cn_identity['Annualized Return']:.4f}`。",
        f"- `CN->FUTURE` 上，`hypergraph` 的 `RankIC={future_cn_hypergraph['RankIC']:.4f}`，而 `identity` 的 `RankIC` 为缺失值，说明超图结构在该方向提供了更有效的排序信号。",
        "- `FUTURE->CN` 方向的 `identity` 与 `hypergraph` 在当前 full 批次下几乎重合，不能夸大为显著优势。",
        "",
        "## 4. 图表文件",
        "",
    ]
    for figure_name, paths in figure_files.items():
        lines.append(f"- `{figure_name}`: `{paths['png']}` / `{paths['pdf']}`")
    notes_path = output_dir / "aaai_figure_notes.md"
    notes_path.write_text("\n".join(lines), encoding="utf-8")
    return notes_path


def build_manifest(figure_files: dict[str, dict[str, str]], notes_path: Path, output_dir: Path) -> Path:
    manifest_path = output_dir / "figure_manifest.json"
    payload = {"figures": figure_files, "notes_path": str(notes_path)}
    manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="将 full 结果转换为 AAAI 风格图表")
    parser.add_argument("--result-root", default=str(DEFAULT_RESULT_ROOT))
    parser.add_argument("--output-dirname", default=DEFAULT_OUTPUT_DIRNAME)
    return parser.parse_args()


def main() -> int:
    apply_aaai_style()
    args = parse_args()
    result_root = Path(args.result_root).resolve()
    output_dir = result_root / args.output_dirname
    ensure_dir(output_dir)

    main_df = load_main_summary(result_root)
    future_df = load_future_summary(result_root)

    figure_files: dict[str, dict[str, str]] = {}
    figure_files["main_rankic_bar"] = plot_main_metric_bars(
        main_df,
        metric="RankIC",
        output_dir=output_dir,
        stem="figure_1_main_rankic_bar",
        ylabel="RankIC",
    )
    figure_files["main_sharpe_bar"] = plot_main_metric_bars(
        main_df,
        metric="Sharpe Ratio",
        output_dir=output_dir,
        stem="figure_2_main_sharpe_bar",
        ylabel="Sharpe Ratio",
    )
    figure_files["main_return_sharpe_scatter"] = plot_main_scatter(main_df, output_dir)
    figure_files["future_hypergraph_vs_identity"] = plot_future_comparison(future_df, output_dir)

    notes_path = build_notes(main_df, future_df, figure_files, output_dir)
    manifest_path = build_manifest(figure_files, notes_path, output_dir)

    print(
        json.dumps(
            {
                "output_dir": str(output_dir),
                "figure_count": len(figure_files),
                "notes_path": str(notes_path),
                "manifest_path": str(manifest_path),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
