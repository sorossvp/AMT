#!/usr/bin/env python3
"""
功能概述：
1. 重新绘制 AAAI V2 论文中使用的两张核心结构图：
   - AMT 总体结构图（修正版，解决文字溢出与盒子拥挤问题）
   - 静态市场超图结构示意图（与总图保持同一视觉风格）
2. 同时输出：
   - 论文可直接引用的 PNG 图片
   - 可编辑的 PPTX 源文件（双页幻灯片，每页一张图）
3. 生成的图统一采用“浅灰底 + 圆角容器 + 低饱和学术配色 + 中粗标题”的 AAAI 风格，
   方便后续直接用于论文正文、答辩材料和二次编辑。

代码逻辑与结构：
1. 先定义统一的颜色、字体、尺寸和坐标映射规则，确保两张图风格一致。
2. 使用 Pillow 绘制 PNG：
   - 负责圆角框、文本、箭头和底部说明条的栅格图生成。
3. 使用 python-pptx 绘制 PPTX：
   - 负责将同样的结构落成可编辑的 PowerPoint 形状对象，而不是单纯贴图。
4. 两张图共用一套样式工具函数：
   - 画圆角框
   - 画箭头
   - 写居中文本 / 左对齐文本
   - 画阶段容器
5. 输出文件统一写入 `paper/AAAI V2/assets/` 与其子目录 `editable/`。

说明：
1. 本脚本不依赖浏览器绘图环境，适合在当前 Linux + LibreOffice / python-pptx 环境下稳定执行。
2. 若后续只需微调文案或位置，建议直接修改本脚本中的 figure spec 后重新运行，
   以保证 PNG 与 PPTX 持续一致。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Inches, Pt


ROOT = Path("/data/zhoutm/exp2")
ASSET_DIR = ROOT / "paper" / "AAAI V2" / "assets"
EDITABLE_DIR = ASSET_DIR / "editable"

ARCH_PNG = ASSET_DIR / "amt_architecture_aaai.png"
HYPER_PNG = ASSET_DIR / "amt_static_hypergraph_aaai.png"
PPT_PATH = EDITABLE_DIR / "amt_structure_figures_editable.pptx"

CANVAS_W = 1800
CANVAS_H = 1080
SLIDE_W_IN = 13.333
SLIDE_H_IN = 8.0


COLORS = {
    "bg": "#F5F7FA",
    "frame": "#CCD5DF",
    "title": "#1F2937",
    "subtitle": "#475569",
    "text": "#334155",
    "muted": "#64748B",
    "arrow": "#475569",
    "blue_fill": "#EAF3FF",
    "blue_border": "#5AA0F5",
    "blue_node": "#DCEBFF",
    "blue_strong": "#2F6FD6",
    "red_fill": "#FFF1F1",
    "red_border": "#F07B7B",
    "purple_fill": "#EFEAFE",
    "purple_border": "#8B5CF6",
    "green_fill": "#ECF8D8",
    "green_border": "#7BAE28",
    "orange_fill": "#FFF0DF",
    "orange_border": "#ED8A2A",
    "yellow_fill": "#FFF6D8",
    "yellow_border": "#E6B325",
    "slate_fill": "#E5ECF3",
    "slate_border": "#74839A",
}


def hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i : i + 2], 16) for i in (0, 2, 4))


def rgb(hex_color: str) -> RGBColor:
    return RGBColor(*hex_to_rgb(hex_color))


def font_regular(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size=size)


def font_bold(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", size=size)


@dataclass
class BoxSpec:
    x: int
    y: int
    w: int
    h: int
    fill: str
    border: str
    title: list[str]
    body: list[str]
    title_size: int = 18
    body_size: int = 15
    radius: int = 22


def draw_round_rect(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], fill: str, border: str, radius: int = 24, width: int = 3) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=hex_to_rgb(fill), outline=hex_to_rgb(border), width=width)


def draw_multiline_center(draw: ImageDraw.ImageDraw, cx: int, y_top: int, lines: Iterable[str], size: int, fill: str, bold: bool = False, line_gap: int = 8) -> int:
    font = font_bold(size) if bold else font_regular(size)
    current_y = y_top
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        draw.text((cx, current_y), line, font=font, fill=hex_to_rgb(fill), anchor="ma")
        current_y += (bbox[3] - bbox[1]) + line_gap
    return current_y


def draw_multiline_left(draw: ImageDraw.ImageDraw, x: int, y_top: int, lines: Iterable[str], size: int, fill: str, bold: bool = False, line_gap: int = 7) -> int:
    font = font_bold(size) if bold else font_regular(size)
    current_y = y_top
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        draw.text((x, current_y), line, font=font, fill=hex_to_rgb(fill), anchor="la")
        current_y += (bbox[3] - bbox[1]) + line_gap
    return current_y


def draw_arrow(draw: ImageDraw.ImageDraw, start: tuple[int, int], end: tuple[int, int], width: int = 4, color: str = COLORS["arrow"]) -> None:
    draw.line([start, end], fill=hex_to_rgb(color), width=width)
    ex, ey = end
    sx, sy = start
    if abs(ex - sx) >= abs(ey - sy):
        direction = 1 if ex >= sx else -1
        p1 = (ex - 18 * direction, ey - 10)
        p2 = (ex - 18 * direction, ey + 10)
    else:
        direction = 1 if ey >= sy else -1
        p1 = (ex - 10, ey - 18 * direction)
        p2 = (ex + 10, ey - 18 * direction)
    draw.polygon([end, p1, p2], fill=hex_to_rgb(color))


def draw_box(draw: ImageDraw.ImageDraw, spec: BoxSpec) -> None:
    draw_round_rect(draw, (spec.x, spec.y, spec.x + spec.w, spec.y + spec.h), fill=spec.fill, border=spec.border, radius=spec.radius, width=3)
    next_y = draw_multiline_center(draw, spec.x + spec.w // 2, spec.y + 18, spec.title, size=spec.title_size, fill=COLORS["title"], bold=True, line_gap=6)
    draw_multiline_center(draw, spec.x + spec.w // 2, next_y + 6, spec.body, size=spec.body_size, fill=COLORS["text"], bold=False, line_gap=5)


def add_textbox(slide, x, y, w, h, lines: list[str], font_size: int, color_hex: str, bold: bool = False, center: bool = True) -> None:
    tx = slide.shapes.add_textbox(x, y, w, h)
    tf = tx.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    for idx, line in enumerate(lines):
        p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        p.text = line
        p.font.size = Pt(font_size)
        p.font.bold = bold
        p.font.name = "Arial"
        p.font.color.rgb = rgb(color_hex)
        p.alignment = PP_ALIGN.CENTER if center else PP_ALIGN.LEFT


def px_to_in(value: int, total_px: int, total_in: float) -> float:
    return value / total_px * total_in


def add_round_rect(slide, x: int, y: int, w: int, h: int, fill: str, border: str, radius_adjust=False):
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        Inches(px_to_in(x, CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(y, CANVAS_H, SLIDE_H_IN)),
        Inches(px_to_in(w, CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(h, CANVAS_H, SLIDE_H_IN)),
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(fill)
    shape.line.color.rgb = rgb(border)
    shape.line.width = Pt(2)
    if radius_adjust:
        shape.adjustments[0] = 0.12
    return shape


def add_arrow(slide, start: tuple[int, int], end: tuple[int, int], color_hex: str = COLORS["arrow"]) -> None:
    line = slide.shapes.add_connector(
        MSO_CONNECTOR.STRAIGHT,
        Inches(px_to_in(start[0], CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(start[1], CANVAS_H, SLIDE_H_IN)),
        Inches(px_to_in(end[0], CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(end[1], CANVAS_H, SLIDE_H_IN)),
    )
    line.line.color.rgb = rgb(color_hex)
    line.line.width = Pt(2.5)
    try:
        line.line.end_arrowhead = True
    except Exception:
        pass


def add_box_ppt(slide, spec: BoxSpec) -> None:
    add_round_rect(slide, spec.x, spec.y, spec.w, spec.h, spec.fill, spec.border, radius_adjust=True)
    add_textbox(
        slide,
        Inches(px_to_in(spec.x + 8, CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(spec.y + 10, CANVAS_H, SLIDE_H_IN)),
        Inches(px_to_in(spec.w - 16, CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(34 * len(spec.title), CANVAS_H, SLIDE_H_IN)),
        spec.title,
        spec.title_size,
        COLORS["title"],
        bold=True,
        center=True,
    )
    add_textbox(
        slide,
        Inches(px_to_in(spec.x + 12, CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(spec.y + 44 + 12 * (len(spec.title) - 1), CANVAS_H, SLIDE_H_IN)),
        Inches(px_to_in(spec.w - 24, CANVAS_W, SLIDE_W_IN)),
        Inches(px_to_in(spec.h - 56, CANVAS_H, SLIDE_H_IN)),
        spec.body,
        spec.body_size,
        COLORS["text"],
        bold=False,
        center=True,
    )


def make_canvas() -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGB", (CANVAS_W, CANVAS_H), hex_to_rgb(COLORS["bg"]))
    draw = ImageDraw.Draw(image)
    draw_round_rect(draw, (18, 18, CANVAS_W - 18, CANVAS_H - 18), fill=COLORS["bg"], border=COLORS["frame"], radius=28, width=3)
    return image, draw


def render_architecture_png() -> None:
    image, draw = make_canvas()

    draw_multiline_center(draw, CANVAS_W // 2, 52, ["AMT: Similarity-Guided Mechanism-Preserving Cross-Market Alpha Transfer"], 30, COLORS["title"], True, 0)
    draw_multiline_center(draw, CANVAS_W // 2, 96, ["Source Pretraining + Market Similarity Assessment + Adaptive Freezing + Local Adaptation"], 18, COLORS["subtitle"], True, 0)

    draw_round_rect(draw, (50, 145, 845, 830), COLORS["blue_fill"], COLORS["blue_border"], radius=28, width=3)
    draw_multiline_center(draw, 447, 172, ["Stage 1: Source-Market Pretraining"], 20, COLORS["title"], True, 0)

    draw_round_rect(draw, (930, 145, 1750, 830), COLORS["red_fill"], COLORS["red_border"], radius=28, width=3)
    draw_multiline_center(draw, 1340, 172, ["Stage 2: Target-Market Adaptive Transfer"], 20, COLORS["title"], True, 0)

    left_inputs = [
        BoxSpec(82, 235, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Temporal Panel"], ["OHLCV + sequence windows"]),
        BoxSpec(82, 365, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Tabular Signals"], ["ret, vol, turnover, alpha stats"]),
        BoxSpec(82, 495, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Hypergraph Concepts"], ["cross-sectional concept exposure"], body_size=14),
        BoxSpec(82, 625, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Formulaic Alpha"], ["factor mechanism features"]),
    ]
    encoders = [
        BoxSpec(355, 235, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Seq Encoder"], ["temporal pattern backbone"]),
        BoxSpec(355, 365, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Tab Encoder"], ["cross-feature context"]),
        BoxSpec(355, 495, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Concept Encoder"], ["relational structure modeling"]),
        BoxSpec(355, 625, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Factor Projector"], ["mechanism-space projection"]),
    ]
    for spec in left_inputs + encoders:
        draw_box(draw, spec)

    fused = BoxSpec(608, 350, 190, 124, COLORS["blue_node"], COLORS["blue_strong"], ["Fused Mechanism", "Representation"], ["common_repr + factor_repr", "+ context"], title_size=17, body_size=15)
    base = BoxSpec(608, 528, 190, 118, COLORS["blue_node"], COLORS["blue_strong"], ["Base Scoring Module"], ["shared representation to", "source-domain alpha score"], title_size=17, body_size=15)
    draw_box(draw, fused)
    draw_box(draw, base)

    draw_round_rect(draw, (292, 745, 795, 803), COLORS["slate_fill"], COLORS["blue_strong"], radius=22, width=3)
    draw_multiline_center(draw, 544, 768, ["Source Alpha Weight and Strategy Backbone Learned on Source Market"], 18, COLORS["title"], True, 0)

    for y in [281, 411, 541, 671]:
        draw_arrow(draw, (272, y), (355, y))
    draw_arrow(draw, (550, 281), (608, 382))
    draw_arrow(draw, (550, 411), (608, 394))
    draw_arrow(draw, (550, 541), (608, 406))
    draw_arrow(draw, (550, 671), (608, 418))
    draw_arrow(draw, (703, 474), (703, 528))

    similarity = BoxSpec(990, 235, 700, 92, COLORS["purple_fill"], COLORS["purple_border"], ["Market Similarity Assessment"], ["embedding cosine + MMD + CORAL + statistical similarity", "output: final_similarity, threshold source, policy selection"], title_size=18, body_size=15)
    freezing = BoxSpec(980, 375, 305, 188, COLORS["red_fill"], COLORS["red_border"], ["Adaptive Freezing Policy"], ["conservative / selective / broad / full", "freeze backbone when similarity is high", "progressively unfreeze when similarity drops", "policy resolved from threshold and similarity gaps"], title_size=18, body_size=14)
    local = BoxSpec(1320, 375, 318, 220, COLORS["green_fill"], COLORS["green_border"], ["Trainable Local Adaptation"], ["Att Query / Att Key", "Adapter", "Regime Embedding", "group-wise learning-rate multipliers", "small-capacity target-domain calibration"], title_size=18, body_size=14)
    target = BoxSpec(1085, 620, 500, 116, COLORS["orange_fill"], COLORS["orange_border"], ["Target Alpha Weight = Source Weight + Sparse Delta"], ["top-r gating and adapters update only a few alpha blocks", "while the strategy backbone is kept or selectively relaxed"], title_size=17, body_size=14)
    loss1 = BoxSpec(1010, 775, 165, 90, COLORS["bg"], COLORS["orange_border"], ["Supervised Loss"], ["L_sup"], title_size=17, body_size=16)
    loss2 = BoxSpec(1258, 775, 165, 90, COLORS["bg"], COLORS["orange_border"], ["Parameter Shift"], ["L_param"], title_size=17, body_size=16)
    loss3 = BoxSpec(1505, 775, 165, 90, COLORS["bg"], COLORS["orange_border"], ["Mechanism Shift"], ["L_mech"], title_size=17, body_size=16)
    for spec in [similarity, freezing, local, target, loss1, loss2, loss3]:
        draw_box(draw, spec)

    draw_arrow(draw, (1340, 327), (1340, 375))
    draw_arrow(draw, (1285, 470), (1320, 470))
    draw_arrow(draw, (1132, 563), (1132, 620))
    draw_arrow(draw, (1480, 595), (1480, 620))
    draw_arrow(draw, (1335, 736), (1335, 775))
    draw_arrow(draw, (1335, 736), (1092, 775))
    draw_arrow(draw, (1335, 736), (1588, 775))

    draw_round_rect(draw, (428, 945, 944 + 428, 1024), COLORS["slate_fill"], COLORS["slate_border"], radius=22, width=3)
    draw_multiline_center(draw, CANVAS_W // 2, 968, ["Output: Cross-Market Alpha Score with Auditable Mechanism Preservation"], 19, COLORS["title"], True, 0)
    draw_multiline_center(draw, CANVAS_W // 2, 1002, ["AMT transfers the same strategy semantics, with freezing strength conditioned on market similarity"], 16, COLORS["text"], False, 0)

    draw_arrow(draw, (795, 774), (930, 774))
    draw_arrow(draw, (1335, 865), (1335, 945))

    legend_y = 865
    draw_multiline_left(draw, 96, legend_y, [
        "Blue blocks: source-market representation learning",
        "Purple block: market similarity assessment and thresholding",
        "Red block: similarity-driven adaptive freezing policy",
        "Green block: trainable local adaptation and learning-rate groups",
        "Orange blocks: controlled target-domain transfer constraints",
    ], 14, COLORS["muted"], False, 6)

    ARCH_PNG.parent.mkdir(parents=True, exist_ok=True)
    image.save(ARCH_PNG)


def render_hypergraph_png() -> None:
    image, draw = make_canvas()

    draw_multiline_center(draw, CANVAS_W // 2, 52, ["Static Market Hypergraph Used by AMT"], 30, COLORS["title"], True, 0)
    draw_multiline_center(draw, CANVAS_W // 2, 96, ["Base concept incidence + training-period stable statistics -> static incidence matrix -> concept exposure vector"], 18, COLORS["subtitle"], True, 0)

    draw_round_rect(draw, (55, 155, 560, 830), COLORS["blue_fill"], COLORS["blue_border"], radius=28, width=3)
    draw_multiline_center(draw, 308, 182, ["Stage 1: Node Layer and Stable Market Statistics"], 20, COLORS["title"], True, 0)

    left_boxes = [
        BoxSpec(90, 255, 190, 96, COLORS["bg"], COLORS["blue_border"], ["Tradable Universe"], ["stock symbols aligned", "to the market panel"], title_size=18, body_size=15),
        BoxSpec(90, 395, 190, 96, COLORS["bg"], COLORS["blue_border"], ["Training Window"], ["train_start to train_end", "used for stable statistics"], title_size=18, body_size=15),
        BoxSpec(305, 255, 210, 96, COLORS["blue_node"], COLORS["blue_strong"], ["Base Concept Edges"], ["industry / theme / relation", "loaded from concept incidence"], title_size=18, body_size=15),
        BoxSpec(305, 395, 210, 148, COLORS["blue_node"], COLORS["blue_strong"], ["Style Bucket Edges"], ["liquidity_bucket", "vol_bucket", "price_bucket", "momentum_bucket"], title_size=18, body_size=15),
        BoxSpec(125, 610, 340, 98, COLORS["slate_fill"], COLORS["blue_strong"], ["Node examples"], ["AAPL / NVDA / MSFT / TSLA", "600519 / 000858 / 300750 / 601318"], title_size=18, body_size=15),
    ]
    for spec in left_boxes:
        draw_box(draw, spec)
    draw_arrow(draw, (280, 303), (305, 303))
    draw_arrow(draw, (280, 443), (305, 443))

    draw_round_rect(draw, (630, 155, 1145, 830), COLORS["purple_fill"], COLORS["purple_border"], radius=28, width=3)
    draw_multiline_center(draw, 888, 182, ["Stage 2: Static Hypergraph Construction"], 20, COLORS["title"], True, 0)

    mid_boxes = [
        BoxSpec(675, 255, 425, 120, COLORS["purple_fill"], COLORS["purple_border"], ["Merged Hyperedge Families"], ["base concept incidence from cn/us_concept_hypergraph", "plus style-bucket hyperedges built from stable market statistics"], title_size=18, body_size=15),
        BoxSpec(675, 425, 425, 165, COLORS["yellow_fill"], COLORS["yellow_border"], ["Static Hypergraph Incidence Matrix H"], ["rows = symbols", "columns = concept edges + style-bucket edges", "H[i, e] = 1 means stock i belongs to hyperedge e"], title_size=18, body_size=15),
        BoxSpec(675, 635, 425, 105, COLORS["orange_fill"], COLORS["orange_border"], ["Why static instead of dynamic?"], ["keep a stable structural prior while avoiding per-day hypergraph rebuild"], title_size=18, body_size=15),
    ]
    for spec in mid_boxes:
        draw_box(draw, spec)
    draw_arrow(draw, (560, 430), (675, 430))
    draw_arrow(draw, (887, 375), (887, 425))
    draw_arrow(draw, (887, 590), (887, 635))

    draw_round_rect(draw, (1210, 155, 1745, 830), COLORS["green_fill"], COLORS["green_border"], radius=28, width=3)
    draw_multiline_center(draw, 1477, 182, ["Stage 3: Concept Exposure Used by the Model"], 20, COLORS["title"], True, 0)

    right_boxes = [
        BoxSpec(1255, 255, 445, 130, COLORS["green_fill"], COLORS["green_border"], ["Concept Exposure Vector", "x^{concept}_{i,t}"], ["each stock reads one aligned row from H", "then passes it to the Concept Encoder"], title_size=18, body_size=15),
        BoxSpec(1255, 440, 445, 145, COLORS["bg"], COLORS["green_border"], ["Model-side meaning"], ["this vector is not a raw price feature", "it is a structural membership summary", "for cross-sectional relational context"], title_size=18, body_size=15),
        BoxSpec(1255, 640, 445, 115, COLORS["slate_fill"], COLORS["green_border"], ["Resulting role in AMT"], ["hypergraph structure becomes a stable relational prior", "inside the fused mechanism representation"], title_size=18, body_size=15),
    ]
    for spec in right_boxes:
        draw_box(draw, spec)
    draw_arrow(draw, (1100, 505), (1255, 505))
    draw_arrow(draw, (1477, 385), (1477, 440))
    draw_arrow(draw, (1477, 585), (1477, 640))

    draw_round_rect(draw, (360, 930, 1440, 1018), COLORS["slate_fill"], COLORS["slate_border"], radius=22, width=3)
    draw_multiline_center(draw, CANVAS_W // 2, 957, ["Takeaway: AMT uses a static market hypergraph composed of concept edges and stable style buckets"], 18, COLORS["title"], True, 0)
    draw_multiline_center(draw, CANVAS_W // 2, 992, ["The aligned incidence row becomes the concept exposure vector that feeds the Concept Encoder and the fused mechanism representation"], 16, COLORS["text"], False, 0)

    draw_multiline_left(draw, 92, 860, [
        "Code anchor: data_pipeline.py::build_static_hypergraph()",
        "Stable buckets come from avg_dollar_volume / avg_volatility / avg_price / avg_momentum",
        "Base concept incidence is loaded from cn/us concept-hypergraph assets when available",
    ], 14, COLORS["muted"], False, 6)

    HYPER_PNG.parent.mkdir(parents=True, exist_ok=True)
    image.save(HYPER_PNG)


def build_ppt() -> None:
    prs = Presentation()
    prs.slide_width = Inches(SLIDE_W_IN)
    prs.slide_height = Inches(SLIDE_H_IN)

    blank = prs.slide_layouts[6]

    # Slide 1: architecture
    slide = prs.slides.add_slide(blank)
    add_round_rect(slide, 18, 18, CANVAS_W - 36, CANVAS_H - 36, COLORS["bg"], COLORS["frame"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(70, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(40, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(1660, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(40, CANVAS_H, SLIDE_H_IN)), ["AMT: Similarity-Guided Mechanism-Preserving Cross-Market Alpha Transfer"], 22, COLORS["title"], True, True)
    add_textbox(slide, Inches(px_to_in(180, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(78, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(1440, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(30, CANVAS_H, SLIDE_H_IN)), ["Source Pretraining + Market Similarity Assessment + Adaptive Freezing + Local Adaptation"], 13, COLORS["subtitle"], True, True)

    add_round_rect(slide, 50, 145, 795, 685, COLORS["blue_fill"], COLORS["blue_border"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(205, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(160, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(480, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(30, CANVAS_H, SLIDE_H_IN)), ["Stage 1: Source-Market Pretraining"], 15, COLORS["title"], True, True)

    add_round_rect(slide, 930, 145, 820, 685, COLORS["red_fill"], COLORS["red_border"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(1145, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(160, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(390, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(30, CANVAS_H, SLIDE_H_IN)), ["Stage 2: Target-Market Adaptive Transfer"], 15, COLORS["title"], True, True)

    arch_boxes = [
        BoxSpec(82, 235, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Temporal Panel"], ["OHLCV + sequence windows"]),
        BoxSpec(82, 365, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Tabular Signals"], ["ret, vol, turnover, alpha stats"]),
        BoxSpec(82, 495, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Hypergraph Concepts"], ["cross-sectional concept exposure"], body_size=12),
        BoxSpec(82, 625, 190, 92, COLORS["bg"], COLORS["blue_border"], ["Formulaic Alpha"], ["factor mechanism features"]),
        BoxSpec(355, 235, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Seq Encoder"], ["temporal pattern backbone"]),
        BoxSpec(355, 365, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Tab Encoder"], ["cross-feature context"]),
        BoxSpec(355, 495, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Concept Encoder"], ["relational structure modeling"]),
        BoxSpec(355, 625, 195, 92, COLORS["blue_node"], COLORS["blue_strong"], ["Factor Projector"], ["mechanism-space projection"]),
        BoxSpec(608, 350, 190, 124, COLORS["blue_node"], COLORS["blue_strong"], ["Fused Mechanism", "Representation"], ["common_repr + factor_repr", "+ context"], title_size=15, body_size=12),
        BoxSpec(608, 528, 190, 118, COLORS["blue_node"], COLORS["blue_strong"], ["Base Scoring Module"], ["shared representation to", "source-domain alpha score"], title_size=15, body_size=12),
        BoxSpec(980, 375, 305, 188, COLORS["red_fill"], COLORS["red_border"], ["Adaptive Freezing Policy"], ["conservative / selective / broad / full", "freeze backbone when similarity is high", "progressively unfreeze when similarity drops", "policy resolved from threshold and similarity gaps"], title_size=15, body_size=12),
        BoxSpec(1320, 375, 318, 220, COLORS["green_fill"], COLORS["green_border"], ["Trainable Local Adaptation"], ["Att Query / Att Key", "Adapter", "Regime Embedding", "group-wise learning-rate multipliers", "small-capacity target-domain calibration"], title_size=15, body_size=12),
        BoxSpec(1085, 620, 500, 116, COLORS["orange_fill"], COLORS["orange_border"], ["Target Alpha Weight = Source Weight + Sparse Delta"], ["top-r gating and adapters update only a few alpha blocks", "while the strategy backbone is kept or selectively relaxed"], title_size=15, body_size=12),
        BoxSpec(1010, 775, 165, 90, COLORS["bg"], COLORS["orange_border"], ["Supervised Loss"], ["L_sup"], title_size=14, body_size=13),
        BoxSpec(1258, 775, 165, 90, COLORS["bg"], COLORS["orange_border"], ["Parameter Shift"], ["L_param"], title_size=14, body_size=13),
        BoxSpec(1505, 775, 165, 90, COLORS["bg"], COLORS["orange_border"], ["Mechanism Shift"], ["L_mech"], title_size=14, body_size=13),
        BoxSpec(990, 235, 700, 92, COLORS["purple_fill"], COLORS["purple_border"], ["Market Similarity Assessment"], ["embedding cosine + MMD + CORAL + statistical similarity", "output: final_similarity, threshold source, policy selection"], title_size=15, body_size=12),
    ]
    for spec in arch_boxes:
        add_box_ppt(slide, spec)

    add_round_rect(slide, 292, 745, 503, 58, COLORS["slate_fill"], COLORS["blue_strong"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(302, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(758, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(485, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(28, CANVAS_H, SLIDE_H_IN)), ["Source Alpha Weight and Strategy Backbone Learned on Source Market"], 13, COLORS["title"], True, True)
    add_round_rect(slide, 428, 945, 944, 79, COLORS["slate_fill"], COLORS["slate_border"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(450, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(958, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(900, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(24, CANVAS_H, SLIDE_H_IN)), ["Output: Cross-Market Alpha Score with Auditable Mechanism Preservation"], 13, COLORS["title"], True, True)
    add_textbox(slide, Inches(px_to_in(470, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(988, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(860, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(20, CANVAS_H, SLIDE_H_IN)), ["AMT transfers the same strategy semantics, with freezing strength conditioned on market similarity"], 11, COLORS["text"], False, True)
    add_textbox(slide, Inches(px_to_in(92, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(858, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(520, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(70, CANVAS_H, SLIDE_H_IN)), [
        "Blue blocks: source-market representation learning",
        "Purple block: market similarity assessment and thresholding",
        "Red block: similarity-driven adaptive freezing policy",
        "Green block: trainable local adaptation and learning-rate groups",
        "Orange blocks: controlled target-domain transfer constraints",
    ], 10, COLORS["muted"], False, False)

    for y in [281, 411, 541, 671]:
        add_arrow(slide, (272, y), (355, y))
    add_arrow(slide, (550, 281), (608, 382))
    add_arrow(slide, (550, 411), (608, 394))
    add_arrow(slide, (550, 541), (608, 406))
    add_arrow(slide, (550, 671), (608, 418))
    add_arrow(slide, (703, 474), (703, 528))
    add_arrow(slide, (1340, 327), (1340, 375))
    add_arrow(slide, (1285, 470), (1320, 470))
    add_arrow(slide, (1132, 563), (1132, 620))
    add_arrow(slide, (1480, 595), (1480, 620))
    add_arrow(slide, (1335, 736), (1335, 775))
    add_arrow(slide, (1335, 736), (1092, 775))
    add_arrow(slide, (1335, 736), (1588, 775))
    add_arrow(slide, (795, 774), (930, 774))
    add_arrow(slide, (1335, 865), (1335, 945))

    # Slide 2: hypergraph schema
    slide = prs.slides.add_slide(blank)
    add_round_rect(slide, 18, 18, CANVAS_W - 36, CANVAS_H - 36, COLORS["bg"], COLORS["frame"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(330, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(40, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(1140, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(36, CANVAS_H, SLIDE_H_IN)), ["Static Market Hypergraph Used by AMT"], 22, COLORS["title"], True, True)
    add_textbox(slide, Inches(px_to_in(140, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(78, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(1520, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(30, CANVAS_H, SLIDE_H_IN)), ["Base concept incidence + training-period stable statistics -> static incidence matrix -> concept exposure vector"], 13, COLORS["subtitle"], True, True)

    add_round_rect(slide, 55, 155, 505, 675, COLORS["blue_fill"], COLORS["blue_border"], radius_adjust=True)
    add_round_rect(slide, 630, 155, 515, 675, COLORS["purple_fill"], COLORS["purple_border"], radius_adjust=True)
    add_round_rect(slide, 1210, 155, 535, 675, COLORS["green_fill"], COLORS["green_border"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(102, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(168, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(410, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(28, CANVAS_H, SLIDE_H_IN)), ["Stage 1: Node Layer and Stable Market Statistics"], 15, COLORS["title"], True, True)
    add_textbox(slide, Inches(px_to_in(720, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(168, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(340, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(28, CANVAS_H, SLIDE_H_IN)), ["Stage 2: Static Hypergraph Construction"], 15, COLORS["title"], True, True)
    add_textbox(slide, Inches(px_to_in(1260, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(168, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(430, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(28, CANVAS_H, SLIDE_H_IN)), ["Stage 3: Concept Exposure Used by the Model"], 15, COLORS["title"], True, True)

    hyper_boxes = [
        BoxSpec(90, 255, 190, 96, COLORS["bg"], COLORS["blue_border"], ["Tradable Universe"], ["stock symbols aligned", "to the market panel"], title_size=15, body_size=12),
        BoxSpec(90, 395, 190, 96, COLORS["bg"], COLORS["blue_border"], ["Training Window"], ["train_start to train_end", "used for stable statistics"], title_size=15, body_size=12),
        BoxSpec(305, 255, 210, 96, COLORS["blue_node"], COLORS["blue_strong"], ["Base Concept Edges"], ["industry / theme / relation", "loaded from concept incidence"], title_size=15, body_size=12),
        BoxSpec(305, 395, 210, 148, COLORS["blue_node"], COLORS["blue_strong"], ["Style Bucket Edges"], ["liquidity_bucket", "vol_bucket", "price_bucket", "momentum_bucket"], title_size=15, body_size=12),
        BoxSpec(125, 610, 340, 98, COLORS["slate_fill"], COLORS["blue_strong"], ["Node examples"], ["AAPL / NVDA / MSFT / TSLA", "600519 / 000858 / 300750 / 601318"], title_size=15, body_size=12),
        BoxSpec(675, 255, 425, 120, COLORS["purple_fill"], COLORS["purple_border"], ["Merged Hyperedge Families"], ["base concept incidence from cn/us_concept_hypergraph", "plus style-bucket hyperedges built from stable market statistics"], title_size=15, body_size=12),
        BoxSpec(675, 425, 425, 165, COLORS["yellow_fill"], COLORS["yellow_border"], ["Static Hypergraph Incidence Matrix H"], ["rows = symbols", "columns = concept edges + style-bucket edges", "H[i, e] = 1 means stock i belongs to hyperedge e"], title_size=15, body_size=12),
        BoxSpec(675, 635, 425, 105, COLORS["orange_fill"], COLORS["orange_border"], ["Why static instead of dynamic?"], ["keep a stable structural prior while avoiding per-day hypergraph rebuild"], title_size=15, body_size=12),
        BoxSpec(1255, 255, 445, 130, COLORS["green_fill"], COLORS["green_border"], ["Concept Exposure Vector", "x^{concept}_{i,t}"], ["each stock reads one aligned row from H", "then passes it to the Concept Encoder"], title_size=15, body_size=12),
        BoxSpec(1255, 440, 445, 145, COLORS["bg"], COLORS["green_border"], ["Model-side meaning"], ["this vector is not a raw price feature", "it is a structural membership summary", "for cross-sectional relational context"], title_size=15, body_size=12),
        BoxSpec(1255, 640, 445, 115, COLORS["slate_fill"], COLORS["green_border"], ["Resulting role in AMT"], ["hypergraph structure becomes a stable relational prior", "inside the fused mechanism representation"], title_size=15, body_size=12),
    ]
    for spec in hyper_boxes:
        add_box_ppt(slide, spec)

    add_round_rect(slide, 360, 930, 1080, 88, COLORS["slate_fill"], COLORS["slate_border"], radius_adjust=True)
    add_textbox(slide, Inches(px_to_in(388, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(950, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(1030, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(22, CANVAS_H, SLIDE_H_IN)), ["Takeaway: AMT uses a static market hypergraph composed of concept edges and stable style buckets"], 12, COLORS["title"], True, True)
    add_textbox(slide, Inches(px_to_in(390, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(980, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(1020, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(20, CANVAS_H, SLIDE_H_IN)), ["The aligned incidence row becomes the concept exposure vector that feeds the Concept Encoder and the fused mechanism representation"], 11, COLORS["text"], False, True)
    add_textbox(slide, Inches(px_to_in(92, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(858, CANVAS_H, SLIDE_H_IN)), Inches(px_to_in(500, CANVAS_W, SLIDE_W_IN)), Inches(px_to_in(50, CANVAS_H, SLIDE_H_IN)), [
        "Code anchor: data_pipeline.py::build_static_hypergraph()",
        "Stable buckets come from avg_dollar_volume / avg_volatility / avg_price / avg_momentum",
        "Base concept incidence is loaded from cn/us concept-hypergraph assets when available",
    ], 10, COLORS["muted"], False, False)

    add_arrow(slide, (280, 303), (305, 303))
    add_arrow(slide, (280, 443), (305, 443))
    add_arrow(slide, (560, 430), (675, 430))
    add_arrow(slide, (887, 375), (887, 425))
    add_arrow(slide, (887, 590), (887, 635))
    add_arrow(slide, (1100, 505), (1255, 505))
    add_arrow(slide, (1477, 385), (1477, 440))
    add_arrow(slide, (1477, 585), (1477, 640))

    EDITABLE_DIR.mkdir(parents=True, exist_ok=True)
    prs.save(PPT_PATH)


def main() -> None:
    ARCH_PNG.parent.mkdir(parents=True, exist_ok=True)
    EDITABLE_DIR.mkdir(parents=True, exist_ok=True)
    render_architecture_png()
    render_hypergraph_png()
    build_ppt()
    print(f"[OK] Wrote {ARCH_PNG}")
    print(f"[OK] Wrote {HYPER_PNG}")
    print(f"[OK] Wrote {PPT_PATH}")


if __name__ == "__main__":
    main()
