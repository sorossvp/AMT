"""
文件功能:
1. 提供独立的市场相似度计算模块, 用于衡量源域与目标域在“输入分布 + 预训练机理表征”上的接近程度。
2. 根据相似度阈值自动生成目标域自适应迁移策略, 包括冻结范围、学习率倍率和动态阈值更新建议。
3. 为论文与实验复现提供统一的阈值估计、历史阈值更新、策略报告渲染与优化器参数组构造能力。

代码逻辑:
1. 先从原始市场数组提取统计特征向量, 再从源域预训练后的主模型提取样本级预训练表征。
2. 使用余弦相似度、MMD 相似度、CORAL 相似度和统计特征余弦相似度组成综合相似度分数。
3. 再用统一阈值与低相似度分阶规则生成迁移策略:
   - 高相似度: 只开放局部适配层, 保持机理骨架稳定。
   - 低相似度: 逐步放开因子投影、基础打分模块和共享主干, 并给予分组学习率倍率。
4. 训练结束后可把本次相似度与下游结果写入历史文件, 用于长期阈值动态更新。

代码结构:
1. 配置与结果数据类。
2. 相似度特征提取与距离度量。
3. 阈值估计与动态更新。
4. 自适应迁移策略与优化器参数组构造。
5. 报告渲染辅助函数。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Any, TYPE_CHECKING

import numpy as np
import torch

if TYPE_CHECKING:
    from models import MechanismPreservingHypergraphTransferModel, TorchTrainingConfig


class MarketSimilarityError(ValueError):
    """市场相似度模块的输入或计算异常。"""


@dataclass(frozen=True)
class SimilarityMetricWeights:
    embedding_cosine: float = 0.40
    embedding_mmd: float = 0.20
    embedding_coral: float = 0.20
    statistics_cosine: float = 0.20


@dataclass(frozen=True)
class MarketSimilarityConfig:
    sample_size: int = 2048
    batch_size: int = 512
    rbf_gamma: float = 0.50
    metric_weights: SimilarityMetricWeights = SimilarityMetricWeights()


@dataclass(frozen=True)
class ThresholdUpdateConfig:
    base_threshold: float = 0.70
    update_method: str = "ema_quantile"
    quantile: float = 0.65
    ema_decay: float = 0.80
    min_threshold: float = 0.55
    max_threshold: float = 0.90
    min_history_for_supervised: int = 8


@dataclass(frozen=True)
class AdaptationPolicyConfig:
    medium_gap: float = 0.15
    low_gap: float = 0.35


@dataclass(frozen=True)
class MarketSimilarityResult:
    final_similarity: float
    metrics: dict[str, float]
    source_stat_vector_dim: int
    source_embedding_dim: int
    target_embedding_dim: int
    sample_size: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AdaptationPolicy:
    policy_name: str
    description: str
    similarity_score: float
    similarity_threshold: float
    freeze_backbone: bool
    freeze_factor_projector: bool
    freeze_base_scoring_module: bool
    unfreeze_base_scoring_last_layer: bool
    freeze_source_alpha_weight: bool
    backbone_lr_multiplier: float
    factor_lr_multiplier: float
    base_scoring_lr_multiplier: float
    gate_lr_multiplier: float
    adapter_lr_multiplier: float
    regime_lr_multiplier: float
    source_alpha_weight_lr_multiplier: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_adaptation_kwargs(self) -> dict[str, bool]:
        return {
            "freeze_backbone": self.freeze_backbone,
            "freeze_factor_projector": self.freeze_factor_projector,
            "freeze_base_scoring_module": self.freeze_base_scoring_module,
            "unfreeze_base_scoring_last_layer": self.unfreeze_base_scoring_last_layer,
            "freeze_source_alpha_weight": self.freeze_source_alpha_weight,
        }


def _ensure_split_arrays(split_arrays: dict[str, np.ndarray]) -> None:
    required = {"sequence_x", "tabular_x", "concept_x", "regime_x", "alpha_x"}
    missing = sorted(required.difference(split_arrays))
    if missing:
        raise MarketSimilarityError(f"市场数组缺少必要字段: {missing}")
    sample_count = int(split_arrays["sequence_x"].shape[0])
    if sample_count <= 0:
        raise MarketSimilarityError("市场数组为空，无法计算相似度")


def _to_numpy_float(array: np.ndarray) -> np.ndarray:
    return np.asarray(array, dtype=np.float32)


def _flatten_feature(array: np.ndarray) -> np.ndarray:
    matrix = _to_numpy_float(array)
    if matrix.ndim < 2:
        return matrix.reshape(-1, 1)
    return matrix.reshape(-1, matrix.shape[-1])


def _mean_std_vector(array: np.ndarray) -> np.ndarray:
    matrix = _flatten_feature(array)
    return np.concatenate([matrix.mean(axis=0), matrix.std(axis=0)], axis=0).astype(np.float32)


def build_market_stat_vector(split_arrays: dict[str, np.ndarray]) -> np.ndarray:
    _ensure_split_arrays(split_arrays)
    regime = np.asarray(split_arrays["regime_x"], dtype=np.int64).reshape(-1)
    regime_hist = np.bincount(np.clip(regime, 0, 3), minlength=4).astype(np.float32)
    regime_hist = regime_hist / max(float(regime_hist.sum()), 1.0)
    parts = [
        _mean_std_vector(split_arrays["sequence_x"]),
        _mean_std_vector(split_arrays["tabular_x"]),
        _mean_std_vector(split_arrays["concept_x"]),
        _mean_std_vector(split_arrays["alpha_x"]),
        regime_hist,
    ]
    return np.concatenate(parts, axis=0).astype(np.float32)


def _normalize_cosine_similarity(source: np.ndarray, target: np.ndarray) -> float:
    source_norm = float(np.linalg.norm(source))
    target_norm = float(np.linalg.norm(target))
    if source_norm <= 1e-12 or target_norm <= 1e-12:
        return 0.5
    cosine = float(np.dot(source, target) / (source_norm * target_norm))
    cosine = max(-1.0, min(1.0, cosine))
    return 0.5 * (cosine + 1.0)


def _sample_rows(matrix: np.ndarray, max_rows: int) -> np.ndarray:
    if matrix.shape[0] <= max_rows:
        return matrix
    rng = np.random.default_rng(42)
    indices = np.sort(rng.choice(matrix.shape[0], size=max_rows, replace=False))
    return matrix[indices]


def _rbf_kernel(x: np.ndarray, y: np.ndarray, gamma: float) -> np.ndarray:
    x_sq = np.sum(x * x, axis=1, keepdims=True)
    y_sq = np.sum(y * y, axis=1, keepdims=True).T
    sq_distance = np.maximum(x_sq + y_sq - 2.0 * np.dot(x, y.T), 0.0)
    return np.exp(-gamma * sq_distance)


def _mmd_similarity(source_embeddings: np.ndarray, target_embeddings: np.ndarray, gamma: float) -> float:
    x = _sample_rows(source_embeddings, max_rows=512)
    y = _sample_rows(target_embeddings, max_rows=512)
    k_xx = _rbf_kernel(x, x, gamma=gamma)
    k_yy = _rbf_kernel(y, y, gamma=gamma)
    k_xy = _rbf_kernel(x, y, gamma=gamma)
    mmd = float(k_xx.mean() + k_yy.mean() - 2.0 * k_xy.mean())
    return 1.0 / (1.0 + max(mmd, 0.0))


def _covariance(matrix: np.ndarray) -> np.ndarray:
    centered = matrix - matrix.mean(axis=0, keepdims=True)
    denom = max(centered.shape[0] - 1, 1)
    return (centered.T @ centered) / float(denom)


def _coral_similarity(source_embeddings: np.ndarray, target_embeddings: np.ndarray) -> float:
    x = _sample_rows(source_embeddings, max_rows=512)
    y = _sample_rows(target_embeddings, max_rows=512)
    source_cov = _covariance(x)
    target_cov = _covariance(y)
    feature_dim = float(source_cov.shape[0])
    coral_distance = float(np.mean((source_cov - target_cov) ** 2) / max(4.0 * feature_dim * feature_dim, 1.0))
    return 1.0 / (1.0 + coral_distance)


def extract_market_embeddings(
    model: "MechanismPreservingHypergraphTransferModel",
    split_arrays: dict[str, np.ndarray],
    device: str,
    config: MarketSimilarityConfig | None = None,
) -> np.ndarray:
    _ensure_split_arrays(split_arrays)
    similarity_config = config or MarketSimilarityConfig()
    sample_count = int(split_arrays["sequence_x"].shape[0])
    limit = min(sample_count, int(similarity_config.sample_size))
    if limit <= 0:
        raise MarketSimilarityError("无可用样本用于提取市场嵌入")
    indices = np.linspace(0, sample_count - 1, num=limit, dtype=int)
    torch_device = torch.device(device)
    model = model.to(torch_device)
    model.eval()
    outputs: list[np.ndarray] = []
    with torch.no_grad():
        for start in range(0, limit, int(similarity_config.batch_size)):
            batch_index = indices[start : start + int(similarity_config.batch_size)]
            sequence_x = torch.as_tensor(split_arrays["sequence_x"][batch_index], dtype=torch.float32, device=torch_device)
            tabular_x = torch.as_tensor(split_arrays["tabular_x"][batch_index], dtype=torch.float32, device=torch_device)
            concept_x = torch.as_tensor(split_arrays["concept_x"][batch_index], dtype=torch.float32, device=torch_device)
            regime_x = torch.as_tensor(split_arrays["regime_x"][batch_index], dtype=torch.int64, device=torch_device)
            alpha_x = torch.as_tensor(split_arrays["alpha_x"][batch_index], dtype=torch.float32, device=torch_device)
            batch_repr = model.encode_similarity_representation(
                sequence_x=sequence_x,
                tabular_x=tabular_x,
                concept_x=concept_x,
                regime_x=regime_x,
                alpha_x=alpha_x,
            )
            outputs.append(batch_repr.detach().cpu().numpy().astype(np.float32))
    if not outputs:
        raise MarketSimilarityError("市场嵌入提取失败，未得到任何批次输出")
    return np.concatenate(outputs, axis=0)


def compute_market_similarity(
    source_arrays: dict[str, np.ndarray],
    target_arrays: dict[str, np.ndarray],
    model: "MechanismPreservingHypergraphTransferModel",
    device: str,
    config: MarketSimilarityConfig | None = None,
) -> MarketSimilarityResult:
    similarity_config = config or MarketSimilarityConfig()
    source_stats = build_market_stat_vector(source_arrays)
    target_stats = build_market_stat_vector(target_arrays)
    source_embeddings = extract_market_embeddings(model, source_arrays, device=device, config=similarity_config)
    target_embeddings = extract_market_embeddings(model, target_arrays, device=device, config=similarity_config)
    metrics = {
        "statistics_cosine": _normalize_cosine_similarity(source_stats, target_stats),
        "embedding_cosine": _normalize_cosine_similarity(source_embeddings.mean(axis=0), target_embeddings.mean(axis=0)),
        "embedding_mmd": _mmd_similarity(source_embeddings, target_embeddings, gamma=float(similarity_config.rbf_gamma)),
        "embedding_coral": _coral_similarity(source_embeddings, target_embeddings),
    }
    weights = {
        "statistics_cosine": float(similarity_config.metric_weights.statistics_cosine),
        "embedding_cosine": float(similarity_config.metric_weights.embedding_cosine),
        "embedding_mmd": float(similarity_config.metric_weights.embedding_mmd),
        "embedding_coral": float(similarity_config.metric_weights.embedding_coral),
    }
    total_weight = sum(weights.values())
    if total_weight <= 0:
        raise MarketSimilarityError("相似度权重配置无效，总权重必须大于 0")
    final_similarity = float(sum(metrics[name] * weights[name] for name in metrics) / total_weight)
    return MarketSimilarityResult(
        final_similarity=final_similarity,
        metrics=metrics,
        source_stat_vector_dim=int(source_stats.shape[0]),
        source_embedding_dim=int(source_embeddings.shape[1]),
        target_embedding_dim=int(target_embeddings.shape[1]),
        sample_size=int(min(source_embeddings.shape[0], target_embeddings.shape[0])),
    )


def estimate_threshold_by_quantile(similarities: list[float], quantile: float) -> float:
    if not similarities:
        raise MarketSimilarityError("无历史相似度样本，无法执行分位数阈值估计")
    return float(np.quantile(np.asarray(similarities, dtype=np.float32), quantile))


def estimate_threshold_by_otsu(similarities: list[float]) -> float:
    if not similarities:
        raise MarketSimilarityError("无历史相似度样本，无法执行 Otsu 阈值估计")
    values = np.clip(np.asarray(similarities, dtype=np.float32), 0.0, 1.0)
    hist, bin_edges = np.histogram(values, bins=64, range=(0.0, 1.0))
    prob = hist.astype(np.float64) / max(float(hist.sum()), 1.0)
    omega = np.cumsum(prob)
    centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])
    mu = np.cumsum(prob * centers)
    mu_total = mu[-1]
    sigma = (mu_total * omega - mu) ** 2 / np.maximum(omega * (1.0 - omega), 1e-12)
    threshold_index = int(np.argmax(sigma))
    return float(centers[threshold_index])


def estimate_threshold_by_supervised_gain(records: list[dict[str, Any]]) -> float:
    valid_records = [
        item
        for item in records
        if item.get("similarity_score") is not None and item.get("supervised_metric") is not None
    ]
    if len(valid_records) < 2:
        raise MarketSimilarityError("监督阈值估计需要至少 2 条带下游指标的历史记录")
    similarities = sorted(float(item["similarity_score"]) for item in valid_records)
    candidate_thresholds = sorted(set(similarities))
    best_threshold = candidate_thresholds[0]
    best_score = float("-inf")
    for threshold in candidate_thresholds:
        high_group = [item for item in valid_records if float(item["similarity_score"]) >= threshold]
        low_group = [item for item in valid_records if float(item["similarity_score"]) < threshold]
        if not high_group or not low_group:
            continue
        high_metric = float(np.mean([float(item["supervised_metric"]) for item in high_group]))
        low_metric = float(np.mean([float(item["supervised_metric"]) for item in low_group]))
        separation = high_metric - low_metric
        balance_penalty = abs(len(high_group) - len(low_group)) / max(len(valid_records), 1)
        objective = separation - 0.05 * balance_penalty
        if objective > best_score:
            best_score = objective
            best_threshold = threshold
    return float(best_threshold)


def _clip_threshold(value: float, config: ThresholdUpdateConfig) -> float:
    return float(np.clip(value, float(config.min_threshold), float(config.max_threshold)))


def load_threshold_history(history_path: Path) -> list[dict[str, Any]]:
    if not history_path.exists():
        return []
    payload = json.loads(history_path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        records = payload.get("records", [])
        if isinstance(records, list):
            return records
    if isinstance(payload, list):
        return payload
    return []


def recommend_similarity_threshold(history_path: Path, config: ThresholdUpdateConfig | None = None) -> dict[str, Any]:
    update_config = config or ThresholdUpdateConfig()
    records = load_threshold_history(history_path)
    if not records:
        return {
            "threshold": float(update_config.base_threshold),
            "history_size": 0,
            "method": "base_threshold",
            "used_supervised_signal": False,
        }
    similarities = [float(item["similarity_score"]) for item in records if item.get("similarity_score") is not None]
    quantile_threshold = estimate_threshold_by_quantile(similarities, quantile=float(update_config.quantile))
    threshold = float(update_config.base_threshold)
    method = "ema_quantile"
    used_supervised_signal = False
    if update_config.update_method == "supervised_gain":
        supervised_records = [item for item in records if item.get("supervised_metric") is not None]
        if len(supervised_records) >= int(update_config.min_history_for_supervised):
            threshold = estimate_threshold_by_supervised_gain(supervised_records)
            method = "supervised_gain"
            used_supervised_signal = True
        else:
            threshold = float(update_config.ema_decay) * float(update_config.base_threshold) + (1.0 - float(update_config.ema_decay)) * quantile_threshold
    else:
        threshold = float(update_config.ema_decay) * float(update_config.base_threshold) + (1.0 - float(update_config.ema_decay)) * quantile_threshold
    threshold = _clip_threshold(threshold, update_config)
    return {
        "threshold": threshold,
        "history_size": len(records),
        "method": method,
        "used_supervised_signal": used_supervised_signal,
        "quantile_threshold": _clip_threshold(quantile_threshold, update_config),
        "otsu_threshold": _clip_threshold(estimate_threshold_by_otsu(similarities), update_config),
    }


def update_threshold_history(
    history_path: Path,
    record: dict[str, Any],
    config: ThresholdUpdateConfig | None = None,
) -> dict[str, Any]:
    update_config = config or ThresholdUpdateConfig()
    records = load_threshold_history(history_path)
    records.append(record)
    history_path.parent.mkdir(parents=True, exist_ok=True)
    similarities = [float(item["similarity_score"]) for item in records if item.get("similarity_score") is not None]
    quantile_threshold = estimate_threshold_by_quantile(similarities, quantile=float(update_config.quantile)) if similarities else float(update_config.base_threshold)
    recommendation = {
        "threshold": _clip_threshold(
            float(update_config.ema_decay) * float(update_config.base_threshold) + (1.0 - float(update_config.ema_decay)) * quantile_threshold,
            update_config,
        ),
        "history_size": len(records),
        "method": "ema_quantile" if similarities else "base_threshold",
        "used_supervised_signal": False,
        "quantile_threshold": _clip_threshold(quantile_threshold, update_config),
        "otsu_threshold": _clip_threshold(estimate_threshold_by_otsu(similarities), update_config) if similarities else float(update_config.base_threshold),
    }
    supervised_records = [item for item in records if item.get("supervised_metric") is not None]
    if update_config.update_method == "supervised_gain" and len(supervised_records) >= int(update_config.min_history_for_supervised):
        recommendation["threshold"] = _clip_threshold(estimate_threshold_by_supervised_gain(supervised_records), update_config)
        recommendation["method"] = "supervised_gain"
        recommendation["used_supervised_signal"] = True
    history_path.write_text(
        json.dumps(
            {
                "config": asdict(update_config),
                "records": records,
                "latest_recommendation": recommendation,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return recommendation


def resolve_adaptation_policy(
    similarity_score: float,
    similarity_threshold: float,
    config: AdaptationPolicyConfig | None = None,
) -> AdaptationPolicy:
    policy_config = config or AdaptationPolicyConfig()
    medium_cutoff = max(0.0, float(similarity_threshold) - float(policy_config.medium_gap))
    low_cutoff = max(0.0, float(similarity_threshold) - float(policy_config.low_gap))
    if similarity_score >= similarity_threshold:
        return AdaptationPolicy(
            policy_name="conservative_finetune",
            description="高相似度场景，仅开放门控、适配器与市场状态嵌入，最大限度保留源域通用机理。",
            similarity_score=float(similarity_score),
            similarity_threshold=float(similarity_threshold),
            freeze_backbone=True,
            freeze_factor_projector=True,
            freeze_base_scoring_module=True,
            unfreeze_base_scoring_last_layer=False,
            freeze_source_alpha_weight=True,
            backbone_lr_multiplier=0.0,
            factor_lr_multiplier=0.0,
            base_scoring_lr_multiplier=0.0,
            gate_lr_multiplier=1.0,
            adapter_lr_multiplier=1.0,
            regime_lr_multiplier=0.8,
            source_alpha_weight_lr_multiplier=0.0,
        )
    if similarity_score >= medium_cutoff:
        return AdaptationPolicy(
            policy_name="selective_unfreeze",
            description="中低相似度场景，解冻因子投影与基础打分模块最后一层，在不动共享主干的前提下允许局部重标定。",
            similarity_score=float(similarity_score),
            similarity_threshold=float(similarity_threshold),
            freeze_backbone=True,
            freeze_factor_projector=False,
            freeze_base_scoring_module=True,
            unfreeze_base_scoring_last_layer=True,
            freeze_source_alpha_weight=True,
            backbone_lr_multiplier=0.0,
            factor_lr_multiplier=0.35,
            base_scoring_lr_multiplier=0.50,
            gate_lr_multiplier=1.0,
            adapter_lr_multiplier=1.0,
            regime_lr_multiplier=0.9,
            source_alpha_weight_lr_multiplier=0.0,
        )
    if similarity_score >= low_cutoff:
        return AdaptationPolicy(
            policy_name="broad_unfreeze",
            description="低相似度场景，放开共享主干、因子投影与基础打分模块最后一层，用较小学习率做更广泛适配。",
            similarity_score=float(similarity_score),
            similarity_threshold=float(similarity_threshold),
            freeze_backbone=False,
            freeze_factor_projector=False,
            freeze_base_scoring_module=True,
            unfreeze_base_scoring_last_layer=True,
            freeze_source_alpha_weight=True,
            backbone_lr_multiplier=0.20,
            factor_lr_multiplier=0.35,
            base_scoring_lr_multiplier=0.50,
            gate_lr_multiplier=1.0,
            adapter_lr_multiplier=1.0,
            regime_lr_multiplier=1.0,
            source_alpha_weight_lr_multiplier=0.0,
        )
    return AdaptationPolicy(
        policy_name="full_adaptation",
        description="极低相似度场景，允许全量层参与适配，仅通过分组学习率倍率保留轻量稳定约束。",
        similarity_score=float(similarity_score),
        similarity_threshold=float(similarity_threshold),
        freeze_backbone=False,
        freeze_factor_projector=False,
        freeze_base_scoring_module=False,
        unfreeze_base_scoring_last_layer=False,
        freeze_source_alpha_weight=False,
        backbone_lr_multiplier=0.35,
        factor_lr_multiplier=0.50,
        base_scoring_lr_multiplier=0.60,
        gate_lr_multiplier=1.0,
        adapter_lr_multiplier=1.0,
        regime_lr_multiplier=1.0,
        source_alpha_weight_lr_multiplier=0.15,
    )


def _resolve_param_group_name(parameter_name: str) -> str:
    if parameter_name.startswith(("seq_encoder.", "tab_encoder.", "concept_encoder.")):
        return "backbone"
    if parameter_name.startswith(("alpha_input_norm.", "factor_projector.")):
        return "factor_projector"
    if parameter_name.startswith("base_head."):
        return "base_scoring"
    if parameter_name.startswith("regime_embedding."):
        return "regime"
    if parameter_name.startswith(("att_query", "att_key.")):
        return "gate"
    if parameter_name.startswith("adapter."):
        return "adapter"
    if parameter_name.startswith("source_alpha_weight"):
        return "source_alpha_weight"
    return "other"


def _resolve_group_multiplier(policy: AdaptationPolicy, group_name: str) -> float:
    multiplier_map = {
        "backbone": policy.backbone_lr_multiplier,
        "factor_projector": policy.factor_lr_multiplier,
        "base_scoring": policy.base_scoring_lr_multiplier,
        "regime": policy.regime_lr_multiplier,
        "gate": policy.gate_lr_multiplier,
        "adapter": policy.adapter_lr_multiplier,
        "source_alpha_weight": policy.source_alpha_weight_lr_multiplier,
        "other": 0.0,
    }
    return float(multiplier_map[group_name])


def collect_optimizer_group_summary(
    model: "MechanismPreservingHypergraphTransferModel",
    base_lr: float,
    policy: AdaptationPolicy,
) -> list[dict[str, Any]]:
    summary: dict[str, dict[str, Any]] = {}
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        group_name = _resolve_param_group_name(name)
        multiplier = _resolve_group_multiplier(policy, group_name)
        if multiplier <= 0:
            continue
        entry = summary.setdefault(
            group_name,
            {
                "group_name": group_name,
                "lr": float(base_lr) * multiplier,
                "lr_multiplier": multiplier,
                "parameter_names": [],
                "parameter_count": 0,
            },
        )
        entry["parameter_names"].append(name)
        entry["parameter_count"] += int(parameter.numel())
    return list(summary.values())


def build_adaptation_param_groups(
    model: "MechanismPreservingHypergraphTransferModel",
    config: "TorchTrainingConfig",
    policy: AdaptationPolicy,
) -> list[dict[str, Any]]:
    groups: list[dict[str, Any]] = []
    grouped_params: dict[str, list[torch.nn.Parameter]] = {}
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        group_name = _resolve_param_group_name(name)
        multiplier = _resolve_group_multiplier(policy, group_name)
        if multiplier <= 0:
            continue
        grouped_params.setdefault(group_name, []).append(parameter)
    for group_name, params in grouped_params.items():
        groups.append(
            {
                "params": params,
                "lr": float(config.lr) * _resolve_group_multiplier(policy, group_name),
                "weight_decay": float(config.weight_decay),
            }
        )
    if not groups:
        raise MarketSimilarityError("当前策略未生成任何可训练参数组，请检查冻结策略配置")
    return groups


def render_similarity_report_markdown(
    source_market: str,
    target_market: str,
    similarity_result: MarketSimilarityResult,
    threshold_summary: dict[str, Any],
    policy: AdaptationPolicy,
    optimizer_groups: list[dict[str, Any]],
) -> str:
    metrics = similarity_result.metrics
    lines = [
        f"# 市场相似度与自适应迁移报告: {source_market}->{target_market}",
        "",
        "## 1. 综合相似度结论",
        "",
        f"- 综合相似度: `{similarity_result.final_similarity:.4f}`",
        f"- 当前阈值: `{float(threshold_summary['threshold']):.4f}`",
        f"- 阈值来源: `{threshold_summary.get('method', 'unknown')}`",
        f"- 选定策略: `{policy.policy_name}`",
        f"- 策略说明: {policy.description}",
        "",
        "## 2. 分项相似度指标",
        "",
        f"- 预训练表征余弦相似度: `{metrics['embedding_cosine']:.4f}`",
        f"- 预训练表征 MMD 相似度: `{metrics['embedding_mmd']:.4f}`",
        f"- 预训练表征 CORAL 相似度: `{metrics['embedding_coral']:.4f}`",
        f"- 市场统计特征余弦相似度: `{metrics['statistics_cosine']:.4f}`",
        "",
        "## 3. 目标域冻结与学习率策略",
        "",
        f"- 冻结共享主干: `{policy.freeze_backbone}`",
        f"- 冻结因子投影: `{policy.freeze_factor_projector}`",
        f"- 冻结基础打分模块: `{policy.freeze_base_scoring_module}`",
        f"- 解冻基础打分模块最后一层: `{policy.unfreeze_base_scoring_last_layer}`",
        f"- 冻结源域 alpha 权重: `{policy.freeze_source_alpha_weight}`",
        "",
        "## 4. 优化器参数组",
        "",
    ]
    if not optimizer_groups:
        lines.append("- 当前无可训练参数组")
    else:
        for group in optimizer_groups:
            lines.append(
                f"- `{group['group_name']}` | lr=`{float(group['lr']):.6g}` | "
                f"倍率=`{float(group['lr_multiplier']):.2f}` | 参数量=`{int(group['parameter_count'])}`"
            )
    lines.extend(
        [
            "",
            "## 5. 解释说明",
            "",
            "- 当综合相似度高于阈值时，策略倾向于保留源域预训练机理，仅允许门控与适配器校准。",
            "- 当综合相似度低于阈值时，策略会分阶放开因子投影、基础打分模块和共享主干，以提升目标域适配自由度。",
        ]
    )
    return "\n".join(lines) + "\n"
