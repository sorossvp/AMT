"""
文件功能:
1. 验证最优 alpha 公式导出模块能否把 `a_A * (A + delta_A) + a_B * (B + delta_B)` 正确格式化为可读公式。
2. 验证最佳公式选择逻辑能否依据验证指标选出最优候选。
3. 通过轻量级合成面板数据, 验证 `alpha_case` 搜索链路能够把最优系数导出为对应公式文本。

代码逻辑:
1. 先用确定性样例检查公式文本格式、展开式和排序等价式。
2. 再用伪造的候选记录检查“验证指标最大”的最佳公式选择是否正确。
3. 最后构造一个小型可复现实验面板, 让真实最优系数在候选集里可辨识, 并验证搜索与导出结果一致。

代码结构:
1. 公式格式化测试。
2. 最佳记录选择测试。
3. 合成数据集成测试。
"""

from __future__ import annotations

import unittest

import numpy as np
import pandas as pd

from alpha_case_transfer import build_case_formula_record, compute_case_signal_affine, find_best_candidate
from alpha_formula_exporter import build_affine_formula_strings, choose_best_formula_record


class TestAlphaFormulaExport(unittest.TestCase):
    def build_synthetic_panel(self) -> pd.DataFrame:
        rows: list[dict[str, object]] = []
        dates = pd.date_range("2024-01-01", periods=18, freq="D")
        symbols = [f"S{i:02d}" for i in range(8)]
        for symbol_idx, symbol in enumerate(symbols):
            base_close = 40.0 + 3.5 * symbol_idx
            base_volume = 1000.0 + 80.0 * symbol_idx
            for date_idx, date_value in enumerate(dates):
                seasonal = np.sin(0.23 * date_idx + 0.41 * symbol_idx)
                cross_sectional = np.cos(0.17 * date_idx - 0.29 * symbol_idx)
                close_value = base_close + 0.9 * date_idx + 1.5 * seasonal + 0.4 * cross_sectional
                volume_value = base_volume + 35.0 * date_idx + 55.0 * np.cos(0.11 * date_idx + 0.19 * symbol_idx)
                rows.append(
                    {
                        "date": date_value,
                        "symbol": symbol,
                        "close": float(close_value),
                        "volume": float(max(volume_value, 1.0)),
                        "future_return": 0.0,
                        "regime": "neutral",
                        "split": "valid",
                    }
                )
        return pd.DataFrame(rows)

    def test_build_affine_formula_strings(self) -> None:
        payload = build_affine_formula_strings(
            a_scale=1.1,
            b_scale=0.9,
            a_offset=0.0,
            b_offset=-0.1,
            include_ranking_equivalent=True,
        )
        self.assertEqual(payload["formula_compact"], "1.1*(A)+0.9*(B-0.1)")
        self.assertEqual(payload["formula_expanded"], "1.1 * A + 0.9 * B - 0.09")
        self.assertEqual(payload["formula_ranking_equivalent"], "1.1 * A + 0.9 * B")
        self.assertAlmostEqual(payload["constant_shift"], -0.09, places=8)

    def test_choose_best_formula_record(self) -> None:
        records = [
            {"method": "candidate_a", "validation_objective": 0.12, "formula_pretty": "1.0 * (A) + 1.0 * (B)"},
            {"method": "candidate_b", "validation_objective": 0.27, "formula_pretty": "1.1 * (A) + 0.9 * (B - 0.1)"},
            {"method": "candidate_c", "validation_objective": 0.19, "formula_pretty": "0.9 * (A + 0.1) + 1.0 * (B)"},
        ]
        best_record = choose_best_formula_record(records, objective_field="validation_objective")
        self.assertEqual(best_record["method"], "candidate_b")

    def test_synthetic_candidate_search_and_formula_export(self) -> None:
        panel_df = self.build_synthetic_panel()
        truth_pred_df = compute_case_signal_affine(
            panel_df,
            w1=3,
            w2=5,
            a_scale=1.15,
            b_scale=0.85,
            a_offset=0.0,
            b_offset=0.0,
            clip_q=1.0,
        )
        truth_scores = truth_pred_df[["date", "symbol", "raw_score"]].rename(columns={"raw_score": "synthetic_label"})
        panel_df = panel_df.merge(truth_scores, on=["date", "symbol"], how="left")
        panel_df["future_return"] = panel_df["synthetic_label"].fillna(0.0)
        panel_df = panel_df.drop(columns=["synthetic_label"])

        candidates = [
            {"w1": 3, "w2": 5, "a_scale": 1.0, "b_scale": 1.0, "a_offset": 0.0, "b_offset": 0.0, "clip_q": 1.0},
            {"w1": 3, "w2": 5, "a_scale": 1.15, "b_scale": 0.85, "a_offset": 0.0, "b_offset": 0.0, "clip_q": 1.0},
            {"w1": 3, "w2": 5, "a_scale": 1.30, "b_scale": 0.70, "a_offset": 0.0, "b_offset": 0.0, "clip_q": 1.0},
        ]

        best_params, best_metrics, _ = find_best_candidate(
            df=panel_df,
            split_name="valid",
            top_k=3,
            candidates=candidates,
        )
        self.assertAlmostEqual(float(best_params["a_scale"]), 1.15, places=8)
        self.assertAlmostEqual(float(best_params["b_scale"]), 0.85, places=8)

        formula_record = build_case_formula_record(
            method_name="synthetic_best",
            params=best_params,
            selection_metrics=best_metrics,
            validation_metrics=best_metrics,
            selection_split="valid",
            validation_split="valid",
        )
        self.assertIn("1.15", formula_record["formula_pretty"])
        self.assertIn("0.85", formula_record["formula_pretty"])
        self.assertGreater(float(formula_record["validation_objective"]), 0.0)


if __name__ == "__main__":
    unittest.main()
