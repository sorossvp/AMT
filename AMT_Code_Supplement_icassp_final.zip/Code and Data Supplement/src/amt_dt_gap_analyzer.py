"""
文件功能说明：
1. 将 multi-alpha 主批次结果与补跑批次结果合并为统一结果表，解决“旧批次已完成大部分 alpha、本轮仅补跑缺失 alpha”的结果分散问题。
2. 面向 `AMT` 与 `Direct Transfer` 的效果差距分析，自动生成结构化 CSV、JSON 与 Markdown 摘要，供论文附录与深度研究报告直接复用。
3. 对结果完整性进行最基本校验，明确每个 alpha、每个方向、每个模型是否齐全，避免把“部分完成”误当成“最终可交付结果”。

代码逻辑说明：
1. 读取指定批次目录下 `主实验/multi_alpha_transfer/alpha_*/all_summary.csv` 的结果表，并补充 `alpha_name`、`batch_name` 等元数据。
2. 以“补跑批次优先覆盖主批次同一 alpha / direction / model 结果”的方式构造统一总表，保证最终表格优先使用最新补跑结果。
3. 基于统一总表抽取 `AMT` 与 `Direct Transfer` 的关键指标，包括 `Annualized Return`、`RankIC`、`Sharpe Ratio`，并计算差值。
4. 同步汇总市场相似度策略报告，统计 `similarity_score / threshold / policy_name`，用于解释 AMT 在实际运行中是否真的触发了差异化冻结策略。
5. 将统一结果、完整性检查、AMT-vs-DT 对比表、策略摘要输出到目标目录，便于后续文档直接引用。

代码结构说明：
1. 路径与参数解析。
2. 批次结果与相似度报告读取。
3. 结果覆盖合并与完整性校验。
4. AMT-vs-DT 指标表构建。
5. CSV / JSON / Markdown 资产写出。
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd


EXPECTED_MODELS = [
    "direct_transfer",
    "amt",
    "lstm_transfer",
    "transformer_transfer",
    "tra_transfer",
    "hist_transfer",
]
EXPECTED_DIRECTIONS = ["CN->US", "US->CN"]


@dataclass(frozen=True)
class BatchLoadResult:
    batch_name: str
    summary_df: pd.DataFrame
    similarity_df: pd.DataFrame


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="合并 multi-alpha 主批次与补跑批次结果，并生成 AMT 与 DT 差距分析资产。")
    parser.add_argument("--base-batch-root", required=True, help="主批次结果根目录，例如 results/full_20260729_015852")
    parser.add_argument("--patch-batch-root", required=True, help="补跑批次结果根目录，例如 results/full_20260731_181543")
    parser.add_argument("--output-dir", required=True, help="分析资产输出目录")
    return parser.parse_args()


def read_csv_if_exists(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


def load_batch(batch_root: Path) -> BatchLoadResult:
    multi_alpha_root = batch_root / "主实验" / "multi_alpha_transfer"
    summary_frames: list[pd.DataFrame] = []
    similarity_rows: list[dict[str, Any]] = []

    for alpha_dir in sorted(multi_alpha_root.glob("alpha_*")):
        if not alpha_dir.is_dir():
            continue
        alpha_name = alpha_dir.name
        alpha_frames: list[pd.DataFrame] = []

        all_summary_path = alpha_dir / "all_summary.csv"
        if all_summary_path.exists():
            alpha_frames.append(pd.read_csv(all_summary_path))
        else:
            for direction_summary_path in sorted(alpha_dir.glob("*_to_*/summary.csv")):
                alpha_frames.append(pd.read_csv(direction_summary_path))

        if not alpha_frames:
            continue
        df = pd.concat(alpha_frames, axis=0, ignore_index=True)
        if df.empty:
            continue
        df = df.drop_duplicates(subset=["direction", "model"], keep="last").copy()
        df["alpha_name"] = alpha_name
        df["batch_name"] = batch_root.name
        summary_frames.append(df)

    for report_path in sorted(multi_alpha_root.glob("alpha_*/**/amt/market_similarity_report.json")):
        payload = json.loads(report_path.read_text(encoding="utf-8"))
        alpha_name = report_path.parents[2].name
        direction_name = report_path.parents[1].name.replace("_to_", "->").upper()
        similarity_result = payload.get("similarity_result", {})
        threshold_summary = payload.get("threshold_summary", {})
        policy = payload.get("adaptation_policy", {})
        similarity_rows.append(
            {
                "alpha_name": alpha_name,
                "direction": direction_name,
                "batch_name": batch_root.name,
                "similarity_score": float(similarity_result.get("final_similarity", 0.0)),
                "threshold": float(threshold_summary.get("threshold", 0.0)),
                "policy_name": str(policy.get("policy_name", "")),
            }
        )

    summary_df = pd.concat(summary_frames, axis=0, ignore_index=True) if summary_frames else pd.DataFrame()
    similarity_df = pd.DataFrame(similarity_rows)
    return BatchLoadResult(batch_name=batch_root.name, summary_df=summary_df, similarity_df=similarity_df)


def merge_batches(base_df: pd.DataFrame, patch_df: pd.DataFrame, key_cols: list[str]) -> pd.DataFrame:
    if base_df.empty:
        return patch_df.copy()
    if patch_df.empty:
        return base_df.copy()

    base_remaining = base_df.merge(
        patch_df[key_cols].drop_duplicates(),
        on=key_cols,
        how="left",
        indicator=True,
    )
    base_remaining = base_remaining.loc[base_remaining["_merge"] == "left_only"].drop(columns="_merge")
    merged = pd.concat([base_remaining, patch_df], axis=0, ignore_index=True)
    sort_cols = [column for column in ["alpha_name", "direction", "model"] if column in merged.columns]
    if sort_cols:
        merged = merged.sort_values(sort_cols).reset_index(drop=True)
    return merged


def build_completeness_table(summary_df: pd.DataFrame) -> pd.DataFrame:
    if summary_df.empty:
        return pd.DataFrame(
            columns=["alpha_name", "direction", "present_models", "missing_models", "is_complete"]
        )

    rows: list[dict[str, Any]] = []
    alpha_names = sorted(summary_df["alpha_name"].dropna().unique().tolist())
    for alpha_name in alpha_names:
        alpha_df = summary_df.loc[summary_df["alpha_name"] == alpha_name]
        for direction in EXPECTED_DIRECTIONS:
            direction_df = alpha_df.loc[alpha_df["direction"] == direction]
            present_models = sorted(direction_df["model"].dropna().unique().tolist())
            missing_models = [item for item in EXPECTED_MODELS if item not in present_models]
            rows.append(
                {
                    "alpha_name": alpha_name,
                    "direction": direction,
                    "present_models": ",".join(present_models),
                    "missing_models": ",".join(missing_models),
                    "is_complete": len(missing_models) == 0,
                }
            )
    return pd.DataFrame(rows)


def build_amt_vs_dt_table(summary_df: pd.DataFrame) -> pd.DataFrame:
    if summary_df.empty:
        return pd.DataFrame()

    target_models = summary_df.loc[summary_df["model"].isin(["amt", "direct_transfer"])].copy()
    pivot = (
        target_models.pivot_table(
            index=["alpha_name", "direction"],
            columns="model",
            values=["Annualized Return", "RankIC", "Sharpe Ratio"],
            aggfunc="first",
        )
        .sort_index()
    )
    pivot.columns = [f"{metric}_{model}" for metric, model in pivot.columns]
    pivot = pivot.reset_index()
    for metric in ["Annualized Return", "RankIC", "Sharpe Ratio"]:
        amt_col = f"{metric}_amt"
        dt_col = f"{metric}_direct_transfer"
        if amt_col in pivot.columns and dt_col in pivot.columns:
            pivot[f"{metric}_amt_minus_dt"] = pivot[amt_col] - pivot[dt_col]
    return pivot


def build_similarity_summary(similarity_df: pd.DataFrame) -> pd.DataFrame:
    if similarity_df.empty:
        return pd.DataFrame()
    grouped = (
        similarity_df.groupby("policy_name", dropna=False)
        .agg(
            task_count=("alpha_name", "count"),
            mean_similarity=("similarity_score", "mean"),
            min_similarity=("similarity_score", "min"),
            max_similarity=("similarity_score", "max"),
            mean_threshold=("threshold", "mean"),
        )
        .reset_index()
        .sort_values(["task_count", "policy_name"], ascending=[False, True])
        .reset_index(drop=True)
    )
    return grouped


def dataframe_to_markdown(df: pd.DataFrame) -> str:
    if df.empty:
        return "_No data._"
    try:
        return df.to_markdown(index=False)
    except ImportError:
        return df.to_string(index=False)


def write_markdown_report(
    output_path: Path,
    base_batch: BatchLoadResult,
    patch_batch: BatchLoadResult,
    merged_df: pd.DataFrame,
    completeness_df: pd.DataFrame,
    amt_dt_df: pd.DataFrame,
    similarity_summary_df: pd.DataFrame,
) -> None:
    complete_count = int(completeness_df["is_complete"].sum()) if not completeness_df.empty else 0
    total_pairs = int(len(completeness_df))
    amt_wins = int((amt_dt_df["Annualized Return_amt_minus_dt"] > 0).sum()) if "Annualized Return_amt_minus_dt" in amt_dt_df.columns else 0
    dt_wins = int((amt_dt_df["Annualized Return_amt_minus_dt"] < 0).sum()) if "Annualized Return_amt_minus_dt" in amt_dt_df.columns else 0

    lines = [
        "# AMT 与 Direct Transfer 差距分析数据资产",
        "",
        "## 1. 数据来源",
        f"- 主批次：`{base_batch.batch_name}`",
        f"- 补跑批次：`{patch_batch.batch_name}`",
        f"- 合并后结果行数：`{len(merged_df)}`",
        "",
        "## 2. 完整性检查",
        f"- 完整 alpha-direction 对数量：`{complete_count} / {total_pairs}`",
        "",
        dataframe_to_markdown(completeness_df),
        "",
        "## 3. AMT vs Direct Transfer",
        f"- `Annualized Return` 维度：AMT 胜出 `{amt_wins}` 次，DT 胜出 `{dt_wins}` 次。",
        "",
        dataframe_to_markdown(amt_dt_df),
        "",
        "## 4. Similarity Policy 摘要",
        dataframe_to_markdown(similarity_summary_df),
        "",
    ]
    output_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    args = parse_args()
    base_batch_root = Path(args.base_batch_root).expanduser().resolve()
    patch_batch_root = Path(args.patch_batch_root).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    base_batch = load_batch(base_batch_root)
    patch_batch = load_batch(patch_batch_root)
    merged_df = merge_batches(
        base_batch.summary_df,
        patch_batch.summary_df,
        key_cols=["alpha_name", "direction", "model"],
    )
    merged_similarity_df = merge_batches(
        base_batch.similarity_df,
        patch_batch.similarity_df,
        key_cols=["alpha_name", "direction"],
    )
    completeness_df = build_completeness_table(merged_df)
    amt_dt_df = build_amt_vs_dt_table(merged_df)
    similarity_summary_df = build_similarity_summary(merged_similarity_df)

    merged_df.to_csv(output_dir / "combined_multi_alpha_summary.csv", index=False, encoding="utf-8-sig")
    completeness_df.to_csv(output_dir / "combined_completeness_check.csv", index=False, encoding="utf-8-sig")
    amt_dt_df.to_csv(output_dir / "amt_vs_dt_table.csv", index=False, encoding="utf-8-sig")
    merged_similarity_df.to_csv(output_dir / "combined_similarity_reports.csv", index=False, encoding="utf-8-sig")
    similarity_summary_df.to_csv(output_dir / "similarity_policy_summary.csv", index=False, encoding="utf-8-sig")

    payload = {
        "base_batch_name": base_batch.batch_name,
        "patch_batch_name": patch_batch.batch_name,
        "combined_row_count": int(len(merged_df)),
        "complete_pair_count": int(completeness_df["is_complete"].sum()) if not completeness_df.empty else 0,
        "total_pair_count": int(len(completeness_df)),
    }
    (output_dir / "analysis_manifest.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_markdown_report(
        output_path=output_dir / "amt_dt_gap_asset_report.md",
        base_batch=base_batch,
        patch_batch=patch_batch,
        merged_df=merged_df,
        completeness_df=completeness_df,
        amt_dt_df=amt_dt_df,
        similarity_summary_df=similarity_summary_df,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
