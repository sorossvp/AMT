"""
文件功能:
1. 优先复用 `DataToSever/processed_data` 中已经准备好的训练缓存;
   如需冷启动重建, 再从 `DataToSever/_workspace_cn_1999_2025_merge_csv`
   与 `DataToSever/_workspace_us_1999_2025_merge_csv` 中提取单票历史数据。
2. 生成论文主实验与对比实验共享的横截面特征、未来收益标签、市场状态标签和静态超图结构。
3. 通过训练期流动性筛选控制股票池规模, 让第一阶段实验能够稳定落地并可复现。
4. 将处理后的中间产物缓存到 `DataToSever/processed_data` 下, 供服务器训练直接复用。

代码逻辑:
1. 先扫描单票 CSV, 依据训练期平均成交额与样本覆盖率筛选流动性股票池。
2. 对每只股票计算收益率、波动率、均线比率、量价交互与公式 alpha 风格特征。
3. 在市场层面计算等权收益与波动, 用训练集分位数切分 `bull/neutral/bear/shock` 状态。
4. 根据训练期稳定风格统计量构造“静态基础超边 + 风格桶”的超图矩阵。
5. 输出面板数据、regime 文件、股票池摘要与超图矩阵, 供主模型和基线复用。

代码结构:
1. 配置与路径定义。
2. 单票数据读取与特征工程。
3. 股票池筛选与市场面板构造。
4. regime 切分与静态超图构造。
5. 缓存与统一入口函数。
"""

from __future__ import annotations

import json
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT_DIR / "results"
PROCESSED_DIR = ROOT_DIR / "DataToSever" / "processed_data"
HGNN_DIR = ROOT_DIR / "HGNNcode"
if str(HGNN_DIR) not in sys.path:
    sys.path.append(str(HGNN_DIR))

# 5 日 future_return 超过 500% 基本只会出现在拆股/反向拆股或极端低价股跳变阶段，
# 会把轻量回测与论文统计直接拉爆。这里将其视为病态标签并在数据层剔除。
MAX_REASONABLE_FUTURE_RETURN = 5.0

MARKET_TO_CSV_DIR_CANDIDATES = {
    "CN": [
        ROOT_DIR / "DataToSever" / "_workspace_cn_1999_2025_merge_csv",
        ROOT_DIR / "DataToSever" / "_workspace_cn_2021_2025_csv",
    ],
    "US": [
        ROOT_DIR / "DataToSever" / "_workspace_us_1999_2025_merge_csv",
        ROOT_DIR / "DataToSever" / "_workspace_us_2021_2025_csv",
    ],
}

MARKET_TO_UNIVERSE_FILE = {
    "CN": ROOT_DIR / "DataToSever" / "cn_index_constituents.csv",
    "US": ROOT_DIR / "DataToSever" / "us_index_constituents.csv",
}


@dataclass
class SplitConfig:
    train_start: str = "2008-01-01"
    train_end: str = "2021-12-31"
    valid_start: str = "2022-01-01"
    valid_end: str = "2022-12-31"
    test_start: str = "2023-01-01"
    test_end: str = "2025-12-31"


@dataclass
class MarketDataConfig:
    market: str
    max_symbols: int = 160
    min_history_days: int = 900
    horizon: int = 5
    use_full_market: bool = False
    split: SplitConfig = field(default_factory=SplitConfig)


@dataclass(frozen=True)
class AlphaParameterRange:
    default: float
    min_value: float
    max_value: float
    step: float
    note: str

    def to_dict(self) -> dict[str, float | str]:
        return asdict(self)


@dataclass(frozen=True)
class AffineAlphaTransformConfig:
    a_scale: float = 1.0
    b_scale: float = 1.0
    a_offset: float = 0.0
    b_offset: float = 0.0


@dataclass(frozen=True)
class AMTAlphaFeatureConfig:
    momentum_lookback: int = 10
    momentum_vol_window: int = 20
    momentum_transform: AffineAlphaTransformConfig = field(default_factory=AffineAlphaTransformConfig)
    reversal_window: int = 5
    reversal_vol_window: int = 20
    reversal_transform: AffineAlphaTransformConfig = field(default_factory=AffineAlphaTransformConfig)
    volume_price_return_window: int = 5
    volume_price_volume_short_window: int = 5
    volume_price_volume_long_window: int = 20
    volume_price_transform: AffineAlphaTransformConfig = field(default_factory=AffineAlphaTransformConfig)
    breakout_window: int = 20
    breakout_transform: AffineAlphaTransformConfig = field(default_factory=AffineAlphaTransformConfig)
    liquidity_short_window: int = 10
    liquidity_long_window: int = 60
    liquidity_transform: AffineAlphaTransformConfig = field(default_factory=AffineAlphaTransformConfig)
    intraday_range_floor: float = 1e-6
    intraday_transform: AffineAlphaTransformConfig = field(default_factory=AffineAlphaTransformConfig)


DEFAULT_AMT_ALPHA_FEATURE_CONFIG = AMTAlphaFeatureConfig()


DEFAULT_AFFINE_RANGE_ENTRIES: dict[str, AlphaParameterRange] = {
    "a_scale": AlphaParameterRange(default=1.0, min_value=0.7, max_value=1.3, step=0.05, note="A 项前置系数局部微调"),
    "b_scale": AlphaParameterRange(default=1.0, min_value=0.7, max_value=1.3, step=0.05, note="B 项前置系数局部微调"),
    "a_offset": AlphaParameterRange(default=0.0, min_value=-0.2, max_value=0.2, step=0.05, note="A 项内偏移量局部微调"),
    "b_offset": AlphaParameterRange(default=0.0, min_value=-0.2, max_value=0.2, step=0.05, note="B 项内偏移量局部微调"),
}


def build_affine_tuning_space(extra_ranges: dict[str, AlphaParameterRange]) -> dict[str, AlphaParameterRange]:
    return {**DEFAULT_AFFINE_RANGE_ENTRIES, **extra_ranges}


AMT_ALPHA_TUNING_SPACE: dict[str, dict[str, AlphaParameterRange]] = {
    "alpha_momentum": build_affine_tuning_space({
        "momentum_lookback": AlphaParameterRange(default=10, min_value=5, max_value=20, step=1, note="控制动量回看周期"),
        "momentum_vol_window": AlphaParameterRange(default=20, min_value=10, max_value=60, step=5, note="控制波动率归一化窗口"),
    }),
    "alpha_reversal": build_affine_tuning_space({
        "reversal_window": AlphaParameterRange(default=5, min_value=3, max_value=15, step=1, note="控制反转均值窗口"),
        "reversal_vol_window": AlphaParameterRange(default=20, min_value=10, max_value=60, step=5, note="控制反转波动归一化窗口"),
    }),
    "alpha_volume_price": build_affine_tuning_space({
        "volume_price_return_window": AlphaParameterRange(default=5, min_value=3, max_value=15, step=1, note="控制价格变化回看长度"),
        "volume_price_volume_short_window": AlphaParameterRange(default=5, min_value=3, max_value=15, step=1, note="控制短期成交量波动窗口"),
        "volume_price_volume_long_window": AlphaParameterRange(default=20, min_value=10, max_value=60, step=5, note="控制长期成交量基准窗口"),
    }),
    "alpha_breakout": build_affine_tuning_space({
        "breakout_window": AlphaParameterRange(default=20, min_value=10, max_value=80, step=5, note="控制突破高点统计窗口"),
    }),
    "alpha_liquidity": build_affine_tuning_space({
        "liquidity_short_window": AlphaParameterRange(default=10, min_value=5, max_value=30, step=1, note="控制短期流动性均值窗口"),
        "liquidity_long_window": AlphaParameterRange(default=60, min_value=20, max_value=120, step=5, note="控制长期流动性均值窗口"),
    }),
    "alpha_intraday": build_affine_tuning_space({
        "intraday_range_floor": AlphaParameterRange(default=1e-6, min_value=1e-8, max_value=1e-4, step=1e-6, note="控制日内振幅分母的稳定项"),
    }),
}


def amt_alpha_tuning_space_to_dict() -> dict[str, dict[str, dict[str, float | str]]]:
    return {
        alpha_name: {
            param_name: spec.to_dict()
            for param_name, spec in param_ranges.items()
        }
        for alpha_name, param_ranges in AMT_ALPHA_TUNING_SPACE.items()
    }


def compose_affine_alpha_signal(
    term_a: pd.Series,
    term_b: pd.Series,
    transform: AffineAlphaTransformConfig | None = None,
) -> pd.Series:
    cfg = transform or AffineAlphaTransformConfig()
    return (
        float(cfg.a_scale) * (pd.to_numeric(term_a, errors="coerce") + float(cfg.a_offset))
        + float(cfg.b_scale) * (pd.to_numeric(term_b, errors="coerce") + float(cfg.b_offset))
    )


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def is_cache_compat_error(exc: BaseException) -> bool:
    text = str(exc)
    return isinstance(exc, ModuleNotFoundError) or "numpy._core.numeric" in text or "pickle" in text.lower()


def install_numpy_pickle_compat() -> None:
    """
    为历史 pickle 中引用的 `numpy._core.*` 提供向后兼容映射。

    背景:
    1. 某些旧环境序列化的 pickle 会把 numpy 内部模块路径记录为 `numpy._core.numeric`；
    2. 在部分新环境中该路径不可直接导入, 会在 `pd.read_pickle()` 时触发 `ModuleNotFoundError`；
    3. 当前服务器上传的是缓存产物而不是原始 CSV, 因此优先做兼容加载比强制重建更稳妥。
    """
    import numpy.core as numpy_core
    import numpy.core.multiarray as numpy_core_multiarray
    import numpy.core.numeric as numpy_core_numeric

    sys.modules.setdefault("numpy._core", numpy_core)
    sys.modules.setdefault("numpy._core.multiarray", numpy_core_multiarray)
    sys.modules.setdefault("numpy._core.numeric", numpy_core_numeric)


def read_pickle_with_recovery(path: Path) -> pd.DataFrame:
    try:
        return pd.read_pickle(path)
    except ModuleNotFoundError as exc:
        if "numpy._core" not in str(exc):
            raise
        install_numpy_pickle_compat()
        return pd.read_pickle(path)


def resolve_market_csv_dir(market: str) -> Path:
    candidates = MARKET_TO_CSV_DIR_CANDIDATES.get(market.upper(), [])
    for candidate in candidates:
        if candidate.exists():
            return candidate
    if candidates:
        return candidates[0]
    raise KeyError(f"未知市场: {market}")


def load_latest_constituent_symbols(market: str) -> set[str]:
    """
    读取“最新可用成分股快照”。

    约定:
    1. 若文件中含 `start_date/end_date`，则取 `end_date` 最大的一批记录作为最新快照；
    2. 若仅有 symbol 列，则直接将其视作最新成分股白名单；
    3. 返回大写 symbol 集合，便于与缓存和 CSV 文件统一匹配。
    """
    universe_file = MARKET_TO_UNIVERSE_FILE.get(market)
    if universe_file is None or not universe_file.exists():
        return set()

    universe_df = pd.read_csv(universe_file)
    if universe_df.empty:
        return set()

    symbol_col = "symbol" if "symbol" in universe_df.columns else universe_df.columns[0]
    work_df = universe_df.copy()
    work_df[symbol_col] = work_df[symbol_col].astype(str).str.upper().str.strip()

    if "end_date" in work_df.columns:
        work_df["end_date"] = pd.to_datetime(work_df["end_date"], errors="coerce")
        latest_end = work_df["end_date"].dropna().max()
        if pd.notna(latest_end):
            work_df = work_df.loc[work_df["end_date"] == latest_end].copy()

    return set(work_df[symbol_col].dropna().astype(str).tolist())


def get_meta_liquidity_column(meta_df: pd.DataFrame) -> str | None:
    for col in ["avg_traded_value", "avg_dollar_volume", "available_days"]:
        if col in meta_df.columns:
            return col
    return None


def resolve_effective_symbol_cap(config: MarketDataConfig, whitelist_size: int) -> int:
    """
    解析当前市场在“最新指数成分股白名单”场景下的实际节点上限。

    设计原则:
    1. A 股主实验继续保持 CSI300 口径，因此仍受 `max_symbols` 控制；
    2. 美股主实验改为保留最近下载的全部 SP500 成分股节点，不再截断到 Top-300；
    3. 若没有白名单，则退回到外部传入的 `max_symbols`。
    """
    if whitelist_size <= 0:
        return config.max_symbols
    if config.market.upper() == "US":
        return whitelist_size
    return min(config.max_symbols, whitelist_size)


def filter_artifacts_by_latest_universe(
    config: MarketDataConfig,
    panel_df: pd.DataFrame,
    meta_df: pd.DataFrame,
    incidence_df: pd.DataFrame,
    symbol_stats_df: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    对冷启动产物或缓存产物做二次股票池过滤，确保“最新 CSI300 / SP500 Top-300”在最终训练中生效。
    """
    latest_symbols: set[str] = set() if config.use_full_market else load_latest_constituent_symbols(config.market)
    if latest_symbols:
        panel_df = panel_df.loc[panel_df["symbol"].isin(latest_symbols)].copy()
        if not meta_df.empty and "symbol" in meta_df.columns:
            meta_df = meta_df.loc[meta_df["symbol"].astype(str).str.upper().isin(latest_symbols)].copy()
        if not symbol_stats_df.empty and "symbol" in symbol_stats_df.columns:
            symbol_stats_df = symbol_stats_df.loc[symbol_stats_df["symbol"].astype(str).str.upper().isin(latest_symbols)].copy()
        if not incidence_df.empty:
            incidence_df = incidence_df.loc[incidence_df.index.astype(str).isin(latest_symbols)].copy()

    liquidity_col = get_meta_liquidity_column(meta_df) if not meta_df.empty else None

    if config.use_full_market:
        ranked_symbols = sorted(panel_df["symbol"].astype(str).str.upper().unique().tolist())
    elif meta_df.empty:
        ranked_symbols = sorted(panel_df["symbol"].astype(str).unique().tolist())
    else:
        effective_cap = resolve_effective_symbol_cap(config, len(latest_symbols))
        if liquidity_col is not None:
            meta_df = meta_df.sort_values(liquidity_col, ascending=False).head(effective_cap).copy()
        else:
            meta_df = meta_df.head(effective_cap).copy()
        ranked_symbols = meta_df["symbol"].astype(str).str.upper().tolist()

    panel_df = panel_df.loc[panel_df["symbol"].isin(ranked_symbols)].copy()
    if not symbol_stats_df.empty and "symbol" in symbol_stats_df.columns:
        symbol_stats_df = symbol_stats_df.loc[symbol_stats_df["symbol"].astype(str).str.upper().isin(ranked_symbols)].copy()
    if not incidence_df.empty:
        incidence_df = incidence_df.loc[incidence_df.index.astype(str).isin(ranked_symbols)].copy()
        incidence_df = incidence_df.reindex(ranked_symbols).fillna(0.0)

    panel_df = panel_df.sort_values(["date", "symbol"]).reset_index(drop=True)
    if not meta_df.empty:
        meta_df = meta_df.reset_index(drop=True)
    if not symbol_stats_df.empty and "symbol" in symbol_stats_df.columns:
        symbol_stats_df = symbol_stats_df.sort_values("symbol").reset_index(drop=True)
    return panel_df, meta_df, incidence_df, symbol_stats_df


def prepare_future_market_artifacts(force_rebuild: bool = False) -> dict[str, object]:
    from futures_hypergraph_pipeline import prepare_futures_hypergraph

    prepare_futures_hypergraph(force_rebuild=force_rebuild)
    market_dir = PROCESSED_DIR / "future"
    panel_path = market_dir / "panel.pkl"
    try:
        panel_df = read_pickle_with_recovery(panel_path)
    except Exception as exc:  # noqa: BLE001
        if not force_rebuild and is_cache_compat_error(exc):
            log(f"[WARN] FUTURE panel 缓存与当前环境不兼容，自动强制重建: {panel_path}")
            prepare_futures_hypergraph(force_rebuild=True)
            panel_df = read_pickle_with_recovery(panel_path)
        else:
            raise
    meta_df = pd.read_csv(market_dir / "universe_summary.csv")
    incidence_df = pd.read_csv(market_dir / "hypergraph_incidence.csv", index_col=0)
    symbol_stats_df = pd.read_csv(market_dir / "hypergraph_symbol_stats.csv")
    regime_thresholds = json.loads((market_dir / "regime_thresholds.json").read_text(encoding="utf-8"))
    return {
        "market": "FUTURE",
        "panel_df": panel_df,
        "meta_df": meta_df,
        "incidence_df": incidence_df,
        "symbol_stats_df": symbol_stats_df,
        "regime_thresholds": regime_thresholds,
        "paths": {
            "panel_path": str(market_dir / "panel.pkl"),
            "meta_path": str(market_dir / "universe_summary.csv"),
            "incidence_path": str(market_dir / "hypergraph_incidence.csv"),
            "symbol_stats_path": str(market_dir / "hypergraph_symbol_stats.csv"),
            "regime_summary_path": str(market_dir / "regime_thresholds.json"),
        },
    }


def iter_symbol_files(csv_dir: Path) -> Iterable[Path]:
    yield from sorted(csv_dir.glob("*.csv"))


def safe_qcut(series: pd.Series, q: int, prefix: str) -> pd.Series:
    clean = series.astype(float).replace([np.inf, -np.inf], np.nan)
    ranked = clean.rank(method="first")
    bucket = pd.qcut(ranked, q=q, labels=False, duplicates="drop")
    bucket = bucket.fillna(-1).astype(int)
    return bucket.map(lambda x: f"{prefix}_{x}" if x >= 0 else f"{prefix}_missing")


def load_symbol_history(csv_path: Path, start_time: str, end_time: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    if df.empty:
        return df
    df.columns = [col.lower() for col in df.columns]
    df["date"] = pd.to_datetime(df["date"])
    df = df[(df["date"] >= pd.Timestamp(start_time)) & (df["date"] <= pd.Timestamp(end_time))].copy()
    if df.empty:
        return df
    df["symbol"] = df["symbol"].astype(str).str.upper()
    numeric_cols = ["open", "high", "low", "close", "volume", "factor", "change"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.sort_values("date").drop_duplicates(subset=["date"], keep="last")
    return df.reset_index(drop=True)


def build_universe_summary(config: MarketDataConfig) -> pd.DataFrame:
    csv_dir = resolve_market_csv_dir(config.market)
    if not csv_dir.exists():
        raise RuntimeError(
            f"{config.market} 原始股票 CSV 目录不存在: {csv_dir}。"
            "请先运行 qlib 全市场数据更新脚本，构建 DataToSever 下的 `_workspace_*_2021_2025_csv` 目录。"
        )
    rows: list[dict[str, object]] = []
    for csv_path in iter_symbol_files(csv_dir):
        try:
            df = load_symbol_history(
                csv_path=csv_path,
                start_time=config.split.train_start,
                end_time=config.split.train_end,
            )
        except Exception as exc:  # noqa: BLE001
            rows.append({"symbol": csv_path.stem.upper(), "usable": False, "error": str(exc)})
            continue
        if df.empty:
            rows.append({"symbol": csv_path.stem.upper(), "usable": False, "error": "empty_train_range"})
            continue
        traded_value = (df["close"].abs() * df["volume"].abs()).replace([np.inf, -np.inf], np.nan)
        coverage = int(df["date"].nunique())
        rows.append(
            {
                "symbol": csv_path.stem.upper(),
                "usable": coverage >= config.min_history_days,
                "avg_traded_value": float(traded_value.mean(skipna=True) or 0.0),
                "coverage_days": coverage,
                "last_date": df["date"].max().strftime("%Y-%m-%d"),
                "error": "",
            }
        )
    summary = pd.DataFrame(rows)
    if summary.empty:
        raise RuntimeError(f"{config.market} 股票池扫描结果为空: {csv_dir}")
    summary["avg_traded_value"] = pd.to_numeric(summary.get("avg_traded_value"), errors="coerce").fillna(0.0)
    summary["coverage_days"] = pd.to_numeric(summary.get("coverage_days"), errors="coerce").fillna(0).astype(int)
    summary["usable"] = summary.get("usable", False).fillna(False)
    summary = summary.sort_values(["usable", "avg_traded_value", "coverage_days"], ascending=[False, False, False])
    return summary.reset_index(drop=True)


def resolve_usable_universe_summary(config: MarketDataConfig, summary: pd.DataFrame) -> pd.DataFrame:
    usable = summary.loc[summary["usable"]].copy()
    if not usable.empty:
        return usable

    max_coverage = int(summary["coverage_days"].max()) if "coverage_days" in summary.columns and not summary.empty else 0
    if max_coverage <= 0:
        return usable

    relaxed_min_history = min(config.min_history_days, max(120, int(max_coverage * 0.8)))
    usable = summary.loc[summary["coverage_days"] >= relaxed_min_history].copy()
    if usable.empty:
        return usable

    log(
        f"[WARN] {config.market} 无满足 min_history_days={config.min_history_days} 的股票，"
        f"自动放宽到 coverage_days>={relaxed_min_history} 以兼容当前可用历史窗口。"
    )
    return usable


def select_liquid_universe(config: MarketDataConfig) -> list[str]:
    summary = build_universe_summary(config)
    usable_summary = resolve_usable_universe_summary(config, summary)
    if config.use_full_market:
        usable = usable_summary.copy()
        usable = usable.sort_values(by="avg_traded_value", ascending=False)
        if usable.empty:
            raise RuntimeError(f"{config.market} 无满足最小历史长度约束的股票。")
        return usable["symbol"].astype(str).tolist()

    # 如果服务器上已经提供精确的指数成分股名单，则优先按白名单过滤。
    # 这对应“只训练 CSI300 / SP500 Top-300，忽略其他个股”的严格模式。
    whitelist = load_latest_constituent_symbols(config.market)
    if whitelist:
        effective_cap = resolve_effective_symbol_cap(config, len(whitelist))
        usable = usable_summary.loc[usable_summary["symbol"].isin(whitelist)].copy()
        usable = usable.sort_values(by="avg_traded_value", ascending=False).head(effective_cap)
        if not usable.empty:
            return usable["symbol"].astype(str).tolist()

    # 若未提供白名单，则回退为“按成交活跃度挑选 Top-K”的代理方案，
    # 以近似 CSI300 / SP500 Top-300 的核心股票池。
    usable = usable_summary.copy()
    usable = usable.sort_values(by="avg_traded_value", ascending=False).head(config.max_symbols)

    if usable.empty:
        raise RuntimeError(f"{config.market} 无满足最小历史长度约束的股票。")
    return usable["symbol"].astype(str).tolist()


def compute_symbol_features(
    raw_df: pd.DataFrame,
    horizon: int,
    alpha_feature_config: AMTAlphaFeatureConfig | None = None,
) -> pd.DataFrame:
    df = raw_df.copy()
    alpha_cfg = alpha_feature_config or DEFAULT_AMT_ALPHA_FEATURE_CONFIG
    price = df["close"].replace(0.0, np.nan)
    volume = df["volume"].replace(0.0, np.nan)
    returns = price.pct_change(fill_method=None)
    high_low = (df["high"] - df["low"]) / price
    open_close = (df["close"] - df["open"]) / df["open"].replace(0.0, np.nan)
    dollar_volume = price * volume

    # 这组特征既覆盖常见时序基线输入, 也为主模型中的公式 alpha 层提供直接可解释的统计量。
    df["ret_1"] = returns
    df["ret_5"] = price.pct_change(5, fill_method=None)
    df["ret_10"] = price.pct_change(10, fill_method=None)
    df["ret_20"] = price.pct_change(20, fill_method=None)
    df["vol_5"] = returns.rolling(5).std()
    df["vol_20"] = returns.rolling(20).std()
    df["vol_60"] = returns.rolling(60).std()
    df["ma_5"] = price.rolling(5).mean()
    df["ma_20"] = price.rolling(20).mean()
    df["ma_60"] = price.rolling(60).mean()
    df["ma_ratio_5_20"] = df["ma_5"] / df["ma_20"].replace(0.0, np.nan) - 1.0
    df["ma_ratio_20_60"] = df["ma_20"] / df["ma_60"].replace(0.0, np.nan) - 1.0
    df["hl_spread"] = high_low
    df["oc_return"] = open_close
    df["turnover_proxy"] = volume / volume.rolling(20).mean()
    df["dollar_volume"] = dollar_volume
    df["log_dollar_volume"] = np.log1p(dollar_volume.clip(lower=0.0))
    df["volume_momentum_20"] = volume / volume.rolling(20).mean() - 1.0
    df["reversal_5"] = -df["ret_5"]

    # 公式 alpha 风格特征:
    # 统一切换为“a_A * (A + delta_A) + a_B * (B + delta_B)”的通用仿射微调结构，
    # 只允许在原始 A/B 金融语义附近做局部系数和偏移量校准。
    momentum_a = price / price.shift(int(alpha_cfg.momentum_lookback)) - 1.0
    momentum_b = -returns.rolling(int(alpha_cfg.momentum_vol_window)).std()
    df["alpha_momentum"] = compose_affine_alpha_signal(momentum_a, momentum_b, alpha_cfg.momentum_transform)

    reversal_a = -returns.rolling(int(alpha_cfg.reversal_window)).mean()
    reversal_b = -returns.rolling(int(alpha_cfg.reversal_vol_window)).std()
    df["alpha_reversal"] = compose_affine_alpha_signal(reversal_a, reversal_b, alpha_cfg.reversal_transform)

    volume_price_a = price.diff(int(alpha_cfg.volume_price_return_window)) / price.shift(int(alpha_cfg.volume_price_return_window))
    volume_price_b = (
        volume.rolling(int(alpha_cfg.volume_price_volume_short_window)).std()
        / (volume.rolling(int(alpha_cfg.volume_price_volume_long_window)).mean() + 1e-6)
        - 1.0
    )
    df["alpha_volume_price"] = compose_affine_alpha_signal(volume_price_a, volume_price_b, alpha_cfg.volume_price_transform)

    breakout_a = price / (df["high"].rolling(int(alpha_cfg.breakout_window)).max() + 1e-6) - 1.0
    breakout_b = price / (df["high"].rolling(int(alpha_cfg.breakout_window)).mean() + 1e-6) - 1.0
    df["alpha_breakout"] = compose_affine_alpha_signal(breakout_a, breakout_b, alpha_cfg.breakout_transform)

    liquidity_a = df["log_dollar_volume"].rolling(int(alpha_cfg.liquidity_short_window)).mean()
    liquidity_b = -df["log_dollar_volume"].rolling(int(alpha_cfg.liquidity_long_window)).mean()
    df["alpha_liquidity"] = compose_affine_alpha_signal(liquidity_a, liquidity_b, alpha_cfg.liquidity_transform)

    intraday_a = open_close
    intraday_b = -high_low.abs() / (1.0 + float(alpha_cfg.intraday_range_floor))
    df["alpha_intraday"] = compose_affine_alpha_signal(intraday_a, intraday_b, alpha_cfg.intraday_transform)

    raw_future_return = price.shift(-horizon) / price - 1.0
    df["future_return"] = raw_future_return.where(raw_future_return.abs() <= MAX_REASONABLE_FUTURE_RETURN)
    df["label_rank_proxy"] = df["future_return"]

    feature_cols = [
        "ret_1",
        "ret_5",
        "ret_10",
        "ret_20",
        "vol_5",
        "vol_20",
        "vol_60",
        "ma_ratio_5_20",
        "ma_ratio_20_60",
        "hl_spread",
        "oc_return",
        "turnover_proxy",
        "log_dollar_volume",
        "volume_momentum_20",
        "reversal_5",
        "alpha_momentum",
        "alpha_reversal",
        "alpha_volume_price",
        "alpha_breakout",
        "alpha_liquidity",
        "alpha_intraday",
    ]
    df = df[["date", "symbol", "open", "high", "low", "close", "volume", "dollar_volume", *feature_cols, "future_return", "label_rank_proxy"]]
    df = df.replace([np.inf, -np.inf], np.nan)
    return df


def build_market_panel(config: MarketDataConfig) -> tuple[pd.DataFrame, pd.DataFrame]:
    universe = select_liquid_universe(config)
    csv_dir = resolve_market_csv_dir(config.market)
    panel_list: list[pd.DataFrame] = []
    meta_rows: list[dict[str, object]] = []
    start_time = config.split.train_start
    end_time = config.split.test_end

    for idx, symbol in enumerate(universe, start=1):
        csv_path = csv_dir / f"{symbol.lower()}.csv"
        if not csv_path.exists():
            continue
        raw_df = load_symbol_history(csv_path, start_time=start_time, end_time=end_time)
        if raw_df.empty:
            continue
        feat_df = compute_symbol_features(raw_df, horizon=config.horizon)
        feat_df["market"] = config.market
        feat_df = feat_df.dropna(subset=["future_return"])
        if feat_df.empty:
            continue
        panel_list.append(feat_df)
        meta_rows.append(
            {
                "symbol": symbol,
                "market": config.market,
                "history_days": int(raw_df["date"].nunique()),
                "avg_traded_value": float((raw_df["close"] * raw_df["volume"]).mean(skipna=True) or 0.0),
            }
        )
        if idx % 25 == 0 or idx == len(universe):
            log(f"[{config.market}] feature build {idx}/{len(universe)}")

    if not panel_list:
        raise RuntimeError(f"{config.market} 面板数据构建失败, 未产出任何有效样本。")
    panel_df = pd.concat(panel_list, axis=0, ignore_index=True)
    panel_df["date"] = pd.to_datetime(panel_df["date"])
    panel_df = panel_df.sort_values(["date", "symbol"]).reset_index(drop=True)
    meta_df = pd.DataFrame(meta_rows).sort_values("avg_traded_value", ascending=False).reset_index(drop=True)
    return panel_df, meta_df


def assign_regime_labels(panel_df: pd.DataFrame, config: MarketDataConfig) -> tuple[pd.DataFrame, dict[str, float]]:
    # 先把个股面板聚合到“市场日度”层面。
    # 这里不追求复杂的宏观状态识别器，而是采用训练期可复现的横截面均值统计量，
    # 保证 CN/US 两个市场都能在统一协议下切出 bull / bear / neutral / shock。
    market_daily = (
        panel_df.groupby("date")
        .agg(
            ew_future_return=("future_return", "mean"),
            ew_ret_1=("ret_1", "mean"),
            ew_vol_20=("vol_20", "mean"),
            ew_turnover=("turnover_proxy", "mean"),
        )
        .reset_index()
        .sort_values("date")
    )
    train_daily = market_daily[market_daily["date"] <= pd.Timestamp(config.split.train_end)].copy()
    if train_daily.empty:
        raise RuntimeError(f"{config.market} 的训练期 regime 基准为空。")

    # 所有状态阈值都只用训练集估计，避免把验证/测试期信息泄露到状态定义中。
    ret_up = float(train_daily["ew_ret_1"].quantile(0.67))
    ret_down = float(train_daily["ew_ret_1"].quantile(0.33))
    vol_high = float(train_daily["ew_vol_20"].quantile(0.80))
    vol_mid = float(train_daily["ew_vol_20"].quantile(0.55))

    def classify(row: pd.Series) -> str:
        if row["ew_vol_20"] >= vol_high:
            return "shock"
        if row["ew_ret_1"] >= ret_up and row["ew_vol_20"] < vol_mid:
            return "bull"
        if row["ew_ret_1"] <= ret_down:
            return "bear"
        return "neutral"

    market_daily["regime"] = market_daily.apply(classify, axis=1)
    regime_df = panel_df.merge(market_daily[["date", "regime"]], on="date", how="left")
    thresholds = {
        "ret_up_q67": ret_up,
        "ret_down_q33": ret_down,
        "vol_high_q80": vol_high,
        "vol_mid_q55": vol_mid,
    }
    return regime_df, thresholds


def build_static_hypergraph(panel_df: pd.DataFrame, config: MarketDataConfig) -> tuple[pd.DataFrame, pd.DataFrame]:
    # 当前工程主实现采用“训练期稳定统计量 + 风格分桶”的静态超图。
    # 这样做是为了贴合 idea 中“静态基础超边 + regime 感知”的折中方案：
    # 不按天重建动态图，但保留流动性/波动率/价格/动量等高阶分组关系。
    train_df = panel_df[
        (panel_df["date"] >= pd.Timestamp(config.split.train_start))
        & (panel_df["date"] <= pd.Timestamp(config.split.train_end))
    ].copy()

    # 如果无法构建出统计指标，回退
    if train_df.empty:
        instruments = sorted(panel_df["symbol"].unique().tolist())
        cn_incidence_path = ROOT_DIR / "DataToSever" / "cn_concept_hypergraph" / "base_incidence_matrix.npz"
        us_incidence_path = ROOT_DIR / "DataToSever" / "us_concept_hypergraph" / "base_incidence_matrix.npz"
        
        if cn_incidence_path.exists() and us_incidence_path.exists():
            incidence_path = cn_incidence_path if config.market == "CN" else us_incidence_path
            data = np.load(incidence_path, allow_pickle=True)
            incidence_df = pd.DataFrame(data['matrix'], index=data['instruments'], columns=data['edge_ids'])
            # 过滤并对齐
            valid_symbols = set(instruments)
            incidence_df = incidence_df[incidence_df.index.isin(valid_symbols)]
            # 补齐缺失的股票
            missing_symbols = list(valid_symbols - set(incidence_df.index))
            if missing_symbols:
                missing_df = pd.DataFrame(0.0, index=missing_symbols, columns=incidence_df.columns)
                incidence_df = pd.concat([incidence_df, missing_df])
            incidence_df = incidence_df.loc[instruments]
            return incidence_df, pd.DataFrame()
        return pd.DataFrame(0.0, index=instruments, columns=["mock_edge"]), pd.DataFrame()

    symbol_stats = (
        train_df.groupby("symbol")
        .agg(
            avg_dollar_volume=("dollar_volume", "mean"),
            avg_volatility=("vol_20", "mean"),
            avg_price=("close", "mean"),
            avg_momentum=("ret_20", "mean"),
        )
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0.0)
    )
    # 四组风格桶对应论文中的稳定高阶关系来源，后续概念向量直接由 incidence matrix 提供。
    symbol_stats["liquidity_bucket"] = safe_qcut(symbol_stats["avg_dollar_volume"], q=5, prefix="liq")
    symbol_stats["vol_bucket"] = safe_qcut(symbol_stats["avg_volatility"], q=5, prefix="vol")
    symbol_stats["price_bucket"] = safe_qcut(symbol_stats["avg_price"], q=5, prefix="price")
    symbol_stats["momentum_bucket"] = safe_qcut(symbol_stats["avg_momentum"], q=5, prefix="mom")

    edge_members: dict[str, list[str]] = {}
    for bucket_col in ["liquidity_bucket", "vol_bucket", "price_bucket", "momentum_bucket"]:
        for bucket_name, group_df in symbol_stats.groupby(bucket_col):
            members = sorted(group_df.index.astype(str).tolist())
            if len(members) <= 1:
                continue
            edge_members[str(bucket_name)] = members

    symbols = sorted(symbol_stats.index.astype(str).tolist())

    cn_incidence_path = ROOT_DIR / "DataToSever" / "cn_concept_hypergraph" / "base_incidence_matrix.npz"
    us_incidence_path = ROOT_DIR / "DataToSever" / "us_concept_hypergraph" / "base_incidence_matrix.npz"
    
    if cn_incidence_path.exists() and us_incidence_path.exists():
        incidence_path = cn_incidence_path if config.market == "CN" else us_incidence_path
        data = np.load(incidence_path, allow_pickle=True)
        incidence = pd.DataFrame(data['matrix'], index=data['instruments'], columns=data['edge_ids'])
        # 过滤并对齐
        valid_symbols = set(symbols)
        incidence = incidence[incidence.index.isin(valid_symbols)]
        # 补齐缺失的股票
        missing_symbols = list(valid_symbols - set(incidence.index))
        if missing_symbols:
            missing_df = pd.DataFrame(0.0, index=missing_symbols, columns=incidence.columns)
            incidence = pd.concat([incidence, missing_df])
        incidence = incidence.loc[symbols]
    else:
        incidence = pd.DataFrame(0.0, index=symbols, columns=sorted(edge_members), dtype=float)
        for edge_name, members in edge_members.items():
            incidence.loc[members, edge_name] = 1.0

    return incidence, symbol_stats.reset_index().rename(columns={"index": "symbol"})


def cache_market_artifacts(
    config: MarketDataConfig,
    panel_df: pd.DataFrame,
    meta_df: pd.DataFrame,
    incidence_df: pd.DataFrame,
    symbol_stats_df: pd.DataFrame,
    regime_thresholds: dict[str, float],
) -> dict[str, str]:
    market_dir = PROCESSED_DIR / config.market.lower()
    ensure_dir(market_dir)

    panel_path = market_dir / "panel.pkl"
    meta_path = market_dir / "universe_summary.csv"
    incidence_path = market_dir / "hypergraph_incidence.csv"
    symbol_stats_path = market_dir / "hypergraph_symbol_stats.csv"
    config_path = market_dir / "market_config.json"
    regime_summary_path = market_dir / "regime_thresholds.json"

    panel_df.to_pickle(panel_path)
    meta_df.to_csv(meta_path, index=False, encoding="utf-8-sig")
    incidence_df.to_csv(incidence_path, index=True, encoding="utf-8-sig")
    symbol_stats_df.to_csv(symbol_stats_path, index=False, encoding="utf-8-sig")
    config_path.write_text(json.dumps(asdict(config), ensure_ascii=False, indent=2), encoding="utf-8")
    regime_summary_path.write_text(json.dumps(regime_thresholds, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "panel_path": str(panel_path),
        "meta_path": str(meta_path),
        "incidence_path": str(incidence_path),
        "symbol_stats_path": str(symbol_stats_path),
        "config_path": str(config_path),
        "regime_summary_path": str(regime_summary_path),
    }


def prepare_market_artifacts(config: MarketDataConfig, force_rebuild: bool = False) -> dict[str, object]:
    if config.market.upper() == "FUTURE":
        future_artifacts = prepare_future_market_artifacts(force_rebuild=force_rebuild)
        panel_df, meta_df, incidence_df, symbol_stats_df = filter_artifacts_by_latest_universe(
            config=config,
            panel_df=future_artifacts["panel_df"],
            meta_df=future_artifacts["meta_df"],
            incidence_df=future_artifacts["incidence_df"],
            symbol_stats_df=future_artifacts["symbol_stats_df"],
        )
        future_artifacts["panel_df"] = panel_df
        future_artifacts["meta_df"] = meta_df
        future_artifacts["incidence_df"] = incidence_df
        future_artifacts["symbol_stats_df"] = symbol_stats_df
        return future_artifacts

    ensure_dir(PROCESSED_DIR)
    market_dir = PROCESSED_DIR / config.market.lower()
    panel_path = market_dir / "panel.pkl"
    incidence_path = market_dir / "hypergraph_incidence.csv"
    symbol_stats_path = market_dir / "hypergraph_symbol_stats.csv"
    regime_summary_path = market_dir / "regime_thresholds.json"
    meta_path = market_dir / "universe_summary.csv"

    if not force_rebuild and all(path.exists() for path in [panel_path, incidence_path, symbol_stats_path, regime_summary_path, meta_path]):
        # 中间产物命中缓存时直接复用，避免每次训练都重新扫描 1999-2025 全历史 CSV。
        try:
            panel_df = read_pickle_with_recovery(panel_path)
        except Exception as exc:  # noqa: BLE001
            if is_cache_compat_error(exc):
                log(f"[WARN] {config.market} panel 缓存与当前环境不兼容，自动重建: {panel_path}")
            else:
                raise
        else:
            meta_df = pd.read_csv(meta_path)
            incidence_df = pd.read_csv(incidence_path, index_col=0)
            symbol_stats_df = pd.read_csv(symbol_stats_path)
            panel_df, meta_df, incidence_df, symbol_stats_df = filter_artifacts_by_latest_universe(
                config=config,
                panel_df=panel_df,
                meta_df=meta_df,
                incidence_df=incidence_df,
                symbol_stats_df=symbol_stats_df,
            )
            return {
                "market": config.market,
                "panel_df": panel_df,
                "meta_df": meta_df,
                "incidence_df": incidence_df,
                "symbol_stats_df": symbol_stats_df,
                "regime_thresholds": json.loads(regime_summary_path.read_text(encoding="utf-8")),
                "paths": {
                    "panel_path": str(panel_path),
                    "meta_path": str(meta_path),
                    "incidence_path": str(incidence_path),
                    "symbol_stats_path": str(symbol_stats_path),
                    "regime_summary_path": str(regime_summary_path),
                },
            }
        meta_df = pd.read_csv(meta_path)

    # 冷启动流程严格对应论文的数据准备闭环：
    # 股票池筛选 -> 个股特征 -> 市场状态 -> 静态超图 -> 落盘缓存。
    panel_df, meta_df = build_market_panel(config)
    panel_df, regime_thresholds = assign_regime_labels(panel_df, config)
    incidence_df, symbol_stats_df = build_static_hypergraph(panel_df, config)
    panel_df, meta_df, incidence_df, symbol_stats_df = filter_artifacts_by_latest_universe(
        config=config,
        panel_df=panel_df,
        meta_df=meta_df,
        incidence_df=incidence_df,
        symbol_stats_df=symbol_stats_df,
    )
    paths = cache_market_artifacts(
        config=config,
        panel_df=panel_df,
        meta_df=meta_df,
        incidence_df=incidence_df,
        symbol_stats_df=symbol_stats_df,
        regime_thresholds=regime_thresholds,
    )
    return {
        "market": config.market,
        "panel_df": panel_df,
        "meta_df": meta_df,
        "incidence_df": incidence_df,
        "symbol_stats_df": symbol_stats_df,
        "regime_thresholds": regime_thresholds,
        "paths": paths,
    }


def prepare_transfer_artifacts(
    source_market: str,
    target_market: str,
    max_symbols: int = 160,
    horizon: int = 5,
    force_rebuild: bool = False,
) -> dict[str, object]:
    # 源域/目标域共享同一套 horizon 和股票池规模约束，保证迁移实验协议可比。
    source_cfg = MarketDataConfig(
        market=source_market.upper(),
        max_symbols=max_symbols,
        horizon=horizon,
        use_full_market=source_market.upper() == "US",
    )
    target_cfg = MarketDataConfig(
        market=target_market.upper(),
        max_symbols=max_symbols,
        horizon=horizon,
        use_full_market=target_market.upper() == "US",
    )
    source_artifacts = prepare_market_artifacts(source_cfg, force_rebuild=force_rebuild)
    target_artifacts = prepare_market_artifacts(target_cfg, force_rebuild=force_rebuild)
    return {
        "source": source_artifacts,
        "target": target_artifacts,
        "horizon": horizon,
        "max_symbols": max_symbols,
    }
