"""
文件功能:
1. 为 10 个 alpha 的双向迁移结果生成论文级净值叠加图, 重点比较 `Direct Transfer`、`AMT` 与 `QuantNet`。
2. 在不改动既有实验结果文件的前提下, 自动读取最新的 multi-alpha 批次和 baseline full-trial 批次, 输出更适合 AAAI 正文/附录使用的图资产。
3. 修复旧版图中“红线几乎贴 0”这一展示问题, 通过动态对数坐标、最大回撤阴影和末端统计表提升可读性。
4. 自动生成 manifest 与代表性案例清单, 将 20 张图拆分为“主文候选 2~4 张 + 其余附录”。

代码逻辑:
1. 先定位最新的 `multi_alpha_transfer` 与 `baseline_full_trial` 结果目录。
2. 对每个 `alpha-direction` 读取 `AMT / Direct Transfer` 的 alpha 级曲线, 再叠加同方向 `QuantNet` 的 direction-level 参考曲线。
3. 若不同方法的净值跨度过大, 自动切换为对数纵轴, 避免某条曲线在图上被压扁。
4. 在主图中加入最大回撤阴影, 并在右上角嵌入一个小型统计表, 同时导出清单、代表性案例和说明文件。

代码结构:
1. 路径解析与 alpha 元信息加载。
2. 曲线读取、统计计算与回撤区间定位。
3. Matplotlib 出图。
4. manifest 与代表性案例导出。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parent))

from alpha_strategy_library import get_alpha_strategy
from experiment_workspace import get_latest_completed_batch_root, get_paper_asset_path, require_batch_artifacts
from multi_alpha_transfer_parallel_runner import ALPHA_TASKS


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT_DIR / "results"

CATEGORY_EN_MAP = {
    "动量类": "Momentum",
    "反转类": "Reversal",
    "波动率类": "Volatility",
    "流动性类": "Liquidity",
    "量价耦合类": "Price-Volume Coupling",
    "突破类": "Breakout",
}

DIRECTION_LABEL_MAP = {
    "cn_to_us": "CN->US",
    "us_to_cn": "US->CN",
}

MODEL_STYLE = {
    "direct_transfer": {
        "display": "Direct Transfer",
        "color": "#1f77b4",
        "linestyle": "-",
        "linewidth": 2.2,
        "scope": "alpha_level",
    },
    "amt": {
        "display": "AMT",
        "color": "#d62728",
        "linestyle": "-",
        "linewidth": 2.4,
        "scope": "alpha_level",
    },
    "quantnet": {
        "display": "QuantNet",
        "color": "#2ca02c",
        "linestyle": "--",
        "linewidth": 2.0,
        "scope": "direction_level_reference",
    },
}

REQUIRED_MODELS = ("direct_transfer", "amt")


@dataclass(frozen=True)
class AlphaMeta:
    alpha_name: str
    category_zh: str
    category_en: str
    formula: str


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def build_asset_root(multi_alpha_root: Path) -> Path:
    asset_root = get_paper_asset_path(multi_alpha_root, "assets", "multi_alpha_transfer", "equity_overlay")
    ensure_dir(asset_root)
    return asset_root


def slugify(text: str, max_len: int = 72) -> str:
    normalized = re.sub(r"[^0-9a-zA-Z]+", "-", str(text).strip().lower()).strip("-")
    normalized = re.sub(r"-{2,}", "-", normalized)
    if not normalized:
        normalized = "na"
    return normalized[:max_len].rstrip("-")


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    display_df = df.copy()
    for column in display_df.columns:
        if pd.api.types.is_float_dtype(display_df[column]):
            display_df[column] = display_df[column].map(lambda value: f"{value:.4f}")
    headers = [str(column) for column in display_df.columns.tolist()]
    rows = [[str(value) for value in row] for row in display_df.astype(object).values.tolist()]
    separator = ["---"] * len(headers)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(separator) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def alpha_meta_map() -> dict[str, AlphaMeta]:
    mapping: dict[str, AlphaMeta] = {}
    for task in ALPHA_TASKS:
        spec = get_alpha_strategy(task.name)
        category_en = CATEGORY_EN_MAP.get(task.category, task.category)
        mapping[task.name] = AlphaMeta(
            alpha_name=task.name,
            category_zh=task.category,
            category_en=category_en,
            formula=spec.formula,
        )
    return mapping


def parse_batch_timestamp(path: Path) -> str:
    match = re.search(r"(full|medium|demo)_(\d{8}_\d{6})$", path.name)
    if not match:
        return ""
    return match.group(2)


def find_latest_result_root(relative_parts: tuple[str, ...]) -> Path:
    candidates: list[Path] = []
    for batch_dir in RESULTS_DIR.glob("full_*"):
        candidate = batch_dir.joinpath(*relative_parts)
        if candidate.exists():
            candidates.append(candidate)
    if not candidates:
        raise FileNotFoundError(f"未找到结果目录: {'/'.join(relative_parts)}")
    candidates.sort(key=lambda item: parse_batch_timestamp(item.parents[len(relative_parts) - 1]), reverse=True)
    return candidates[0]


def resolve_default_roots() -> tuple[Path, Path]:
    batch_root = require_batch_artifacts(
        get_latest_completed_batch_root(prefix="full"),
        (
            ("主实验", "multi_alpha_transfer"),
            ("对比实验", "baseline_full_trial"),
        ),
    )
    multi_alpha_root = batch_root / "主实验" / "multi_alpha_transfer"
    baseline_root = batch_root / "对比实验" / "baseline_full_trial"
    return multi_alpha_root, baseline_root


def load_curve(curve_path: Path, summary_path: Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    curve_df = pd.read_csv(curve_path)
    curve_df["date"] = pd.to_datetime(curve_df["date"])
    curve_df = curve_df.sort_values("date").reset_index(drop=True)
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    return curve_df, summary


def load_alpha_curve(result_root: Path, alpha_name: str, direction: str, model_name: str) -> tuple[pd.DataFrame, dict[str, Any], Path]:
    model_dir = result_root / alpha_name / direction / model_name
    curve_path = model_dir / "equity_curve.csv"
    summary_path = model_dir / "summary.json"
    if not curve_path.exists() or not summary_path.exists():
        raise FileNotFoundError(f"缺少 alpha 级曲线资产: {model_dir}")
    curve_df, summary = load_curve(curve_path=curve_path, summary_path=summary_path)
    return curve_df, summary, model_dir


def load_quantnet_curve(baseline_root: Path, direction: str) -> tuple[pd.DataFrame, dict[str, Any], Path]:
    baseline_dir = baseline_root / direction / "quantnet"
    curve_path = baseline_dir / "equity_curve.csv"
    summary_path = baseline_dir / "summary.json"
    if not curve_path.exists() or not summary_path.exists():
        raise FileNotFoundError(f"缺少 QuantNet 曲线资产: {baseline_dir}")
    curve_df, summary = load_curve(curve_path=curve_path, summary_path=summary_path)
    return curve_df, summary, baseline_dir


def format_metric(value: float | int | None) -> str:
    if value is None:
        return "NA"
    try:
        return f"{float(value):.4f}"
    except Exception:  # noqa: BLE001
        return str(value)


def compute_running_max(nav: pd.Series) -> pd.Series:
    return nav.astype(float).cummax()


def locate_max_drawdown_interval(curve_df: pd.DataFrame) -> tuple[pd.Timestamp, pd.Timestamp]:
    work_df = curve_df.copy()
    work_df["running_max"] = compute_running_max(work_df["nav"])
    work_df["drawdown_calc"] = work_df["nav"] / work_df["running_max"] - 1.0
    trough_index = int(work_df["drawdown_calc"].idxmin())
    peak_slice = work_df.loc[:trough_index, "nav"]
    peak_index = int(peak_slice.idxmax())
    peak_date = pd.Timestamp(work_df.loc[peak_index, "date"])
    trough_date = pd.Timestamp(work_df.loc[trough_index, "date"])
    return peak_date, trough_date


def compute_plot_scale(curves: dict[str, pd.DataFrame]) -> str:
    nav_values: list[float] = []
    for curve_df in curves.values():
        nav_values.extend(pd.to_numeric(curve_df["nav"], errors="coerce").dropna().tolist())
    positive_values = [value for value in nav_values if value > 0]
    if len(positive_values) < 2:
        return "linear"
    scale_ratio = max(positive_values) / max(min(positive_values), 1e-12)
    if scale_ratio >= 12.0:
        return "log"
    return "linear"


def build_title(meta: AlphaMeta, alpha_name: str, direction: str) -> str:
    direction_label = DIRECTION_LABEL_MAP.get(direction, direction.upper())
    return (
        f"{meta.category_en} - {alpha_name} | Formula: {meta.formula} | "
        f"Direction: {direction_label} | Methods: Direct Transfer / AMT / QuantNet"
    )


def build_output_name(meta: AlphaMeta, alpha_name: str, direction: str) -> str:
    category_slug = slugify(meta.category_en)
    formula_slug = slugify(meta.formula)
    return f"{category_slug}__{alpha_name}__{formula_slug}__{direction}__direct_amt_quantnet.png"


def draw_drawdown_shadow(ax: Any, curve_df: pd.DataFrame, model_name: str) -> dict[str, str]:
    peak_date, trough_date = locate_max_drawdown_interval(curve_df)
    work_df = curve_df[(curve_df["date"] >= peak_date) & (curve_df["date"] <= trough_date)].copy()
    work_df["running_max"] = compute_running_max(work_df["nav"])
    style = MODEL_STYLE[model_name]
    ax.fill_between(
        work_df["date"],
        work_df["nav"],
        work_df["running_max"],
        color=style["color"],
        alpha=0.08,
        linewidth=0.0,
    )
    return {"peak_date": str(peak_date.date()), "trough_date": str(trough_date.date())}


def build_stats_table_rows(summary_map: dict[str, dict[str, Any]], end_nav_map: dict[str, float]) -> list[list[str]]:
    rows: list[list[str]] = []
    for model_name in ("direct_transfer", "amt", "quantnet"):
        summary = summary_map[model_name]
        rows.append(
            [
                MODEL_STYLE[model_name]["display"],
                format_metric(summary.get("Annualized Return")),
                format_metric(summary.get("Sharpe Ratio")),
                format_metric(summary.get("Maximum Drawdown")),
                format_metric(end_nav_map.get(model_name)),
            ]
        )
    return rows


def select_representative_cases(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    candidates: list[pd.Series] = []
    positive_df = df[df["delta_ann_return"] > 0].sort_values("delta_ann_return", ascending=False)
    negative_df = df[df["delta_ann_return"] < 0].sort_values("delta_ann_return", ascending=True)
    for subset in [
        positive_df.head(1),
        negative_df.head(1),
        df[df["direction"] == "us_to_cn"].sort_values("delta_ann_return", ascending=False).head(1),
        df[df["direction"] == "cn_to_us"].sort_values("delta_ann_return", ascending=True).head(1),
    ]:
        if not subset.empty:
            candidates.append(subset.iloc[0])
    if not candidates:
        return df.head(0)
    result_df = pd.DataFrame(candidates).drop_duplicates(subset=["alpha_name", "direction"]).reset_index(drop=True)
    result_df["paper_role"] = "main_text_candidate"
    return result_df


def plot_one(
    alpha_name: str,
    direction: str,
    multi_alpha_root: Path,
    baseline_root: Path,
    asset_root: Path,
    meta_map: dict[str, AlphaMeta],
) -> dict[str, Any]:
    meta = meta_map[alpha_name]
    curve_map: dict[str, pd.DataFrame] = {}
    summary_map: dict[str, dict[str, Any]] = {}
    curve_source_paths: dict[str, str] = {}
    mdd_intervals: dict[str, dict[str, str]] = {}

    for model_name in REQUIRED_MODELS:
        curve_df, summary, model_dir = load_alpha_curve(
            result_root=multi_alpha_root,
            alpha_name=alpha_name,
            direction=direction,
            model_name=model_name,
        )
        curve_map[model_name] = curve_df
        summary_map[model_name] = summary
        curve_source_paths[model_name] = str(model_dir / "equity_curve.csv")

    quantnet_curve, quantnet_summary, quantnet_dir = load_quantnet_curve(baseline_root=baseline_root, direction=direction)
    curve_map["quantnet"] = quantnet_curve
    summary_map["quantnet"] = quantnet_summary
    curve_source_paths["quantnet"] = str(quantnet_dir / "equity_curve.csv")

    y_scale = compute_plot_scale(curve_map)
    fig, (ax_nav, ax_dd) = plt.subplots(
        2,
        1,
        figsize=(15, 9.5),
        sharex=True,
        gridspec_kw={"height_ratios": [3.2, 1.15]},
    )
    end_nav_map: dict[str, float] = {}
    min_drawdown = 0.0

    for model_name in ("direct_transfer", "amt", "quantnet"):
        curve_df = curve_map[model_name]
        style = MODEL_STYLE[model_name]
        ax_nav.plot(
            curve_df["date"],
            curve_df["nav"],
            label=style["display"],
            color=style["color"],
            linestyle=style["linestyle"],
            linewidth=style["linewidth"],
        )
        end_nav_map[model_name] = float(pd.to_numeric(curve_df["nav"], errors="coerce").iloc[-1])
        mdd_intervals[model_name] = draw_drawdown_shadow(ax=ax_nav, curve_df=curve_df, model_name=model_name)
        ax_dd.plot(
            curve_df["date"],
            curve_df["drawdown"],
            label=style["display"],
            color=style["color"],
            linestyle=style["linestyle"],
            linewidth=max(1.8, style["linewidth"] - 0.2),
            alpha=0.92,
        )
        min_drawdown = min(min_drawdown, float(pd.to_numeric(curve_df["drawdown"], errors="coerce").min()))
        last_point = curve_df.iloc[-1]
        ax_nav.scatter(last_point["date"], last_point["nav"], color=style["color"], s=18, zorder=4)
        ax_nav.annotate(
            f"{end_nav_map[model_name]:.2f}",
            xy=(last_point["date"], last_point["nav"]),
            xytext=(4, 4),
            textcoords="offset points",
            fontsize=8,
            color=style["color"],
        )

    if y_scale == "log":
        ax_nav.set_yscale("log")

    ax_nav.set_title(build_title(meta=meta, alpha_name=alpha_name, direction=direction), fontsize=12)
    ax_nav.set_ylabel("Net Asset Value")
    ax_nav.grid(True, linestyle="--", linewidth=0.5, alpha=0.45)
    ax_nav.legend(loc="upper left")
    ax_nav.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=6, maxticks=10))
    ax_nav.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))

    ax_dd.axhline(0.0, color="#444444", linewidth=0.9, alpha=0.75)
    ax_dd.set_ylabel("Drawdown")
    ax_dd.set_xlabel("Date")
    ax_dd.grid(True, linestyle="--", linewidth=0.45, alpha=0.35)
    ax_dd.set_ylim(min_drawdown * 1.08 if min_drawdown < 0 else -0.05, 0.05)

    table = ax_nav.table(
        cellText=build_stats_table_rows(summary_map=summary_map, end_nav_map=end_nav_map),
        colLabels=["Method", "AR", "Sharpe", "MDD", "End NAV"],
        cellLoc="center",
        bbox=[0.62, 0.62, 0.35, 0.25],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8.5)

    note_lines = [
        f"Y scale: {y_scale}",
        "Drawdown shades mark each method's max drawdown interval.",
        "QuantNet curve is a direction-level reference rather than an alpha-specific run.",
    ]
    ax_dd.text(
        0.015,
        0.02,
        "\n".join(note_lines),
        transform=ax_dd.transAxes,
        fontsize=8.5,
        va="bottom",
        ha="left",
        bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.85, "edgecolor": "#BBBBBB"},
    )

    fig.autofmt_xdate()
    fig.tight_layout()
    ensure_dir(asset_root)
    output_path = asset_root / build_output_name(meta=meta, alpha_name=alpha_name, direction=direction)
    fig.savefig(output_path, dpi=260, bbox_inches="tight")
    plt.close(fig)

    direct_ar = float(summary_map["direct_transfer"]["Annualized Return"])
    amt_ar = float(summary_map["amt"]["Annualized Return"])
    compression_ratio = float(
        max(
            pd.to_numeric(curve_map["direct_transfer"]["nav"], errors="coerce").max(),
            pd.to_numeric(curve_map["amt"]["nav"], errors="coerce").max(),
        )
        / max(
            min(
                pd.to_numeric(curve_map["direct_transfer"]["nav"], errors="coerce").min(),
                pd.to_numeric(curve_map["amt"]["nav"], errors="coerce").min(),
            ),
            1e-12,
        )
    )

    return {
        "alpha_name": alpha_name,
        "category_zh": meta.category_zh,
        "category_en": meta.category_en,
        "formula": meta.formula,
        "direction": direction,
        "direction_label": DIRECTION_LABEL_MAP.get(direction, direction.upper()),
        "plot_path": str(output_path),
        "y_scale": y_scale,
        "compression_ratio": compression_ratio,
        "direct_ann_return": direct_ar,
        "amt_ann_return": amt_ar,
        "quantnet_ann_return": float(summary_map["quantnet"]["Annualized Return"]),
        "delta_ann_return": amt_ar - direct_ar,
        "direct_sharpe": float(summary_map["direct_transfer"]["Sharpe Ratio"]),
        "amt_sharpe": float(summary_map["amt"]["Sharpe Ratio"]),
        "quantnet_sharpe": float(summary_map["quantnet"]["Sharpe Ratio"]),
        "direct_mdd": float(summary_map["direct_transfer"]["Maximum Drawdown"]),
        "amt_mdd": float(summary_map["amt"]["Maximum Drawdown"]),
        "quantnet_mdd": float(summary_map["quantnet"]["Maximum Drawdown"]),
        "direct_end_nav": end_nav_map["direct_transfer"],
        "amt_end_nav": end_nav_map["amt"],
        "quantnet_end_nav": end_nav_map["quantnet"],
        "quantnet_scope": MODEL_STYLE["quantnet"]["scope"],
        "red_line_near_zero_root_cause": (
            "旧图在线性纵轴下受到 Direct Transfer 极端放大影响，"
            "导致 AMT 曲线视觉上贴近 0；新版改为动态对数坐标。"
        ),
        "curve_source_paths": json.dumps(curve_source_paths, ensure_ascii=False),
        "mdd_intervals": json.dumps(mdd_intervals, ensure_ascii=False),
    }


def export_outputs(
    manifest_df: pd.DataFrame,
    representative_df: pd.DataFrame,
    multi_alpha_root: Path,
    baseline_root: Path,
    asset_root: Path,
) -> None:
    ensure_dir(asset_root)
    manifest_csv = asset_root / "equity_overlay_manifest.csv"
    manifest_md = asset_root / "equity_overlay_manifest.md"
    manifest_json = asset_root / "equity_overlay_manifest.json"
    cases_md = asset_root / "representative_cases.md"
    cases_json = asset_root / "representative_cases.json"

    manifest_df.to_csv(manifest_csv, index=False, encoding="utf-8-sig")
    manifest_md.write_text(
        "# equity_overlay_manifest\n\n"
        f"- multi_alpha_root: `{multi_alpha_root}`\n"
        f"- baseline_root: `{baseline_root}`\n"
        "- QuantNet line scope: `direction-level reference`\n\n"
        + render_markdown_table(manifest_df)
        + "\n",
        encoding="utf-8",
    )
    manifest_json.write_text(manifest_df.to_json(orient="records", force_ascii=False, indent=2), encoding="utf-8")

    cases_md.write_text(
        "# representative_cases\n\n"
        "建议主文优先保留以下 2~4 张代表性案例，其余图放附录。\n\n"
        + render_markdown_table(representative_df)
        + "\n",
        encoding="utf-8",
    )
    cases_json.write_text(representative_df.to_json(orient="records", force_ascii=False, indent=2), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成 AAAI V2 多 alpha 净值叠加图 v2")
    parser.add_argument("--batch-root", default="", help="可选，显式指定 full 批次根目录；若为空则严格使用最新 full 批次")
    parser.add_argument("--multi-alpha-root", default="", help="可选，手动指定 multi alpha 结果目录")
    parser.add_argument("--baseline-root", default="", help="可选，手动指定 baseline full-trial 结果目录")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if str(args.batch_root).strip():
        batch_root = require_batch_artifacts(
            Path(args.batch_root).expanduser(),
            (
                ("主实验", "multi_alpha_transfer"),
                ("对比实验", "baseline_full_trial"),
            ),
        )
        default_multi_alpha_root = batch_root / "主实验" / "multi_alpha_transfer"
        default_baseline_root = batch_root / "对比实验" / "baseline_full_trial"
    else:
        default_multi_alpha_root, default_baseline_root = resolve_default_roots()
    multi_alpha_root = Path(args.multi_alpha_root).expanduser() if str(args.multi_alpha_root).strip() else default_multi_alpha_root
    baseline_root = Path(args.baseline_root).expanduser() if str(args.baseline_root).strip() else default_baseline_root
    asset_root = build_asset_root(multi_alpha_root)

    meta_map = alpha_meta_map()
    rows: list[dict[str, Any]] = []
    for alpha_name in sorted(meta_map.keys()):
        for direction in ("cn_to_us", "us_to_cn"):
            rows.append(
                plot_one(
                    alpha_name=alpha_name,
                    direction=direction,
                    multi_alpha_root=multi_alpha_root,
                    baseline_root=baseline_root,
                    asset_root=asset_root,
                    meta_map=meta_map,
                )
            )

    manifest_df = pd.DataFrame(rows).sort_values(["alpha_name", "direction"]).reset_index(drop=True)
    representative_df = select_representative_cases(manifest_df)
    manifest_df["paper_role"] = "appendix"
    if not representative_df.empty:
        selected_keys = set(zip(representative_df["alpha_name"], representative_df["direction"]))
        manifest_df["paper_role"] = manifest_df.apply(
            lambda row: "main_text_candidate" if (row["alpha_name"], row["direction"]) in selected_keys else "appendix",
            axis=1,
        )
    export_outputs(
        manifest_df=manifest_df,
        representative_df=representative_df,
        multi_alpha_root=multi_alpha_root,
        baseline_root=baseline_root,
        asset_root=asset_root,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
