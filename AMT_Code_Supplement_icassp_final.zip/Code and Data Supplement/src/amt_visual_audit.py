"""
文件功能:
1. 基于 `full_20260715_070111` 的原始结果生成 AMT 对比增益、显著性摘要与增强版论文图表。
2. 对主实验 `main_transfer`（论文中记为 AMT）相对各 baseline 的性能差值与百分比增益进行量化展示。
3. 输出结构化的 AMT 优劣势分析文档，严格区分“已验证优势”“未体现优势”和“显著性不可判定”。
4. 所有分析均遵循原始实验评估体系，不修改任何原始指标文件。

代码逻辑:
1. 读取主实验摘要与逐模型 `test_predictions.csv`，计算日度 RankIC / Top-k Return，并做配对显著性检验。
2. 读取 future 报告与 compare_models 结果，生成 future 对照增益图与状态说明。
3. 生成增强版图表、增益表、显著性汇总表与 AMT 优劣势分析文档。
4. 统一输出到 `results/full_20260715_070111/论文图表_v1/`，方便直接归档。

代码结构:
1. 数据加载与日度指标计算。
2. 显著性检验与增益表构造。
3. 主实验 / future 增强版图表绘制。
4. 优劣势分析文档与 manifest 输出。
5. CLI 入口。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, ttest_rel


DEFAULT_RESULT_ROOT = Path("/data/ztm/exp2/results/full_20260715_070111")
OUTPUT_DIRNAME = "论文图表_v1"
MAIN_SUMMARY_PATH = Path("主实验/phase1_transfer/all_summary.csv")
MAIN_ROOT = Path("主实验/phase1_transfer")
TRANSFER_FAMILY_SUMMARY_PATH = Path("主实验/phase1_transfer_family/all_summary.csv")
TRANSFER_FAMILY_ROOT = Path("主实验/phase1_transfer_family")
FUTURE_REPORT_PATH = Path("其他/future_hgnn_time_report.json")
FUTURE_COMPARE_ROOT = Path("对比实验/compare_models")
AMT_NAME = "main_transfer"
AMT_ALIAS = "AMT"
TOP_K = 10

AMT_COLOR = "#C62828"
BASE_COLOR = "#90A4AE"
POS_GAIN_COLOR = "#2E7D32"
NEG_GAIN_COLOR = "#EF6C00"
NEUTRAL_COLOR = "#B0BEC5"
HYPERGRAPH_COLOR = "#1565C0"
IDENTITY_COLOR = "#9E9E9E"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def display_model_name(model_name: str) -> str:
    transfer_name_map = {
        "amt": AMT_ALIAS,
        "direct_transfer": "Direct Transfer",
        "lstm_transfer": "LSTM-Transfer",
        "transformer_transfer": "Transformer-Transfer",
        "tra_transfer": "Routing-Transfer (TRA-like)",
        "hist_transfer": "Relation-Transfer (HIST-like)",
    }
    if model_name in transfer_name_map:
        return transfer_name_map[model_name]
    return AMT_ALIAS if model_name == AMT_NAME else model_name


def apply_style() -> None:
    plt.rcParams.update(
        {
            "figure.dpi": 150,
            "font.size": 10,
            "axes.labelsize": 10,
            "axes.titlesize": 11,
            "legend.fontsize": 9,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "grid.alpha": 0.2,
            "grid.linestyle": "--",
        }
    )


def ndcg_at_k(labels: np.ndarray, scores: np.ndarray, k: int) -> float:
    if labels.size == 0:
        return np.nan
    k = int(min(k, labels.size))
    order = np.argsort(scores)[::-1][:k]
    ideal = np.argsort(labels)[::-1][:k]
    gains = (2 ** labels[order] - 1.0) / np.log2(np.arange(2, k + 2))
    ideal_gains = (2 ** labels[ideal] - 1.0) / np.log2(np.arange(2, k + 2))
    denom = float(np.sum(ideal_gains))
    if denom == 0.0:
        return np.nan
    return float(np.sum(gains) / denom)


def safe_percent_gain(amt_value: float, baseline_value: float) -> float:
    if pd.isna(amt_value) or pd.isna(baseline_value):
        return np.nan
    if abs(baseline_value) < 1e-12:
        return np.nan
    return float((amt_value - baseline_value) / abs(baseline_value) * 100.0)


def significance_label(p_value: float | None) -> str:
    if p_value is None or pd.isna(p_value):
        return "N/A"
    if p_value < 0.01:
        return "**"
    if p_value < 0.05:
        return "*"
    return "ns"


def load_main_summary(result_root: Path) -> pd.DataFrame:
    summary_path = result_root / MAIN_SUMMARY_PATH
    if not summary_path.exists():
        return pd.DataFrame()
    df = pd.read_csv(summary_path)
    numeric_cols = ["IC", "ICIR", "RankIC", "RankICIR", "NDCG@10", "Annualized Return", "Sharpe Ratio", "Maximum Drawdown"]
    for column in numeric_cols:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def load_transfer_family_summary(result_root: Path) -> pd.DataFrame:
    summary_path = result_root / TRANSFER_FAMILY_SUMMARY_PATH
    if summary_path.exists():
        df = pd.read_csv(summary_path)
    else:
        rows: list[dict[str, Any]] = []
        transfer_root = result_root / TRANSFER_FAMILY_ROOT
        if not transfer_root.exists():
            return pd.DataFrame()
        for direction_dir in sorted(path for path in transfer_root.iterdir() if path.is_dir()):
            direction_name = direction_dir.name.replace("_to_", "->").upper()
            for model_dir in sorted(path for path in direction_dir.iterdir() if path.is_dir()):
                summary_json = model_dir / "summary.json"
                if not summary_json.exists():
                    continue
                rows.append(
                    {
                        "direction": direction_name,
                        "model": model_dir.name,
                        **json.loads(summary_json.read_text(encoding="utf-8")),
                    }
                )
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
    numeric_cols = ["IC", "ICIR", "RankIC", "RankICIR", "NDCG@10", "Annualized Return", "Sharpe Ratio", "Maximum Drawdown"]
    for column in numeric_cols:
        if column in df.columns:
            df[column] = pd.to_numeric(df[column], errors="coerce")
    return df


def load_prediction_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values(["date", "symbol"]).reset_index(drop=True)


def load_equity_curve(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])
    df["nav"] = pd.to_numeric(df["nav"], errors="coerce")
    return df.dropna(subset=["date", "nav"]).sort_values("date").reset_index(drop=True)


def compute_daily_metrics(pred_df: pd.DataFrame, top_k: int = TOP_K) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for date_value, daily_df in pred_df.groupby("date"):
        if len(daily_df) < 5:
            rows.append({"date": date_value, "count": int(len(daily_df)), "IC": np.nan, "RankIC": np.nan, "NDCG@10": np.nan, "TopKReturn": np.nan, "skip_reason": "small_sample"})
            continue
        labels = daily_df["label"].to_numpy(dtype=float)
        preds = daily_df["prediction"].to_numpy(dtype=float)
        label_std = float(np.std(labels))
        pred_std = float(np.std(preds))
        if label_std < 1e-12:
            rows.append({"date": date_value, "count": int(len(daily_df)), "IC": np.nan, "RankIC": np.nan, "NDCG@10": np.nan, "TopKReturn": np.nan, "skip_reason": "zero_label_std"})
            continue
        if pred_std < 1e-12:
            rows.append({"date": date_value, "count": int(len(daily_df)), "IC": np.nan, "RankIC": np.nan, "NDCG@10": np.nan, "TopKReturn": np.nan, "skip_reason": "zero_prediction_std"})
            continue
        effective_k = min(top_k, len(daily_df))
        ranked = daily_df.sort_values("prediction", ascending=False).head(effective_k)
        rows.append(
            {
                "date": date_value,
                "count": int(len(daily_df)),
                "IC": float(np.corrcoef(labels, preds)[0, 1]),
                "RankIC": float(spearmanr(labels, preds, nan_policy="omit").statistic),
                "NDCG@10": float(ndcg_at_k(labels, preds, k=top_k)),
                "TopKReturn": float(ranked["future_return"].mean()) if not ranked.empty else np.nan,
                "skip_reason": "",
            }
        )
    return pd.DataFrame(rows)


def build_main_daily_metrics(result_root: Path, main_df: pd.DataFrame) -> dict[tuple[str, str], pd.DataFrame]:
    if main_df.empty:
        return {}
    payload: dict[tuple[str, str], pd.DataFrame] = {}
    for _, row in main_df.iterrows():
        direction_dir = row["direction"].lower().replace("->", "_to_")
        model_name = row["model"]
        pred_path = result_root / MAIN_ROOT / direction_dir / model_name / "test_predictions.csv"
        payload[(row["direction"], model_name)] = compute_daily_metrics(load_prediction_csv(pred_path), top_k=TOP_K)
    return payload


def build_gain_table(main_df: pd.DataFrame) -> pd.DataFrame:
    if main_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for direction, direction_df in main_df.groupby("direction"):
        amt_row = direction_df[direction_df["model"] == AMT_NAME].iloc[0]
        for _, row in direction_df.iterrows():
            if row["model"] == AMT_NAME:
                continue
            rows.append(
                {
                    "direction": direction,
                    "baseline": row["model"],
                    "AMT_RankIC": float(amt_row["RankIC"]),
                    "Baseline_RankIC": float(row["RankIC"]),
                    "RankIC_Delta": float(amt_row["RankIC"] - row["RankIC"]),
                    "RankIC_GainPct": safe_percent_gain(float(amt_row["RankIC"]), float(row["RankIC"])),
                    "AMT_Sharpe": float(amt_row["Sharpe Ratio"]),
                    "Baseline_Sharpe": float(row["Sharpe Ratio"]),
                    "Sharpe_Delta": float(amt_row["Sharpe Ratio"] - row["Sharpe Ratio"]),
                    "Sharpe_GainPct": safe_percent_gain(float(amt_row["Sharpe Ratio"]), float(row["Sharpe Ratio"])),
                    "AMT_AnnualizedReturn": float(amt_row["Annualized Return"]),
                    "Baseline_AnnualizedReturn": float(row["Annualized Return"]),
                    "Return_Delta": float(amt_row["Annualized Return"] - row["Annualized Return"]),
                    "Return_GainPct": safe_percent_gain(float(amt_row["Annualized Return"]), float(row["Annualized Return"])),
                }
            )
    return pd.DataFrame(rows)


def build_transfer_family_gain_table(transfer_df: pd.DataFrame) -> pd.DataFrame:
    if transfer_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for direction, direction_df in transfer_df.groupby("direction"):
        amt_candidates = direction_df[direction_df["model"] == "amt"]
        if amt_candidates.empty:
            continue
        amt_row = amt_candidates.iloc[0]
        for _, row in direction_df.iterrows():
            if row["model"] == "amt":
                continue
            rows.append(
                {
                    "direction": direction,
                    "baseline": row["model"],
                    "AMT_RankIC": float(amt_row["RankIC"]),
                    "Baseline_RankIC": float(row["RankIC"]),
                    "RankIC_Delta": float(amt_row["RankIC"] - row["RankIC"]),
                    "RankIC_GainPct": safe_percent_gain(float(amt_row["RankIC"]), float(row["RankIC"])),
                    "AMT_Sharpe": float(amt_row["Sharpe Ratio"]),
                    "Baseline_Sharpe": float(row["Sharpe Ratio"]),
                    "Sharpe_Delta": float(amt_row["Sharpe Ratio"] - row["Sharpe Ratio"]),
                    "Sharpe_GainPct": safe_percent_gain(float(amt_row["Sharpe Ratio"]), float(row["Sharpe Ratio"])),
                    "AMT_AnnualizedReturn": float(amt_row["Annualized Return"]),
                    "Baseline_AnnualizedReturn": float(row["Annualized Return"]),
                    "Return_Delta": float(amt_row["Annualized Return"] - row["Annualized Return"]),
                    "Return_GainPct": safe_percent_gain(float(amt_row["Annualized Return"]), float(row["Annualized Return"])),
                    "AMT_MaxDrawdown": float(amt_row["Maximum Drawdown"]),
                    "Baseline_MaxDrawdown": float(row["Maximum Drawdown"]),
                    "MaxDrawdown_Delta": float(amt_row["Maximum Drawdown"] - row["Maximum Drawdown"]),
                }
            )
    return pd.DataFrame(rows)


def paired_significance_test(amt_series: pd.Series, base_series: pd.Series) -> tuple[float, float, int]:
    paired = pd.DataFrame({"amt": amt_series, "base": base_series}).dropna()
    if len(paired) < 5:
        return np.nan, np.nan, int(len(paired))
    stat = ttest_rel(paired["amt"], paired["base"], alternative="greater")
    return float((paired["amt"] - paired["base"]).mean()), float(stat.pvalue), int(len(paired))


def build_significance_table(main_df: pd.DataFrame, daily_payload: dict[tuple[str, str], pd.DataFrame]) -> pd.DataFrame:
    if main_df.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for direction, direction_df in main_df.groupby("direction"):
        amt_daily = daily_payload[(direction, AMT_NAME)]
        for _, row in direction_df.iterrows():
            baseline = row["model"]
            if baseline == AMT_NAME:
                continue
            base_daily = daily_payload[(direction, baseline)]
            rankic_mean_diff, rankic_p, rankic_n = paired_significance_test(amt_daily["RankIC"], base_daily["RankIC"])
            topk_mean_diff, topk_p, topk_n = paired_significance_test(amt_daily["TopKReturn"], base_daily["TopKReturn"])
            rows.append(
                {
                    "direction": direction,
                    "baseline": baseline,
                    "rankic_mean_diff": rankic_mean_diff,
                    "rankic_p_value": rankic_p,
                    "rankic_pairs": rankic_n,
                    "rankic_significance": significance_label(rankic_p),
                    "topk_return_mean_diff": topk_mean_diff,
                    "topk_return_p_value": topk_p,
                    "topk_pairs": topk_n,
                    "topk_return_significance": significance_label(topk_p),
                }
            )
    return pd.DataFrame(rows)


def load_future_report(result_root: Path) -> dict[str, Any]:
    future_path = result_root / FUTURE_REPORT_PATH
    if not future_path.exists():
        return {
            "sthgcn_bidirectional": {
                "cn_to_future": {
                    "identity": {"metrics": {"Annualized Return": np.nan, "Sharpe Ratio": np.nan, "RankIC": np.nan}},
                    "hypergraph": {"metrics": {"Annualized Return": np.nan, "Sharpe Ratio": np.nan, "RankIC": np.nan}},
                },
                "future_to_cn": {
                    "identity": {"metrics": {"Annualized Return": np.nan, "Sharpe Ratio": np.nan, "RankIC": np.nan}},
                    "hypergraph": {"metrics": {"Annualized Return": np.nan, "Sharpe Ratio": np.nan, "RankIC": np.nan}},
                },
            },
            "note": "future report missing; generated placeholder metrics for main-only visualization batch",
        }
    return json.loads(future_path.read_text(encoding="utf-8"))


def save_figure(fig: plt.Figure, output_dir: Path, stem: str) -> dict[str, str]:
    png_path = output_dir / f"{stem}.png"
    pdf_path = output_dir / f"{stem}.pdf"
    fig.savefig(png_path, dpi=300, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)
    return {"png": str(png_path), "pdf": str(pdf_path)}


def bar_colors(methods: list[str]) -> list[str]:
    return [AMT_COLOR if method == AMT_NAME else BASE_COLOR for method in methods]


def plot_main_metric_with_gain(main_df: pd.DataFrame, gain_df: pd.DataFrame, metric: str, gain_metric: str, title: str, output_dir: Path, stem: str) -> dict[str, str]:
    directions = ["CN->US", "US->CN"]
    fig, axes = plt.subplots(2, 2, figsize=(14.5, 8.6))
    for col_idx, direction in enumerate(directions):
        direction_df = main_df[main_df["direction"] == direction].copy().sort_values(metric, ascending=False).reset_index(drop=True)
        ax_top = axes[0, col_idx]
        ax_bottom = axes[1, col_idx]

        display_names = [display_model_name(name) for name in direction_df["model"].tolist()]
        ax_top.bar(display_names, direction_df[metric].to_numpy(), color=bar_colors(direction_df["model"].tolist()), edgecolor="black", linewidth=0.5)
        ax_top.set_title(f"{direction} | {metric}")
        ax_top.tick_params(axis="x", rotation=35)
        for patch, (_, row) in zip(ax_top.patches, direction_df.iterrows()):
            label = f"{AMT_ALIAS}" if row["model"] == AMT_NAME else row["model"]
            patch.set_label(label)
            value = float(row[metric])
            if not pd.isna(value):
                ax_top.text(patch.get_x() + patch.get_width() / 2.0, value, f"{value:.3f}", ha="center", va="bottom", fontsize=8)

        direction_gain_df = gain_df[gain_df["direction"] == direction].copy().sort_values(gain_metric, ascending=False)
        colors = [POS_GAIN_COLOR if (not pd.isna(v) and v >= 0) else NEG_GAIN_COLOR for v in direction_gain_df[gain_metric].to_numpy()]
        baseline_display_names = [display_model_name(name) for name in direction_gain_df["baseline"].tolist()]
        ax_bottom.bar(baseline_display_names, direction_gain_df[gain_metric].to_numpy(), color=colors, edgecolor="black", linewidth=0.5)
        ax_bottom.axhline(0.0, color="black", linewidth=0.8, alpha=0.6)
        ax_bottom.set_title(f"{direction} | {AMT_ALIAS} vs baseline gain %")
        ax_bottom.tick_params(axis="x", rotation=35)
        for patch, (_, row) in zip(ax_bottom.patches, direction_gain_df.iterrows()):
            value = row[gain_metric]
            label = "N/A" if pd.isna(value) else f"{value:.1f}%"
            y = 0.0 if pd.isna(value) else float(value)
            ax_bottom.text(patch.get_x() + patch.get_width() / 2.0, y, label, ha="center", va="bottom" if y >= 0 else "top", fontsize=8)

    fig.suptitle(title)
    fig.tight_layout()
    return save_figure(fig, output_dir, stem)


def plot_significance_cards(significance_df: pd.DataFrame, output_dir: Path) -> dict[str, str]:
    directions = ["CN->US", "US->CN"]
    fig, axes = plt.subplots(1, 2, figsize=(14.0, 5.0))
    for ax, direction in zip(axes, directions):
        ax.axis("off")
        subset = significance_df[significance_df["direction"] == direction].copy()
        lines = [f"{direction} | AMT paired test summary", ""]
        for _, row in subset.iterrows():
            lines.append(
                f"{row['baseline']}: RankIC Δ={row['rankic_mean_diff']:.4f} | p={row['rankic_p_value']:.4f} | {row['rankic_significance']}"
                if not pd.isna(row["rankic_p_value"])
                else f"{row['baseline']}: RankIC p-value=N/A"
            )
            lines.append(
                f"    TopKRet Δ={row['topk_return_mean_diff']:.5f} | p={row['topk_return_p_value']:.4f} | {row['topk_return_significance']}"
                if not pd.isna(row["topk_return_p_value"])
                else "    TopKRet p-value=N/A"
            )
        ax.text(0.02, 0.98, "\n".join(lines), va="top", ha="left", family="monospace", fontsize=9)
    fig.suptitle("AMT Statistical Significance Summary")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_7_amt_significance_cards")


def plot_future_status(future_report: dict[str, Any], output_dir: Path) -> dict[str, str]:
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 5.0))
    for ax, direction_key, title in zip(
        axes,
        ["cn_to_future", "future_to_cn"],
        ["CN->FUTURE", "FUTURE->CN"],
    ):
        identity_metrics = future_report["sthgcn_bidirectional"][direction_key]["identity"]["metrics"]
        hyper_metrics = future_report["sthgcn_bidirectional"][direction_key]["hypergraph"]["metrics"]
        metrics = ["Annualized Return", "Sharpe Ratio", "RankIC"]
        x = np.arange(len(metrics))
        width = 0.34
        identity_values = [identity_metrics[m] for m in metrics]
        hyper_values = [hyper_metrics[m] for m in metrics]
        ax.bar(x - width / 2.0, np.nan_to_num(identity_values, nan=0.0), width=width, color=IDENTITY_COLOR, edgecolor="black", linewidth=0.5, label="Identity")
        ax.bar(x + width / 2.0, np.nan_to_num(hyper_values, nan=0.0), width=width, color=HYPERGRAPH_COLOR, edgecolor="black", linewidth=0.5, label="Hypergraph")
        for idx, metric in enumerate(metrics):
            identity_label = "N/A" if pd.isna(identity_values[idx]) else f"{float(identity_values[idx]):.3f}"
            hyper_label = "N/A" if pd.isna(hyper_values[idx]) else f"{float(hyper_values[idx]):.3f}"
            ax.text(x[idx] - width / 2.0, 0.0 if pd.isna(identity_values[idx]) else float(identity_values[idx]), identity_label, ha="center", va="bottom", fontsize=8)
            ax.text(x[idx] + width / 2.0, 0.0 if pd.isna(hyper_values[idx]) else float(hyper_values[idx]), hyper_label, ha="center", va="bottom", fontsize=8)
        ax.set_title(title)
        ax.set_xticks(x)
        ax.set_xticklabels(metrics, rotation=15)
        ax.axhline(0.0, color="black", linewidth=0.8, alpha=0.6)
        notes = []
        for metric in metrics:
            i_val = identity_metrics[metric]
            h_val = hyper_metrics[metric]
            if pd.isna(i_val) or pd.isna(h_val):
                notes.append(f"{metric}: delta=N/A")
            else:
                notes.append(f"{metric}: Δ={float(h_val - i_val):.3f}")
        ax.text(0.02, 0.98, "\n".join(notes), transform=ax.transAxes, ha="left", va="top", fontsize=8, bbox={"boxstyle": "round", "fc": "white", "ec": "#CCCCCC"})
    axes[0].legend(frameon=False)
    fig.suptitle("Future Auxiliary Study: Delta and Missing-Metric Status")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_8_future_delta_status")


def plot_gain_heatmap(gain_df: pd.DataFrame, output_dir: Path) -> dict[str, str]:
    metrics = ["RankIC_GainPct", "Sharpe_GainPct", "Return_GainPct"]
    metric_alias = {
        "RankIC_GainPct": "RankIC Gain %",
        "Sharpe_GainPct": "Sharpe Gain %",
        "Return_GainPct": "Return Gain %",
    }
    directions = ["CN->US", "US->CN"]
    fig, axes = plt.subplots(1, 2, figsize=(14.0, 5.2))
    for ax, direction in zip(axes, directions):
        subset = gain_df[gain_df["direction"] == direction].copy()
        subset["baseline"] = subset["baseline"].map(display_model_name)
        subset = subset.set_index("baseline")
        heatmap = subset[metrics].rename(columns=metric_alias)
        values = heatmap.to_numpy(dtype=float)
        capped_values = np.clip(values, -500.0, 500.0)
        image = ax.imshow(capped_values, cmap="RdYlGn", aspect="auto", vmin=-500.0, vmax=500.0)
        ax.set_title(f"{direction} | AMT relative gain heatmap")
        ax.set_xticks(np.arange(len(heatmap.columns)))
        ax.set_xticklabels(list(heatmap.columns), rotation=20)
        ax.set_yticks(np.arange(len(heatmap.index)))
        ax.set_yticklabels(list(heatmap.index))
        for row_idx in range(values.shape[0]):
            for col_idx in range(values.shape[1]):
                value = values[row_idx, col_idx]
                label = "N/A" if pd.isna(value) else f"{value:.1f}%"
                ax.text(col_idx, row_idx, label, ha="center", va="center", fontsize=8, color="black")
    cbar = fig.colorbar(image, ax=axes.ravel().tolist(), shrink=0.88)
    cbar.set_label("Gain % (clipped to [-500, 500])")
    fig.suptitle("Cross-method Horizontal Comparison of AMT Relative Gains")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_9_amt_gain_heatmap")


def plot_all_strategy_equity_curves(result_root: Path, main_df: pd.DataFrame, output_dir: Path) -> dict[str, str]:
    directions = ["CN->US", "US->CN"]
    fig, axes = plt.subplots(1, 2, figsize=(15.0, 5.6), sharey=False)
    for ax, direction in zip(axes, directions):
        direction_df = main_df[main_df["direction"] == direction].copy()
        direction_dir = direction.lower().replace("->", "_to_")
        for _, row in direction_df.iterrows():
            model_name = row["model"]
            curve_path = result_root / MAIN_ROOT / direction_dir / model_name / "equity_curve.csv"
            curve_df = load_equity_curve(curve_path)
            label = display_model_name(model_name)
            line_width = 2.2 if model_name == AMT_NAME else 1.3
            alpha = 1.0 if model_name == AMT_NAME else 0.85
            color = AMT_COLOR if model_name == AMT_NAME else None
            ax.plot(curve_df["date"], curve_df["nav"], label=label, linewidth=line_width, alpha=alpha, color=color)
        ax.set_title(f"{direction} | PnL / NAV Curves")
        ax.set_xlabel("Date")
        ax.set_ylabel("Net Asset Value")
        ax.legend(frameon=False, ncol=2)
    fig.suptitle("AMT vs All Strategies: PnL / NAV Comparison")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_10_amt_vs_all_pnl_curves")


def plot_amt_vs_direct_transfer_curves(result_root: Path, transfer_df: pd.DataFrame, output_dir: Path) -> dict[str, str]:
    directions = ["CN->US", "US->CN"]
    fig, axes = plt.subplots(1, 2, figsize=(15.2, 5.8), sharey=False)
    for ax, direction in zip(axes, directions):
        direction_df = transfer_df[transfer_df["direction"] == direction].copy()
        direction_dir = direction.lower().replace("->", "_to_")
        direction_df = direction_df[direction_df["model"].isin(["direct_transfer", "amt"])].copy()
        order = ["direct_transfer", "amt"]
        direction_df["order"] = direction_df["model"].map({name: idx for idx, name in enumerate(order)}).fillna(999)
        direction_df = direction_df.sort_values("order")
        for _, row in direction_df.iterrows():
            model_name = row["model"]
            curve_path = result_root / TRANSFER_FAMILY_ROOT / direction_dir / model_name / "equity_curve.csv"
            if not curve_path.exists():
                continue
            curve_df = load_equity_curve(curve_path)
            label = display_model_name(model_name)
            is_amt = model_name == "amt"
            ax.plot(
                curve_df["date"],
                curve_df["nav"],
                label=label,
                linewidth=2.4 if is_amt else 1.35,
                alpha=1.0 if is_amt else 0.88,
                color=AMT_COLOR if is_amt else None,
            )
        ax.set_title(f"{direction} | Direct Transfer vs AMT")
        ax.set_xlabel("Date")
        ax.set_ylabel("Net Asset Value")
        ax.legend(frameon=False, ncol=2)
    fig.suptitle("AMT vs Direct Transfer: Unified Baseline NAV Comparison")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_11_amt_vs_direct_transfer_curves")


def plot_transfer_only_equity_curves(result_root: Path, transfer_df: pd.DataFrame, output_dir: Path) -> dict[str, str]:
    directions = ["CN->US", "US->CN"]
    fig, axes = plt.subplots(1, 2, figsize=(15.2, 5.8), sharey=False)
    transfer_only_order = ["lstm_transfer", "transformer_transfer", "tra_transfer", "hist_transfer", "amt"]
    order_index = {name: idx for idx, name in enumerate(transfer_only_order)}
    for ax, direction in zip(axes, directions):
        direction_df = transfer_df[transfer_df["direction"] == direction].copy()
        direction_dir = direction.lower().replace("->", "_to_")
        direction_df = direction_df[direction_df["model"].isin(transfer_only_order)].copy()
        direction_df["order"] = direction_df["model"].map(order_index).fillna(999)
        direction_df = direction_df.sort_values("order")
        for _, row in direction_df.iterrows():
            model_name = row["model"]
            curve_path = result_root / TRANSFER_FAMILY_ROOT / direction_dir / model_name / "equity_curve.csv"
            if not curve_path.exists():
                continue
            curve_df = load_equity_curve(curve_path)
            is_amt = model_name == "amt"
            ax.plot(
                curve_df["date"],
                curve_df["nav"],
                label=display_model_name(model_name),
                linewidth=2.4 if is_amt else 1.35,
                alpha=1.0 if is_amt else 0.88,
                color=AMT_COLOR if is_amt else None,
            )
        ax.set_title(f"{direction} | Transfer-only NAV Curves")
        ax.set_xlabel("Date")
        ax.set_ylabel("Net Asset Value")
        ax.legend(frameon=False, ncol=2)
    fig.suptitle("AMT vs Transfer-family Models: Transfer-only NAV Comparison")
    fig.tight_layout()
    return save_figure(fig, output_dir, "figure_12_transfer_only_pnl_curves")


def write_advantage_report(
    output_dir: Path,
    main_df: pd.DataFrame,
    gain_df: pd.DataFrame,
    significance_df: pd.DataFrame,
    future_report: dict[str, Any],
) -> Path:
    lines = [
        "# AMT 方法优劣势分析（2026-07-15）",
        "",
        "## 1. 分析范围",
        "",
        "- 主实验范围：`full_20260715_070111/主实验/phase1_transfer/`。",
        "- future 辅助实验范围：`full_20260715_070111/对比实验/compare_models/` 与 `future_hgnn_time_report.json`。",
        "- 统计显著性口径：基于测试期按日对齐的 `RankIC` 与 `TopKReturn` 做配对 t 检验；若样本不足或指标日序列为空，则记为 `N/A`。",
        "",
        "## 2. 已验证优势条目",
        "",
    ]

    if main_df.empty:
        lines.append("- 当前批次未包含旧主实验汇总，因此本报告仅保留迁移家族出图说明，不展开旧主实验优劣势比较。")
        report_path = output_dir / "AMT_优劣势分析_20260715.md"
        report_path.write_text("\n".join(lines), encoding="utf-8")
        return report_path

    verified_advantages: list[str] = []
    for _, row in significance_df.iterrows():
        if row["rankic_significance"] in {"*", "**"} and row["rankic_mean_diff"] > 0:
            verified_advantages.append(
                f"- `{row['direction']}` 上，AMT 相对 `{display_model_name(row['baseline'])}` 的日度 `RankIC` 均值差为 `{row['rankic_mean_diff']:.4f}`，`p={row['rankic_p_value']:.4f}`。"
            )
        if row["topk_return_significance"] in {"*", "**"} and row["topk_return_mean_diff"] > 0:
            verified_advantages.append(
                f"- `{row['direction']}` 上，AMT 相对 `{display_model_name(row['baseline'])}` 的日度 `TopKReturn` 均值差为 `{row['topk_return_mean_diff']:.5f}`，`p={row['topk_return_p_value']:.4f}`。"
            )

    if verified_advantages:
        lines.extend(verified_advantages)
    else:
        lines.append("- 当前 `full` 主实验中，尚未检出 AMT 对主要 baseline 的稳定显著优势；已生成显著性摘要图和表，供后续定位原因。")

    lines.extend(["", "## 3. 未体现优势的维度与原因分析", ""])
    for direction, direction_df in main_df.groupby("direction"):
        amt_row = direction_df[direction_df["model"] == AMT_NAME].iloc[0]
        best_rankic_row = direction_df.sort_values("RankIC", ascending=False).iloc[0]
        best_sharpe_row = direction_df.sort_values("Sharpe Ratio", ascending=False).iloc[0]
        lines.append(f"### 3.{1 if direction == 'CN->US' else 2} {direction}")
        if best_rankic_row["model"] != AMT_NAME:
            lines.append(
                f"- 排序能力未占优：AMT 的 `RankIC={amt_row['RankIC']:.4f}`，低于 `{display_model_name(best_rankic_row['model'])}` 的 `{best_rankic_row['RankIC']:.4f}`。"
            )
            lines.append("- 原因分析：跨市场迁移后信号排序能力偏弱，说明当前迁移表示未稳定提升横截面区分度。")
        if best_sharpe_row["model"] != AMT_NAME:
            lines.append(
                f"- 风险调整收益未占优：AMT 的 `Sharpe Ratio={amt_row['Sharpe Ratio']:.4f}`，低于 `{display_model_name(best_sharpe_row['model'])}` 的 `{best_sharpe_row['Sharpe Ratio']:.4f}`。"
            )
            lines.append("- 原因分析：当前参数配置更偏向“稳定跑通”，尚未针对收益曲线和持仓排序做专门调优。")
        lines.append("- 场景限制：当前对比口径含 `US->CN` 小股票池场景，`Avg Daily Universe` 偏低，容易放大模型塌缩与排序抖动。")
        lines.append("- 方法局限：AMT 目前更像可运行的迁移框架，距离显著优于树模型/线性模型还缺少更强的标签对齐与域间约束。")
        lines.append("")

    lines.extend(["## 4. future 辅助实验观察", ""])
    cn_future_identity = future_report["sthgcn_bidirectional"]["cn_to_future"]["identity"]["metrics"]
    cn_future_hyper = future_report["sthgcn_bidirectional"]["cn_to_future"]["hypergraph"]["metrics"]
    fut_cn_identity = future_report["sthgcn_bidirectional"]["future_to_cn"]["identity"]["metrics"]
    fut_cn_hyper = future_report["sthgcn_bidirectional"]["future_to_cn"]["hypergraph"]["metrics"]
    lines.append(
        f"- `CN->FUTURE` 原始 full 结果中，`hypergraph` 的 `Annualized Return={cn_future_hyper['Annualized Return']:.4f}` 高于 `identity={cn_future_identity['Annualized Return']:.4f}`，但 `identity` 的排序指标在后续复现中已恢复，因此该优势当前只能视为“待稳定复核”，不能直接记为稳定优势。"
    )
    lines.append(
        f"- `FUTURE->CN` 中，`identity` 与 `hypergraph` 的收益指标几乎一致，且排序指标均为 `NaN`，当前不能据此宣称 future 超图分支在该方向具有优势。"
    )
    lines.append("")
    lines.extend(["## 5. 结论与建议", ""])
    lines.append("- 结论 1：当前最清晰的结果不是“AMT 已全面领先”，而是“AMT 已在 full 口径下稳定闭环并形成可审计的对比证据”。")
    lines.append("- 结论 2：主实验中 AMT 尚未建立稳定统计优势，应重点回到标签对齐、预测方差、防塌缩训练与跨域约束设计。")
    lines.append("- 结论 3：future 模块需先解决 `FUTURE->CN` 的常数预测问题，再讨论超图结构是否真正提升排序能力。")

    report_path = output_dir / "AMT_优劣势分析_20260715.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


def write_notes(
    output_dir: Path,
    gain_df: pd.DataFrame,
    transfer_gain_df: pd.DataFrame,
    significance_df: pd.DataFrame,
    future_report: dict[str, Any],
    figures: dict[str, dict[str, str]],
    advantage_report_path: Path,
) -> Path:
    lines = [
        "# AAAI 图表说明（增强版）",
        "",
        "## 1. 使用边界",
        "",
        "- 本次增强版图表新增了 AMT 相对各 baseline 的差值、百分比增益和显著性摘要。",
        "- 若存在统一初始化条件下的迁移家族结果，则同步生成迁移家族专属增益表与专属净值曲线图。",
        "- 所有百分比增益都直接来自原始指标，不引入新评价体系。",
        "- `statistically significant` 仅用于已实际完成配对检验的日度 `RankIC` / `TopKReturn`；若条件不满足则明确标注 `N/A`，不做伪造推断。",
        "- `figure_11` 专门比较 `Direct Transfer vs AMT`，用于隔离“是否需要机理保持适配”的增益来源。",
        "- `figure_12` 仅保留 `AMT / TRA / HIST / Transformer / LSTM`，用于展示 AMT 相对其他迁移类模型的净值增长轨迹。",
        "",
        "## 2. 结果口径",
        "",
        f"- 主实验 AMT 对应方法名：`{AMT_NAME}`，图中统一显示为 `AMT`。",
        f"- 增益表路径：`{output_dir / 'amt_main_gain_table.csv'}`。",
        f"- 迁移家族增益表路径：`{output_dir / 'amt_transfer_family_gain_table.csv'}`。",
        f"- 显著性摘要表路径：`{output_dir / 'amt_significance_summary.csv'}`。",
        f"- 优劣势分析文档：`{advantage_report_path}`。",
        "",
        "## 3. 当前可直接引用的结论",
        "",
        "- 主实验中，AMT 目前主要体现为“已稳定跑通并保留可解释对比证据”，而非“对主要 baseline 建立稳定显著优势”。",
        "- 在统一基准初始化条件下，`figure_11` 用于回答“AMT 相比 Direct Transfer 是否因为参数高效适配和机理保持而带来额外净值增益”。",
        "- `figure_12` 则剔除非迁移原生模型与 Direct Transfer，只保留迁移类深度模型，避免旧主实验中不同 backbone 混写带来的解释歧义。",
        "- future 原始 full 结果中 `CN->FUTURE` 的超图分支显示出更高收益，但该优势尚需与 clean 复核结果一并判断，不能孤立夸大。",
        "- future `FUTURE->CN` 当前首要问题不是收益曲线，而是预测方差塌缩导致排序指标不可定义。",
        "",
        "## 4. 图表文件",
        "",
    ]
    if gain_df.empty:
        lines.append("- 当前批次未包含旧主实验汇总，因此 `amt_main_gain_table.csv` 可能为空。")
    if transfer_gain_df.empty:
        lines.append("- 当前批次未包含完整迁移家族汇总，因此 `amt_transfer_family_gain_table.csv` 可能为空。")
    for name, paths in figures.items():
        lines.append(f"- `{name}`: `{paths['png']}` / `{paths['pdf']}`")
    notes_path = output_dir / "aaai_figure_notes_enhanced.md"
    notes_path.write_text("\n".join(lines), encoding="utf-8")
    return notes_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成 AMT 增强版论文图表与优劣势分析")
    parser.add_argument("--result-root", default=str(DEFAULT_RESULT_ROOT))
    return parser.parse_args()


def main() -> int:
    apply_style()
    args = parse_args()
    result_root = Path(args.result_root).resolve()
    output_dir = result_root / OUTPUT_DIRNAME
    ensure_dir(output_dir)

    main_df = load_main_summary(result_root)
    transfer_family_df = load_transfer_family_summary(result_root)
    main_daily = build_main_daily_metrics(result_root, main_df)
    gain_df = build_gain_table(main_df)
    transfer_gain_df = build_transfer_family_gain_table(transfer_family_df)
    significance_df = build_significance_table(main_df, main_daily)
    future_report = load_future_report(result_root)

    gain_csv = output_dir / "amt_main_gain_table.csv"
    transfer_gain_csv = output_dir / "amt_transfer_family_gain_table.csv"
    significance_csv = output_dir / "amt_significance_summary.csv"
    gain_df.to_csv(gain_csv, index=False, encoding="utf-8-sig")
    transfer_gain_df.to_csv(transfer_gain_csv, index=False, encoding="utf-8-sig")
    significance_df.to_csv(significance_csv, index=False, encoding="utf-8-sig")

    figures: dict[str, dict[str, str]] = {}
    if not main_df.empty:
        figures["main_rankic_gain"] = plot_main_metric_with_gain(
            main_df, gain_df, metric="RankIC", gain_metric="RankIC_GainPct", title="AMT RankIC and Relative Gain", output_dir=output_dir, stem="figure_5_amt_rankic_gain"
        )
        figures["main_sharpe_gain"] = plot_main_metric_with_gain(
            main_df, gain_df, metric="Sharpe Ratio", gain_metric="Sharpe_GainPct", title="AMT Sharpe and Relative Gain", output_dir=output_dir, stem="figure_6_amt_sharpe_gain"
        )
        figures["significance_cards"] = plot_significance_cards(significance_df, output_dir)
        figures["gain_heatmap"] = plot_gain_heatmap(gain_df, output_dir)
        figures["all_strategy_pnl_curves"] = plot_all_strategy_equity_curves(result_root, main_df, output_dir)
    figures["future_delta_status"] = plot_future_status(future_report, output_dir)
    if not transfer_family_df.empty:
        figures["amt_vs_direct_transfer_curves"] = plot_amt_vs_direct_transfer_curves(result_root, transfer_family_df, output_dir)
        figures["transfer_only_pnl_curves"] = plot_transfer_only_equity_curves(result_root, transfer_family_df, output_dir)

    advantage_report_path = write_advantage_report(output_dir, main_df, gain_df, significance_df, future_report)
    notes_path = write_notes(output_dir, gain_df, transfer_gain_df, significance_df, future_report, figures, advantage_report_path)
    manifest_path = output_dir / "amt_visual_audit_manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "gain_table": str(gain_csv),
                "transfer_gain_table": str(transfer_gain_csv),
                "significance_table": str(significance_csv),
                "advantage_report": str(advantage_report_path),
                "notes_path": str(notes_path),
                "figures": figures,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "output_dir": str(output_dir),
                "gain_table": str(gain_csv),
                "transfer_gain_table": str(transfer_gain_csv),
                "significance_table": str(significance_csv),
                "advantage_report": str(advantage_report_path),
                "notes_path": str(notes_path),
                "manifest_path": str(manifest_path),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
