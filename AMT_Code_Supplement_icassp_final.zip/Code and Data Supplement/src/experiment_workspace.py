"""
文件功能:
1. 统一管理本次实验开发与部署所需的根目录、数据目录、日志目录和结果目录。
2. 为本地与任意远程服务器提供一致的路径解析接口, 不再依赖特定机器代号。
3. 为后续分布式 demo、主实验调度器和 baseline 适配批处理提供通用的文件写入工具。

代码逻辑:
1. 根据当前文件位置自动回溯项目根目录, 避免脚本因工作目录变化而找不到数据。
2. 将 `resultsFromSSH/<server_name>/log` 与 `resultsFromSSH/<server_name>/results` 统一封装为运行时输出根路径。
3. 提供 JSON / 文本写出、目录创建和时间戳生成函数, 让所有新脚本共享相同的落盘规范。

代码结构:
1. 常量与路径数据类。
2. 运行时路径解析函数。
3. 通用文件写入与复制工具函数。
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime
import os
from pathlib import Path
import re
import socket
import shutil
from typing import Any


ROOT_DIR = Path(__file__).resolve().parents[1]
CODE_DIR = ROOT_DIR / "code"
DATA_TO_SERVER_DIR = ROOT_DIR / "DataToSever"
THIRD_PARTY_DIR = ROOT_DIR / "third_party"
RESULTS_DIR = ROOT_DIR / "results"
RESULTS_FROM_SSH_DIR = ROOT_DIR / "resultsFromSSH"
LOCAL_SERVER_NAME = "local"
DEFAULT_SERVER_NAME = "auto"
RUN_TIMESTAMP_ENV = "AMT_RUN_TIMESTAMP"
ARCHIVE_PREFIX_ENV = "AMT_ARCHIVE_PREFIX"
_RUN_TIMESTAMP: str | None = None
_RESOLVED_OUTPUT_PATHS: dict[str, Path] = {}
STAMPED_FILE_RE = re.compile(r"^(?P<stem>.+)_(?P<stamp>\d{8}_\d{6})$")
BATCH_DIR_RE = re.compile(r"^(?P<prefix>full|medium|smoke|demo)_(?P<stamp>\d{8}_\d{6})$")
RESULT_CATEGORY_DIRS = {
    "main": "主实验",
    "baseline": "对比实验",
    "ablation": "消融实验",
    "other": "其他",
}


@dataclass(frozen=True)
class RuntimePaths:
    server_name: str
    root_dir: Path
    code_dir: Path
    data_dir: Path
    third_party_dir: Path
    project_results_dir: Path
    server_root_dir: Path
    archive_dir: Path
    log_dir: Path
    result_dir: Path
    mirror_root_dir: Path
    mirror_log_dir: Path
    mirror_result_dir: Path

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        return {key: str(value) if isinstance(value, Path) else value for key, value in payload.items()}


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def now_string() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def format_run_timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def get_run_timestamp() -> str:
    global _RUN_TIMESTAMP
    if _RUN_TIMESTAMP:
        return _RUN_TIMESTAMP
    env_value = str(os.environ.get(RUN_TIMESTAMP_ENV, "")).strip()
    if env_value:
        _RUN_TIMESTAMP = env_value
    else:
        _RUN_TIMESTAMP = format_run_timestamp()
        os.environ[RUN_TIMESTAMP_ENV] = _RUN_TIMESTAMP
    return _RUN_TIMESTAMP


def get_archive_prefix() -> str:
    env_value = str(os.environ.get(ARCHIVE_PREFIX_ENV, "")).strip().lower()
    if env_value in {"demo", "medium", "smoke", "full"}:
        return env_value
    return "full"


def get_archive_name() -> str:
    return f"{get_archive_prefix()}_{get_run_timestamp()}"


def get_archive_root() -> Path:
    return ensure_dir(RESULTS_DIR / get_archive_name())


def parse_batch_timestamp(path: Path) -> str:
    match = BATCH_DIR_RE.match(path.name)
    if not match:
        return ""
    return str(match.group("stamp"))


def is_result_batch_dir(path: Path) -> bool:
    return path.is_dir() and BATCH_DIR_RE.match(path.name) is not None


def infer_batch_root_from_path(path: Path) -> Path | None:
    current = path.resolve()
    if is_result_batch_dir(current):
        return current
    for parent in current.parents:
        if is_result_batch_dir(parent):
            return parent
    return None


def find_latest_batch_root(prefix: str = "full", required_relative_path: tuple[str, ...] | None = None) -> Path:
    normalized = str(prefix).strip().lower()
    if normalized not in {"full", "medium", "smoke", "demo"}:
        raise ValueError(f"未知批次前缀: {prefix}")
    candidates: list[Path] = []
    for batch_dir in RESULTS_DIR.glob(f"{normalized}_*"):
        if not is_result_batch_dir(batch_dir):
            continue
        if required_relative_path is not None and not batch_dir.joinpath(*required_relative_path).exists():
            continue
        candidates.append(batch_dir)
    if not candidates:
        suffix = "/".join(required_relative_path or tuple())
        raise FileNotFoundError(f"未找到满足条件的 {normalized}_* 结果批次: {suffix}")
    candidates.sort(key=parse_batch_timestamp, reverse=True)
    return candidates[0]


def get_latest_batch_root(prefix: str = "full") -> Path:
    normalized = str(prefix).strip().lower()
    if normalized not in {"full", "medium", "smoke", "demo"}:
        raise ValueError(f"未知批次前缀: {prefix}")
    candidates = [path for path in RESULTS_DIR.glob(f"{normalized}_*") if is_result_batch_dir(path)]
    if not candidates:
        raise FileNotFoundError(f"未找到任何 {normalized}_* 结果批次。")
    candidates.sort(key=parse_batch_timestamp, reverse=True)
    return candidates[0]


def get_latest_completed_batch_root(prefix: str = "full") -> Path:
    normalized = str(prefix).strip().lower()
    if normalized not in {"full", "medium", "smoke", "demo"}:
        raise ValueError(f"未知批次前缀: {prefix}")
    manifest_name = f"experiment_pipeline_{normalized}_manifest.json"
    candidates = [
        path for path in RESULTS_DIR.glob(f"{normalized}_*")
        if is_result_batch_dir(path) and (path / manifest_name).exists()
    ]
    if not candidates:
        raise FileNotFoundError(f"未找到任何带 `{manifest_name}` 的 {normalized}_* 已完成结果批次。")
    candidates.sort(key=parse_batch_timestamp, reverse=True)
    return candidates[0]


def require_batch_artifacts(batch_root: Path, required_relative_paths: tuple[tuple[str, ...], ...]) -> Path:
    missing_paths = ["/".join(parts) for parts in required_relative_paths if not batch_root.joinpath(*parts).exists()]
    if missing_paths:
        missing_text = "；".join(missing_paths)
        raise FileNotFoundError(
            f"批次 `{batch_root.name}` 缺少以下必需产物：{missing_text}。"
            "为避免后续脚本自动回退到旧批次并污染论文取数，本次停止继续执行。"
        )
    return batch_root


def get_paper_asset_root(batch_root_or_result_path: Path, paper_name: str = "AAAI V2") -> Path:
    batch_root = infer_batch_root_from_path(batch_root_or_result_path)
    if batch_root is None:
        raise ValueError(f"无法从路径解析结果批次根目录: {batch_root_or_result_path}")
    return ensure_dir(batch_root / "论文素材" / paper_name)


def get_paper_asset_path(batch_root_or_result_path: Path, *parts: str, paper_name: str = "AAAI V2") -> Path:
    asset_root = get_paper_asset_root(batch_root_or_result_path=batch_root_or_result_path, paper_name=paper_name)
    if not parts:
        return asset_root
    return asset_root.joinpath(*parts)


def sanitize_server_name(raw_value: str) -> str:
    text = str(raw_value).strip()
    if not text:
        return ""
    text = re.sub(r"[\\/:*?\"<>|]+", "_", text)
    text = re.sub(r"\s+", "_", text)
    return text.strip("._-")


def resolve_server_name(server_name: str | None = None) -> str:
    explicit = sanitize_server_name(server_name or "")
    if explicit:
        return explicit
    env_value = sanitize_server_name(os.environ.get("AMT_SERVER_NAME", ""))
    if env_value:
        return env_value
    try:
        hostname = sanitize_server_name(socket.gethostname())
    except OSError:
        hostname = ""
    return hostname or LOCAL_SERVER_NAME


def resolve_output_path(path: Path) -> Path:
    logical_path = str(path.resolve())
    resolved = _RESOLVED_OUTPUT_PATHS.get(logical_path)
    if resolved is not None:
        ensure_dir(resolved.parent)
        return resolved

    candidate = path
    if candidate.exists():
        stamp = get_run_timestamp()
        candidate = candidate.with_name(f"{candidate.stem}_{stamp}{candidate.suffix}")
    ensure_dir(candidate.parent)
    _RESOLVED_OUTPUT_PATHS[logical_path] = candidate
    return candidate


def find_latest_output_path(path: Path) -> Path:
    logical_path = str(path.resolve())
    resolved = _RESOLVED_OUTPUT_PATHS.get(logical_path)
    if resolved is not None and resolved.exists():
        return resolved

    candidates: list[Path] = []
    if path.exists():
        candidates.append(path)
    if path.parent.exists():
        for candidate in path.parent.glob(f"{path.stem}_*{path.suffix}"):
            match = STAMPED_FILE_RE.match(candidate.stem)
            if match and match.group("stem") == path.stem:
                candidates.append(candidate)
    if not candidates:
        return path

    def candidate_key(item: Path) -> tuple[int, str, float]:
        match = STAMPED_FILE_RE.match(item.stem)
        stamp = match.group("stamp") if match and match.group("stem") == path.stem else ""
        return (1 if stamp else 0, stamp, item.stat().st_mtime)

    return max(candidates, key=candidate_key)


def build_runtime_paths(server_name: str | None = None) -> RuntimePaths:
    normalized = resolve_server_name(server_name)
    server_root = ensure_dir(RESULTS_FROM_SSH_DIR / normalized)
    archive_root = ensure_dir(get_archive_root())
    log_dir = ensure_dir(ROOT_DIR / "logs" / get_archive_name())
    result_dir = archive_root
    mirror_root = ensure_dir(server_root / get_archive_name())
    mirror_log_dir = ensure_dir(mirror_root / "log")
    mirror_result_dir = ensure_dir(mirror_root / "results")
    return RuntimePaths(
        server_name=normalized,
        root_dir=ROOT_DIR,
        code_dir=CODE_DIR,
        data_dir=DATA_TO_SERVER_DIR,
        third_party_dir=THIRD_PARTY_DIR,
        project_results_dir=RESULTS_DIR,
        server_root_dir=server_root,
        archive_dir=archive_root,
        log_dir=log_dir,
        result_dir=result_dir,
        mirror_root_dir=mirror_root,
        mirror_log_dir=mirror_log_dir,
        mirror_result_dir=mirror_result_dir,
    )


def get_categorized_results_root(category: str) -> Path:
    normalized = str(category).strip().lower()
    if normalized not in RESULT_CATEGORY_DIRS:
        raise ValueError(f"未知结果分类: {category}")
    return ensure_dir(get_archive_root() / RESULT_CATEGORY_DIRS[normalized])


def get_categorized_result_path(category: str, *parts: str) -> Path:
    root = get_categorized_results_root(category)
    if not parts:
        return root
    return root.joinpath(*parts)


def write_json(path: Path, payload: dict[str, Any] | list[Any]) -> Path:
    target_path = resolve_output_path(path)
    target_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target_path


def write_text(path: Path, content: str) -> Path:
    target_path = resolve_output_path(path)
    target_path.write_text(content, encoding="utf-8")
    return target_path


def write_dataframe(
    dataframe: Any,
    path: Path,
    *,
    index: bool = False,
    encoding: str = "utf-8-sig",
    **kwargs: Any,
) -> Path:
    target_path = resolve_output_path(path)
    dataframe.to_csv(target_path, index=index, encoding=encoding, **kwargs)
    return target_path


def append_log(path: Path, message: str) -> Path:
    ensure_dir(path.parent)
    with path.open("a", encoding="utf-8") as fp:
        fp.write(f"[{now_string()}] {message}\n")
    return path


def copy_path(src: Path, dst: Path) -> Path:
    if src.is_dir():
        ensure_dir(dst)
        for child in src.rglob("*"):
            relative = child.relative_to(src)
            target_child = dst / relative
            if child.is_dir():
                ensure_dir(target_child)
            else:
                resolved_target = resolve_output_path(target_child)
                shutil.copy2(child, resolved_target)
        return dst

    resolved_dst = resolve_output_path(dst)
    shutil.copy2(src, resolved_dst)
    return resolved_dst


def _reset_output_registry_for_tests() -> None:
    global _RUN_TIMESTAMP
    _RUN_TIMESTAMP = None
    _RESOLVED_OUTPUT_PATHS.clear()
    os.environ.pop(RUN_TIMESTAMP_ENV, None)
    os.environ.pop(ARCHIVE_PREFIX_ENV, None)
