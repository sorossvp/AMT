"""
文件功能:
1. 面向论文正文与附录, 将任意多条已落盘的 `equity_curve.csv` 净值曲线绘制为统一风格的对比图。
2. 支持直接从实验批次结果中选取若干方法的净值曲线, 输出适合 AAAI 论文插图使用的 PNG 图像。
3. 允许通过命令行灵活指定标题、图例名称、坐标轴标签、是否使用对数纵轴以及输出文件名。

代码逻辑:
1. 解析命令行传入的多组 `标签=曲线路径` 参数, 逐条读取净值曲线。
2. 对日期列和净值列做统一清洗, 并按时间顺序绘制多条曲线。
3. 自动在图中标记各条曲线的终点净值, 提升论文插图的可读性。
4. 将图像保存到指定目录, 便于后续复制到 `paper/AAAI V2/assets/` 作为正文图。

代码结构:
1. 参数解析与输入校验。
2. 曲线读取与格式清洗。
3. Matplotlib 绘图与终点标注。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import pandas as pd


DEFAULT_COLORS = [
    "#d62728",
    "#1f77b4",
    "#2ca02c",
    "#9467bd",
    "#ff7f0e",
    "#8c564b",
]


def parse_curve_arg(raw_value: str) -> tuple[str, Path]:
    if "=" not in raw_value:
        raise ValueError(f"曲线参数格式错误, 期望 `label=path`: {raw_value}")
    label, raw_path = raw_value.split("=", 1)
    label = str(label).strip()
    curve_path = Path(raw_path).expanduser().resolve()
    if not label:
        raise ValueError(f"曲线标签不能为空: {raw_value}")
    if not curve_path.exists():
        raise FileNotFoundError(f"曲线文件不存在: {curve_path}")
    return label, curve_path


def load_curve(curve_path: Path) -> pd.DataFrame:
    df = pd.read_csv(curve_path)
    if "date" not in df.columns or "nav" not in df.columns:
        raise ValueError(f"曲线文件缺少 `date/nav` 列: {curve_path}")
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["nav"] = pd.to_numeric(df["nav"], errors="coerce")
    df = df.dropna(subset=["date", "nav"]).sort_values("date").reset_index(drop=True)
    if df.empty:
        raise ValueError(f"曲线文件为空或无有效数据: {curve_path}")
    return df


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="绘制论文级净值对比图")
    parser.add_argument("--curve", action="append", required=True, help="格式: label=/abs/path/to/equity_curve.csv")
    parser.add_argument("--title", default="Equity Curve Comparison")
    parser.add_argument("--ylabel", default="Net Asset Value")
    parser.add_argument("--output", required=True, help="输出 PNG 绝对路径")
    parser.add_argument("--log-scale", action="store_true", help="是否使用对数纵轴")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    curve_specs = [parse_curve_arg(item) for item in args.curve]
    output_path = Path(args.output).expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    plt.rcParams.update(
        {
            "figure.dpi": 180,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": True,
            "grid.alpha": 0.25,
            "grid.linestyle": "--",
            "font.size": 10,
        }
    )

    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    for index, (label, curve_path) in enumerate(curve_specs):
        curve_df = load_curve(curve_path)
        color = DEFAULT_COLORS[index % len(DEFAULT_COLORS)]
        ax.plot(curve_df["date"], curve_df["nav"], label=label, linewidth=2.2, color=color)
        last_row = curve_df.iloc[-1]
        ax.scatter(last_row["date"], last_row["nav"], s=18, color=color, zorder=4)
        ax.annotate(
            f"{float(last_row['nav']):.2f}",
            xy=(last_row["date"], last_row["nav"]),
            xytext=(4, 2),
            textcoords="offset points",
            fontsize=9,
            color=color,
        )

    if args.log_scale:
        ax.set_yscale("log")
    ax.set_title(str(args.title))
    ax.set_ylabel(str(args.ylabel))
    ax.set_xlabel("Date")
    ax.legend(loc="upper left")
    ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=5, maxticks=9))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    plt.setp(ax.get_xticklabels(), rotation=20, ha="right")
    fig.tight_layout()
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)
    print(str(output_path))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
