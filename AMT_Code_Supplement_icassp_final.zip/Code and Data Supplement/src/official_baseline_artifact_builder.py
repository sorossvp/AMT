"""
文件功能:
1. 为 AlphaMechTransfer 的第三方官方 baseline 生成“外层最小适配”所需的数据资产与运行说明。
2. 严格保留官方仓库核心逻辑不变, 仅导出数据入口、文件路径、标签规则和结果保存所需的外围文件。
3. 将项目统一的 `processed_data` 缓存转换为 HIST / MASTER / ADGAT / QuantNet / Qlib 类 baseline 可消费的外层资产。
4. 为后续本地执行或 8x4090 服务器批量调度生成结构化 manifest 与 Markdown 说明。

代码逻辑:
1. 读取 `DataToSever/processed_data/{market}` 下的标准化面板和超图 incidence。
2. 按统一论文划分规则切分 train / valid / test, 保持标签口径为未来 5 日截面收益排序。
3. 根据 baseline 类型分别导出最小必需资产:
   - qlib_like: 给 TRA / DoubleAdapt 提供统一面板、路径和说明。
   - hist_like: 生成特征、标签、市值、stock_index、stock2concept 等外围文件。
   - master_like: 生成按 split 划分的多索引特征面板与市场信息文件。
   - adgat_like: 生成数值张量、零文本张量和基于超图重叠的关系矩阵。
   - quantnet_like: 生成按市场拆分的收益矩阵任务文件。
4. 将所有输出写入 `results/official_baseline_artifacts/{direction}/{baseline}/`。

代码结构:
1. 基础常量、baseline 注册表与路径工具。
2. 通用数据读取、切分和张量/矩阵构建函数。
3. 各 baseline 类型的导出函数。
4. CLI 入口, 支持单 baseline 单方向构建。
"""

from __future__ import annotations

import argparse
import gzip
import json
import pickle
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from data_pipeline import read_pickle_with_recovery
from experiment_profiles import get_profile, profile_to_dict, resolve_max_symbols, truncate_panel_by_profile
from experiment_workspace import get_categorized_result_path, resolve_output_path, write_dataframe, write_json as workspace_write_json, write_text


ROOT_DIR = Path(__file__).resolve().parents[1]
PROCESSED_DIR = ROOT_DIR / "DataToSever" / "processed_data"
ARTIFACT_ROOT = get_categorized_result_path("baseline", "official_baseline_artifacts")
OFFICIAL_DIR = ROOT_DIR / "third_party" / "official_baselines"

SPLIT_DATES = {
    "train_start": "2008-01-01",
    "train_end": "2021-12-31",
    "valid_start": "2022-01-01",
    "valid_end": "2022-12-31",
    "test_start": "2023-01-01",
    "test_end": "2025-12-31",
}

COMMON_FEATURE_COLUMNS = [
    "open",
    "high",
    "low",
    "close",
    "volume",
    "ret_1",
    "ret_5",
    "ret_10",
    "ret_20",
    "vol_5",
    "vol_20",
    "vol_60",
    "ma_ratio_5_20",
    "ma_ratio_20_60",
    "hl_spread",
    "oc_return",
    "turnover_proxy",
    "log_dollar_volume",
    "volume_momentum_20",
    "reversal_5",
    "alpha_momentum",
    "alpha_reversal",
    "alpha_volume_price",
    "alpha_breakout",
    "alpha_liquidity",
    "alpha_intraday",
]

MASTER_MARKET_FEATURE_COLUMNS = [
    "ret_1",
    "ret_5",
    "ret_10",
    "ret_20",
    "vol_5",
    "vol_20",
    "vol_60",
]

ADGAT_NUMERIC_COLUMNS = [
    "close",
    "volume",
    "ret_1",
    "ret_5",
    "ret_20",
    "vol_20",
]

QUANTNET_RETURN_COLUMN = "future_return"
LABEL_COLUMN = "label_rank_proxy"


@dataclass(frozen=True)
class BaselineProfile:
    name: str
    repo_dir: str
    artifact_style: str
    supports_cross_market: bool
    supports_cross_asset: bool
    appendix_only: bool
    notes: str


BASELINE_PROFILES: dict[str, BaselineProfile] = {
    "TRA": BaselineProfile(
        name="TRA",
        repo_dir="qlib-main  TRA/qlib-main",
        artifact_style="qlib_like",
        supports_cross_market=True,
        supports_cross_asset=True,
        appendix_only=False,
        notes="官方 benchmark 依赖 Qlib 环境, 当前导出统一 panel 资产与启动说明。",
    ),
    "DoubleAdapt": BaselineProfile(
        name="DoubleAdapt",
        repo_dir="DoubleAdapt-main/DoubleAdapt-main",
        artifact_style="qlib_like",
        supports_cross_market=True,
        supports_cross_asset=True,
        appendix_only=False,
        notes="官方实现明确允许重写 _load_data / _evaluate_metrics, 当前仅生成外层适配资产。",
    ),
    "QuantNet": BaselineProfile(
        name="QuantNet",
        repo_dir="quantnet-main/quantnet-main",
        artifact_style="quantnet_like",
        supports_cross_market=True,
        supports_cross_asset=True,
        appendix_only=False,
        notes="导出收益矩阵任务文件, 保持 QuantNet 原有系统化交易任务设定。",
    ),
    "HIST": BaselineProfile(
        name="HIST",
        repo_dir="HIST-main/HIST-main",
        artifact_style="hist_like",
        supports_cross_market=True,
        supports_cross_asset=True,
        appendix_only=False,
        notes="同时为 HIST / LSTM / Transformer 复用同一组外围数据文件。",
    ),
    "MASTER": BaselineProfile(
        name="MASTER",
        repo_dir="MASTER-master/MASTER-master",
        artifact_style="master_like",
        supports_cross_market=True,
        supports_cross_asset=True,
        appendix_only=False,
        notes="导出 split 级多索引面板与市场信息文件, 供官方模型入口消费。",
    ),
    "ADGAT": BaselineProfile(
        name="ADGAT",
        repo_dir="ADGAT-main/ADGAT-main",
        artifact_style="adgat_like",
        supports_cross_market=True,
        supports_cross_asset=False,
        appendix_only=True,
        notes="原论文依赖专有新闻与公司关系; 当前用零文本 + 超图重叠关系生成附录级可运行输入。",
    ),
}


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def parse_direction(direction: str) -> tuple[str, str]:
    mapping = {
        "CN_TO_US": ("CN", "US"),
        "US_TO_CN": ("US", "CN"),
        "CN_TO_FUTURE": ("CN", "FUTURE"),
        "FUTURE_TO_CN": ("FUTURE", "CN"),
    }
    if direction not in mapping:
        raise ValueError(f"不支持的方向: {direction}")
    return mapping[direction]


def load_market_bundle(market: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    market_dir = PROCESSED_DIR / market.lower()
    panel_path = market_dir / "panel.pkl"
    incidence_path = market_dir / "hypergraph_incidence.csv"
    if not panel_path.exists():
        raise FileNotFoundError(f"找不到面板文件: {panel_path}")
    if not incidence_path.exists():
        raise FileNotFoundError(f"找不到超图 incidence 文件: {incidence_path}")
    panel_df = read_pickle_with_recovery(panel_path).copy()
    panel_df["date"] = pd.to_datetime(panel_df["date"])
    panel_df = panel_df.sort_values(["date", "symbol"]).reset_index(drop=True)
    incidence_df = pd.read_csv(incidence_path, index_col=0)
    incidence_df.index = incidence_df.index.astype(str)
    return panel_df, incidence_df


def apply_profile_view(
    panel_df: pd.DataFrame,
    incidence_df: pd.DataFrame,
    market: str,
    mode: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    profile = get_profile(mode)
    if profile.name == "full":
        return panel_df, incidence_df
    max_symbols = resolve_max_symbols(profile, market)
    latest_liquidity = (
        panel_df.groupby("symbol")["volume"].mean().sort_values(ascending=False).head(max_symbols).index.astype(str).tolist()
    )
    panel_df = panel_df[panel_df["symbol"].astype(str).isin(latest_liquidity)].copy()
    incidence_df = incidence_df.reindex(latest_liquidity).fillna(0.0)
    if "split" not in panel_df.columns:
        panel_df = apply_unified_split(panel_df)
    panel_df = truncate_panel_by_profile(panel_df, profile)
    return panel_df.reset_index(drop=True), incidence_df


def filter_available_columns(df: pd.DataFrame, columns: list[str]) -> list[str]:
    return [column for column in columns if column in df.columns]


def apply_unified_split(panel_df: pd.DataFrame) -> pd.DataFrame:
    df = panel_df.copy()
    train_start = pd.Timestamp(SPLIT_DATES["train_start"])
    train_end = pd.Timestamp(SPLIT_DATES["train_end"])
    valid_start = pd.Timestamp(SPLIT_DATES["valid_start"])
    valid_end = pd.Timestamp(SPLIT_DATES["valid_end"])
    test_start = pd.Timestamp(SPLIT_DATES["test_start"])
    test_end = pd.Timestamp(SPLIT_DATES["test_end"])
    df["split"] = None
    df.loc[(df["date"] >= train_start) & (df["date"] <= train_end), "split"] = "train"
    df.loc[(df["date"] >= valid_start) & (df["date"] <= valid_end), "split"] = "valid"
    df.loc[(df["date"] >= test_start) & (df["date"] <= test_end), "split"] = "test"
    df = df[df["split"].notna()].copy()
    return df


def make_multiindex_frame(panel_df: pd.DataFrame, value_columns: list[str]) -> pd.DataFrame:
    frame = panel_df[["date", "symbol", *value_columns]].copy()
    frame = frame.rename(columns={"symbol": "instrument"})
    frame = frame.set_index(["date", "instrument"]).sort_index()
    return frame


def make_market_value_series(panel_df: pd.DataFrame) -> pd.Series:
    if "dollar_volume" in panel_df.columns:
        series = panel_df["dollar_volume"].astype(float)
    else:
        series = (panel_df["close"].astype(float) * panel_df["volume"].astype(float)).astype(float)
    return pd.Series(series.to_numpy(), index=pd.MultiIndex.from_frame(panel_df[["date", "symbol"]]))


def build_stock_index_and_concepts(panel_df: pd.DataFrame, incidence_df: pd.DataFrame) -> tuple[dict[str, int], np.ndarray]:
    symbols = sorted(panel_df["symbol"].astype(str).unique().tolist())
    stock_index = {symbol: idx for idx, symbol in enumerate(symbols)}
    concept_matrix = incidence_df.reindex(symbols).fillna(0.0).to_numpy(dtype=np.float32)
    return stock_index, concept_matrix


def export_pickle(path: Path, obj: Any) -> None:
    target_path = resolve_output_path(path)
    with target_path.open("wb") as file_obj:
        pickle.dump(obj, file_obj)


def export_gzip_pickle(path: Path, obj: Any) -> None:
    target_path = resolve_output_path(path)
    with gzip.open(target_path, "wb") as file_obj:
        pickle.dump(obj, file_obj)


def write_json(path: Path, payload: dict[str, Any]) -> Path:
    return workspace_write_json(path, payload)


def write_markdown_note(
    path: Path,
    profile: BaselineProfile,
    direction: str,
    source_market: str,
    target_market: str,
    artifact_files: dict[str, str],
) -> None:
    lines = [
        f"# {profile.name} 外层最小适配说明",
        "",
        f"- 迁移方向: `{direction}`",
        f"- 源域: `{source_market}`",
        f"- 目标域: `{target_market}`",
        f"- 官方仓库: `{OFFICIAL_DIR / profile.repo_dir}`",
        f"- 适配类型: `{profile.artifact_style}`",
        f"- 说明: {profile.notes}",
        "",
        "## 公平性边界",
        "",
        "- 允许修改: `data_loader`, `file_path`, `label_generator`, `result_export`",
        "- 禁止修改: `model_core`, `loss_function`, `attention_module`, `graph_logic`, `custom_innovation`",
        "",
        "## 已生成的外围资产",
        "",
    ]
    for name, file_path in artifact_files.items():
        lines.append(f"- `{name}`: `{file_path}`")
    lines.extend(
        [
            "",
            "## 统一结果协议",
            "",
            "- 测试集结果统一导出为 `date, instrument, score`。",
            "- 结果文件编码统一为 `utf-8-sig`。",
            "- 指标计算由项目统一评估管线完成, 不在官方模型核心内部新增自定义评价逻辑。",
        ]
    )
    return write_text(path, "\n".join(lines))


def export_qlib_like_artifacts(
    profile: BaselineProfile,
    direction: str,
    source_market: str,
    target_market: str,
    artifact_dir: Path,
    mode: str,
) -> dict[str, str]:
    source_panel, source_incidence = load_market_bundle(source_market)
    target_panel, target_incidence = load_market_bundle(target_market)
    source_panel = apply_unified_split(source_panel)
    target_panel = apply_unified_split(target_panel)
    source_panel, source_incidence = apply_profile_view(source_panel, source_incidence, source_market, mode)
    target_panel, target_incidence = apply_profile_view(target_panel, target_incidence, target_market, mode)
    ensure_dir(artifact_dir)

    source_panel_path = artifact_dir / f"{source_market.lower()}_panel.pkl"
    target_panel_path = artifact_dir / f"{target_market.lower()}_panel.pkl"
    source_incidence_path = artifact_dir / f"{source_market.lower()}_incidence.csv"
    target_incidence_path = artifact_dir / f"{target_market.lower()}_incidence.csv"
    actual_source_panel_path = resolve_output_path(source_panel_path)
    actual_target_panel_path = resolve_output_path(target_panel_path)
    source_panel.to_pickle(actual_source_panel_path)
    target_panel.to_pickle(actual_target_panel_path)
    actual_source_incidence_path = write_dataframe(source_incidence, source_incidence_path, encoding="utf-8-sig")
    actual_target_incidence_path = write_dataframe(target_incidence, target_incidence_path, encoding="utf-8-sig")

    profile_path = artifact_dir / "adapter_manifest.json"
    actual_profile_path = write_json(
        profile_path,
        {
            "baseline": profile.name,
            "direction": direction,
            "source_market": source_market,
            "target_market": target_market,
            "label_column": LABEL_COLUMN,
            "feature_columns": filter_available_columns(target_panel, COMMON_FEATURE_COLUMNS),
            "source_rows": int(len(source_panel)),
            "target_rows": int(len(target_panel)),
            "mode": mode,
            "notes": profile.notes,
        },
    )
    return {
        "source_panel": str(actual_source_panel_path),
        "target_panel": str(actual_target_panel_path),
        "source_incidence": str(actual_source_incidence_path),
        "target_incidence": str(actual_target_incidence_path),
        "adapter_manifest": str(actual_profile_path),
    }


def export_hist_like_artifacts(
    profile: BaselineProfile,
    target_market: str,
    artifact_dir: Path,
    mode: str,
) -> dict[str, str]:
    panel_df, incidence_df = load_market_bundle(target_market)
    panel_df = apply_unified_split(panel_df)
    panel_df, incidence_df = apply_profile_view(panel_df, incidence_df, target_market, mode)
    feature_columns = filter_available_columns(panel_df, COMMON_FEATURE_COLUMNS)
    label_columns = [LABEL_COLUMN]
    ensure_dir(artifact_dir)

    stock_index, stock2concept = build_stock_index_and_concepts(panel_df, incidence_df)
    stock_index_path = artifact_dir / "stock_index.npy"
    stock2concept_path = artifact_dir / "stock2concept.npy"
    actual_stock_index_path = resolve_output_path(stock_index_path)
    actual_stock2concept_path = resolve_output_path(stock2concept_path)
    np.save(actual_stock_index_path, stock_index, allow_pickle=True)
    np.save(actual_stock2concept_path, stock2concept)

    market_value_series = make_market_value_series(panel_df)
    market_value_path = artifact_dir / "market_value.pkl"
    export_pickle(market_value_path, market_value_series)

    artifact_files: dict[str, str] = {
        "stock_index": str(actual_stock_index_path),
        "stock2concept_matrix": str(actual_stock2concept_path),
        "market_value": str(market_value_path),
    }
    for split_name in ("train", "valid", "test"):
        split_df = panel_df[panel_df["split"] == split_name].copy()
        feature_frame = make_multiindex_frame(split_df, feature_columns)
        label_frame = make_multiindex_frame(split_df, label_columns)
        feature_path = artifact_dir / f"{split_name}_feature.pkl"
        label_path = artifact_dir / f"{split_name}_label.pkl"
        actual_feature_path = resolve_output_path(feature_path)
        actual_label_path = resolve_output_path(label_path)
        feature_frame.to_pickle(actual_feature_path)
        label_frame.to_pickle(actual_label_path)
        artifact_files[f"{split_name}_feature"] = str(actual_feature_path)
        artifact_files[f"{split_name}_label"] = str(actual_label_path)

    summary_path = artifact_dir / "dataset_summary.json"
    actual_summary_path = write_json(
        summary_path,
        {
            "baseline": profile.name,
            "target_market": target_market,
            "feature_columns": feature_columns,
            "label_column": LABEL_COLUMN,
            "instrument_count": int(panel_df["symbol"].nunique()),
            "rows": int(len(panel_df)),
            "mode": mode,
        },
    )
    artifact_files["dataset_summary"] = str(actual_summary_path)
    return artifact_files


def export_master_like_artifacts(
    profile: BaselineProfile,
    target_market: str,
    artifact_dir: Path,
    mode: str,
) -> dict[str, str]:
    panel_df, incidence_df = load_market_bundle(target_market)
    panel_df = apply_unified_split(panel_df)
    panel_df, incidence_df = apply_profile_view(panel_df, incidence_df, target_market, mode)
    del incidence_df
    feature_columns = filter_available_columns(panel_df, COMMON_FEATURE_COLUMNS)
    market_feature_columns = filter_available_columns(panel_df, MASTER_MARKET_FEATURE_COLUMNS)
    ensure_dir(artifact_dir)

    artifact_files: dict[str, str] = {}
    for split_name in ("train", "valid", "test"):
        split_df = panel_df[panel_df["split"] == split_name].copy()
        frame = make_multiindex_frame(split_df, feature_columns + [LABEL_COLUMN, QUANTNET_RETURN_COLUMN])
        frame_path = artifact_dir / f"{split_name}_frame.pkl"
        actual_frame_path = resolve_output_path(frame_path)
        frame.to_pickle(actual_frame_path)
        artifact_files[f"{split_name}_frame"] = str(actual_frame_path)

    market_info = panel_df.groupby("date")[market_feature_columns].mean().reset_index()
    market_info_path = artifact_dir / "market_information.csv"
    actual_market_info_path = write_dataframe(market_info, market_info_path, index=False, encoding="utf-8-sig")
    feature_config_path = artifact_dir / "master_feature_config.json"
    actual_feature_config_path = write_json(
        feature_config_path,
        {
            "baseline": profile.name,
            "target_market": target_market,
            "feature_columns": feature_columns,
            "market_feature_columns": market_feature_columns,
            "label_column": LABEL_COLUMN,
            "mode": mode,
            "notes": "该配置文件用于官方 MASTER 模型外层 loader 读取, 不修改核心 Transformer 逻辑。",
        },
    )
    artifact_files["market_information"] = str(actual_market_info_path)
    artifact_files["feature_config"] = str(actual_feature_config_path)
    return artifact_files


def build_dense_relation_matrices(incidence_df: pd.DataFrame) -> dict[str, np.ndarray]:
    incidence = incidence_df.fillna(0.0).to_numpy(dtype=np.float32)
    overlap = incidence @ incidence.T
    overlap = (overlap > 0).astype(np.float32)
    np.fill_diagonal(overlap, 0.0)
    relation_dict = {
        "all_relation": overlap,
        "industry_relation": overlap.copy(),
        "competitor_relation": overlap.copy(),
        "customer_relation": overlap.copy(),
        "stratigic_relation": overlap.copy(),
        "supply_relation": overlap.copy(),
    }
    return relation_dict


def export_adgat_like_artifacts(
    profile: BaselineProfile,
    target_market: str,
    artifact_dir: Path,
    mode: str,
) -> dict[str, str]:
    panel_df, incidence_df = load_market_bundle(target_market)
    panel_df = apply_unified_split(panel_df)
    panel_df, incidence_df = apply_profile_view(panel_df, incidence_df, target_market, mode)
    numeric_columns = filter_available_columns(panel_df, ADGAT_NUMERIC_COLUMNS)
    if not numeric_columns:
        raise RuntimeError("ADGAT 外围数据缺少数值列, 无法构建输入张量。")
    ensure_dir(artifact_dir)
    relations_dir = artifact_dir / "relations"
    ensure_dir(relations_dir)

    split_df = panel_df[panel_df["split"].isin(["train", "valid", "test"])].copy()
    pivot_dates = sorted(split_df["date"].unique().tolist())
    pivot_symbols = sorted(split_df["symbol"].astype(str).unique().tolist())

    numeric_tensor = np.zeros((len(pivot_dates), len(pivot_symbols), len(numeric_columns)), dtype=np.float32)
    label_tensor = np.zeros((len(pivot_dates), len(pivot_symbols)), dtype=np.float32)
    textual_tensor = np.zeros((len(pivot_dates), len(pivot_symbols), 1), dtype=np.float32)
    symbol_index = {symbol: idx for idx, symbol in enumerate(pivot_symbols)}
    date_index = {date_value: idx for idx, date_value in enumerate(pivot_dates)}
    numeric_nonfinite_replaced = 0
    label_nonfinite_replaced = 0

    for row in split_df.itertuples(index=False):
        row_dict = row._asdict()
        i = date_index[row_dict["date"]]
        j = symbol_index[str(row_dict["symbol"])]
        numeric_row = np.asarray([row_dict[column] for column in numeric_columns], dtype=np.float32)
        numeric_nonfinite_replaced += int((~np.isfinite(numeric_row)).sum())
        numeric_tensor[i, j, :] = np.nan_to_num(numeric_row, nan=0.0, posinf=0.0, neginf=0.0)
        label_value = np.float32(row_dict[LABEL_COLUMN])
        if not np.isfinite(label_value):
            label_nonfinite_replaced += 1
            label_value = np.float32(0.0)
        label_tensor[i, j] = label_value

    x_numerical_path = artifact_dir / "x_numerical.pkl"
    x_textual_path = artifact_dir / "x_textual.pkl"
    y_path = artifact_dir / "y_.pkl"
    export_pickle(x_numerical_path, numeric_tensor)
    export_pickle(x_textual_path, textual_tensor)
    export_pickle(y_path, label_tensor)

    relation_files = {"x_numerical": str(x_numerical_path), "x_textual": str(x_textual_path), "y_label": str(y_path)}
    for relation_name, relation_matrix in build_dense_relation_matrices(incidence_df.reindex(pivot_symbols).fillna(0.0)).items():
        relation_path = relations_dir / f"{relation_name}.pkl"
        export_pickle(relation_path, relation_matrix.astype(np.float32))
        relation_files[relation_name] = str(resolve_output_path(relation_path))

    summary_path = artifact_dir / "adgat_config.json"
    actual_summary_path = write_json(
        summary_path,
        {
            "baseline": profile.name,
            "target_market": target_market,
            "numeric_columns": numeric_columns,
            "label_column": LABEL_COLUMN,
            "textual_strategy": "all_zero_placeholder",
            "relation_strategy": "hypergraph incidence overlap",
            "numeric_nonfinite_replaced": int(numeric_nonfinite_replaced),
            "label_nonfinite_replaced": int(label_nonfinite_replaced),
            "mode": mode,
            "notes": profile.notes,
        },
    )
    relation_files["config"] = str(actual_summary_path)
    return relation_files


def export_quantnet_like_artifacts(
    profile: BaselineProfile,
    source_market: str,
    target_market: str,
    artifact_dir: Path,
    mode: str,
) -> dict[str, str]:
    ensure_dir(artifact_dir)
    artifact_files: dict[str, str] = {}
    for market in (source_market, target_market):
        panel_df, incidence_df = load_market_bundle(market)
        panel_df = apply_unified_split(panel_df)
        panel_df, incidence_df = apply_profile_view(panel_df, incidence_df, market, mode)
        del incidence_df
        return_matrix = (
            panel_df.pivot(index="date", columns="symbol", values=QUANTNET_RETURN_COLUMN)
            .sort_index()
            .sort_index(axis=1)
            .fillna(0.0)
        )
        export_path = artifact_dir / f"{market.lower()}_all_assets_data.pkl.gz"
        export_gzip_pickle(export_path, return_matrix.astype(np.float32))
        artifact_files[f"{market.lower()}_returns"] = str(export_path)

    config_path = artifact_dir / "quantnet_config.json"
    actual_config_path = write_json(
        config_path,
        {
            "baseline": profile.name,
            "source_market": source_market,
            "target_market": target_market,
            "task_files": artifact_files,
            "holdout_period": get_profile(mode).quantnet_holdout_period,
            "label_column": QUANTNET_RETURN_COLUMN,
            "mode": mode,
            "notes": "当前按统一 future_return 口径导出收益矩阵, 由官方 QuantNet 外层任务加载器消费。",
        },
    )
    artifact_files["config"] = str(actual_config_path)
    return artifact_files


def build_artifacts(baseline: str, direction: str, mode: str = "full") -> dict[str, Any]:
    if baseline not in BASELINE_PROFILES:
        raise ValueError(f"未知 baseline: {baseline}")
    profile = BASELINE_PROFILES[baseline]
    source_market, target_market = parse_direction(direction)
    experiment_profile = get_profile(mode)
    if "FUTURE" in {source_market, target_market} and not profile.supports_cross_asset:
        raise ValueError(f"{baseline} 当前不纳入跨资产主链方向: {direction}")
    if "FUTURE" not in {source_market, target_market} and not profile.supports_cross_market:
        raise ValueError(f"{baseline} 当前不纳入跨市场方向: {direction}")

    artifact_dir = ARTIFACT_ROOT / mode.lower() / direction.lower() / baseline.lower()
    ensure_dir(artifact_dir)

    if profile.artifact_style == "qlib_like":
        artifact_files = export_qlib_like_artifacts(profile, direction, source_market, target_market, artifact_dir, mode)
    elif profile.artifact_style == "hist_like":
        artifact_files = export_hist_like_artifacts(profile, target_market, artifact_dir, mode)
    elif profile.artifact_style == "master_like":
        artifact_files = export_master_like_artifacts(profile, target_market, artifact_dir, mode)
    elif profile.artifact_style == "adgat_like":
        artifact_files = export_adgat_like_artifacts(profile, target_market, artifact_dir, mode)
    elif profile.artifact_style == "quantnet_like":
        artifact_files = export_quantnet_like_artifacts(profile, source_market, target_market, artifact_dir, mode)
    else:
        raise ValueError(profile.artifact_style)

    note_path = artifact_dir / "adapter_note.md"
    actual_note_path = write_markdown_note(note_path, profile, direction, source_market, target_market, artifact_files)
    manifest_path = artifact_dir / "artifact_manifest.json"
    manifest = {
        "profile": asdict(profile),
        "direction": direction,
        "mode": mode,
        "profile": profile_to_dict(experiment_profile),
        "source_market": source_market,
        "target_market": target_market,
        "artifact_dir": str(artifact_dir),
        "artifact_files": artifact_files,
        "adapter_note": str(actual_note_path),
    }
    actual_manifest_path = write_json(manifest_path, manifest)
    manifest["manifest_path"] = str(actual_manifest_path)
    return manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="构建官方 baseline 外层适配资产")
    parser.add_argument("--baseline", required=True, choices=sorted(BASELINE_PROFILES))
    parser.add_argument(
        "--direction",
        required=True,
        choices=["CN_TO_US", "US_TO_CN", "CN_TO_FUTURE", "FUTURE_TO_CN"],
    )
    parser.add_argument("--mode", default="full", choices=["full", "medium"])
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    payload = build_artifacts(args.baseline, args.direction, mode=args.mode)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
