import os
import re
import shutil

src_tex = "/data/zhoutm/exp2/paper/AAAIV3/AAAI27_AMT_V3_English.tex"
dst_dir = "/data/zhoutm/exp2/paper/ICASSP/V0(AAAI TO ICASSP)"
dst_tex = os.path.join(dst_dir, "ICASSP_draft.tex")

os.makedirs(dst_dir, exist_ok=True)

with open(src_tex, "r", encoding="utf-8") as f:
    content = f.read()

# Replace preamble
preamble = r"""\documentclass{article}
\usepackage{spconf,amsmath,amssymb,graphicx,booktabs,natbib,hyperref}
\usepackage{enumitem}
\usepackage{setspace}

\title{AMT: A Cross-Market Alpha Strategy Transfer Framework with Fused Strategy-Mechanism Preservation and Structure Freezing}
\name{Anonymous Submission}
\address{}
"""

# Extract body
body_match = re.search(r'\\begin\{document\}(.*?)\\end\{document\}', content, re.DOTALL)
body = body_match.group(1)

# Compress spacing
body = body.replace(r"\begin{itemize}", r"\begin{itemize}[leftmargin=*,noitemsep,topsep=0pt]")
body = body.replace(r"\section{", r"\vspace{-0.2cm}\section{")
body = body.replace(r"\subsection{", r"\vspace{-0.2cm}\subsection{")

# Make tables and figures smaller
body = body.replace(r"\small", r"\footnotesize")
body = body.replace(r"\scriptsize", r"\scriptsize")

new_content = preamble + "\n\\begin{document}\n" + body + "\n\\end{document}\n"

with open(dst_tex, "w", encoding="utf-8") as f:
    f.write(new_content)

# Copy refs
src_bib = "/data/zhoutm/exp2/paper/AAAIV3/aaai27_amt_v3_refs.bib"
dst_bib = os.path.join(dst_dir, "aaai27_amt_v3_refs.bib")
if os.path.exists(src_bib):
    shutil.copy(src_bib, dst_bib)
