"""
文件功能:
1. 提供项目级的 Qlib 全市场数据更新入口，统一处理官方 Qlib 数据包下载、Yahoo 全市场日频 CSV 构建与 processed_data 重建。
2. 对美股优先支持“全市场普通股”下载，修复当前实验缓存仅含极少股票导致回测退化的问题。
3. 将下载后的原始 CSV、Qlib 兼容目录和项目训练缓存统一写入 `DataToSever/`，方便服务器端直接复用。

代码逻辑:
1. 可选下载官方 Qlib 现成数据包到 `DataToSever/qlib_market_data/{region}_data`。
2. 可选按 Qlib/Yahoo 协议抓取全市场日频数据，并标准化到 `DataToSever/_workspace_*_2021_2025_csv`。
3. 使用 Qlib 官方 `dump_bin.py` 将 CSV 转换为 Qlib 兼容目录，便于后续扩展或核查覆盖率。
4. 可选触发 `prepare_market_artifacts()` 强制重建 `processed_data`，让主实验直接使用更新后的大样本股票池。

代码结构:
1. 路径常量、区域配置与下载 URL 工具。
2. 官方 Qlib 数据包下载函数。
3. 美股/ A股股票池构建与 Yahoo 日频抓取函数。
4. Qlib 风格标准化、dump_bin 转换与 processed_data 重建入口。
5. 命令行入口。
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import subprocess
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import requests

from data_pipeline import MarketDataConfig, prepare_market_artifacts


ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT_DIR / "DataToSever"
QLIB_ROOT = DATA_DIR / "qlib_market_data"
QLIB_SCRIPT_ROOT = ROOT_DIR / "third_party" / "official_baselines" / "qlib-main  TRA" / "qlib-main" / "scripts"
DUMP_BIN_PATH = QLIB_SCRIPT_ROOT / "dump_bin.py"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
)
REQUEST_TIMEOUT = 60
RETRY_SLEEP_SECONDS = 2.0
MAX_RETRIES = 3
DEFAULT_START = "2021-01-01"
DEFAULT_END_EXCLUSIVE = "2026-01-01"
DEFAULT_BATCH_SIZE = 100
DEFAULT_DOWNLOAD_WORKERS = 3
DEFAULT_DUMP_WORKERS = 2


@dataclass(frozen=True)
class RegionConfig:
    region_name: str
    official_qlib_dir: Path
    csv_dir: Path
    qlib_dump_dir: Path
    detail_report_path: Path
    summary_report_path: Path


REGION_CONFIGS: dict[str, RegionConfig] = {
    "CN": RegionConfig(
        region_name="CN",
        official_qlib_dir=QLIB_ROOT / "cn_data",
        csv_dir=DATA_DIR / "_workspace_cn_2021_2025_csv",
        qlib_dump_dir=QLIB_ROOT / "cn_data_from_csv",
        detail_report_path=QLIB_ROOT / "cn_download_details.csv",
        summary_report_path=QLIB_ROOT / "cn_download_report.json",
    ),
    "US": RegionConfig(
        region_name="US",
        official_qlib_dir=QLIB_ROOT / "us_data",
        csv_dir=DATA_DIR / "_workspace_us_2021_2025_csv",
        qlib_dump_dir=QLIB_ROOT / "us_data_from_csv",
        detail_report_path=QLIB_ROOT / "us_download_details.csv",
        summary_report_path=QLIB_ROOT / "us_download_report.json",
    ),
}

OFFICIAL_PACKAGE_CANDIDATES = {
    "CN": [
        "https://github.com/SunsetWolf/qlib_dataset/releases/download/v2/qlib_data_cn_1d_latest.zip",
        "https://github.com/SunsetWolf/qlib_dataset/releases/download/v1/qlib_data_cn_1d_latest.zip",
        "https://github.com/SunsetWolf/qlib_dataset/releases/download/v0/qlib_data_cn_1d_latest.zip",
    ],
    "US": [
        "https://github.com/SunsetWolf/qlib_dataset/releases/download/v2/qlib_data_us_1d_latest.zip",
        "https://github.com/SunsetWolf/qlib_dataset/releases/download/v1/qlib_data_us_1d_latest.zip",
        "https://github.com/SunsetWolf/qlib_dataset/releases/download/v0/qlib_data_us_1d_latest.zip",
    ],
}

CN_SNAPSHOT_DATES = [
    "2021-01-04",
    "2021-12-31",
    "2022-12-30",
    "2023-12-29",
    "2024-12-31",
    "2025-12-31",
]


def log(message: str) -> None:
    print(message, flush=True)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def build_request(url: str) -> requests.PreparedRequest:
    session = requests.Session()
    request = requests.Request("GET", url, headers={"User-Agent": USER_AGENT})
    return session.prepare_request(request)


def probe_url(url: str) -> tuple[str, str]:
    response = requests.get(url, timeout=REQUEST_TIMEOUT, headers={"User-Agent": USER_AGENT}, allow_redirects=True, stream=True)
    response.raise_for_status()
    content_type = response.headers.get("Content-Type", "")
    final_url = response.url
    response.close()
    return content_type, final_url


def stream_download(url: str, target_path: Path) -> None:
    with requests.get(url, timeout=REQUEST_TIMEOUT, headers={"User-Agent": USER_AGENT}, stream=True, allow_redirects=True) as response:
        response.raise_for_status()
        with target_path.open("wb") as file_obj:
            for chunk in response.iter_content(chunk_size=1024 * 512):
                if chunk:
                    file_obj.write(chunk)


def validate_qlib_dir(target_dir: Path) -> bool:
    return all((target_dir / name).exists() for name in ["features", "calendars", "instruments"])


def download_official_qlib_pack(region: str) -> dict[str, Any]:
    cfg = REGION_CONFIGS[region]
    ensure_dir(cfg.official_qlib_dir)
    if validate_qlib_dir(cfg.official_qlib_dir):
        return {"region": region, "status": "skipped_existing", "target_dir": str(cfg.official_qlib_dir)}

    chosen_url: str | None = None
    for candidate in OFFICIAL_PACKAGE_CANDIDATES[region]:
        try:
            content_type, final_url = probe_url(candidate)
        except Exception:  # noqa: BLE001
            continue
        if "zip" in content_type.lower() or final_url.lower().endswith(".zip") or "release-assets.githubusercontent.com" in final_url.lower():
            chosen_url = final_url
            break
    if chosen_url is None:
        raise RuntimeError(f"{region} 未找到可用的官方 Qlib 数据包链接。")

    temp_zip = cfg.official_qlib_dir / f"{region.lower()}_{int(time.time())}.zip"
    log(f"[{region}] 开始下载官方 Qlib 数据包: {chosen_url}")
    stream_download(chosen_url, temp_zip)
    if not zipfile.is_zipfile(temp_zip):
        temp_zip.unlink(missing_ok=True)
        raise RuntimeError(f"{region} 官方 Qlib 数据包下载失败，结果不是 ZIP 文件。")

    for child in list(cfg.official_qlib_dir.iterdir()):
        if child == temp_zip:
            continue
        if child.is_dir():
            subprocess.run(["powershell", "-Command", f"Remove-Item -Recurse -Force '{child}'"], check=False)
        else:
            child.unlink(missing_ok=True)
    with zipfile.ZipFile(temp_zip, "r") as zip_file:
        zip_file.extractall(cfg.official_qlib_dir)
    temp_zip.unlink(missing_ok=True)

    if not validate_qlib_dir(cfg.official_qlib_dir):
        raise RuntimeError(f"{region} 官方 Qlib 数据包解压后目录不完整。")
    return {"region": region, "status": "downloaded", "target_dir": str(cfg.official_qlib_dir), "source_url": chosen_url}


def load_existing_csv_symbols(csv_dir: Path) -> set[str]:
    if not csv_dir.exists():
        return set()
    return {file_path.stem.upper() for file_path in csv_dir.glob("*.csv")}


def normalize_us_symbol(symbol: str) -> str:
    return symbol.upper().strip().replace(".", "-").strip("$").strip("*")


def is_supported_us_common_symbol(symbol: str) -> bool:
    if not symbol or "^" in symbol or "/" in symbol or "+" in symbol or "$" in symbol:
        return False
    if len(symbol) >= 8:
        return False
    if len(symbol) == 5 and symbol[-1] in {"W", "R", "U", "V", "Z", "P", "Q"}:
        return False
    if "-" not in symbol:
        return True
    base, suffix = symbol.rsplit("-", 1)
    if not base or not suffix:
        return False
    return len(suffix) == 1 and suffix.isalpha()


def is_supported_cn_a_share(symbol: str) -> bool:
    symbol = symbol.upper()
    allowed_prefixes = (
        "SH600",
        "SH601",
        "SH603",
        "SH605",
        "SH688",
        "SZ000",
        "SZ001",
        "SZ002",
        "SZ003",
        "SZ300",
        "SZ301",
    )
    return symbol.startswith(allowed_prefixes)


def build_cn_symbol_universe() -> list[str]:
    import baostock as bs

    login_result = bs.login()
    if login_result.error_code != "0":
        raise RuntimeError(f"baostock 登录失败: {login_result.error_msg}")
    symbols: set[str] = set()
    try:
        for date_str in CN_SNAPSHOT_DATES:
            result = bs.query_all_stock(date_str)
            if result.error_code != "0":
                continue
            while result.next():
                row = result.get_row_data()
                code = row[0].strip().lower()
                if code.startswith("sh."):
                    symbol = f"SH{code[3:]}"
                elif code.startswith("sz."):
                    symbol = f"SZ{code[3:]}"
                else:
                    continue
                if is_supported_cn_a_share(symbol):
                    symbols.add(symbol)
    finally:
        bs.logout()
    symbols |= {symbol for symbol in load_existing_csv_symbols(REGION_CONFIGS["CN"].csv_dir) if is_supported_cn_a_share(symbol)}
    return sorted(symbols)


def fetch_nasdaq_trader_symbols() -> set[str]:
    symbols: set[str] = set()
    url_groups = [
        [
            "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt",
            "ftp://ftp.nasdaqtrader.com/SymbolDirectory/otherlisted.txt",
        ],
        [
            "https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqtraded.txt",
            "ftp://ftp.nasdaqtrader.com/SymbolDirectory/nasdaqtraded.txt",
        ],
    ]
    for candidates in url_groups:
        frame = None
        for url in candidates:
            try:
                frame = pd.read_csv(url, sep="|")
                break
            except Exception:  # noqa: BLE001
                continue
        if frame is None:
            continue
        if "Test Issue" in frame.columns:
            frame = frame[frame["Test Issue"] == "N"]
        if "ETF" in frame.columns:
            frame = frame[frame["ETF"] == "N"]
        symbol_col = "ACT Symbol" if "ACT Symbol" in frame.columns else "Symbol"
        if symbol_col not in frame.columns:
            continue
        for raw_symbol in frame[symbol_col].dropna().astype(str):
            normalized = normalize_us_symbol(raw_symbol)
            if is_supported_us_common_symbol(normalized):
                symbols.add(normalized)
    return symbols


def fetch_nyse_symbols() -> set[str]:
    url = "https://www.nyse.com/api/quotes/filter"
    payload = {
        "instrumentType": "EQUITY",
        "pageNumber": 1,
        "sortColumn": "NORMALIZED_TICKER",
        "sortOrder": "ASC",
        "maxResultsPerPage": 10000,
        "filterToken": "",
    }
    try:
        response = requests.post(url, json=payload, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        rows = response.json()
    except Exception:  # noqa: BLE001
        return set()
    symbols: set[str] = set()
    for item in rows:
        raw_symbol = str(item.get("symbolTicker", "")).strip()
        normalized = normalize_us_symbol(raw_symbol)
        if is_supported_us_common_symbol(normalized):
            symbols.add(normalized)
    return symbols


def build_us_symbol_universe() -> list[str]:
    existing = {symbol for symbol in load_existing_csv_symbols(REGION_CONFIGS["US"].csv_dir) if is_supported_us_common_symbol(symbol)}
    symbols = existing | fetch_nasdaq_trader_symbols() | fetch_nyse_symbols()
    return sorted(symbols)


def qlib_to_yahoo_symbol(symbol: str, region: str) -> str:
    if region == "US":
        return symbol
    if symbol.startswith("SH"):
        return f"{symbol[2:]}.SS"
    if symbol.startswith("SZ"):
        return f"{symbol[2:]}.SZ"
    raise ValueError(f"无法映射到 Yahoo ticker: {symbol}")


def fetch_yahoo_chart(yahoo_symbol: str, start: str, end_exclusive: str) -> tuple[str, dict[str, Any] | None, str | None]:
    start_ts = int(pd.Timestamp(start).timestamp())
    end_ts = int(pd.Timestamp(end_exclusive).timestamp())
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{yahoo_symbol}"
    params = {
        "period1": start_ts,
        "period2": end_ts,
        "interval": "1d",
        "events": "div,splits",
        "includeAdjustedClose": "true",
    }
    last_error: str | None = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = requests.get(url, params=params, headers={"User-Agent": USER_AGENT}, timeout=REQUEST_TIMEOUT)
            if response.status_code in {400, 404}:
                return "empty", None, "No data found"
            response.raise_for_status()
            payload = response.json()
            result = payload.get("chart", {}).get("result")
            if not result:
                return "empty", None, str(payload.get("chart", {}).get("error") or "No data found")
            return "ok", result[0], None
        except Exception as exc:  # noqa: BLE001
            last_error = str(exc)
            time.sleep(RETRY_SLEEP_SECONDS * attempt)
    return "failed", None, last_error


def build_dataframe_from_chart(chart_result: dict[str, Any], qlib_symbol: str) -> pd.DataFrame:
    timestamps = chart_result.get("timestamp") or []
    indicators = chart_result.get("indicators", {})
    quote = (indicators.get("quote") or [{}])[0]
    adjclose_data = (indicators.get("adjclose") or [{}])[0].get("adjclose", [])
    if not timestamps or not quote:
        return pd.DataFrame()
    frame = pd.DataFrame(
        {
            "date": pd.to_datetime(timestamps, unit="s").tz_localize(None),
            "open": quote.get("open", []),
            "high": quote.get("high", []),
            "low": quote.get("low", []),
            "close": quote.get("close", []),
            "volume": quote.get("volume", []),
            "adjclose": adjclose_data,
        }
    )
    frame["symbol"] = qlib_symbol
    frame = frame.sort_values("date").drop_duplicates(subset=["date"], keep="first")
    return frame


def qlib_style_normalize(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame
    result = frame.copy()
    for column in ["open", "high", "low", "close", "adjclose", "volume"]:
        result[column] = pd.to_numeric(result[column], errors="coerce")
    result["factor"] = (result["adjclose"] / result["close"]).replace([math.inf, -math.inf], pd.NA).ffill().fillna(1.0)
    for column in ["open", "high", "low", "close"]:
        result[column] = result[column] * result["factor"]
    result["volume"] = result["volume"] / result["factor"]
    result["change"] = result["close"].pct_change(fill_method=None)
    valid_close = result["close"].dropna()
    if valid_close.empty or float(valid_close.iloc[0]) == 0:
        return pd.DataFrame()
    base_close = float(valid_close.iloc[0])
    for column in ["open", "high", "low", "close", "factor"]:
        result[column] = result[column] / base_close
    result["volume"] = result["volume"] * base_close
    result["date"] = pd.to_datetime(result["date"]).dt.strftime("%Y-%m-%d")
    return result[["date", "symbol", "open", "high", "low", "close", "volume", "factor", "change", "adjclose"]].dropna(
        subset=["date", "symbol"]
    )


def init_detail_report(path: Path) -> None:
    ensure_dir(path.parent)
    if path.exists():
        return
    with path.open("w", encoding="utf-8-sig", newline="") as file_obj:
        writer = csv.writer(file_obj)
        writer.writerow(["symbol", "status", "error"])


def append_detail_row(path: Path, symbol: str, status: str, error: str | None) -> None:
    with path.open("a", encoding="utf-8-sig", newline="") as file_obj:
        writer = csv.writer(file_obj)
        writer.writerow([symbol, status, error or ""])


def write_summary_report(
    path: Path,
    region: str,
    start: str,
    end_exclusive: str,
    total_symbols: int,
    counters: dict[str, int],
    sample_failed: list[dict[str, str]],
) -> None:
    payload = {
        "region": region,
        "start": start,
        "end_exclusive": end_exclusive,
        "total_symbols": total_symbols,
        **counters,
        "sample_failed": sample_failed,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def batched(items: list[str], batch_size: int) -> Iterable[list[str]]:
    for idx in range(0, len(items), batch_size):
        yield items[idx : idx + batch_size]


def fetch_and_save_one_symbol(region: str, qlib_symbol: str, start: str, end_exclusive: str, csv_dir: Path) -> tuple[str, str, str | None]:
    output_path = csv_dir / f"{qlib_symbol.lower()}.csv"
    if output_path.exists() and output_path.stat().st_size > 0:
        return qlib_symbol, "skipped_existing", None
    yahoo_symbol = qlib_to_yahoo_symbol(qlib_symbol, region)
    fetch_status, chart_result, fetch_error = fetch_yahoo_chart(yahoo_symbol, start, end_exclusive)
    if fetch_status != "ok" or chart_result is None:
        return qlib_symbol, fetch_status, fetch_error
    frame = qlib_style_normalize(build_dataframe_from_chart(chart_result, qlib_symbol))
    if frame.empty:
        return qlib_symbol, "empty", "无有效日频数据"
    frame.to_csv(output_path, index=False, encoding="utf-8")
    return qlib_symbol, "ok", None


def download_market_csv(region: str, start: str, end_exclusive: str, limit: int | None, max_workers: int, batch_size: int) -> dict[str, Any]:
    cfg = REGION_CONFIGS[region]
    ensure_dir(cfg.csv_dir)
    init_detail_report(cfg.detail_report_path)
    symbols = build_cn_symbol_universe() if region == "CN" else build_us_symbol_universe()
    if limit is not None:
        symbols = symbols[:limit]

    counters = {"ok": 0, "skipped_existing": 0, "empty": 0, "failed": 0}
    sample_failed: list[dict[str, str]] = []
    total = len(symbols)
    for batch_idx, symbol_batch in enumerate(batched(symbols, batch_size), start=1):
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_map = {
                executor.submit(fetch_and_save_one_symbol, region, symbol, start, end_exclusive, cfg.csv_dir): symbol for symbol in symbol_batch
            }
            for future in as_completed(future_map):
                symbol = future_map[future]
                try:
                    _, status, error = future.result()
                except Exception as exc:  # noqa: BLE001
                    status = "failed"
                    error = str(exc)
                counters[status] += 1
                append_detail_row(cfg.detail_report_path, symbol, status, error)
                if status == "failed" and len(sample_failed) < 100:
                    sample_failed.append({"symbol": symbol, "error": error or ""})
        done = min(batch_idx * batch_size, total)
        log(
            f"[{region}] 进度 {done}/{total} | ok={counters['ok']} | skipped={counters['skipped_existing']} | empty={counters['empty']} | failed={counters['failed']}"
        )
        write_summary_report(cfg.summary_report_path, region, start, end_exclusive, total, counters, sample_failed)
    return {
        "region": region,
        "csv_dir": str(cfg.csv_dir),
        "total_symbols": total,
        **counters,
        "detail_report": str(cfg.detail_report_path),
        "summary_report": str(cfg.summary_report_path),
    }


def run_dump_bin(csv_dir: Path, qlib_dir: Path, dump_workers: int) -> None:
    ensure_dir(qlib_dir)
    command = [
        "python",
        str(DUMP_BIN_PATH),
        "dump_all",
        "--data_path",
        str(csv_dir),
        "--qlib_dir",
        str(qlib_dir),
        "--freq",
        "day",
        "--exclude_fields",
        "date,symbol,adjclose",
        "--file_suffix",
        ".csv",
        "--symbol_field_name",
        "symbol",
        "--date_field_name",
        "date",
        "--max_workers",
        str(dump_workers),
    ]
    subprocess.run(command, cwd=str(ROOT_DIR), check=True)


def rebuild_processed_market(region: str) -> dict[str, Any]:
    config = MarketDataConfig(
        market=region,
        max_symbols=160,
        min_history_days=900,
        horizon=5,
        use_full_market=region.upper() == "US",
    )
    payload = prepare_market_artifacts(config, force_rebuild=True)
    return {
        "market": region,
        "panel_rows": int(len(payload["panel_df"])),
        "symbol_count": int(payload["panel_df"]["symbol"].nunique()),
        "paths": payload["paths"],
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Qlib 全市场数据更新脚本")
    parser.add_argument("--region", choices=["CN", "US", "BOTH"], default="US")
    parser.add_argument("--start", default=DEFAULT_START)
    parser.add_argument("--end-exclusive", default=DEFAULT_END_EXCLUSIVE)
    parser.add_argument("--download-official-pack", action="store_true")
    parser.add_argument("--download-yahoo-full", action="store_true")
    parser.add_argument("--rebuild-processed", action="store_true")
    parser.add_argument("--limit", type=int, default=None, help="调试用；为空表示不限制股票数。")
    parser.add_argument("--max-workers", type=int, default=DEFAULT_DOWNLOAD_WORKERS)
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE)
    parser.add_argument("--dump-workers", type=int, default=DEFAULT_DUMP_WORKERS)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    regions = ["CN", "US"] if args.region == "BOTH" else [args.region]
    results: dict[str, Any] = {}

    for region in regions:
        results[region] = {}
        if args.download_official_pack:
            results[region]["official_pack"] = download_official_qlib_pack(region)
        if args.download_yahoo_full:
            csv_payload = download_market_csv(
                region=region,
                start=args.start,
                end_exclusive=args.end_exclusive,
                limit=args.limit,
                max_workers=args.max_workers,
                batch_size=args.batch_size,
            )
            results[region]["csv_download"] = csv_payload
            run_dump_bin(REGION_CONFIGS[region].csv_dir, REGION_CONFIGS[region].qlib_dump_dir, dump_workers=args.dump_workers)
            results[region]["qlib_dump_dir"] = str(REGION_CONFIGS[region].qlib_dump_dir)
        if args.rebuild_processed:
            results[region]["processed_rebuild"] = rebuild_processed_market(region)

    print(json.dumps(results, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
