"""
文件功能:
1. 基于官方 STHGCN 的“时序卷积 + 超图传播”核心主线，提供当前项目可运行的适配版。
2. 使用本项目已有的静态超图 incidence matrix 构造横截面关系图，避免另起一套数据协议。
3. 按交易日组织横截面样本，在每个日期上同时预测多只股票，保留官方方法的横截面图学习特征。

代码逻辑:
1. 从统一面板数据中抽取“同一日期的多股票窗口样本”。
2. 由静态超图 incidence matrix 构造日期内股票子图的归一化邻接矩阵。
3. 使用时间卷积编码每只股票的历史窗口，再通过图卷积传播横截面关系。
4. 输出每只股票的预测得分，并复用统一评估与轻量回测落盘。

代码结构:
1. 日期级横截面数据组织。
2. STHGCN 风格网络模块。
3. 训练、预测与落盘入口。
"""

from __future__ import annotations

import argparse
import copy
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch import nn

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parent))

from data_pipeline import SplitConfig, prepare_transfer_artifacts
from experiment_workspace import get_categorized_result_path
from experiment_runner import REGIME_TO_ID, SEQ_FEATURES, evaluate_and_save, infer_split


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULT_DIR = get_categorized_result_path("baseline", "compare_models")


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def is_finite_array(array: np.ndarray) -> bool:
    return bool(np.isfinite(np.asarray(array, dtype=np.float32)).all())


def sanitize_future_numeric_vector(values: np.ndarray, fill_value: float = 0.0) -> np.ndarray:
    return np.nan_to_num(np.asarray(values, dtype=np.float32), nan=fill_value, posinf=fill_value, neginf=fill_value).astype(np.float32)


def normalize_adjacency(adj: np.ndarray) -> np.ndarray:
    deg = adj.sum(axis=1)
    deg_inv_sqrt = np.power(np.clip(deg, 1e-6, None), -0.5)
    d_mat = np.diag(deg_inv_sqrt)
    return d_mat @ adj @ d_mat


def build_graph_from_incidence(incidence_sub: np.ndarray) -> np.ndarray:
    # 使用 H * H^T 构造节点间共享超边强度，再加自环并归一化。
    adj = incidence_sub @ incidence_sub.T
    adj = (adj > 0).astype(np.float32)
    np.fill_diagonal(adj, 1.0)
    return normalize_adjacency(adj)


def build_identity_graph(num_nodes: int) -> np.ndarray:
    return np.eye(num_nodes, dtype=np.float32)


def build_daily_cross_section_samples(
    panel_df: pd.DataFrame,
    incidence_df: pd.DataFrame,
    split: SplitConfig,
    lookback: int,
    graph_mode: str = "hypergraph",
) -> tuple[dict[str, list[dict[str, Any]]], dict[str, pd.DataFrame]]:
    panel_df = panel_df.sort_values(["symbol", "date"]).reset_index(drop=True)
    incidence_df = incidence_df.sort_index()
    symbol_to_inc = {symbol: row.to_numpy(dtype=np.float32) for symbol, row in incidence_df.iterrows()}

    per_day_rows: list[dict[str, Any]] = []
    for symbol, symbol_df in panel_df.groupby("symbol"):
        symbol_df = symbol_df.sort_values("date").reset_index(drop=True)
        if len(symbol_df) <= lookback:
            continue
        seq_values = symbol_df[SEQ_FEATURES].to_numpy(dtype=np.float32)
        incidence = symbol_to_inc.get(symbol, np.zeros(incidence_df.shape[1], dtype=np.float32))
        for idx in range(lookback - 1, len(symbol_df)):
            date_value = symbol_df.loc[idx, "date"]
            split_name = infer_split(date_value, split)
            if split_name is None:
                continue
            window = seq_values[idx - lookback + 1 : idx + 1]
            target = float(symbol_df.loc[idx, "label_rank_proxy"])
            future_return = float(symbol_df.loc[idx, "future_return"])
            if not np.isfinite(window).all() or not np.isfinite(target) or not np.isfinite(future_return):
                continue
            if not is_finite_array(incidence):
                continue
            per_day_rows.append(
                {
                    "split": split_name,
                    "date": date_value,
                    "symbol": symbol,
                    "sequence_x": window,
                    "incidence": incidence,
                    "future_return": future_return,
                    "label": target,
                    "regime": str(symbol_df.loc[idx, "regime"]),
                }
            )

    sample_df = pd.DataFrame(per_day_rows)
    if sample_df.empty:
        raise RuntimeError("STHGCN 样本构造为空。")

    split_batches: dict[str, list[dict[str, Any]]] = {"train": [], "valid": [], "test": []}
    meta_frames: dict[str, pd.DataFrame] = {}

    for split_name in ["train", "valid", "test"]:
        one_split = sample_df.loc[sample_df["split"] == split_name].copy()
        meta_frames[split_name] = one_split[["date", "symbol", "future_return", "label", "regime"]].copy().reset_index(drop=True)
        for date_value, daily_df in one_split.groupby("date"):
            daily_df = daily_df.sort_values("symbol").reset_index(drop=True)
            daily_df = daily_df.replace([np.inf, -np.inf], np.nan)
            daily_df = daily_df.dropna(subset=["future_return", "label"]).copy()
            if len(daily_df) < 5:
                continue
            incidence = np.vstack(daily_df["incidence"].to_list()).astype(np.float32)
            if not is_finite_array(incidence):
                continue
            adjacency = build_graph_from_incidence(incidence) if graph_mode == "hypergraph" else build_identity_graph(len(daily_df))
            sequence_x = np.stack(daily_df["sequence_x"].to_list()).astype(np.float32)
            y_array = daily_df["label"].to_numpy(dtype=np.float32)
            future_return_array = daily_df["future_return"].to_numpy(dtype=np.float32)
            if not is_finite_array(sequence_x):
                continue
            if not is_finite_array(adjacency):
                continue
            if not is_finite_array(y_array):
                continue
            future_return_array = sanitize_future_numeric_vector(future_return_array, fill_value=0.0)
            split_batches[split_name].append(
                {
                    "date": date_value,
                    "symbols": daily_df["symbol"].astype(str).tolist(),
                    "sequence_x": sequence_x,
                    "incidence": incidence,
                    "adjacency": adjacency,
                    "y": y_array,
                    "future_return": future_return_array,
                }
            )
    return split_batches, meta_frames


class TimeBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv2 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv3 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.permute(0, 3, 1, 2)
        temp = self.conv1(x) + torch.sigmoid(self.conv2(x))
        out = F.relu(temp + self.conv3(x))
        return out.permute(0, 2, 3, 1)


class GraphTemporalBlock(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int, out_channels: int) -> None:
        super().__init__()
        self.temporal1 = TimeBlock(in_channels=in_channels, out_channels=out_channels)
        self.theta = nn.Parameter(torch.empty(out_channels, hidden_channels))
        self.temporal2 = TimeBlock(in_channels=hidden_channels, out_channels=out_channels)
        nn.init.xavier_uniform_(self.theta)

    def forward(self, x: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        t = self.temporal1(x)
        spatial = torch.einsum("ij,bjtf->bitf", adjacency, t)
        spatial = F.relu(torch.matmul(spatial, self.theta))
        return self.temporal2(spatial)


class STHGCNLikeModel(nn.Module):
    """
    项目级 STHGCN 适配版：
    - 时间卷积保留官方 STGCN/时序块思想；
    - 横截面关系传播由静态超图导出的邻接矩阵完成；
    - 最终输出日期内每只股票的一个回归分数。
    """

    def __init__(self, num_features: int, lookback: int, hidden_channels: int = 16, out_channels: int = 32) -> None:
        super().__init__()
        self.block1 = GraphTemporalBlock(in_channels=num_features, hidden_channels=hidden_channels, out_channels=out_channels)
        self.block2 = GraphTemporalBlock(in_channels=out_channels, hidden_channels=hidden_channels, out_channels=out_channels)
        self.last_temporal = TimeBlock(in_channels=out_channels, out_channels=out_channels)
        # 两个 GraphTemporalBlock 各包含 2 个时间卷积块，最后还有 1 个时间卷积块，
        # 若 kernel_size=3，则时间长度总共减少 10 步。
        reduced_steps = max(1, lookback - 10)
        self.head = nn.Sequential(
            nn.Linear(reduced_steps * out_channels, out_channels),
            nn.ReLU(),
            nn.Linear(out_channels, 1),
        )

    def forward(self, sequence_x: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        # 输入重组为 [1, num_nodes, num_timesteps, num_features]，以便在日期横截面上共同建模。
        x = sequence_x.unsqueeze(0)
        out = self.block1(x, adjacency)
        out = self.block2(out, adjacency)
        out = self.last_temporal(out)
        node_repr = out.squeeze(0).reshape(out.shape[1], -1)
        pred = self.head(node_repr).squeeze(-1)
        return pred


@dataclass
class STHGCNTrainConfig:
    n_epochs: int = 12
    lr: float = 1e-3
    weight_decay: float = 1e-5
    early_stop_rounds: int = 3


def masked_mse(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    mask = torch.isfinite(target)
    if mask.sum() == 0:
        return (pred * 0.0).sum()
    return ((pred[mask] - target[mask]) ** 2).mean()


def fit_sthgcn_model(
    model: STHGCNLikeModel,
    train_batches: list[dict[str, Any]],
    valid_batches: list[dict[str, Any]],
    config: STHGCNTrainConfig,
    device: str,
) -> STHGCNLikeModel:
    torch_device = torch.device(device)
    model = model.to(torch_device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.lr, weight_decay=config.weight_decay)

    best_state = copy.deepcopy(model.state_dict())
    best_valid = float("inf")
    patience = 0

    for _ in range(config.n_epochs):
        model.train()
        for batch in train_batches:
            sequence_x = torch.as_tensor(batch["sequence_x"], dtype=torch.float32, device=torch_device)
            adjacency = torch.as_tensor(batch["adjacency"], dtype=torch.float32, device=torch_device)
            y = torch.as_tensor(batch["y"], dtype=torch.float32, device=torch_device)
            if not torch.isfinite(sequence_x).all() or not torch.isfinite(adjacency).all() or not torch.isfinite(y).all():
                continue
            optimizer.zero_grad()
            pred = model(sequence_x, adjacency)
            if not torch.isfinite(pred).all():
                continue
            loss = masked_mse(pred, y)
            if not torch.isfinite(loss):
                continue
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

        model.eval()
        losses: list[float] = []
        with torch.no_grad():
            for batch in valid_batches:
                sequence_x = torch.as_tensor(batch["sequence_x"], dtype=torch.float32, device=torch_device)
                adjacency = torch.as_tensor(batch["adjacency"], dtype=torch.float32, device=torch_device)
                y = torch.as_tensor(batch["y"], dtype=torch.float32, device=torch_device)
                if not torch.isfinite(sequence_x).all() or not torch.isfinite(adjacency).all() or not torch.isfinite(y).all():
                    continue
                pred = model(sequence_x, adjacency)
                if not torch.isfinite(pred).all():
                    continue
                loss = masked_mse(pred, y)
                if not torch.isfinite(loss):
                    continue
                losses.append(float(loss.item()))
        valid_loss = float(np.mean(losses)) if losses else float("inf")
        if valid_loss + 1e-8 < best_valid:
            best_valid = valid_loss
            best_state = copy.deepcopy(model.state_dict())
            patience = 0
        else:
            patience += 1
            if patience >= config.early_stop_rounds:
                break

    model.load_state_dict(best_state)
    return model


def predict_sthgcn_model(model: STHGCNLikeModel, test_batches: list[dict[str, Any]], device: str) -> pd.DataFrame:
    torch_device = torch.device(device)
    model = model.to(torch_device)
    model.eval()
    rows: list[dict[str, Any]] = []
    with torch.no_grad():
        for batch in test_batches:
            sequence_x = torch.as_tensor(batch["sequence_x"], dtype=torch.float32, device=torch_device)
            adjacency = torch.as_tensor(batch["adjacency"], dtype=torch.float32, device=torch_device)
            if not torch.isfinite(sequence_x).all() or not torch.isfinite(adjacency).all():
                continue
            pred = model(sequence_x, adjacency).detach().cpu().numpy()
            pred = sanitize_future_numeric_vector(pred, fill_value=0.0)
            for idx, symbol in enumerate(batch["symbols"]):
                rows.append(
                    {
                        "date": batch["date"],
                        "symbol": symbol,
                        "future_return": float(np.nan_to_num(batch["future_return"][idx], nan=0.0, posinf=0.0, neginf=0.0)),
                        "label": float(np.nan_to_num(batch["y"][idx], nan=0.0, posinf=0.0, neginf=0.0)),
                        "prediction": float(pred[idx]),
                    }
                )
    pred_df = pd.DataFrame(rows).sort_values(["date", "symbol"]).reset_index(drop=True)
    return pred_df


def run_sthgcn_direction(
    source_market: str,
    target_market: str,
    max_symbols: int,
    lookback: int,
    top_k: int,
    device: str,
    force_rebuild: bool,
    graph_mode: str = "hypergraph",
) -> dict[str, float]:
    transfer = prepare_transfer_artifacts(
        source_market=source_market,
        target_market=target_market,
        max_symbols=max_symbols,
        horizon=5,
        force_rebuild=force_rebuild,
    )
    target_panel = transfer["target"]["panel_df"]
    target_incidence = transfer["target"]["incidence_df"]
    split = SplitConfig()
    split_batches, _ = build_daily_cross_section_samples(
        target_panel,
        target_incidence,
        split=split,
        lookback=lookback,
        graph_mode=graph_mode,
    )
    if not split_batches["train"] or not split_batches["valid"] or not split_batches["test"]:
        raise RuntimeError(
            f"STHGCN 样本不足: source={source_market}, target={target_market}, graph_mode={graph_mode}, "
            f"train={len(split_batches['train'])}, valid={len(split_batches['valid'])}, test={len(split_batches['test'])}"
        )

    model = STHGCNLikeModel(num_features=len(SEQ_FEATURES), lookback=lookback)
    train_cfg = STHGCNTrainConfig()
    model = fit_sthgcn_model(model, split_batches["train"], split_batches["valid"], config=train_cfg, device=device)
    pred_df = predict_sthgcn_model(model, split_batches["test"], device=device)

    model_tag = "sthgcn" if graph_mode == "hypergraph" else f"sthgcn_{graph_mode}"
    result_dir = RESULT_DIR / f"{source_market.lower()}_to_{target_market.lower()}" / model_tag
    metrics = evaluate_and_save(
        model_tag,
        result_dir,
        pred_df[["date", "symbol", "future_return", "label"]],
        pred_df["prediction"].to_numpy(dtype=np.float32),
        top_k=top_k,
    )
    train_payload = {**train_cfg.__dict__, "graph_mode": graph_mode}
    (result_dir / "train_config.json").write_text(json.dumps(train_payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行项目级 STHGCN 适配版")
    parser.add_argument("--source-market", default="CN")
    parser.add_argument("--target-market", default="US")
    parser.add_argument("--max-symbols", type=int, default=80)
    parser.add_argument("--lookback", type=int, default=20)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true")
    parser.add_argument("--graph-mode", choices=["hypergraph", "identity"], default="hypergraph")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    ensure_dir(RESULT_DIR)
    metrics = run_sthgcn_direction(
        source_market=args.source_market,
        target_market=args.target_market,
        max_symbols=args.max_symbols,
        lookback=args.lookback,
        top_k=args.top_k,
        device=args.device,
        force_rebuild=args.force_rebuild,
        graph_mode=args.graph_mode,
    )
    log(json.dumps(metrics, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

