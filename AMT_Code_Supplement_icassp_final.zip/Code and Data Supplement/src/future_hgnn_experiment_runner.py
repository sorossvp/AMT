"""
文件功能:
1. 一键串联期货静态超图构建、双向 `alpha_case` 迁移实验与 STHGCN 超图消融实验。
2. 将 `CN -> FUTURE` 与 `FUTURE -> CN` 两个方向统一纳入可复现实验协议。
3. 对比 `hypergraph` 与 `identity` 两种图结构模式，验证期货超图约束的真实增益。
4. 输出统一时间报告，便于论文实验部分与附录直接引用。

代码逻辑:
1. 先构建或复用 `future_static_hypergraph` 与 `processed_data/future` 缓存。
2. 分别运行 `CN -> FUTURE` 和 `FUTURE -> CN` 的 `alpha_case` 案例迁移实验。
3. 分别运行 `CN -> FUTURE` 和 `FUTURE -> CN` 的 STHGCN 训练，并对比超图结构与无图结构。
4. 汇总关键指标与耗时到 JSON 文件，保证实验链路闭环。

代码结构:
1. 路径与模块导入。
2. 双向案例实验执行函数。
3. 双向 STHGCN 消融执行函数。
4. 结果汇总与命令行入口。
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import torch

ROOT_DIR = Path(__file__).resolve().parents[1]
HGNN_DIR = ROOT_DIR / "HGNNcode"
if str(HGNN_DIR) not in sys.path:
    sys.path.append(str(HGNN_DIR))

from alpha_case_transfer import AlphaCaseConfig, run_alpha_case_transfer
from data_pipeline import MarketDataConfig, prepare_market_artifacts
from experiment_workspace import get_categorized_result_path, write_json
from futures_hypergraph_pipeline import prepare_futures_hypergraph
from STHGCN import run_sthgcn_direction


TIME_REPORT_PATH = get_categorized_result_path("other", "future_hgnn_time_report.json")


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def build_empty_future_metrics(top_k: int, error_message: str) -> dict[str, object]:
    return {
        "IC": 0.0,
        "ICIR": 0.0,
        "RankIC": 0.0,
        "RankICIR": 0.0,
        f"NDCG@{top_k}": 0.0,
        "Annualized Return": 0.0,
        "Sharpe Ratio": 0.0,
        "Maximum Drawdown": 0.0,
        "Requested TopK": int(top_k),
        "Effective TopK Mean": 0.0,
        "Effective TopK Min": 0,
        "Avg Daily Universe": 0.0,
        "Min Daily Universe": 0,
        "Adjusted TopK Day Ratio": 0.0,
        "Empty Position Day Ratio": 1.0,
        "Sanitized Invalid Row Count": 0,
        "error": error_message,
    }


def run_alpha_bidirectional(top_k: int, force_rebuild: bool = False) -> dict[str, object]:
    results: dict[str, object] = {}
    if force_rebuild:
        prepare_market_artifacts(MarketDataConfig(market="FUTURE"), force_rebuild=True)
    for source_market, target_market in [("CN", "FUTURE"), ("FUTURE", "CN")]:
        start_time = time.perf_counter()
        payload = run_alpha_case_transfer(
            AlphaCaseConfig(
                source_market=source_market,
                target_market=target_market,
                top_k=top_k,
            )
        )
        results[f"{source_market.lower()}_to_{target_market.lower()}"] = {
            "elapsed_seconds": float(time.perf_counter() - start_time),
            "payload": payload,
        }
    return results


def run_sthgcn_bidirectional(top_k: int, device: str, force_rebuild: bool) -> dict[str, object]:
    results: dict[str, object] = {}
    for source_market, target_market in [("CN", "FUTURE"), ("FUTURE", "CN")]:
        direction_key = f"{source_market.lower()}_to_{target_market.lower()}"
        results[direction_key] = {}
        for graph_mode in ["identity", "hypergraph"]:
            start_time = time.perf_counter()
            try:
                metrics = run_sthgcn_direction(
                    source_market=source_market,
                    target_market=target_market,
                    max_symbols=160,
                    lookback=20,
                    top_k=top_k,
                    device=device,
                    force_rebuild=force_rebuild,
                    graph_mode=graph_mode,
                )
            except Exception as exc:
                metrics = build_empty_future_metrics(top_k=top_k, error_message=str(exc))
            results[direction_key][graph_mode] = {
                "elapsed_seconds": float(time.perf_counter() - start_time),
                "metrics": metrics,
            }
    return results


def run_future_hgnn_experiment(top_k: int, device: str, force_rebuild: bool) -> dict[str, object]:
    build_start = time.perf_counter()
    build_payload = prepare_futures_hypergraph(force_rebuild=force_rebuild)
    build_elapsed = float(time.perf_counter() - build_start)

    try:
        alpha_results = run_alpha_bidirectional(top_k=top_k, force_rebuild=force_rebuild)
    except RuntimeError as exc:
        error_text = str(exc)
        if "NumPy 环境不兼容" not in error_text and "numpy._core.numeric" not in error_text:
            raise
        prepare_market_artifacts(MarketDataConfig(market="FUTURE"), force_rebuild=True)
        alpha_results = run_alpha_bidirectional(top_k=top_k, force_rebuild=False)
    sthgcn_results = run_sthgcn_bidirectional(top_k=top_k, device=device, force_rebuild=force_rebuild)

    payload = {
        "build_elapsed_seconds": build_elapsed,
        "build_payload": build_payload,
        "alpha_bidirectional": alpha_results,
        "sthgcn_bidirectional": sthgcn_results,
        "device": device,
    }
    ensure_parent(TIME_REPORT_PATH)
    write_json(TIME_REPORT_PATH, payload)
    return payload


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行期货超图双向迁移与 STHGCN 消融实验")
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    payload = run_future_hgnn_experiment(top_k=args.top_k, device=args.device, force_rebuild=args.force_rebuild)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
