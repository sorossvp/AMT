"""
文件功能:
1. 汇总 `multi_alpha_transfer` 下 10 个 alpha 的双向迁移结果, 生成论文可直接引用的标准化统计表。
2. 统计 AMT 相对直接迁移与其他迁移方法的收益提升、中位数提升、迁移胜率、负迁移比例与显著性检验结果。
3. 基于 alpha 类别与方向划分形成“可迁移性”分析摘要, 支撑 AAAI V2 的实验分析与结论写作。
4. 统一导出 CSV / Markdown / LaTeX / JSON 四类资产, 保证正文与附录共享同一结果底稿。

代码逻辑:
1. 读取每个 alpha 独立目录下的 `all_summary.csv` 与 `run_config.json`, 拼接出全量长表。
2. 以 `Annualized Return / Sharpe Ratio / RankIC` 为核心指标, 构建方向汇总表、AMT 增益表、alpha 可迁移性明细表与类别汇总表。
3. 对 AMT 相对各 baseline 的收益增量执行配对 t 检验与 Wilcoxon 符号秩检验。
4. 生成标准化 Markdown 结论摘要, 供论文实验结论段直接引用。

代码结构:
1. 数据读取与字段标准化。
2. 显著性检验与聚合统计。
3. 论文表格导出与结论摘要生成。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from alpha_strategy_library import get_alpha_strategy
from experiment_workspace import (
    get_categorized_result_path,
    get_latest_completed_batch_root,
    get_paper_asset_path,
    require_batch_artifacts,
    write_json,
)
from multi_alpha_transfer_parallel_runner import ALPHA_TASKS


RESULT_ROOT = get_categorized_result_path("main", "multi_alpha_transfer")

DISPLAY_NAME_MAP = {
    "amt": "AMT",
    "direct_transfer": "Direct Transfer",
    "lstm_transfer": "LSTM-Transfer",
    "transformer_transfer": "Transformer-Transfer",
    "tra_transfer": "Routing-Transfer (TRA-like)",
    "hist_transfer": "Relation-Transfer (HIST-like)",
}

BASELINE_COMPARE_ORDER = [
    "direct_transfer",
    "lstm_transfer",
    "transformer_transfer",
    "tra_transfer",
    "hist_transfer",
]


@dataclass(frozen=True)
class AlphaMeta:
    alpha_name: str
    alpha_category: str
    rationale: str
    formula: str
    intuition: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    display_df = df.copy()
    for column in display_df.columns:
        if pd.api.types.is_float_dtype(display_df[column]):
            display_df[column] = display_df[column].map(lambda value: f"{value:.4f}")
    headers = [str(column) for column in display_df.columns.tolist()]
    rows = [[str(value) for value in row] for row in display_df.astype(object).values.tolist()]
    separator = ["---"] * len(headers)
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(separator) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def render_tex(df: pd.DataFrame, caption: str, label: str) -> str:
    header = " & ".join(df.columns.tolist()) + " \\\\"
    body_rows = []
    for _, row in df.iterrows():
        values = []
        for value in row.tolist():
            if isinstance(value, float):
                values.append(f"{value:.4f}")
            else:
                values.append(str(value))
        body_rows.append(" & ".join(values) + " \\\\")
    body = "\n".join(body_rows)
    return (
        "\\begin{table*}[t]\n"
        "\\centering\n"
        f"\\caption{{{caption}}}\n"
        f"\\label{{{label}}}\n"
        f"\\begin{{tabular}}{{{'l' * len(df.columns)}}}\n"
        "\\toprule\n"
        f"{header}\n"
        "\\midrule\n"
        f"{body}\n"
        "\\bottomrule\n"
        "\\end{tabular}\n"
        "\\end{table*}\n"
    )


def build_asset_dir(result_root: Path) -> Path:
    asset_dir = get_paper_asset_path(result_root, "assets", "multi_alpha_transfer")
    ensure_dir(asset_dir)
    return asset_dir


def export_table(df: pd.DataFrame, asset_dir: Path, stem: str, caption: str, label: str) -> dict[str, str]:
    ensure_dir(asset_dir)
    csv_path = asset_dir / f"{stem}.csv"
    md_path = asset_dir / f"{stem}.md"
    tex_path = asset_dir / f"{stem}.tex"
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    md_path.write_text(f"# {stem}\n\n{render_markdown_table(df)}\n", encoding="utf-8")
    tex_path.write_text(render_tex(df, caption=caption, label=label), encoding="utf-8")
    return {"csv_path": str(csv_path), "md_path": str(md_path), "tex_path": str(tex_path)}


def alpha_meta_map() -> dict[str, AlphaMeta]:
    mapping: dict[str, AlphaMeta] = {}
    for task in ALPHA_TASKS:
        spec = get_alpha_strategy(task.name)
        mapping[task.name] = AlphaMeta(
            alpha_name=task.name,
            alpha_category=task.category,
            rationale=task.rationale,
            formula=spec.formula,
            intuition=spec.intuition,
        )
    return mapping


def direction_display(value: str) -> str:
    return str(value).replace("->", "->").upper()


def load_all_alpha_results(result_root: Path) -> pd.DataFrame:
    meta_map = alpha_meta_map()
    frames: list[pd.DataFrame] = []
    for alpha_name, meta in meta_map.items():
        summary_path = result_root / alpha_name / "all_summary.csv"
        if not summary_path.exists():
            continue
        df = pd.read_csv(summary_path)
        if df.empty:
            continue
        df["alpha_name"] = alpha_name
        df["alpha_category"] = meta.alpha_category
        df["alpha_formula"] = meta.formula
        df["alpha_intuition"] = meta.intuition
        df["display_name"] = df["model"].map(DISPLAY_NAME_MAP).fillna(df["model"])
        frames.append(df)
    if not frames:
        raise FileNotFoundError(f"未找到任何 multi alpha 汇总结果: {result_root}")
    result_df = pd.concat(frames, axis=0, ignore_index=True)
    result_df["direction"] = result_df["direction"].astype(str)
    for column in ["Annualized Return", "Sharpe Ratio", "RankIC", "IC", "NDCG@10", "Maximum Drawdown"]:
        if column in result_df.columns:
            result_df[column] = pd.to_numeric(result_df[column], errors="coerce")
    return result_df


def paired_test(values: np.ndarray) -> tuple[float, float]:
    clean_values = np.asarray(values, dtype=float)
    clean_values = clean_values[np.isfinite(clean_values)]
    if clean_values.size < 2:
        return np.nan, np.nan
    ttest_p = float(stats.ttest_1samp(clean_values, popmean=0.0, nan_policy="omit").pvalue)
    non_zero = clean_values[np.abs(clean_values) > 1e-12]
    if non_zero.size < 2:
        return ttest_p, np.nan
    wilcoxon_p = float(stats.wilcoxon(non_zero).pvalue)
    return ttest_p, wilcoxon_p


def build_direction_summary(df: pd.DataFrame) -> pd.DataFrame:
    grouped = (
        df.groupby(["direction", "display_name"], as_index=False)
        .agg(
            alpha_count=("alpha_name", "nunique"),
            mean_ann_return=("Annualized Return", "mean"),
            median_ann_return=("Annualized Return", "median"),
            mean_sharpe=("Sharpe Ratio", "mean"),
            mean_rankic=("RankIC", "mean"),
        )
        .sort_values(["direction", "mean_ann_return"], ascending=[True, False])
        .reset_index(drop=True)
    )
    return grouped


def build_amt_gain_table(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for direction in sorted(df["direction"].unique().tolist()):
        direction_df = df[df["direction"] == direction].copy()
        amt_df = direction_df[direction_df["model"] == "amt"][["alpha_name", "Annualized Return", "Sharpe Ratio", "RankIC"]].rename(
            columns={
                "Annualized Return": "amt_ann_return",
                "Sharpe Ratio": "amt_sharpe",
                "RankIC": "amt_rankic",
            }
        )
        for baseline_name in BASELINE_COMPARE_ORDER:
            baseline_df = direction_df[direction_df["model"] == baseline_name][["alpha_name", "Annualized Return", "Sharpe Ratio", "RankIC"]].rename(
                columns={
                    "Annualized Return": "baseline_ann_return",
                    "Sharpe Ratio": "baseline_sharpe",
                    "RankIC": "baseline_rankic",
                }
            )
            merged = amt_df.merge(baseline_df, on="alpha_name", how="inner")
            if merged.empty:
                continue
            merged["delta_ann_return"] = merged["amt_ann_return"] - merged["baseline_ann_return"]
            merged["delta_sharpe"] = merged["amt_sharpe"] - merged["baseline_sharpe"]
            merged["delta_rankic"] = merged["amt_rankic"] - merged["baseline_rankic"]
            ttest_p, wilcoxon_p = paired_test(merged["delta_ann_return"].to_numpy(dtype=float))
            rows.append(
                {
                    "direction": direction,
                    "baseline": DISPLAY_NAME_MAP[baseline_name],
                    "sample_count": int(len(merged)),
                    "avg_return_gain": float(merged["delta_ann_return"].mean()),
                    "median_return_gain": float(merged["delta_ann_return"].median()),
                    "avg_sharpe_gain": float(merged["delta_sharpe"].mean()),
                    "avg_rankic_gain": float(merged["delta_rankic"].mean()),
                    "win_rate": float((merged["delta_ann_return"] > 0).mean()),
                    "negative_transfer_ratio": float((merged["delta_ann_return"] < 0).mean()),
                    "ttest_p": ttest_p,
                    "wilcoxon_p": wilcoxon_p,
                }
            )
    return pd.DataFrame(rows).sort_values(["direction", "avg_return_gain"], ascending=[True, False]).reset_index(drop=True)


def classify_transferability(row: pd.Series) -> str:
    direct_ret = float(row["direct_ann_return"])
    amt_ret = float(row["amt_ann_return"])
    direct_rankic = float(row["direct_rankic"])
    amt_rankic = float(row["amt_rankic"])
    if amt_ret > direct_ret and amt_rankic > direct_rankic:
        return "stable_positive_transfer"
    if amt_ret > 0 and direct_ret <= 0:
        return "amt_rescued_transfer"
    if amt_ret <= direct_ret:
        return "negative_or_weak_transfer"
    return "mixed_transfer"


def build_transferability_detail(df: pd.DataFrame) -> pd.DataFrame:
    amt_df = df[df["model"] == "amt"][["alpha_name", "alpha_category", "direction", "Annualized Return", "Sharpe Ratio", "RankIC"]].rename(
        columns={
            "Annualized Return": "amt_ann_return",
            "Sharpe Ratio": "amt_sharpe",
            "RankIC": "amt_rankic",
        }
    )
    direct_df = df[df["model"] == "direct_transfer"][["alpha_name", "direction", "Annualized Return", "Sharpe Ratio", "RankIC"]].rename(
        columns={
            "Annualized Return": "direct_ann_return",
            "Sharpe Ratio": "direct_sharpe",
            "RankIC": "direct_rankic",
        }
    )
    merged = amt_df.merge(direct_df, on=["alpha_name", "direction"], how="inner")
    merged["amt_delta_ann_return"] = merged["amt_ann_return"] - merged["direct_ann_return"]
    merged["amt_delta_sharpe"] = merged["amt_sharpe"] - merged["direct_sharpe"]
    merged["amt_delta_rankic"] = merged["amt_rankic"] - merged["direct_rankic"]
    merged["transferability_label"] = merged.apply(classify_transferability, axis=1)
    return merged.sort_values(["direction", "amt_delta_ann_return"], ascending=[True, False]).reset_index(drop=True)


def build_category_summary(detail_df: pd.DataFrame) -> pd.DataFrame:
    return (
        detail_df.groupby(["direction", "alpha_category"], as_index=False)
        .agg(
            alpha_count=("alpha_name", "nunique"),
            avg_amt_gain=("amt_delta_ann_return", "mean"),
            median_amt_gain=("amt_delta_ann_return", "median"),
            amt_win_rate=("amt_delta_ann_return", lambda values: float((values > 0).mean())),
            amt_negative_ratio=("amt_delta_ann_return", lambda values: float((values < 0).mean())),
        )
        .sort_values(["direction", "avg_amt_gain"], ascending=[True, False])
        .reset_index(drop=True)
    )


def build_findings_markdown(
    direction_summary: pd.DataFrame,
    amt_gain_table: pd.DataFrame,
    transferability_detail: pd.DataFrame,
    category_summary: pd.DataFrame,
) -> str:
    lines = [
        "# Multi-Alpha Findings",
        "",
        "## 1. 方向级总体结论",
        "",
    ]
    for direction in sorted(direction_summary["direction"].unique().tolist()):
        subset = direction_summary[direction_summary["direction"] == direction].copy()
        best_row = subset.sort_values("mean_ann_return", ascending=False).iloc[0]
        lines.append(
            f"- `{direction}` 方向平均年化收益最优的方法为 `{best_row['display_name']}`，"
            f"`mean_ann_return={best_row['mean_ann_return']:.4f}`，`mean_rankic={best_row['mean_rankic']:.4f}`。"
        )
    lines.extend(["", "## 2. AMT 相对直接迁移", ""])
    direct_rows = amt_gain_table[amt_gain_table["baseline"] == "Direct Transfer"]
    for _, row in direct_rows.iterrows():
        lines.append(
            f"- `{row['direction']}` 上，AMT 相对 `Direct Transfer` 的平均年化收益增量为 `{row['avg_return_gain']:.4f}`，"
            f"中位数增量为 `{row['median_return_gain']:.4f}`，迁移胜率为 `{row['win_rate']:.2%}`，"
            f"负迁移比例为 `{row['negative_transfer_ratio']:.2%}`。"
        )
    lines.extend(["", "## 3. 可迁移 alpha 类型", ""])
    for direction in sorted(category_summary["direction"].unique().tolist()):
        direction_df = category_summary[category_summary["direction"] == direction].copy()
        best_category = direction_df.sort_values("avg_amt_gain", ascending=False).iloc[0]
        worst_category = direction_df.sort_values("avg_amt_gain", ascending=True).iloc[0]
        lines.append(
            f"- `{direction}` 中最易迁移的类别是 `{best_category['alpha_category']}`，平均增量 `{best_category['avg_amt_gain']:.4f}`；"
            f"最易发生负迁移的类别是 `{worst_category['alpha_category']}`，平均增量 `{worst_category['avg_amt_gain']:.4f}`。"
        )
    lines.extend(["", "## 4. 策略级结论", ""])
    stable_count = int((transferability_detail["transferability_label"] == "stable_positive_transfer").sum())
    rescue_count = int((transferability_detail["transferability_label"] == "amt_rescued_transfer").sum())
    negative_count = int((transferability_detail["transferability_label"] == "negative_or_weak_transfer").sum())
    lines.append(
        f"- 在全部 `{len(transferability_detail)}` 个 alpha-direction 样本中，"
        f"`stable_positive_transfer={stable_count}`，`amt_rescued_transfer={rescue_count}`，"
        f"`negative_or_weak_transfer={negative_count}`。"
    )
    return "\n".join(lines) + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="构建 10 个 alpha 迁移补充实验的标准化统计表")
    parser.add_argument("--batch-root", default="", help="可选，显式指定 full 批次根目录；若为空则严格使用最新 full 批次")
    parser.add_argument("--result-root", default="")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if str(args.result_root).strip():
        result_root = Path(args.result_root)
    elif str(args.batch_root).strip():
        batch_root = require_batch_artifacts(
            Path(args.batch_root),
            (( "主实验", "multi_alpha_transfer" ),),
        )
        result_root = batch_root / "主实验" / "multi_alpha_transfer"
    else:
        batch_root = require_batch_artifacts(
            get_latest_completed_batch_root(prefix="full"),
            (( "主实验", "multi_alpha_transfer" ),),
        )
        result_root = batch_root / "主实验" / "multi_alpha_transfer"
    asset_dir = build_asset_dir(result_root)
    detail_df = load_all_alpha_results(result_root)
    direction_summary = build_direction_summary(detail_df)
    amt_gain_table = build_amt_gain_table(detail_df)
    transferability_detail = build_transferability_detail(detail_df)
    category_summary = build_category_summary(transferability_detail)

    outputs = {
        "multi_alpha_direction_summary": export_table(
            direction_summary,
            asset_dir,
            "multi_alpha_direction_summary",
            "Direction-level averaged performance across 10 alpha tasks.",
            "tab:multi_alpha_direction_summary",
        ),
        "multi_alpha_amt_gain": export_table(
            amt_gain_table,
            asset_dir,
            "multi_alpha_amt_gain",
            "AMT gains against transfer baselines across 10 alpha tasks.",
            "tab:multi_alpha_amt_gain",
        ),
        "multi_alpha_transferability_detail": export_table(
            transferability_detail,
            asset_dir,
            "multi_alpha_transferability_detail",
            "Transferability detail for each alpha and direction.",
            "tab:multi_alpha_transferability_detail",
        ),
        "multi_alpha_category_summary": export_table(
            category_summary,
            asset_dir,
            "multi_alpha_category_summary",
            "Category-level transferability summary.",
            "tab:multi_alpha_category_summary",
        ),
    }
    findings_md = build_findings_markdown(direction_summary, amt_gain_table, transferability_detail, category_summary)
    findings_path = asset_dir / "multi_alpha_findings.md"
    findings_path.write_text(findings_md, encoding="utf-8")
    manifest = {
        "result_root": str(result_root),
        "asset_dir": str(asset_dir),
        "outputs": outputs,
        "findings_path": str(findings_path),
        "alpha_meta": [meta.to_dict() for meta in alpha_meta_map().values()],
    }
    write_json(asset_dir / "multi_alpha_manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
