"""
文件功能:
1. 构建 `DataToSever/_workspace_cn_1999_2025_merge_csv`，为主实验冷启动重建提供标准化的 A 股原始逐股 CSV 工作区。
2. 优先复用 `index_constituent_data/history/{hs300,csi500}` 中已经审计过的 A 股历史明细；若目标股票缺失，则回退到本地 `qlib_market_data/cn_data` 的二进制特征文件进行补全。
3. 将不同来源的行情统一标准化为项目既有的 qlib 风格字段：`date,symbol,open,high,low,close,volume,factor,change,adjclose`。
4. 输出工作区构建清单、质量摘要 JSON 与 Markdown 校验报告，便于 DataToSever 文档与论文复现实验保持一致。

代码逻辑:
1. 读取 `cn_index_constituents.csv` 的历史成分股白名单，并与 `hs300/csi500` 历史明细中的股票集合求并，形成本次应覆盖的 A 股目标集合。
2. 对已有 A 股历史明细做字段重命名、日期与数值清洗、按交易日去重，然后转换为 qlib 风格归一化 CSV。
3. 对缺失股票，使用本地 `qlib_market_data/cn_data/features/<symbol>` 中的 open/high/low/close/volume/factor/change 二进制文件重建工作区 CSV。
4. 对全部输出文件执行列完整性、日期范围、重复交易日、关键字段缺失与白名单覆盖率检查，并落盘校验报告。

代码结构:
1. 路径常量与字段规范。
2. 源数据读取与标准化函数。
3. 工作区构建与结果写入函数。
4. 质量校验与报告生成函数。
5. 命令行入口。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_ROOT = ROOT_DIR / "DataToSever"
HISTORY_ROOT = DATA_ROOT / "index_constituent_data" / "history"
QLIB_ROOT = DATA_ROOT / "qlib_market_data" / "cn_data"
WORKSPACE_DIR = DATA_ROOT / "_workspace_cn_1999_2025_merge_csv"
SUMMARY_JSON_PATH = WORKSPACE_DIR / "workspace_build_summary.json"
DETAIL_CSV_PATH = WORKSPACE_DIR / "workspace_build_details.csv"
REQUIRED_COLUMNS = ["date", "symbol", "open", "high", "low", "close", "volume", "factor", "change", "adjclose"]
BUILD_START = pd.Timestamp("1999-01-01")
BUILD_END = pd.Timestamp("2025-12-31")
SOURCE_PRIORITY = {"history": 1, "qlib": 2}


@dataclass(frozen=True)
class BuildStats:
    target_symbol_count: int
    output_symbol_count: int
    whitelist_symbol_count: int
    whitelist_covered_count: int
    history_source_count: int
    qlib_source_count: int
    missing_symbol_count: int
    total_rows: int


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def to_qlib_cn_symbol(raw_symbol: str) -> str:
    text = str(raw_symbol).strip().upper()
    if text.startswith(("SH", "SZ")):
        return text
    code = "".join(ch for ch in text if ch.isdigit()).zfill(6)
    if code.startswith(("600", "601", "603", "605", "688")):
        return f"SH{code}"
    return f"SZ{code}"


def read_cn_whitelist() -> set[str]:
    whitelist_path = DATA_ROOT / "cn_index_constituents.csv"
    if not whitelist_path.exists():
        return set()
    df = pd.read_csv(whitelist_path)
    if df.empty:
        return set()
    symbol_col = "symbol" if "symbol" in df.columns else df.columns[0]
    work_df = df.copy()
    work_df[symbol_col] = work_df[symbol_col].map(to_qlib_cn_symbol)
    if "end_date" in work_df.columns:
        work_df["end_date"] = pd.to_datetime(work_df["end_date"], errors="coerce")
        latest_end = work_df["end_date"].dropna().max()
        if pd.notna(latest_end):
            work_df = work_df.loc[work_df["end_date"] == latest_end].copy()
    return set(work_df[symbol_col].dropna().astype(str))


def collect_history_candidates() -> dict[str, list[Path]]:
    symbol_to_paths: dict[str, list[Path]] = {}
    for index_key in ["hs300", "csi500"]:
        index_dir = HISTORY_ROOT / index_key
        if not index_dir.exists():
            continue
        for csv_path in sorted(index_dir.glob("*.csv")):
            symbol = to_qlib_cn_symbol(csv_path.stem)
            symbol_to_paths.setdefault(symbol, []).append(csv_path)
    return symbol_to_paths


def read_history_source(symbol: str, csv_paths: list[Path]) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for csv_path in csv_paths:
        df = pd.read_csv(csv_path)
        if df.empty:
            continue
        rename_map = {"adj_close": "adjclose"}
        work_df = df.rename(columns=rename_map).copy()
        work_df.columns = [str(col).strip().lower() for col in work_df.columns]
        needed_cols = [col for col in ["date", "open", "high", "low", "close", "volume", "adjclose"] if col in work_df.columns]
        if "date" not in needed_cols or "close" not in needed_cols:
            continue
        work_df = work_df[needed_cols].copy()
        work_df["date"] = pd.to_datetime(work_df["date"], errors="coerce")
        for col in ["open", "high", "low", "close", "volume", "adjclose"]:
            if col in work_df.columns:
                work_df[col] = pd.to_numeric(work_df[col], errors="coerce")
        if "adjclose" not in work_df.columns:
            work_df["adjclose"] = work_df["close"]
        work_df["symbol"] = symbol
        frames.append(work_df)
    if not frames:
        return pd.DataFrame()
    merged = pd.concat(frames, axis=0, ignore_index=True)
    merged = merged.dropna(subset=["date"]).sort_values("date").drop_duplicates(subset=["date"], keep="last")
    merged = merged[(merged["date"] >= BUILD_START) & (merged["date"] <= BUILD_END)].copy()
    if merged.empty:
        return merged
    return merged.reset_index(drop=True)


def read_calendar() -> pd.Series:
    calendar_path = QLIB_ROOT / "calendars" / "day.txt"
    calendar = pd.read_csv(calendar_path, header=None)[0]
    return pd.to_datetime(calendar, errors="coerce")


def read_qlib_bin_series(bin_path: Path, calendar: pd.Series) -> pd.Series:
    with bin_path.open("rb") as file_obj:
        start_index = int(np.frombuffer(file_obj.read(4), dtype="<f")[0])
        values = np.frombuffer(file_obj.read(), dtype="<f")
    if len(values) == 0:
        return pd.Series(dtype=np.float32)
    dates = calendar.iloc[start_index : start_index + len(values)].reset_index(drop=True)
    return pd.Series(values, index=dates)


def read_qlib_source(symbol: str, calendar: pd.Series) -> pd.DataFrame:
    feature_dir = QLIB_ROOT / "features" / symbol.lower()
    if not feature_dir.exists():
        return pd.DataFrame()
    field_map = {
        "open": feature_dir / "open.day.bin",
        "high": feature_dir / "high.day.bin",
        "low": feature_dir / "low.day.bin",
        "close": feature_dir / "close.day.bin",
        "volume": feature_dir / "volume.day.bin",
        "factor": feature_dir / "factor.day.bin",
        "change": feature_dir / "change.day.bin",
    }
    if not all(path.exists() for path in field_map.values()):
        return pd.DataFrame()
    data: dict[str, pd.Series] = {name: read_qlib_bin_series(path, calendar) for name, path in field_map.items()}
    frame = pd.DataFrame(data).reset_index(names="date")
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce")
    frame = frame[(frame["date"] >= BUILD_START) & (frame["date"] <= BUILD_END)].copy()
    if frame.empty:
        return frame
    for col in ["open", "high", "low", "close", "volume", "factor", "change"]:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    # `adjclose` 在 qlib 官方 bin 中并非所有标的都有独立字段，这里使用 `close / factor`
    # 近似恢复未归一化的原始收盘价，满足工作区 CSV 的字段完整性与主实验兼容性。
    frame["adjclose"] = frame["close"] / frame["factor"].replace(0.0, np.nan)
    frame["symbol"] = symbol
    frame = frame.dropna(subset=["date"]).sort_values("date").drop_duplicates(subset=["date"], keep="last")
    return frame.reset_index(drop=True)


def qlib_style_normalize(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame
    work_df = frame.copy()
    work_df["date"] = pd.to_datetime(work_df["date"], errors="coerce")
    work_df = work_df.dropna(subset=["date", "symbol"]).sort_values("date").drop_duplicates(subset=["date"], keep="last")
    for col in ["open", "high", "low", "close", "volume", "adjclose"]:
        work_df[col] = pd.to_numeric(work_df[col], errors="coerce")
    if "factor" not in work_df.columns:
        work_df["factor"] = (work_df["adjclose"] / work_df["close"]).replace([np.inf, -np.inf], np.nan)
    work_df["factor"] = pd.to_numeric(work_df["factor"], errors="coerce").replace([np.inf, -np.inf], np.nan)
    work_df["factor"] = work_df["factor"].ffill().bfill().fillna(1.0)
    work_df["change"] = pd.to_numeric(work_df.get("change"), errors="coerce")
    work_df["change"] = work_df["change"].where(work_df["change"].notna(), work_df["close"].pct_change(fill_method=None))

    # 统一转为项目现有 qlib 风格：OHLC 采用复权价并按首个有效 close 归一化，
    # volume 做反向缩放，方便与 `_workspace_us_2021_2025_csv` 保持相同接口。
    work_df["open"] = work_df["open"] * work_df["factor"]
    work_df["high"] = work_df["high"] * work_df["factor"]
    work_df["low"] = work_df["low"] * work_df["factor"]
    work_df["close"] = work_df["close"] * work_df["factor"]
    work_df["volume"] = work_df["volume"] / work_df["factor"].replace(0.0, np.nan)

    valid_close = work_df["close"].dropna()
    if valid_close.empty or float(valid_close.iloc[0]) == 0.0:
        return pd.DataFrame(columns=REQUIRED_COLUMNS)
    base_close = float(valid_close.iloc[0])
    for col in ["open", "high", "low", "close", "factor"]:
        work_df[col] = work_df[col] / base_close
    work_df["volume"] = work_df["volume"] * base_close
    work_df = work_df.dropna(subset=["open", "high", "low", "close", "volume"]).copy()
    work_df["change"] = work_df["close"].pct_change(fill_method=None)
    work_df["date"] = work_df["date"].dt.strftime("%Y-%m-%d")
    work_df["symbol"] = work_df["symbol"].astype(str).str.upper()
    return work_df[REQUIRED_COLUMNS].dropna(subset=["date", "symbol"]).reset_index(drop=True)


def validate_output_csv(csv_path: Path) -> dict[str, Any]:
    df = pd.read_csv(csv_path)
    columns_ok = df.columns.tolist() == REQUIRED_COLUMNS
    date_series = pd.to_datetime(df["date"], errors="coerce")
    duplicate_dates = int(date_series.duplicated().sum())
    null_core = int(df[["date", "symbol", "open", "high", "low", "close", "volume"]].isna().sum().sum())
    return {
        "path": str(csv_path),
        "symbol": csv_path.stem.upper(),
        "rows": int(len(df)),
        "columns_ok": bool(columns_ok),
        "date_min": date_series.min().strftime("%Y-%m-%d") if not date_series.isna().all() else "",
        "date_max": date_series.max().strftime("%Y-%m-%d") if not date_series.isna().all() else "",
        "duplicate_dates": duplicate_dates,
        "null_core_fields": null_core,
    }


def build_workspace() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    ensure_dir(WORKSPACE_DIR)
    calendar = read_calendar()
    whitelist = read_cn_whitelist()
    history_candidates = collect_history_candidates()
    target_symbols = sorted(set(history_candidates) | whitelist)
    details: list[dict[str, Any]] = []
    output_stats: list[dict[str, Any]] = []
    history_source_count = 0
    qlib_source_count = 0

    for idx, symbol in enumerate(target_symbols, start=1):
        source_used = ""
        source_note = ""
        raw_df = pd.DataFrame()
        history_paths = history_candidates.get(symbol, [])
        if history_paths:
            raw_df = read_history_source(symbol, history_paths)
            if not raw_df.empty:
                source_used = "history"
                source_note = ";".join(sorted({str(path.relative_to(DATA_ROOT)) for path in history_paths}))
        if raw_df.empty:
            raw_df = read_qlib_source(symbol, calendar)
            if not raw_df.empty:
                source_used = "qlib"
                source_note = f"qlib_market_data/cn_data/features/{symbol.lower()}"

        if raw_df.empty:
            details.append(
                {
                    "symbol": symbol,
                    "status": "missing",
                    "source": "",
                    "rows": 0,
                    "date_min": "",
                    "date_max": "",
                    "note": "未在 index_constituent_data/history 与 qlib_market_data/cn_data 中找到可用源数据",
                }
            )
            continue

        normalized_df = qlib_style_normalize(raw_df)
        if normalized_df.empty:
            details.append(
                {
                    "symbol": symbol,
                    "status": "empty_after_normalize",
                    "source": source_used,
                    "rows": 0,
                    "date_min": "",
                    "date_max": "",
                    "note": source_note,
                }
            )
            continue

        output_path = WORKSPACE_DIR / f"{symbol.lower()}.csv"
        normalized_df.to_csv(output_path, index=False, encoding="utf-8")
        validation = validate_output_csv(output_path)
        details.append(
            {
                "symbol": symbol,
                "status": "ok",
                "source": source_used,
                "rows": int(len(normalized_df)),
                "date_min": validation["date_min"],
                "date_max": validation["date_max"],
                "note": source_note,
            }
        )
        output_stats.append(validation)
        if source_used == "history":
            history_source_count += 1
        elif source_used == "qlib":
            qlib_source_count += 1

        if idx % 50 == 0 or idx == len(target_symbols):
            log(f"[CN workspace] {idx}/{len(target_symbols)} symbols processed")

    detail_df = pd.DataFrame(details).sort_values(["status", "symbol"], ascending=[True, True]).reset_index(drop=True)
    detail_df.to_csv(DETAIL_CSV_PATH, index=False, encoding="utf-8-sig")

    ok_symbols = {item["symbol"] for item in details if item["status"] == "ok"}
    stats = BuildStats(
        target_symbol_count=len(target_symbols),
        output_symbol_count=len(ok_symbols),
        whitelist_symbol_count=len(whitelist),
        whitelist_covered_count=len(ok_symbols & whitelist),
        history_source_count=history_source_count,
        qlib_source_count=qlib_source_count,
        missing_symbol_count=sum(1 for item in details if item["status"] != "ok"),
        total_rows=int(sum(item["rows"] for item in details if item["status"] == "ok")),
    )
    payload = {
        "workspace_dir": str(WORKSPACE_DIR),
        "build_start": str(BUILD_START.date()),
        "build_end": str(BUILD_END.date()),
        "stats": stats.__dict__,
        "missing_symbols": [item["symbol"] for item in details if item["status"] != "ok"],
        "sample_output_files": [item["path"] for item in output_stats[:20]],
        "validation_summary": {
            "columns_all_ok": all(item["columns_ok"] for item in output_stats),
            "duplicate_date_symbols": [item["symbol"] for item in output_stats if item["duplicate_dates"] > 0][:50],
            "null_core_symbols": [item["symbol"] for item in output_stats if item["null_core_fields"] > 0][:50],
        },
    }
    SUMMARY_JSON_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return details, payload


def render_markdown_report(payload: dict[str, Any], details: list[dict[str, Any]]) -> str:
    stats = payload["stats"]
    missing_rows = [item for item in details if item["status"] != "ok"]
    sample_rows = [item for item in details if item["status"] == "ok"][:10]
    lines = [
        "# CN 原始 CSV 工作区补全校验报告 v1",
        "",
        "## 1. 校验结论",
        "",
        f"- 工作区目录: `{payload['workspace_dir']}`",
        f"- 构建时间窗口: `{payload['build_start']}` 至 `{payload['build_end']}`",
        f"- 目标股票数: `{stats['target_symbol_count']}`",
        f"- 成功输出股票数: `{stats['output_symbol_count']}`",
        f"- 白名单覆盖数: `{stats['whitelist_covered_count']} / {stats['whitelist_symbol_count']}`",
        f"- 历史明细来源股票数: `{stats['history_source_count']}`",
        f"- qlib 二进制补全股票数: `{stats['qlib_source_count']}`",
        f"- 未成功输出股票数: `{stats['missing_symbol_count']}`",
        f"- 总输出行数: `{stats['total_rows']}`",
        f"- 列结构一致性: `{payload['validation_summary']['columns_all_ok']}`",
        "",
        "## 2. 输出字段规范",
        "",
        "- 固定字段顺序: `date,symbol,open,high,low,close,volume,factor,change,adjclose`",
        "- 日期格式: `YYYY-MM-DD`",
        "- 符号格式: `SH/SZ + 6 位数字`，文件名为小写，例如 `sh600000.csv`",
        "- 价格/成交量口径: 与现有 `_workspace_us_2021_2025_csv` 保持一致，采用 qlib 风格归一化接口",
        "",
        "## 3. 样例文件",
        "",
        "| symbol | source | rows | date_min | date_max | note |",
        "| --- | --- | ---: | --- | --- | --- |",
    ]
    for item in sample_rows:
        lines.append(
            f"| {item['symbol']} | {item['source']} | {item['rows']} | {item['date_min']} | {item['date_max']} | {item['note']} |"
        )
    lines.extend(["", "## 4. 未成功输出清单", ""])
    if not missing_rows:
        lines.append("- 无。")
    else:
        lines.append("| symbol | status | note |")
        lines.append("| --- | --- | --- |")
        for item in missing_rows[:100]:
            lines.append(f"| {item['symbol']} | {item['status']} | {item['note']} |")
    lines.extend(
        [
            "",
            "## 5. 交叉校验说明",
            "",
            "- `workspace_build_details.csv` 记录了每个股票的来源、行数、起止日期与状态。",
            "- `workspace_build_summary.json` 汇总了白名单覆盖率、来源分布、缺失符号与列结构校验结果。",
            "- 本报告与上述两份文件共同作为 DataToSever 文档同步更新的依据。",
            "",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> int:
    details, payload = build_workspace()
    report_path = DATA_ROOT / "CN原始CSV工作区补全校验报告_v1.md"
    report_path.write_text(render_markdown_report(payload, details), encoding="utf-8")
    log(f"CN workspace build finished: {WORKSPACE_DIR}")
    log(f"Summary: {SUMMARY_JSON_PATH}")
    log(f"Details: {DETAIL_CSV_PATH}")
    log(f"Report: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
