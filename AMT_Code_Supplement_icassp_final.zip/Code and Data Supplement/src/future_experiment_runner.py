"""
文件功能:
1. 一键串联期货静态超图构建与 `alpha_case` 股票到期货迁移实验。
2. 记录超图构建时间、alpha 迁移时间以及总耗时，生成可直接引用的时间评估结果。
3. 保持结果目录协议与现有股票 `alpha_case` 一致，便于横向比较。

代码逻辑:
1. 先调用 `HGNNcode/futures_hypergraph_pipeline.py` 中的构建函数准备 `processed_data/future`。
2. 再直接复用现有 `alpha_case_transfer.py`，运行 `CN -> FUTURE` 的跨资产迁移案例。
3. 最后将构建耗时、迁移耗时、结果目录和关键配置写入根目录结果 JSON。

代码结构:
1. 路径准备与模块导入。
2. 单次实验执行函数。
3. 命令行入口。
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
HGNN_DIR = ROOT_DIR / "HGNNcode"
if str(HGNN_DIR) not in sys.path:
    sys.path.append(str(HGNN_DIR))

from alpha_case_transfer import AlphaCaseConfig, run_alpha_case_transfer
from experiment_workspace import get_categorized_result_path, write_json
from futures_hypergraph_pipeline import prepare_futures_hypergraph


TIME_REPORT_PATH = get_categorized_result_path("other", "future_experiment_time_report.json")


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def run_future_experiment(force_rebuild: bool = False, source_market: str = "CN", target_market: str = "FUTURE") -> dict[str, object]:
    build_start = time.perf_counter()
    build_payload = prepare_futures_hypergraph(force_rebuild=force_rebuild)
    build_elapsed = float(time.perf_counter() - build_start)

    transfer_start = time.perf_counter()
    alpha_payload = run_alpha_case_transfer(
        AlphaCaseConfig(
            source_market=source_market.upper(),
            target_market=target_market.upper(),
            top_k=10,
        )
    )
    transfer_elapsed = float(time.perf_counter() - transfer_start)

    payload = {
        "source_market": source_market.upper(),
        "target_market": target_market.upper(),
        "build_elapsed_seconds": build_elapsed,
        "transfer_elapsed_seconds": transfer_elapsed,
        "total_elapsed_seconds": build_elapsed + transfer_elapsed,
        "build_payload": build_payload,
        "alpha_payload": alpha_payload,
        "gpu_note": "当前 alpha_case 为纯 pandas/numpy 参数搜索流程，4060 不直接参与计算；若后续接入 HGNN/神经网络训练，再单独统计 GPU 训练耗时。",
    }
    ensure_parent(TIME_REPORT_PATH)
    write_json(TIME_REPORT_PATH, payload)
    return payload


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行期货静态超图与 alpha_case 股票到期货迁移实验")
    parser.add_argument("--force-rebuild", action="store_true", help="强制重建期货超图与 panel 缓存")
    parser.add_argument("--source-market", default="CN")
    parser.add_argument("--target-market", default="FUTURE")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    payload = run_future_experiment(
        force_rebuild=args.force_rebuild,
        source_market=args.source_market,
        target_market=args.target_market,
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

