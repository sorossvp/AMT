"""
文件功能:
1. 在统一的源域预训练 + 目标域适配初始化条件下, 运行专属的迁移类方法对比实验。
2. 输出 `Direct Transfer / AMT / LSTM-Transfer / Transformer-Transfer / Routing-Transfer (TRA-like) / Relation-Transfer (HIST-like)` 六类结果。
3. 为论文中的“AMT vs 直接迁移”“AMT vs 其他迁移方法”提供单独、可复现、可审计的公平对照结果。

代码逻辑:
1. 读取与主实验完全一致的源域/目标域面板和超图数据。
2. 对所有迁移类方法统一采用“源域预训练 -> 目标域 fine-tune / adapt”的初始化条件。
3. 将结果统一保存到 `主实验/phase1_transfer_family` 下, 与旧主实验结果并行存在, 避免混淆。

代码结构:
1. 常量与模型命名映射。
2. 统一迁移训练函数。
3. 单方向实验驱动。
4. 总汇总与 CLI 入口。
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys
import time
from typing import Any

import pandas as pd
import torch

if __package__ is None or __package__ == "":
    sys.path.append(str(Path(__file__).resolve().parent))

from alpha_strategy_library import (
    get_alpha_strategy,
    inject_base_alpha_features,
    normalize_alpha_strategy_names,
)
from data_pipeline import SplitConfig, prepare_transfer_artifacts
from experiment_profiles import get_profile, profile_to_dict, resolve_max_symbols
from experiment_runner import (
    DIRECTION_SPECS,
    ModelHeartbeat,
    align_transfer_concept_arrays,
    amt_scoring_config_to_dict,
    amt_supervised_loss_config_to_dict,
    cap_market_artifacts_for_quick_mode,
    build_amt_scoring_config,
    build_amt_supervised_loss_config,
    build_adaptation_policy_config,
    build_market_similarity_config,
    build_threshold_update_config,
    evaluate_and_save,
    format_progress,
    format_seconds,
    log,
    make_dataset,
    normalize_direction,
    parse_csv_args,
    read_existing_summary,
    scale_epoch_count,
    summarize_metrics,
    build_split_arrays,
)
from experiment_workspace import get_categorized_result_path, write_dataframe, write_json
from market_similarity import (
    AdaptationPolicyConfig,
    MarketSimilarityConfig,
    ThresholdUpdateConfig,
    build_adaptation_param_groups,
    collect_optimizer_group_summary,
    compute_market_similarity,
    recommend_similarity_threshold,
    render_similarity_report_markdown,
    resolve_adaptation_policy,
    update_threshold_history,
)
from models import (
    ALPHA_FEATURES,
    AMTScoringConfig,
    SupervisedLossConfig,
    TorchTrainingConfig,
    build_torch_model,
    fit_torch_regressor,
    predict_torch_regressor,
    unwrap_model,
)


DEFAULT_TRANSFER_FAMILY_RESULT_DIR = get_categorized_result_path("main", "phase1_transfer_family")
TRANSFER_MODEL_NAMES = [
    "direct_transfer",
    "amt",
    "lstm_transfer",
    "transformer_transfer",
    "tra_transfer",
    "hist_transfer",
]
TRANSFER_DISPLAY_NAMES = {
    "direct_transfer": "Direct Transfer",
    "amt": "AMT",
    "lstm_transfer": "LSTM-Transfer",
    "transformer_transfer": "Transformer-Transfer",
    "tra_transfer": "Routing-Transfer (TRA-like)",
    "hist_transfer": "Relation-Transfer (HIST-like)",
}


def normalize_transfer_model_name(value: str) -> str:
    normalized = str(value).strip().lower()
    alias_map = {
        "amt": "amt",
        "main": "amt",
        "main_transfer": "amt",
        "direct": "direct_transfer",
        "direct_transfer": "direct_transfer",
        "lstm": "lstm_transfer",
        "lstm_transfer": "lstm_transfer",
        "transformer": "transformer_transfer",
        "transformer_transfer": "transformer_transfer",
        "tra": "tra_transfer",
        "tra_transfer": "tra_transfer",
        "hist": "hist_transfer",
        "hist_transfer": "hist_transfer",
    }
    normalized = alias_map.get(normalized, normalized)
    if normalized not in TRANSFER_MODEL_NAMES:
        raise ValueError(f"不支持的迁移模型参数: {value}")
    return normalized


def normalize_transfer_model_names(raw_value: str | None) -> list[str]:
    values = parse_csv_args(raw_value)
    if not values:
        return list(TRANSFER_MODEL_NAMES)
    normalized: list[str] = []
    for item in values:
        model_name = normalize_transfer_model_name(item)
        if model_name not in normalized:
            normalized.append(model_name)
    return normalized


def fine_tune_transfer_model(
    save_name: str,
    base_model_name: str,
    source_arrays: dict[str, dict[str, Any]],
    target_arrays: dict[str, dict[str, Any]],
    target_meta: dict[str, pd.DataFrame],
    model_dir: Path,
    top_k: int,
    device: str,
    mode: str,
) -> dict[str, float]:
    source_train = make_dataset(source_arrays["train"])
    source_valid = make_dataset(source_arrays["valid"])
    target_train = make_dataset(target_arrays["train"])
    target_valid = make_dataset(target_arrays["valid"])
    target_test = make_dataset(target_arrays["test"])
    model = build_torch_model(
        model_name=base_model_name,
        seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=source_arrays["train"]["concept_x"].shape[-1],
        alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
    )
    pretrain_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(10, mode=mode, minimum_epochs=4),
        batch_size=512,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    model = fit_torch_regressor(model, source_train, source_valid, config=pretrain_cfg, device=device)
    fine_tune_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(6, mode=mode, minimum_epochs=3),
        batch_size=512,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    model = fit_torch_regressor(model, target_train, target_valid, config=fine_tune_cfg, device=device)
    prediction = predict_torch_regressor(model, target_test, batch_size=1024, device=device)
    return evaluate_and_save(save_name, model_dir, target_meta["test"], prediction, top_k=top_k)


def run_amt_transfer_model(
    source_arrays: dict[str, dict[str, Any]],
    target_arrays: dict[str, dict[str, Any]],
    target_meta: dict[str, pd.DataFrame],
    model_dir: Path,
    top_k: int,
    device: str,
    mode: str,
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    weight_param: float,
    weight_mech: float,
    source_market: str,
    target_market: str,
    enable_similarity_policy: bool,
    similarity_config: MarketSimilarityConfig,
    threshold_config: ThresholdUpdateConfig,
    policy_config: AdaptationPolicyConfig,
    similarity_history_path: Path,
) -> dict[str, float]:
    source_train = make_dataset(source_arrays["train"])
    source_valid = make_dataset(source_arrays["valid"])
    target_train = make_dataset(target_arrays["train"])
    target_valid = make_dataset(target_arrays["valid"])
    target_test = make_dataset(target_arrays["test"])

    model = build_torch_model(
        model_name="main",
        seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=source_arrays["train"]["concept_x"].shape[-1],
        alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
        scoring_config=scoring_config,
    )
    pretrain_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(12, mode=mode, minimum_epochs=4),
        batch_size=512,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=3,
    )
    model = fit_torch_regressor(
        model,
        source_train,
        source_valid,
        config=pretrain_cfg,
        supervised_loss_config=supervised_loss_config,
        device=device,
    )
    model = unwrap_model(model)

    def transfer_penalty(model_obj: torch.nn.Module, batch: tuple[torch.Tensor, ...], pred: Any) -> torch.Tensor:
        _ = pred
        return model_obj.extra_transfer_loss(
            batch[4],
            batch[1],
            batch[0],
            batch[2],
            batch[3],
            weight_param=weight_param,
            weight_mech=weight_mech,
        )

    adapt_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(8, mode=mode, minimum_epochs=3),
        batch_size=512,
        lr=1e-3,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    optimizer_group_builder = None
    similarity_payload: dict[str, Any] | None = None
    report_markdown: str | None = None
    if enable_similarity_policy:
        similarity_result = compute_market_similarity(
            source_arrays=source_arrays["train"],
            target_arrays=target_arrays["train"],
            model=model,
            device=device,
            config=similarity_config,
        )
        threshold_summary = recommend_similarity_threshold(similarity_history_path, config=threshold_config)
        adaptation_policy = resolve_adaptation_policy(
            similarity_score=float(similarity_result.final_similarity),
            similarity_threshold=float(threshold_summary["threshold"]),
            config=policy_config,
        )
        model.configure_target_adaptation(**adaptation_policy.to_adaptation_kwargs())
        optimizer_group_builder = lambda model_obj, cfg: build_adaptation_param_groups(model_obj, cfg, adaptation_policy)
        optimizer_groups = collect_optimizer_group_summary(model, base_lr=float(adapt_cfg.lr), policy=adaptation_policy)
        similarity_payload = {
            "direction": f"{source_market}->{target_market}",
            "similarity_result": similarity_result.to_dict(),
            "threshold_summary": threshold_summary,
            "adaptation_policy": adaptation_policy.to_dict(),
            "optimizer_groups": optimizer_groups,
            "history_path": str(similarity_history_path),
        }
        report_markdown = render_similarity_report_markdown(
            source_market=source_market,
            target_market=target_market,
            similarity_result=similarity_result,
            threshold_summary=threshold_summary,
            policy=adaptation_policy,
            optimizer_groups=optimizer_groups,
        )
    else:
        model.switch_to_target_adaptation()

    model = fit_torch_regressor(
        model,
        target_train,
        target_valid,
        config=adapt_cfg,
        supervised_loss_config=supervised_loss_config,
        extra_loss_fn=transfer_penalty,
        optimizer_group_builder=optimizer_group_builder,
        device=device,
    )
    prediction = predict_torch_regressor(model, target_test, batch_size=1024, device=device)
    metrics = evaluate_and_save("AMT", model_dir, target_meta["test"], prediction, top_k=top_k)
    if similarity_payload is not None:
        similarity_payload["post_run_metrics"] = {
            "Annualized Return": float(metrics.get("Annualized Return", metrics.get("AnnualizedReturn", 0.0))),
            "Sharpe": float(metrics.get("Sharpe Ratio", metrics.get("Sharpe", 0.0))),
            "RankIC": float(metrics.get("RankIC", 0.0)),
        }
        similarity_payload["post_run_threshold_recommendation"] = update_threshold_history(
            history_path=similarity_history_path,
            record={
                "direction": f"{source_market}->{target_market}",
                "similarity_score": float(similarity_payload["similarity_result"]["final_similarity"]),
                "threshold_used": float(similarity_payload["threshold_summary"]["threshold"]),
                "policy_name": str(similarity_payload["adaptation_policy"]["policy_name"]),
                "supervised_metric": float(metrics.get("Annualized Return", metrics.get("AnnualizedReturn", 0.0))),
                "rankic": float(metrics.get("RankIC", 0.0)),
            },
            config=threshold_config,
        )
        write_json(model_dir / "market_similarity_report.json", similarity_payload)
        if report_markdown is not None:
            (model_dir / "market_similarity_report.md").write_text(report_markdown, encoding="utf-8")
    return metrics


def run_direct_transfer_model(
    source_arrays: dict[str, dict[str, Any]],
    target_arrays: dict[str, dict[str, Any]],
    target_meta: dict[str, pd.DataFrame],
    model_dir: Path,
    top_k: int,
    device: str,
    mode: str,
) -> dict[str, float]:
    source_train = make_dataset(source_arrays["train"])
    source_valid = make_dataset(source_arrays["valid"])
    target_train = make_dataset(target_arrays["train"])
    target_valid = make_dataset(target_arrays["valid"])
    target_test = make_dataset(target_arrays["test"])

    model = build_torch_model(
        model_name="main",
        seq_dim=source_arrays["train"]["sequence_x"].shape[-1],
        tab_dim=source_arrays["train"]["tabular_x"].shape[-1],
        concept_dim=source_arrays["train"]["concept_x"].shape[-1],
        alpha_dim=source_arrays["train"]["alpha_x"].shape[-1],
    )
    pretrain_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(12, mode=mode, minimum_epochs=4),
        batch_size=512,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=3,
    )
    model = fit_torch_regressor(model, source_train, source_valid, config=pretrain_cfg, device=device)
    fine_tune_cfg = TorchTrainingConfig(
        n_epochs=scale_epoch_count(8, mode=mode, minimum_epochs=3),
        batch_size=512,
        lr=8e-4,
        weight_decay=1e-5,
        early_stop_rounds=2,
    )
    model = fit_torch_regressor(model, target_train, target_valid, config=fine_tune_cfg, device=device)
    prediction = predict_torch_regressor(model, target_test, batch_size=1024, device=device)
    return evaluate_and_save("Direct Transfer", model_dir, target_meta["test"], prediction, top_k=top_k)


def run_transfer_model(
    model_name: str,
    source_arrays: dict[str, dict[str, Any]],
    target_arrays: dict[str, dict[str, Any]],
    target_meta: dict[str, pd.DataFrame],
    experiment_dir: Path,
    top_k: int,
    device: str,
    mode: str,
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    weight_param: float,
    weight_mech: float,
    source_market: str,
    target_market: str,
    enable_similarity_policy: bool,
    similarity_config: MarketSimilarityConfig,
    threshold_config: ThresholdUpdateConfig,
    policy_config: AdaptationPolicyConfig,
    similarity_history_path: Path,
) -> dict[str, float]:
    model_dir = experiment_dir / model_name
    if model_name == "direct_transfer":
        return run_direct_transfer_model(source_arrays, target_arrays, target_meta, model_dir, top_k=top_k, device=device, mode=mode)
    if model_name == "amt":
        return run_amt_transfer_model(
            source_arrays,
            target_arrays,
            target_meta,
            model_dir,
            top_k=top_k,
            device=device,
            mode=mode,
            scoring_config=scoring_config,
            supervised_loss_config=supervised_loss_config,
            weight_param=weight_param,
            weight_mech=weight_mech,
            source_market=source_market,
            target_market=target_market,
            enable_similarity_policy=enable_similarity_policy,
            similarity_config=similarity_config,
            threshold_config=threshold_config,
            policy_config=policy_config,
            similarity_history_path=similarity_history_path,
        )
    base_map = {
        "lstm_transfer": "lstm",
        "transformer_transfer": "transformer",
        "tra_transfer": "tra",
        "hist_transfer": "hist",
    }
    if model_name not in base_map:
        raise ValueError(model_name)
    return fine_tune_transfer_model(
        save_name=TRANSFER_DISPLAY_NAMES[model_name],
        base_model_name=base_map[model_name],
        source_arrays=source_arrays,
        target_arrays=target_arrays,
        target_meta=target_meta,
        model_dir=model_dir,
        top_k=top_k,
        device=device,
        mode=mode,
    )


def run_one_direction(
    source_market: str,
    target_market: str,
    max_symbols: int,
    lookback: int,
    top_k: int,
    device: str,
    force_rebuild: bool,
    mode: str,
    base_alpha_names: list[str],
    result_root: Path,
    scoring_config: AMTScoringConfig,
    supervised_loss_config: SupervisedLossConfig,
    weight_param: float,
    weight_mech: float,
    enable_similarity_policy: bool,
    similarity_config: MarketSimilarityConfig,
    threshold_config: ThresholdUpdateConfig,
    policy_config: AdaptationPolicyConfig,
    similarity_history_path: Path,
    selected_models: list[str] | None = None,
    skip_existing: bool = True,
) -> pd.DataFrame:
    requested_models = selected_models or list(TRANSFER_MODEL_NAMES)
    direction_name = f"{source_market}->{target_market}"
    experiment_dir = result_root / f"{source_market.lower()}_to_{target_market.lower()}"
    experiment_dir.mkdir(parents=True, exist_ok=True)
    summary_rows: list[dict[str, Any]] = []
    runnable_models: list[str] = []

    for model_name in requested_models:
        existing_summary = read_existing_summary(experiment_dir / model_name)
        if existing_summary is not None and skip_existing:
            summary_rows.append({"direction": direction_name, "model": model_name, "display_name": TRANSFER_DISPLAY_NAMES[model_name], **existing_summary})
            continue
        runnable_models.append(model_name)

    if not runnable_models:
        summary_df = pd.DataFrame(summary_rows)
        if not summary_df.empty:
            write_dataframe(summary_df, experiment_dir / "summary.csv", index=False, encoding="utf-8-sig")
        return summary_df

    profile = get_profile(mode)
    source_max_symbols = resolve_max_symbols(profile, source_market, max_symbols)
    target_max_symbols = resolve_max_symbols(profile, target_market, max_symbols)
    effective_max_symbols = min(source_max_symbols, target_max_symbols)
    transfer = prepare_transfer_artifacts(
        source_market=source_market,
        target_market=target_market,
        max_symbols=effective_max_symbols,
        horizon=5,
        force_rebuild=force_rebuild,
    )
    if str(mode).lower() in {"smoke", "medium"}:
        transfer["source"] = cap_market_artifacts_for_quick_mode(transfer["source"], source_max_symbols)
        transfer["target"] = cap_market_artifacts_for_quick_mode(transfer["target"], target_max_symbols)
    source_panel = transfer["source"]["panel_df"]
    target_panel = transfer["target"]["panel_df"]
    source_incidence = transfer["source"]["incidence_df"]
    target_incidence = transfer["target"]["incidence_df"]
    split = SplitConfig()

    log(
        f"[EXP-LOG][TRANSFER] direction started | 当前方向={direction_name} | "
        f"待运行模型数={len(runnable_models)} | 基准alpha={'+'.join(base_alpha_names)} | 状态=BUILDING_ARRAYS"
    )
    source_panel = inject_base_alpha_features(source_panel, base_alpha_names, ALPHA_FEATURES)
    target_panel = inject_base_alpha_features(target_panel, base_alpha_names, ALPHA_FEATURES)
    source_arrays, _source_meta = build_split_arrays(source_panel, source_incidence, split=split, lookback=lookback)
    target_arrays, target_meta = build_split_arrays(target_panel, target_incidence, split=split, lookback=lookback)
    source_arrays, target_arrays, _ = align_transfer_concept_arrays(source_arrays, target_arrays)

    total_models = len(requested_models)
    completed_count = len(summary_rows)
    for model_name in runnable_models:
        progress_before = format_progress(completed_count, total_models)
        heartbeat = ModelHeartbeat(direction_name=direction_name, model_name=model_name, progress_text=progress_before)
        heartbeat.start()
        model_start_time = time.perf_counter()
        try:
            metrics = run_transfer_model(
                model_name=model_name,
                source_arrays=source_arrays,
                target_arrays=target_arrays,
                target_meta=target_meta,
                experiment_dir=experiment_dir,
                top_k=top_k,
                device=device,
                mode=mode,
                scoring_config=scoring_config,
                supervised_loss_config=supervised_loss_config,
                weight_param=weight_param,
                weight_mech=weight_mech,
                source_market=source_market,
                target_market=target_market,
                enable_similarity_policy=enable_similarity_policy,
                similarity_config=similarity_config,
                threshold_config=threshold_config,
                policy_config=policy_config,
                similarity_history_path=similarity_history_path,
            )
        finally:
            heartbeat.stop()
        summary_rows.append({"direction": direction_name, "model": model_name, "display_name": TRANSFER_DISPLAY_NAMES[model_name], **metrics})
        completed_count += 1
        log(
            f"[EXP-DONE][TRANSFER] model finished | 当前方向={direction_name} | 当前模型={model_name} | "
            f"方向内完成百分比={format_progress(completed_count, total_models)} | "
            f"模型完成摘要={summarize_metrics(metrics)} | 用时={format_seconds(time.perf_counter() - model_start_time)}"
        )

    summary_df = pd.DataFrame(summary_rows)
    write_dataframe(summary_df, experiment_dir / "summary.csv", index=False, encoding="utf-8-sig")
    return summary_df


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行统一基准初始化条件下的迁移类方法对比实验")
    parser.add_argument("--mode", default="medium", choices=["full", "medium", "smoke"], help="实验运行模式")
    parser.add_argument("--max-symbols", type=int, default=160, help="每个市场参与训练的流动性标的数")
    parser.add_argument("--lookback", type=int, default=20, help="时序模型回看窗口")
    parser.add_argument("--top-k", type=int, default=20, help="轻量回测的 Top-k 持仓数")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--force-rebuild", action="store_true", help="强制重建中间缓存")
    parser.add_argument("--direction", default="cn_to_us,us_to_cn", help="实验方向, 多个方向用逗号分隔")
    parser.add_argument("--models", default=",".join(TRANSFER_MODEL_NAMES), help="指定要运行的迁移类模型")
    parser.add_argument("--base-alpha", default="alpha_ma_ratio_5_20", help="统一基准 alpha 策略名, 支持逗号分隔的 1~2 个策略")
    parser.add_argument("--rerun-existing", action="store_true", help="即使已有结果也重新训练并覆盖")
    parser.add_argument(
        "--result-subdir",
        default="phase1_transfer_family",
        help="结果相对目录名, 默认写入 `主实验/phase1_transfer_family`",
    )
    parser.add_argument("--amt-top-r", type=int, default=3, help="AMT 稀疏门控保留的 alpha 参数块数量")
    parser.add_argument("--amt-gate-temperature", type=float, default=0.70, help="AMT 门控 softmax 温度")
    parser.add_argument("--amt-alpha-residual-scale", type=float, default=0.35, help="AMT 目标域增量注入到源域权重时的残差缩放")
    parser.add_argument("--amt-delta-clip", type=float, default=0.75, help="AMT 适配器输出增量的裁剪上界")
    parser.add_argument("--amt-min-gate-mass", type=float, default=1e-6, help="AMT 稀疏门控重归一化时的最小分母")
    parser.add_argument("--amt-supervised-objective", choices=["mse", "rank_return"], default="rank_return", help="AMT 主监督项类型")
    parser.add_argument("--amt-rank-loss-weight", type=float, default=1.0, help="AMT 排序损失权重")
    parser.add_argument("--amt-return-loss-weight", type=float, default=2.0, help="AMT 年化收益代理损失权重")
    parser.add_argument("--amt-mse-anchor-weight", type=float, default=0.05, help="AMT 回归锚点损失权重")
    parser.add_argument("--amt-pairwise-label-threshold", type=float, default=1e-4, help="AMT 排序损失中忽略微小标签差异的阈值")
    parser.add_argument("--amt-return-temperature", type=float, default=0.35, help="AMT 收益代理中的 softmax 温度")
    parser.add_argument("--amt-annualization-factor", type=float, default=252.0, help="AMT 收益代理的年化放大系数")
    parser.add_argument("--amt-weight-param", type=float, default=0.002, help="AMT 参数偏移约束权重")
    parser.add_argument("--amt-weight-mech", type=float, default=0.0005, help="AMT 机理偏移约束权重")
    parser.add_argument("--disable-market-similarity-policy", action="store_true", help="关闭相似度驱动的 AMT 自适应冻结与学习率策略")
    parser.add_argument("--market-similarity-threshold", type=float, default=0.70, help="市场相似度统一阈值")
    parser.add_argument("--market-similarity-sample-size", type=int, default=2048, help="计算市场嵌入时每个市场最多采样的样本数")
    parser.add_argument("--market-similarity-batch-size", type=int, default=512, help="计算市场嵌入时的批大小")
    parser.add_argument("--market-similarity-rbf-gamma", type=float, default=0.50, help="MMD RBF 核的 gamma 参数")
    parser.add_argument("--market-similarity-medium-gap", type=float, default=0.15, help="低于阈值后进入第一档宽松策略的相似度间隔")
    parser.add_argument("--market-similarity-low-gap", type=float, default=0.35, help="低于阈值后进入更宽松策略的相似度间隔")
    parser.add_argument("--market-threshold-update-method", choices=["ema_quantile", "supervised_gain"], default="ema_quantile", help="相似度阈值动态更新方法")
    parser.add_argument("--market-threshold-quantile", type=float, default=0.65, help="无监督阈值更新时使用的历史相似度分位数")
    parser.add_argument("--market-threshold-ema-decay", type=float, default=0.80, help="动态阈值更新时的 EMA 衰减系数")
    parser.add_argument(
        "--market-similarity-history-path",
        default=str(Path(__file__).resolve().parents[1] / "results" / "market_similarity_threshold_history.json"),
        help="市场相似度阈值历史文件路径",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    os.environ["AMT_ARCHIVE_PREFIX"] = str(args.mode).strip().lower()
    selected_base_alpha_names = normalize_alpha_strategy_names(args.base_alpha)
    if not selected_base_alpha_names:
        raise ValueError("请至少指定一个基础 alpha 策略。")
    if len(selected_base_alpha_names) > 2:
        raise ValueError(f"当前仅支持 1~2 个基础 alpha 策略, 收到 {len(selected_base_alpha_names)} 个。")
    base_alpha_specs = [get_alpha_strategy(name) for name in selected_base_alpha_names]
    direction_keys = [normalize_direction(item) for item in parse_csv_args(args.direction)]
    selected_models = normalize_transfer_model_names(args.models)
    scoring_config = build_amt_scoring_config(args)
    supervised_loss_config = build_amt_supervised_loss_config(args)
    market_similarity_config = build_market_similarity_config(args)
    threshold_update_config = build_threshold_update_config(args)
    adaptation_policy_config = build_adaptation_policy_config(args)
    similarity_history_path = Path(args.market_similarity_history_path).expanduser().resolve()
    result_root = get_categorized_result_path("main", args.result_subdir.strip() or "phase1_transfer_family")
    result_root.mkdir(parents=True, exist_ok=True)
    summary_frames: list[pd.DataFrame] = []
    for direction_key in direction_keys:
        source_market, target_market = DIRECTION_SPECS[direction_key]
        summary_df = run_one_direction(
            source_market=source_market,
            target_market=target_market,
            max_symbols=args.max_symbols,
            lookback=args.lookback,
            top_k=args.top_k,
            device=args.device,
            force_rebuild=args.force_rebuild,
            mode=args.mode,
            base_alpha_names=selected_base_alpha_names,
            result_root=result_root,
            scoring_config=scoring_config,
            supervised_loss_config=supervised_loss_config,
            weight_param=args.amt_weight_param,
            weight_mech=args.amt_weight_mech,
            enable_similarity_policy=not args.disable_market_similarity_policy,
            similarity_config=market_similarity_config,
            threshold_config=threshold_update_config,
            policy_config=adaptation_policy_config,
            similarity_history_path=similarity_history_path,
            selected_models=selected_models,
            skip_existing=not args.rerun_existing,
        )
        if not summary_df.empty:
            summary_frames.append(summary_df)
    all_summary_df = pd.concat(summary_frames, axis=0, ignore_index=True) if summary_frames else pd.DataFrame()
    write_dataframe(all_summary_df, result_root / "all_summary.csv", index=False, encoding="utf-8-sig")
    write_json(
        result_root / "run_config.json",
        {
            "mode": args.mode,
            "max_symbols": args.max_symbols,
            "lookback": args.lookback,
            "top_k": args.top_k,
            "device": args.device,
            "direction_keys": direction_keys,
            "selected_models": selected_models,
            "base_alpha_strategy": [spec.to_dict() for spec in base_alpha_specs],
            "profile": profile_to_dict(get_profile(args.mode)),
            "result_root": str(result_root),
            "amt_scoring": amt_scoring_config_to_dict(scoring_config),
            "amt_supervised_loss": amt_supervised_loss_config_to_dict(supervised_loss_config),
            "amt_transfer_loss": {
                "weight_param": float(args.amt_weight_param),
                "weight_mech": float(args.amt_weight_mech),
            },
            "market_similarity": {
                "enabled": not args.disable_market_similarity_policy,
                "history_path": str(similarity_history_path),
                "feature_config": {
                    "sample_size": int(market_similarity_config.sample_size),
                    "batch_size": int(market_similarity_config.batch_size),
                    "rbf_gamma": float(market_similarity_config.rbf_gamma),
                },
                "threshold_update": {
                    "base_threshold": float(threshold_update_config.base_threshold),
                    "update_method": threshold_update_config.update_method,
                    "quantile": float(threshold_update_config.quantile),
                    "ema_decay": float(threshold_update_config.ema_decay),
                },
                "policy_gap": {
                    "medium_gap": float(adaptation_policy_config.medium_gap),
                    "low_gap": float(adaptation_policy_config.low_gap),
                },
            },
        },
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
