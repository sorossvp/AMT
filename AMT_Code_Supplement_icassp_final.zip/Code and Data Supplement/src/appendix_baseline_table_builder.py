"""
文件功能:
1. 读取指定论文批次中的主实验、迁移 family 对比与官方 baseline 结果, 生成 AAAIV3 附录可直接引用的完整 baseline 对照表。
2. 将不同来源的方法统一整理为“主模型 / family controls / official baselines”三层, 并补充是否与 AMT 主命题直接可比的标记。
3. 输出 CSV / Markdown / JSON 三类资产, 同时登记源结果路径与生成文件路径, 便于审稿追溯。

代码逻辑:
1. 从 `phase1_transfer`、`phase1_transfer_family` 与 `baseline_full_trial` 读取汇总表。
2. 对主实验、迁移方法家族和官方 baseline 逐行标准化字段。
3. 对 TRA 等“问题设定不完全同构”的方法补充 `comparable_to_amt_claim` 标记。
4. 将结果写入当前附录批次资产目录, 供 technical appendix 与 supplementary package 直接复用。

代码结构:
1. 路径与表格渲染工具。
2. 各结果源的标准化函数。
3. 总表构建与说明写出。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import pandas as pd

from experiment_workspace import (
    get_archive_root,
    get_paper_asset_path,
    require_batch_artifacts,
    write_dataframe,
    write_json,
)


ROOT_DIR = Path(__file__).resolve().parents[1]


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    view = df.copy()
    for column in view.columns:
        if pd.api.types.is_float_dtype(view[column]):
            view[column] = view[column].map(lambda value: f"{value:.4f}")
    headers = [str(column) for column in view.columns.tolist()]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in view.iterrows():
        lines.append("| " + " | ".join(str(value) for value in row.tolist()) + " |")
    return "\n".join(lines)


def normalize_official_name(value: str) -> str:
    mapping = {
        "QuantNet": "QuantNet",
        "DoubleAdapt": "DoubleAdapt",
        "TRA": "TRA",
        "HIST": "HIST",
        "MASTER": "MASTER",
        "ADGAT": "ADGAT",
    }
    return mapping.get(str(value), str(value))


def normalize_direction(value: str) -> str:
    text = str(value).strip()
    return text.replace("_", "->").replace("CN->TO->US", "CN->US").replace("US->TO->CN", "US->CN")


def comparable_flag(method_name: str) -> tuple[str, str]:
    normalized = str(method_name).strip().lower()
    if normalized in {"tra", "routing-transfer", "routing-transfer (tra-like)"}:
        return "no", "目标函数与机制保持命题不完全同构, 仅作为扩展参考"
    return "yes", "与统一 Top-k 迁移比较口径直接相关"


def standardize_main_table(batch_root: Path) -> pd.DataFrame:
    path = batch_root / "主实验" / "phase1_transfer" / "all_summary.csv"
    df = pd.read_csv(path)
    rows: list[dict[str, Any]] = []
    for _, row in df.iterrows():
        model = str(row["model"])
        display_name = "AMT" if model == "main_transfer" else model.upper()
        comparable, note = comparable_flag(display_name)
        rows.append(
            {
                "direction": str(row["direction"]),
                "method": display_name,
                "source_group": "main_experiment",
                "comparison_role": "principal_result",
                "comparable_to_amt_claim": comparable,
                "comparison_note": note,
                "RankIC": float(row.get("RankIC", 0.0)),
                "Annualized Return": float(row.get("Annualized Return", 0.0)),
                "Sharpe Ratio": float(row.get("Sharpe Ratio", 0.0)),
                "Maximum Drawdown": float(row.get("Maximum Drawdown", 0.0)),
                "prediction_path": "",
                "summary_path": "",
            }
        )
    return pd.DataFrame(rows)


def standardize_family_table(batch_root: Path) -> pd.DataFrame:
    path = batch_root / "主实验" / "phase1_transfer_family" / "all_summary.csv"
    df = pd.read_csv(path)
    rows: list[dict[str, Any]] = []
    for _, row in df.iterrows():
        display_name = str(row["display_name"])
        comparable, note = comparable_flag(display_name)
        rows.append(
            {
                "direction": str(row["direction"]),
                "method": display_name,
                "source_group": "family_control",
                "comparison_role": "family_control",
                "comparable_to_amt_claim": comparable,
                "comparison_note": note,
                "RankIC": float(row.get("RankIC", 0.0)),
                "Annualized Return": float(row.get("Annualized Return", 0.0)),
                "Sharpe Ratio": float(row.get("Sharpe Ratio", 0.0)),
                "Maximum Drawdown": float(row.get("Maximum Drawdown", 0.0)),
                "prediction_path": str(row.get("prediction_path", "")),
                "summary_path": str(row.get("summary_path", "")),
            }
        )
    return pd.DataFrame(rows)


def standardize_official_table(batch_root: Path) -> pd.DataFrame:
    path = batch_root / "对比实验" / "baseline_full_trial" / "all_full_trial_summary.csv"
    df = pd.read_csv(path)
    rows: list[dict[str, Any]] = []
    for _, row in df.iterrows():
        method = normalize_official_name(str(row["baseline"]))
        comparable, note = comparable_flag(method)
        rows.append(
            {
                "direction": normalize_direction(str(row["direction"])),
                "method": method,
                "source_group": "official_baseline",
                "comparison_role": str(row.get("paper_role", "reference")),
                "comparable_to_amt_claim": comparable,
                "comparison_note": note,
                "RankIC": float(row.get("RankIC", 0.0)),
                "Annualized Return": float(row.get("Annualized Return", 0.0)),
                "Sharpe Ratio": float(row.get("Sharpe Ratio", 0.0)),
                "Maximum Drawdown": float(row.get("Maximum Drawdown", 0.0)),
                "prediction_path": str(row.get("prediction_path", "")),
                "summary_path": str(row.get("summary_path", "")),
            }
        )
    return pd.DataFrame(rows)


def build_baseline_table(batch_root: Path) -> pd.DataFrame:
    main_df = standardize_main_table(batch_root)
    family_df = standardize_family_table(batch_root)
    official_df = standardize_official_table(batch_root)
    merged = pd.concat([main_df, family_df, official_df], axis=0, ignore_index=True)
    order = {
        "main_experiment": 0,
        "family_control": 1,
        "official_baseline": 2,
    }
    merged["_group_order"] = merged["source_group"].map(order).fillna(9)
    merged = merged.sort_values(
        ["direction", "_group_order", "Annualized Return"],
        ascending=[True, True, False],
    ).drop(columns="_group_order")
    return merged.reset_index(drop=True)


def build_appendix_note(table_df: pd.DataFrame) -> str:
    summary = (
        table_df.groupby(["direction", "source_group"], as_index=False)
        .agg(method_count=("method", "count"))
        .sort_values(["direction", "source_group"])
    )
    return (
        "# AAAIV3 附录 baseline 对照说明\n\n"
        "## 1. 说明\n\n"
        "- 本表将现有证据链分为主实验、迁移 family controls 与官方 baseline 三层。\n"
        "- `comparable_to_amt_claim=no` 表示该方法仅作为扩展参考，不应直接用于支持“mechanism-preserving transfer”主命题。\n"
        "- 当前项目中未发现独立的 `target-only / source-only` 结果文件，因此本版附录只登记已实际落盘、可追溯的结果。\n\n"
        "## 2. 结果层级计数\n\n"
        f"{render_markdown_table(summary)}\n\n"
        "## 3. 完整 baseline 表\n\n"
        f"{render_markdown_table(table_df)}\n"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成 AAAIV3 附录 baseline 对照总表")
    parser.add_argument(
        "--source-batch-root",
        default="/data/zhoutm/exp2/results/full_20260729_015852",
        help="读取现有论文证据链结果的批次根目录",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source_batch_root = Path(args.source_batch_root).resolve()
    require_batch_artifacts(
        source_batch_root,
        required_relative_paths=(
            ("主实验", "phase1_transfer", "all_summary.csv"),
            ("主实验", "phase1_transfer_family", "all_summary.csv"),
            ("对比实验", "baseline_full_trial", "all_full_trial_summary.csv"),
        ),
    )
    archive_root = get_archive_root()
    asset_dir = ensure_dir(get_paper_asset_path(archive_root, "appendix_support", "baseline_table", paper_name="AAAIV3"))
    table_df = build_baseline_table(source_batch_root)
    csv_path = write_dataframe(table_df, asset_dir / "full_baseline_table.csv", index=False, encoding="utf-8-sig")
    md_text = build_appendix_note(table_df)
    md_path = asset_dir / "full_baseline_table.md"
    md_path.write_text(md_text, encoding="utf-8")
    manifest = {
        "source_batch_root": str(source_batch_root),
        "archive_root": str(archive_root),
        "generated_files": {
            "csv": str(csv_path),
            "markdown": str(md_path),
        },
        "row_count": int(len(table_df)),
    }
    write_json(asset_dir / "manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
