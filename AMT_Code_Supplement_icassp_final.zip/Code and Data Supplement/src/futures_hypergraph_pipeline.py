"""
文件功能:
1. 读取 `DataToSever/FutureData` 中的期货主力连续收盘价与成交量宽表。
2. 将宽表清洗为与股票管线兼容的 `panel.pkl`，生成未来收益标签、横截面特征和 regime 标签。
3. 基于期货品种元数据构建静态超图，输出超边模板、关联矩阵、稀疏矩阵文件和摘要信息。
4. 生成数据完整性校验报告，便于后续复核“交易所/交易时段/产业链/规则组”的覆盖情况。

代码逻辑:
1. 先读取 close/volume 宽表并转成长表，统一成 `date-symbol-close-volume` 结构。
2. 在只有量价数据的前提下，使用前一日收盘价构造近似 `open/high/low`，再复用股票侧的特征工程方式计算基础 alpha 风格特征。
3. 根据训练期市场横截面均值切分 `bull/bear/neutral/shock` 状态。
4. 按元数据字段生成 `exchange / asset_class / industry_chain / session_group / rule_group` 五类静态超边。
5. 将 panel、incidence、模板、校验报告统一落盘，保证和股票 case 的目录协议一致。

代码结构:
1. 路径与配置定义。
2. 原始数据读取、宽表转长表与特征工程。
3. regime 标注与静态超图构建。
4. 校验报告与文件导出。
5. 命令行入口。
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from experiment_workspace import resolve_output_path, write_dataframe, write_json
from futures_universe_metadata import build_symbol_metadata, validate_metadata_coverage


ROOT_DIR = Path(__file__).resolve().parents[1]
FUTURE_DATA_DIR = ROOT_DIR / "DataToSever" / "FutureData"
PROCESSED_DIR = ROOT_DIR / "DataToSever" / "processed_data" / "future"
HYPERGRAPH_DIR = ROOT_DIR / "DataToSever" / "future_static_hypergraph"

CLOSE_CSV = FUTURE_DATA_DIR / "futures_dominant_close_2010-01-04_2026-05-30.csv"
VOLUME_CSV = FUTURE_DATA_DIR / "futures_dominant_volume_2010-01-04_2026-05-30.csv"
EPS = 1e-8


@dataclass
class SplitConfig:
    train_start: str = "2008-01-01"
    train_end: str = "2021-12-31"
    valid_start: str = "2022-01-01"
    valid_end: str = "2022-12-31"
    test_start: str = "2023-01-01"
    test_end: str = "2025-12-31"


@dataclass
class FuturesDataConfig:
    market: str = "FUTURE"
    horizon: int = 5
    min_history_days: int = 120
    split: SplitConfig = field(default_factory=SplitConfig)


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def log(message: str) -> None:
    print(message, flush=True)


def infer_split(date_value: pd.Timestamp, split: SplitConfig) -> str | None:
    if pd.Timestamp(split.train_start) <= date_value <= pd.Timestamp(split.train_end):
        return "train"
    if pd.Timestamp(split.valid_start) <= date_value <= pd.Timestamp(split.valid_end):
        return "valid"
    if pd.Timestamp(split.test_start) <= date_value <= pd.Timestamp(split.test_end):
        return "test"
    return None


def load_wide_frames() -> tuple[pd.DataFrame, pd.DataFrame]:
    close_df = pd.read_csv(CLOSE_CSV, parse_dates=["date"])
    volume_df = pd.read_csv(VOLUME_CSV, parse_dates=["date"])
    close_df.columns = [str(col).upper() if col != "date" else "date" for col in close_df.columns]
    volume_df.columns = [str(col).upper() if col != "date" else "date" for col in volume_df.columns]
    return close_df, volume_df


def melt_long_panel(close_df: pd.DataFrame, volume_df: pd.DataFrame) -> pd.DataFrame:
    symbol_cols = [col for col in close_df.columns if col != "date"]
    close_long = close_df.melt(id_vars="date", value_vars=symbol_cols, var_name="symbol", value_name="close")
    volume_long = volume_df.melt(id_vars="date", value_vars=symbol_cols, var_name="symbol", value_name="volume")
    panel_df = close_long.merge(volume_long, on=["date", "symbol"], how="inner")
    panel_df["symbol"] = panel_df["symbol"].astype(str).str.upper()
    panel_df["close"] = pd.to_numeric(panel_df["close"], errors="coerce")
    panel_df["volume"] = pd.to_numeric(panel_df["volume"], errors="coerce")
    panel_df = panel_df.dropna(subset=["close", "volume"]).copy()
    panel_df = panel_df.loc[(panel_df["close"] > 0) & (panel_df["volume"] >= 0)].copy()
    panel_df = panel_df.sort_values(["symbol", "date"]).reset_index(drop=True)
    return panel_df


def compute_symbol_features(panel_df: pd.DataFrame, config: FuturesDataConfig) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for symbol, symbol_df in panel_df.groupby("symbol", sort=True):
        df = symbol_df.sort_values("date").copy()
        close = df["close"].replace(0.0, np.nan)
        volume = df["volume"].replace(0.0, np.nan)

        # 期货原始下载数据当前仅包含 close/volume。
        # 为了与既有股票面板协议兼容，这里使用前收构造近似 open/high/low。
        df["open"] = close.shift(1).fillna(close)
        df["high"] = np.maximum(df["open"], close)
        df["low"] = np.minimum(df["open"], close)

        returns = close.pct_change(fill_method=None)
        high_low = (df["high"] - df["low"]) / close
        open_close = (close - df["open"]) / df["open"].replace(0.0, np.nan)
        dollar_volume = close * df["volume"]

        df["ret_1"] = returns
        df["ret_5"] = close.pct_change(5, fill_method=None)
        df["ret_10"] = close.pct_change(10, fill_method=None)
        df["ret_20"] = close.pct_change(20, fill_method=None)
        df["vol_5"] = returns.rolling(5).std()
        df["vol_20"] = returns.rolling(20).std()
        df["vol_60"] = returns.rolling(60).std()
        df["ma_5"] = close.rolling(5).mean()
        df["ma_20"] = close.rolling(20).mean()
        df["ma_60"] = close.rolling(60).mean()
        df["ma_ratio_5_20"] = df["ma_5"] / df["ma_20"].replace(0.0, np.nan) - 1.0
        df["ma_ratio_20_60"] = df["ma_20"] / df["ma_60"].replace(0.0, np.nan) - 1.0
        df["hl_spread"] = high_low
        df["oc_return"] = open_close
        df["turnover_proxy"] = volume / volume.rolling(20).mean()
        df["dollar_volume"] = dollar_volume
        df["log_dollar_volume"] = np.log1p(dollar_volume.clip(lower=0.0))
        df["volume_momentum_20"] = volume / volume.rolling(20).mean() - 1.0
        df["reversal_5"] = -df["ret_5"]
        df["alpha_momentum"] = (close / close.shift(10) - 1.0) / (returns.rolling(20).std() + 1e-6)
        df["alpha_reversal"] = -returns.rolling(5).mean() / (returns.rolling(20).std() + 1e-6)
        df["alpha_volume_price"] = (close.diff(5) / close.shift(5)) * (volume.rolling(5).std() / volume.rolling(20).mean())
        df["alpha_breakout"] = (close - close.rolling(20).max()) / (close.rolling(20).max() + 1e-6)
        df["alpha_liquidity"] = df["log_dollar_volume"].rolling(10).mean() - df["log_dollar_volume"].rolling(60).mean()
        df["alpha_intraday"] = open_close / (high_low.abs() + 1e-6)
        df["future_return"] = close.shift(-config.horizon) / close - 1.0
        df["label_rank_proxy"] = df["future_return"]
        df["market"] = config.market
        frames.append(df)

    result_df = pd.concat(frames, axis=0, ignore_index=True)
    result_df = result_df.replace([np.inf, -np.inf], np.nan)
    result_df["split"] = result_df["date"].map(lambda x: infer_split(pd.Timestamp(x), config.split))
    result_df = result_df.dropna(subset=["future_return", "split"]).reset_index(drop=True)
    return result_df


def assign_regime_labels(panel_df: pd.DataFrame, config: FuturesDataConfig) -> tuple[pd.DataFrame, dict[str, float]]:
    market_daily = (
        panel_df.groupby("date")
        .agg(
            ew_future_return=("future_return", "mean"),
            ew_ret_1=("ret_1", "mean"),
            ew_vol_20=("vol_20", "mean"),
            ew_turnover=("turnover_proxy", "mean"),
        )
        .reset_index()
        .sort_values("date")
    )
    train_daily = market_daily.loc[
        (market_daily["date"] >= pd.Timestamp(config.split.train_start))
        & (market_daily["date"] <= pd.Timestamp(config.split.train_end))
    ].copy()
    ret_up = float(train_daily["ew_ret_1"].quantile(0.67))
    ret_down = float(train_daily["ew_ret_1"].quantile(0.33))
    vol_high = float(train_daily["ew_vol_20"].quantile(0.80))
    vol_mid = float(train_daily["ew_vol_20"].quantile(0.55))

    def classify(row: pd.Series) -> str:
        if row["ew_vol_20"] >= vol_high:
            return "shock"
        if row["ew_ret_1"] >= ret_up and row["ew_vol_20"] < vol_mid:
            return "bull"
        if row["ew_ret_1"] <= ret_down:
            return "bear"
        return "neutral"

    market_daily["regime"] = market_daily.apply(classify, axis=1)
    merged_df = panel_df.merge(market_daily[["date", "regime"]], on="date", how="left")
    thresholds = {
        "ret_up_q67": ret_up,
        "ret_down_q33": ret_down,
        "vol_high_q80": vol_high,
        "vol_mid_q55": vol_mid,
    }
    return merged_df, thresholds


def build_hypergraph_from_metadata(metadata_df: pd.DataFrame) -> tuple[pd.DataFrame, list[dict[str, object]]]:
    edge_fields = [
        ("exchange", "exchange"),
        ("asset", "asset_class"),
        ("chain", "industry_chain"),
        ("session", "session_group"),
        ("rule", "rule_group"),
    ]
    symbols = metadata_df["symbol"].astype(str).tolist()
    templates: list[dict[str, object]] = []
    edge_members: dict[str, list[str]] = {}

    for edge_type, field_name in edge_fields:
        for field_value, group_df in metadata_df.groupby(field_name):
            members = sorted(group_df["symbol"].astype(str).tolist())
            if len(members) <= 1:
                continue
            edge_id = f"{edge_type}::{field_value}"
            templates.append(
                {
                    "edge_id": edge_id,
                    "edge_type": edge_type,
                    "edge_name": str(field_value),
                    "source_field": field_name,
                    "members": members,
                    "base_weight": 1.0,
                }
            )
            edge_members[edge_id] = members

    incidence_df = pd.DataFrame(0.0, index=symbols, columns=[item["edge_id"] for item in templates], dtype=float)
    for edge_id, members in edge_members.items():
        incidence_df.loc[members, edge_id] = 1.0
    return incidence_df, templates


def build_symbol_summary(panel_df: pd.DataFrame, metadata_df: pd.DataFrame) -> pd.DataFrame:
    summary_df = (
        panel_df.groupby("symbol")
        .agg(
            available_days=("date", "nunique"),
            first_date=("date", "min"),
            last_date=("date", "max"),
            avg_close=("close", "mean"),
            avg_volume=("volume", "mean"),
            avg_dollar_volume=("dollar_volume", "mean"),
            avg_volatility=("vol_20", "mean"),
        )
        .reset_index()
    )
    summary_df["first_date"] = summary_df["first_date"].dt.strftime("%Y-%m-%d")
    summary_df["last_date"] = summary_df["last_date"].dt.strftime("%Y-%m-%d")
    return summary_df.merge(metadata_df, on="symbol", how="left")


def build_validation_report(
    raw_panel_df: pd.DataFrame,
    panel_df: pd.DataFrame,
    metadata_df: pd.DataFrame,
    incidence_df: pd.DataFrame,
    templates: list[dict[str, object]],
) -> dict[str, object]:
    coverage_errors = validate_metadata_coverage(metadata_df["symbol"].tolist())
    raw_summary = (
        raw_panel_df.groupby("symbol")
        .agg(raw_available_days=("date", "nunique"), raw_first_date=("date", "min"), raw_last_date=("date", "max"))
        .reset_index()
    )
    raw_summary["raw_first_date"] = raw_summary["raw_first_date"].dt.strftime("%Y-%m-%d")
    raw_summary["raw_last_date"] = raw_summary["raw_last_date"].dt.strftime("%Y-%m-%d")
    duplicate_count = int(raw_panel_df.duplicated(subset=["date", "symbol"]).sum())
    report = {
        "symbol_count": int(metadata_df["symbol"].nunique()),
        "panel_rows": int(len(panel_df)),
        "raw_rows": int(len(raw_panel_df)),
        "date_range": {
            "start": str(raw_panel_df["date"].min().date()),
            "end": str(raw_panel_df["date"].max().date()),
        },
        "duplicate_date_symbol_rows": duplicate_count,
        "metadata_coverage_errors": coverage_errors,
        "legacy_symbol_count": int(metadata_df["is_legacy_symbol"].sum()),
        "average_price_symbol_count": int(metadata_df["is_average_price_future"].sum()),
        "has_regime_labels": bool(panel_df["regime"].notna().all()),
        "hyperedge_count": int(len(templates)),
        "incidence_shape": [int(incidence_df.shape[0]), int(incidence_df.shape[1])],
        "exchange_distribution": metadata_df["exchange"].value_counts().to_dict(),
        "session_distribution": metadata_df["session_group"].value_counts().to_dict(),
        "rule_distribution": metadata_df["rule_group"].value_counts().to_dict(),
        "raw_symbol_summary": raw_summary.to_dict(orient="records"),
    }
    return report


def save_artifacts(
    config: FuturesDataConfig,
    panel_df: pd.DataFrame,
    metadata_df: pd.DataFrame,
    symbol_summary_df: pd.DataFrame,
    incidence_df: pd.DataFrame,
    templates: list[dict[str, object]],
    regime_thresholds: dict[str, float],
    validation_report: dict[str, object],
) -> dict[str, str]:
    ensure_dir(PROCESSED_DIR)
    ensure_dir(HYPERGRAPH_DIR)

    panel_path = PROCESSED_DIR / "panel.pkl"
    incidence_path = PROCESSED_DIR / "hypergraph_incidence.csv"
    stats_path = PROCESSED_DIR / "hypergraph_symbol_stats.csv"
    meta_path = PROCESSED_DIR / "universe_summary.csv"
    config_path = PROCESSED_DIR / "market_config.json"
    regime_path = PROCESSED_DIR / "regime_thresholds.json"

    template_path = HYPERGRAPH_DIR / "hyperedge_templates.json"
    base_matrix_path = HYPERGRAPH_DIR / "base_incidence_matrix.npz"
    hypergraph_summary_path = HYPERGRAPH_DIR / "static_regime_hypergraph_summary.json"
    metadata_path = HYPERGRAPH_DIR / "futures_metadata.csv"
    validation_path = HYPERGRAPH_DIR / "validation_report.json"

    actual_panel_path = resolve_output_path(panel_path)
    panel_df.to_pickle(actual_panel_path)
    actual_incidence_path = write_dataframe(incidence_df, incidence_path, index=True, encoding="utf-8-sig")
    actual_stats_path = write_dataframe(symbol_summary_df, stats_path, index=False, encoding="utf-8-sig")
    actual_meta_path = write_dataframe(symbol_summary_df, meta_path, index=False, encoding="utf-8-sig")
    write_json(config_path, asdict(config))
    write_json(regime_path, regime_thresholds)

    actual_template_path = write_json(template_path, templates)
    actual_metadata_path = write_dataframe(metadata_df, metadata_path, index=False, encoding="utf-8-sig")
    actual_validation_path = write_json(validation_path, validation_report)
    actual_base_matrix_path = resolve_output_path(base_matrix_path)
    np.savez_compressed(
        actual_base_matrix_path,
        matrix=incidence_df.to_numpy(dtype=np.float32),
        instruments=incidence_df.index.to_numpy(dtype=object),
        edge_ids=incidence_df.columns.to_numpy(dtype=object),
    )
    actual_hypergraph_summary_path = write_json(
        hypergraph_summary_path,
        {
            "instrument_count": int(incidence_df.shape[0]),
            "hyperedge_count": int(incidence_df.shape[1]),
            "base_incidence_path": str(actual_base_matrix_path),
            "template_path": str(actual_template_path),
            "validation_report_path": str(actual_validation_path),
        },
    )

    return {
        "panel_path": str(actual_panel_path),
        "incidence_path": str(actual_incidence_path),
        "stats_path": str(actual_stats_path),
        "meta_path": str(actual_meta_path),
        "template_path": str(actual_template_path),
        "base_matrix_path": str(actual_base_matrix_path),
        "hypergraph_summary_path": str(actual_hypergraph_summary_path),
        "metadata_path": str(actual_metadata_path),
        "validation_path": str(actual_validation_path),
    }


def prepare_futures_hypergraph(force_rebuild: bool = False) -> dict[str, object]:
    start_time = time.perf_counter()
    config = FuturesDataConfig()

    required_paths = [
        PROCESSED_DIR / "panel.pkl",
        PROCESSED_DIR / "hypergraph_incidence.csv",
        PROCESSED_DIR / "hypergraph_symbol_stats.csv",
        PROCESSED_DIR / "universe_summary.csv",
        PROCESSED_DIR / "regime_thresholds.json",
        HYPERGRAPH_DIR / "hyperedge_templates.json",
        HYPERGRAPH_DIR / "base_incidence_matrix.npz",
        HYPERGRAPH_DIR / "validation_report.json",
    ]
    if not force_rebuild and all(path.exists() for path in required_paths):
        return {
            "market": config.market,
            "paths": {path.name: str(path) for path in required_paths},
            "elapsed_seconds": float(time.perf_counter() - start_time),
            "cached": True,
        }

    close_df, volume_df = load_wide_frames()
    raw_panel_df = melt_long_panel(close_df, volume_df)
    symbols = sorted(raw_panel_df["symbol"].astype(str).unique().tolist())
    metadata_df = build_symbol_metadata(symbols)
    feature_df = compute_symbol_features(raw_panel_df, config)
    feature_df, regime_thresholds = assign_regime_labels(feature_df, config)
    feature_df = feature_df.sort_values(["date", "symbol"]).reset_index(drop=True)

    incidence_df, templates = build_hypergraph_from_metadata(metadata_df)
    symbol_summary_df = build_symbol_summary(feature_df, metadata_df)
    validation_report = build_validation_report(raw_panel_df, feature_df, metadata_df, incidence_df, templates)
    paths = save_artifacts(
        config=config,
        panel_df=feature_df,
        metadata_df=metadata_df,
        symbol_summary_df=symbol_summary_df,
        incidence_df=incidence_df,
        templates=templates,
        regime_thresholds=regime_thresholds,
        validation_report=validation_report,
    )
    elapsed_seconds = float(time.perf_counter() - start_time)
    return {
        "market": config.market,
        "paths": paths,
        "instrument_count": int(metadata_df["symbol"].nunique()),
        "panel_rows": int(len(feature_df)),
        "hyperedge_count": int(len(templates)),
        "elapsed_seconds": elapsed_seconds,
        "cached": False,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="构建期货静态超图与 processed_data/future 数据缓存")
    parser.add_argument("--force-rebuild", action="store_true", help="强制重建期货 panel 与静态超图")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    payload = prepare_futures_hypergraph(force_rebuild=args.force_rebuild)
    log("[SUCCESS] 期货静态超图与面板缓存构建完成")
    log(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
