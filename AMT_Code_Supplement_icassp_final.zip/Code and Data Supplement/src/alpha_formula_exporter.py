"""
文件功能:
1. 将 `a_A * (A + delta_A) + a_B * (B + delta_B)` 这类仿射 alpha 参数导出为可直接阅读的最优公式文本。
2. 同时给出原始公式、展开公式、排序等价公式与常数平移项, 便于区分“表达上的 offset”和“实际影响排序的有效项”。
3. 统一封装“候选公式 + 选择指标 + 验证指标”的结构化记录, 供案例实验结果落盘与后续论文引用复用。

代码逻辑:
1. 先对系数与偏移量做稳定格式化, 避免输出中出现冗余的 `-0.0000` 或过长小数。
2. 再把 A/B 两个项拼成可读公式, 同时计算等价展开式与常数项。
3. 若下游任务属于“按日再次 rank 的排序输出”, 则额外生成一个去掉常数平移的排序等价公式。
4. 最后将公式文本与核心指标打包成结构化字典, 方便写入 CSV/JSON。

代码结构:
1. 数值格式化工具。
2. 仿射公式文本构造。
3. 结构化公式记录构造与最佳公式选择。
"""

from __future__ import annotations

from typing import Any


def format_formula_number(value: float, digits: int = 6) -> str:
    numeric_value = float(value)
    if abs(numeric_value) < 1e-12:
        numeric_value = 0.0
    text = f"{numeric_value:.{digits}f}".rstrip("0").rstrip(".")
    if text in {"-0", ""}:
        return "0"
    return text


def _format_inner_term(term_name: str, offset: float) -> str:
    offset_value = float(offset)
    if abs(offset_value) < 1e-12:
        return term_name
    sign = "+" if offset_value >= 0.0 else "-"
    return f"{term_name} {sign} {format_formula_number(abs(offset_value))}"


def build_affine_formula_strings(
    *,
    a_scale: float,
    b_scale: float,
    a_offset: float = 0.0,
    b_offset: float = 0.0,
    term_a_name: str = "A",
    term_b_name: str = "B",
    include_ranking_equivalent: bool = False,
) -> dict[str, Any]:
    a_scale_value = float(a_scale)
    b_scale_value = float(b_scale)
    a_offset_value = float(a_offset)
    b_offset_value = float(b_offset)

    pretty_formula = (
        f"{format_formula_number(a_scale_value)} * ({_format_inner_term(term_a_name, a_offset_value)})"
        f" + {format_formula_number(b_scale_value)} * ({_format_inner_term(term_b_name, b_offset_value)})"
    )
    compact_formula = pretty_formula.replace(" ", "")

    constant_shift = a_scale_value * a_offset_value + b_scale_value * b_offset_value
    expanded_formula = (
        f"{format_formula_number(a_scale_value)} * {term_a_name}"
        f" + {format_formula_number(b_scale_value)} * {term_b_name}"
    )
    if abs(constant_shift) >= 1e-12:
        expanded_formula = (
            f"{expanded_formula} "
            f"{'+' if constant_shift >= 0.0 else '-'} "
            f"{format_formula_number(abs(constant_shift))}"
        )

    payload: dict[str, Any] = {
        "formula_pretty": pretty_formula,
        "formula_compact": compact_formula,
        "formula_expanded": expanded_formula,
        "constant_shift": float(constant_shift),
        "a_scale": a_scale_value,
        "b_scale": b_scale_value,
        "a_offset": a_offset_value,
        "b_offset": b_offset_value,
    }

    if include_ranking_equivalent:
        ranking_equivalent = (
            f"{format_formula_number(a_scale_value)} * {term_a_name}"
            f" + {format_formula_number(b_scale_value)} * {term_b_name}"
        )
        payload["formula_ranking_equivalent"] = ranking_equivalent
        payload["ranking_constant_invariant"] = True
        payload["ranking_note"] = (
            "当前输出在日横截面会再次做 rank，常数平移项不会改变最终排序；"
            "因此 ranking_equivalent 更直接反映可交易排序信号。"
        )
    else:
        payload["ranking_constant_invariant"] = False
        payload["ranking_note"] = ""

    return payload


def build_validated_formula_record(
    *,
    method_name: str,
    params: dict[str, float | int],
    selection_metrics: dict[str, float] | None,
    validation_metrics: dict[str, float] | None,
    term_a_definition: str,
    term_b_definition: str,
    selection_split: str = "valid",
    validation_split: str = "test",
    template_formula: str = "a_A * (A + delta_A) + a_B * (B + delta_B)",
    rank_normalized_output: bool = False,
    selection_objective: float | None = None,
    validation_objective: float | None = None,
) -> dict[str, Any]:
    formula_payload = build_affine_formula_strings(
        a_scale=float(params.get("a_scale", 1.0)),
        b_scale=float(params.get("b_scale", 1.0)),
        a_offset=float(params.get("a_offset", 0.0)),
        b_offset=float(params.get("b_offset", 0.0)),
        term_a_name="A",
        term_b_name="B",
        include_ranking_equivalent=rank_normalized_output,
    )

    record: dict[str, Any] = {
        "method": method_name,
        "template_formula": template_formula,
        "term_a_definition": term_a_definition,
        "term_b_definition": term_b_definition,
        "selection_split": selection_split,
        "validation_split": validation_split,
        "selection_objective": None if selection_objective is None else float(selection_objective),
        "validation_objective": None if validation_objective is None else float(validation_objective),
        **formula_payload,
    }

    if selection_metrics:
        for metric_name, metric_value in selection_metrics.items():
            record[f"selection_{metric_name}"] = metric_value
    if validation_metrics:
        for metric_name, metric_value in validation_metrics.items():
            record[f"validation_{metric_name}"] = metric_value
    return record


def choose_best_formula_record(
    records: list[dict[str, Any]],
    objective_field: str = "validation_objective",
) -> dict[str, Any]:
    if not records:
        raise ValueError("最佳公式选择失败: records 为空。")
    available_records = [record for record in records if record.get(objective_field) is not None]
    if not available_records:
        raise ValueError(f"最佳公式选择失败: 字段 `{objective_field}` 在所有记录中均为空。")
    return max(available_records, key=lambda item: float(item[objective_field]))
