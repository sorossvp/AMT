"""
文件功能:
1. 在本地环境对官方 baseline 的 medium 模式进行首轮可行性验证。
2. 按优先级组织 `CN -> US`、`US -> CN`、`CN -> FUTURE`、`FUTURE -> CN` 两阶段任务。
3. 对不同官方 baseline 采取“能真实跑就真实跑, 其余至少完成核心模块 smoke train / smoke forward”的策略。
4. 统一输出 trial manifest, 为后续服务器全量实验提供可直接复用的记录。

代码逻辑:
1. 先为指定 baseline / 方向生成 medium 外围资产。
2. 对 TRA / HIST / MASTER / ADGAT / DoubleAdapt 执行官方核心模块 smoke 训练或前向验证。
3. 对 QuantNet 执行一次真实的官方 baseline 训练与预测。
4. 按阶段与优先级顺序记录状态、耗时、日志与异常。

代码结构:
1. 路径和通用工具。
2. 不同 baseline 的 medium trial 实现。
3. 两阶段任务编排。
4. 结果汇总与 CLI 入口。
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from data_pipeline import read_pickle_with_recovery
from experiment_workspace import get_categorized_result_path, write_json
from official_baseline_artifact_builder import build_artifacts


ROOT_DIR = Path(__file__).resolve().parents[1]
RESULT_DIR = get_categorized_result_path("baseline", "medium_trial")
PROCESSED_DIR = ROOT_DIR / "DataToSever" / "processed_data"
OFFICIAL_DIR = ROOT_DIR / "third_party" / "official_baselines"
QUANTNET_STABILITY_EPS = 1e-16

SEQ_COLUMNS = ["open", "high", "low", "close", "volume", "ret_1"]
MASTER_GATE_COLUMNS = ["ret_5", "ret_10", "ret_20", "vol_5", "vol_20", "vol_60"]

PHASE1_TASKS = {
    "CN_TO_US": ["TRA", "DoubleAdapt", "HIST", "MASTER", "QuantNet", "ADGAT"],
    "US_TO_CN": ["TRA", "DoubleAdapt", "HIST", "MASTER", "QuantNet", "ADGAT"],
}
PHASE2_TASKS = {
    "CN_TO_FUTURE": ["TRA", "DoubleAdapt", "HIST", "MASTER", "QuantNet"],
    "FUTURE_TO_CN": ["TRA", "DoubleAdapt", "HIST", "MASTER", "QuantNet"],
}


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def parse_optional_csv(raw_value: str | None) -> set[str] | None:
    if raw_value is None:
        return None
    tokens = {token.strip() for token in raw_value.split(",") if token.strip()}
    return tokens or None


def is_under_directory(file_path: str | Path | None, root_dir: Path) -> bool:
    if not file_path:
        return False
    try:
        Path(file_path).resolve().relative_to(root_dir.resolve())
        return True
    except Exception:  # noqa: BLE001
        return False


def load_repo_module(repo_dir: Path, module_file: str, module_alias: str) -> Any:
    """按绝对路径隔离加载官方仓库模块，避免 `model.py` / `utils.py` 的缓存污染。"""
    module_path = repo_dir / module_file
    before_modules = set(sys.modules)
    sys.path.insert(0, str(repo_dir))
    try:
        spec = importlib.util.spec_from_file_location(module_alias, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"无法构造模块 spec: {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_alias] = module
        spec.loader.exec_module(module)
        return module
    finally:
        sys.path.pop(0)
        created_modules = set(sys.modules) - before_modules
        created_modules.add(module_alias)
        for module_name in created_modules:
            module_obj = sys.modules.get(module_name)
            module_origin = getattr(module_obj, "__file__", None)
            if module_name == module_alias or is_under_directory(module_origin, repo_dir):
                sys.modules.pop(module_name, None)


def load_panel(market: str) -> pd.DataFrame:
    panel_path = PROCESSED_DIR / market.lower() / "panel.pkl"
    df = read_pickle_with_recovery(panel_path).copy()
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["symbol", "date"]).reset_index(drop=True)
    return df


def build_sequence_batch(market: str, lookback: int = 12, max_symbols: int = 24) -> tuple[torch.Tensor, torch.Tensor, pd.DataFrame]:
    panel_df = load_panel(market)
    symbol_order = panel_df.groupby("symbol")["volume"].mean().sort_values(ascending=False).head(max_symbols).index.tolist()
    panel_df = panel_df[panel_df["symbol"].isin(symbol_order)].copy()
    samples: list[dict[str, Any]] = []
    for symbol, symbol_df in panel_df.groupby("symbol"):
        symbol_df = symbol_df.sort_values("date").reset_index(drop=True)
        if len(symbol_df) <= lookback:
            continue
        for idx in range(lookback - 1, len(symbol_df)):
            row = symbol_df.iloc[idx]
            if row["date"] < pd.Timestamp("2023-01-01"):
                continue
            seq = symbol_df.loc[idx - lookback + 1 : idx, SEQ_COLUMNS].to_numpy(dtype=np.float32)
            gate = symbol_df.loc[idx - lookback + 1 : idx, MASTER_GATE_COLUMNS].to_numpy(dtype=np.float32)
            raw_market_value = row.get("dollar_volume", np.nan)
            fallback_market_value = float(row["close"] * row["volume"])
            market_value = float(raw_market_value) if pd.notna(raw_market_value) and np.isfinite(float(raw_market_value)) else fallback_market_value
            if not np.isfinite(market_value) or market_value <= 0.0:
                market_value = 1.0
            samples.append(
                {
                    "date": row["date"],
                    "symbol": symbol,
                    "seq": seq,
                    "gate": gate,
                    "label": float(row["label_rank_proxy"]),
                    "future_return": float(row["future_return"]),
                    "market_value": market_value,
                }
            )
            if len(samples) >= 160:
                break
        if len(samples) >= 160:
            break
    if not samples:
        raise RuntimeError(f"无法从 {market} 构造 medium 序列样本。")
    sample_df = pd.DataFrame(samples)
    seq_x = torch.tensor(np.stack(sample_df["seq"].to_list()), dtype=torch.float32)
    y = torch.tensor(sample_df["label"].to_numpy(dtype=np.float32), dtype=torch.float32)
    return seq_x, y, sample_df


def run_tra_smoke(target_market: str) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / "qlib-main  TRA" / "qlib-main" / "examples" / "benchmarks" / "TRA" / "src"
    tra_module = load_repo_module(repo_dir, "model.py", "alpha_mech_transfer_tra_model")
    OfficialTRALSTM = tra_module.LSTM
    OfficialTRA = tra_module.TRA

    x, y, sample_df = build_sequence_batch(target_market)
    model = OfficialTRALSTM(input_size=x.shape[-1], hidden_size=16, num_layers=1, use_attn=True, dropout=0.0)
    router = OfficialTRA(model.output_size, num_states=2, hidden_size=8, tau=1.0)
    optimizer = torch.optim.Adam(list(model.parameters()) + list(router.parameters()), lr=1e-3)
    hist_loss = torch.zeros((x.shape[0], x.shape[1] - 1, 2), dtype=torch.float32)

    model.train()
    router.train()
    for _ in range(2):
        hidden = model(x)
        pred, _, _ = router(hidden, hist_loss)
        loss = ((pred - y) ** 2).mean()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    with torch.no_grad():
        hidden = model(x)
        pred, _, _ = router(hidden, hist_loss)
    return {
        "status": "smoke_train_ok",
        "sample_count": int(len(sample_df)),
        "prediction_mean": float(pred.mean().item()),
        "loss": float(((pred - y) ** 2).mean().item()),
    }


def run_hist_smoke(target_market: str) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / "HIST-main" / "HIST-main"
    hist_module = load_repo_module(repo_dir, "model.py", "alpha_mech_transfer_hist_model")
    OfficialHIST = hist_module.HIST

    x, y, sample_df = build_sequence_batch(target_market)
    artifact_dir = Path(build_artifacts("HIST", f"CN_TO_{target_market}" if target_market != "CN" else "US_TO_CN", mode="medium")["artifact_dir"])
    concept_matrix = np.load(artifact_dir / "stock2concept.npy")
    stock_index = np.load(artifact_dir / "stock_index.npy", allow_pickle=True).item()
    concept_rows = np.stack([concept_matrix[stock_index[symbol]] for symbol in sample_df["symbol"]]).astype(np.float32)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    market_value = torch.tensor(sample_df["market_value"].to_numpy(dtype=np.float32), dtype=torch.float32, device=device)
    x_flat = x.permute(0, 2, 1).reshape(len(sample_df), -1).to(device)
    concept_x = torch.tensor(concept_rows, dtype=torch.float32, device=device)
    y = y.to(device)
    # #region debug-point A:hist-input-finiteness
    import json, urllib.request; _p='.dbg/hist-medium-nan.env'; _u,_s='http://127.0.0.1:7777/event','hist-medium-nan'; exec("try:\n with open(_p) as f: c=f.read(); _u=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SERVER_URL=')),_u); _s=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SESSION_ID=')),_s)\nexcept: pass"); urllib.request.urlopen(urllib.request.Request(_u, data=json.dumps({'sessionId':_s,'runId':'post-fix','hypothesisId':'A','location':'official_baseline_medium_trial_runner.py:run_hist_smoke:input','msg':'[DEBUG] HIST medium input finiteness snapshot','data':{'target_market':target_market,'sample_count':int(len(sample_df)),'device':str(device),'x_nan':int(torch.isnan(x_flat).sum().item()),'x_inf':int(torch.isinf(x_flat).sum().item()),'concept_nan':int(torch.isnan(concept_x).sum().item()),'concept_inf':int(torch.isinf(concept_x).sum().item()),'market_value_nan':int(torch.isnan(market_value).sum().item()),'market_value_inf':int(torch.isinf(market_value).sum().item()),'label_nan':int(torch.isnan(y).sum().item()),'label_inf':int(torch.isinf(y).sum().item())}}).encode(), headers={'Content-Type':'application/json'})).read()
    # #endregion

    model = OfficialHIST(d_feat=x.shape[-1], num_layers=1, K=2).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    for epoch_idx in range(2):
        pred = model(x_flat, concept_x, market_value)
        loss = ((pred - y) ** 2).mean()
        # #region debug-point B:hist-train-step-finiteness
        import json, urllib.request; _p='.dbg/hist-medium-nan.env'; _u,_s='http://127.0.0.1:7777/event','hist-medium-nan'; exec("try:\n with open(_p) as f: c=f.read(); _u=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SERVER_URL=')),_u); _s=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SESSION_ID=')),_s)\nexcept: pass"); urllib.request.urlopen(urllib.request.Request(_u, data=json.dumps({'sessionId':_s,'runId':'post-fix','hypothesisId':'B','location':'official_baseline_medium_trial_runner.py:run_hist_smoke:train-step','msg':'[DEBUG] HIST medium train step snapshot','data':{'target_market':target_market,'epoch_idx':int(epoch_idx),'pred_nan':int(torch.isnan(pred).sum().item()),'pred_inf':int(torch.isinf(pred).sum().item()),'pred_mean':float(torch.nan_to_num(pred.detach(), nan=0.0, posinf=0.0, neginf=0.0).mean().item()),'loss_isfinite':bool(torch.isfinite(loss).item()),'loss_value':float(torch.nan_to_num(loss.detach(), nan=0.0, posinf=0.0, neginf=0.0).item())}}).encode(), headers={'Content-Type':'application/json'})).read()
        # #endregion
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    with torch.no_grad():
        pred = model(x_flat, concept_x, market_value)
    final_loss = ((pred - y) ** 2).mean()
    # #region debug-point C:hist-final-finiteness
    import json, urllib.request; _p='.dbg/hist-medium-nan.env'; _u,_s='http://127.0.0.1:7777/event','hist-medium-nan'; exec("try:\n with open(_p) as f: c=f.read(); _u=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SERVER_URL=')),_u); _s=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SESSION_ID=')),_s)\nexcept: pass"); urllib.request.urlopen(urllib.request.Request(_u, data=json.dumps({'sessionId':_s,'runId':'post-fix','hypothesisId':'C','location':'official_baseline_medium_trial_runner.py:run_hist_smoke:final','msg':'[DEBUG] HIST medium final snapshot','data':{'target_market':target_market,'pred_nan':int(torch.isnan(pred).sum().item()),'pred_inf':int(torch.isinf(pred).sum().item()),'pred_mean_raw':str(pred.mean().detach().cpu().item()),'loss_isfinite':bool(torch.isfinite(final_loss).item()),'loss_value_raw':str(final_loss.detach().cpu().item())}}).encode(), headers={'Content-Type':'application/json'})).read()
    # #endregion
    return {
        "status": "smoke_train_ok",
        "sample_count": int(len(sample_df)),
        "prediction_mean": float(pred.mean().detach().cpu().item()),
        "loss": float(final_loss.detach().cpu().item()),
        "device": str(device),
    }


def run_master_smoke(target_market: str) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / "MASTER-master" / "MASTER-master"
    master_module = load_repo_module(repo_dir, "master.py", "alpha_mech_transfer_master_model")
    MASTER = master_module.MASTER

    x, y, sample_df = build_sequence_batch(target_market)
    gate_x = torch.tensor(np.stack(sample_df["gate"].to_list()), dtype=torch.float32)
    full_x = torch.cat([x, gate_x], dim=-1)
    model = MASTER(
        d_feat=x.shape[-1],
        d_model=32,
        t_nhead=2,
        s_nhead=2,
        T_dropout_rate=0.1,
        S_dropout_rate=0.1,
        gate_input_start_index=x.shape[-1],
        gate_input_end_index=x.shape[-1] + gate_x.shape[-1],
        beta=2.0,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    for _ in range(2):
        pred = model(full_x)
        loss = ((pred - y) ** 2).mean()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        pred = model(full_x)
    return {
        "status": "smoke_train_ok",
        "sample_count": int(len(sample_df)),
        "prediction_mean": float(pred.mean().item()),
        "loss": float(((pred - y) ** 2).mean().item()),
    }


def run_quantnet_trial(direction: str) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / "quantnet-main" / "quantnet-main"
    sys.path.insert(0, str(repo_dir))
    try:
        from quantnet.baselines import RiskParity
        from quantnet.utils import get_data
    finally:
        sys.path.pop(0)

    manifest = build_artifacts("QuantNet", direction, mode="medium")
    artifact_dir = Path(manifest["artifact_dir"])
    source_market = manifest["source_market"]
    target_market = manifest["target_market"]

    data_config = {
        "data_path": artifact_dir.as_posix() + "/",
        "region": ["AlphaMechTransferRegion"],
        "AlphaMechTransferRegion": [
            f"{source_market.lower()}",
            f"{target_market.lower()}",
        ],
        "additional_data_path": "_all_assets_data.pkl.gz",
    }
    problem_config = {"export_path": (artifact_dir / "exports").as_posix() + "/", "val_period": 0, "holdout_period": 160}
    model_config = {"baseline": "risk_parity", "risk_parity": {"window": 20}, "export_path": problem_config["export_path"], "export_label": f"{direction.lower()}_medium"}
    ensure_dir(Path(problem_config["export_path"]))

    x_train, x_val, x_test = get_data(data_config, problem_config, {**model_config, "device": "cpu"})
    zero_risk_summary = summarize_quantnet_risk(x_test, window=int(model_config["risk_parity"]["window"]))
    strategy = RiskParity(x_train, model_config)
    strategy.train()
    y_pred = strategy.predict(x_test)
    used_stability_guard = False
    stability_guard_report: dict[str, dict[str, Any]] = {}
    if has_nonfinite_prediction(y_pred):
        y_pred, stability_guard_report = build_stable_quantnet_prediction(
            x_test,
            window=int(model_config["risk_parity"]["window"]),
            eps=QUANTNET_STABILITY_EPS,
        )
        used_stability_guard = True
    first_region = next(iter(y_pred))
    first_task = next(iter(y_pred[first_region]))
    sample_pred = y_pred[first_region][first_task]
    return {
        "status": "train_predict_ok",
        "artifact_dir": str(artifact_dir),
        "region": first_region,
        "task": first_task,
        "prediction_shape": list(sample_pred.shape),
        "prediction_mean": float(np.mean(sample_pred)),
        "risk_summary": zero_risk_summary,
        "used_adapter_stability_guard": used_stability_guard,
        "stability_guard_report": stability_guard_report,
    }


def run_doubleadapt_smoke(target_market: str) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / "DoubleAdapt-main" / "DoubleAdapt-main" / "src"
    doubleadapt_module = load_repo_module(repo_dir, "model.py", "alpha_mech_transfer_doubleadapt_model")
    DoubleAdaptManager = doubleadapt_module.DoubleAdaptManager

    x, y, sample_df = build_sequence_batch(target_market)
    x_flat = x.reshape(len(sample_df), -1)
    train_end = int(len(sample_df) * 0.7)
    meta_input = {
        "X_train": x[:train_end],
        "y_train": y[:train_end],
        "X_test": x[train_end:],
        "y_test": y[train_end:],
        "meta_end": int(len(sample_df) - train_end),
        "test_idx": pd.MultiIndex.from_frame(sample_df.iloc[train_end:][["date", "symbol"]].rename(columns={"symbol": "instrument", "date": "datetime"})),
    }
    base_model = torch.nn.Sequential(
        torch.nn.Linear(x_flat.shape[1], 64),
        torch.nn.ReLU(),
        torch.nn.Linear(64, 1),
    )
    manager = DoubleAdaptManager(
        model=base_model,
        lr_model=1e-3,
        lr_da=5e-3,
        factor_num=x.shape[-1],
        x_dim=x_flat.shape[1],
        need_permute=False,
        num_head=2,
        temperature=4,
        begin_valid_epoch=0,
    )
    output = manager._run_task(meta_input, phase="train")
    return {
        "status": "smoke_train_ok",
        "sample_count": int(len(sample_df)),
        "output_shape": list(np.asarray(output).shape),
    }


def run_adgat_smoke(target_market: str, direction: str) -> dict[str, Any]:
    repo_dir = OFFICIAL_DIR / "ADGAT-main" / "ADGAT-main"
    adgat_module = load_repo_module(repo_dir, "Model.py", "alpha_mech_transfer_adgat_model")
    AD_GAT = adgat_module.AD_GAT

    manifest = build_artifacts("ADGAT", direction, mode="medium")
    artifact_dir = Path(manifest["artifact_dir"])
    x_market_np = np.asarray(pd.read_pickle(artifact_dir / "x_numerical.pkl"), dtype=np.float32)
    x_news_np = np.asarray(pd.read_pickle(artifact_dir / "x_textual.pkl"), dtype=np.float32)
    relation_static_np = np.asarray(pd.read_pickle(artifact_dir / "relations" / "all_relation.pkl"), dtype=np.float32)
    y_tensor = np.asarray(pd.read_pickle(artifact_dir / "y_.pkl"), dtype=np.float32)

    # ADGAT 官方实现要求输入为 [time, num_stock, feature]。
    # 之前错误转置成了 [num_stock, time, feature]，导致 24 个时间步与 20/24 个标的维度在前向中混淆。
    time_window = min(24, x_market_np.shape[0], x_news_np.shape[0], y_tensor.shape[0])
    x_market = torch.tensor(x_market_np[:time_window], dtype=torch.float32)
    x_news = torch.tensor(x_news_np[:time_window], dtype=torch.float32)
    active_stock_count = int(x_market.shape[1])

    # ADGAT 官方实现在 attention 中硬编码了 198x198 的静态参数矩阵。
    # 因此这里通过外层数据适配把 medium 子集零填充到 198 维股票轴，避免修改官方模型核心。
    official_stock_dim = 198
    padded_market = torch.zeros((time_window, official_stock_dim, x_market.shape[-1]), dtype=torch.float32)
    padded_news = torch.zeros((time_window, official_stock_dim, x_news.shape[-1]), dtype=torch.float32)
    padded_market[:, :active_stock_count, :] = x_market
    padded_news[:, :active_stock_count, :] = x_news
    x_market = padded_market
    x_news = padded_news

    padded_relation = np.zeros((official_stock_dim, official_stock_dim), dtype=np.float32)
    padded_relation[:active_stock_count, :active_stock_count] = relation_static_np[:active_stock_count, :active_stock_count]
    relation_static = torch.tensor(padded_relation, dtype=torch.float32)

    padded_labels = np.zeros((official_stock_dim,), dtype=np.int64)
    padded_labels[:active_stock_count] = (y_tensor[time_window - 1, :active_stock_count] > 0).astype(np.int64)
    labels = torch.tensor(padded_labels, dtype=torch.long)

    model = AD_GAT(
        num_stock=official_stock_dim,
        d_market=x_market.shape[-1],
        d_news=x_news.shape[-1],
        d_hidden=8,
        hidn_rnn=8,
        heads_att=2,
        hidn_att=4,
        dropout=0.0,
        relation_static=1 if relation_static is not None else 0,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = torch.nn.NLLLoss()
    for _ in range(2):
        pred = model(x_market, x_news, relation_static=relation_static)
        loss = criterion(pred, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    return {
        "status": "smoke_train_ok",
        "num_stock": official_stock_dim,
        "active_stock_count": active_stock_count,
        "time_window": int(time_window),
        "relation_static_used": True,
        "loss": float(loss.item()),
    }


def build_task_plan() -> list[tuple[str, str, int]]:
    tasks: list[tuple[str, str, int]] = []
    for direction, baselines in PHASE1_TASKS.items():
        for priority, baseline in enumerate(baselines, start=1):
            tasks.append((direction, baseline, priority))
    for direction, baselines in PHASE2_TASKS.items():
        for priority, baseline in enumerate(baselines, start=1):
            tasks.append((direction, baseline, priority))
    return tasks


def summarize_quantnet_risk(x_test: dict[str, dict[str, Any]], window: int) -> dict[str, dict[str, Any]]:
    summary: dict[str, dict[str, Any]] = {}
    for task_name, sub_tasks in x_test.items():
        summary[str(task_name)] = {}
        for sub_task_name, values in sub_tasks.items():
            task_array = np.asarray(values, dtype=np.float32)
            risk = pd.DataFrame(task_array).rolling(window=window).std().values[-task_array.shape[0] :, :]
            summary[str(task_name)][str(sub_task_name)] = {
                "risk_shape": list(risk.shape),
                "risk_zero_count": int((risk == 0.0).sum()),
                "risk_nan_count": int(np.isnan(risk).sum()),
                "risk_inf_count": int(np.isinf(risk).sum()),
            }
    return summary


def has_nonfinite_prediction(y_pred: dict[str, dict[str, Any]]) -> bool:
    for task_predictions in y_pred.values():
        for values in task_predictions.values():
            prediction = np.asarray(values, dtype=np.float32)
            if not np.isfinite(prediction).all():
                return True
    return False


def build_stable_quantnet_prediction(
    x_test: dict[str, dict[str, Any]],
    window: int,
    eps: float,
) -> tuple[dict[str, dict[str, np.ndarray]], dict[str, dict[str, Any]]]:
    y_pred: dict[str, dict[str, np.ndarray]] = {}
    stability_report: dict[str, dict[str, Any]] = {}
    for task_name, sub_tasks in x_test.items():
        y_pred[str(task_name)] = {}
        stability_report[str(task_name)] = {}
        for sub_task_name, values in sub_tasks.items():
            task_array = np.asarray(values, dtype=np.float32)
            risk = pd.DataFrame(task_array).rolling(window=window).std().values[-task_array.shape[0] :, :]
            risk = np.nan_to_num(risk, nan=0.0, posinf=0.0, neginf=0.0)
            stabilized_risk = np.where(risk <= 0.0, eps, risk)
            inverse_risk = 1.0 / stabilized_risk
            denominator = np.sum(inverse_risk, axis=1, keepdims=True)
            denominator = np.where(denominator <= 0.0, eps, denominator)
            prediction = inverse_risk / denominator
            prediction = np.nan_to_num(prediction, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
            y_pred[str(task_name)][str(sub_task_name)] = prediction
            stability_report[str(task_name)][str(sub_task_name)] = {
                "epsilon": eps,
                "stabilized_zero_or_nonfinite_count": int((risk <= 0.0).sum()),
                "prediction_nan_count": int(np.isnan(prediction).sum()),
                "prediction_inf_count": int(np.isinf(prediction).sum()),
            }
    return y_pred, stability_report


def execute_one_trial(direction: str, baseline: str) -> dict[str, Any]:
    start_time = time.perf_counter()
    artifact_manifest = build_artifacts(baseline, direction, mode="medium")
    target_market = artifact_manifest["target_market"]

    if baseline == "TRA":
        detail = run_tra_smoke(target_market)
    elif baseline == "DoubleAdapt":
        detail = run_doubleadapt_smoke(target_market)
    elif baseline == "HIST":
        detail = run_hist_smoke(target_market)
    elif baseline == "MASTER":
        detail = run_master_smoke(target_market)
    elif baseline == "QuantNet":
        detail = run_quantnet_trial(direction)
    elif baseline == "ADGAT":
        detail = run_adgat_smoke(target_market, direction)
    else:
        raise ValueError(baseline)

    return {
        "direction": direction,
        "baseline": baseline,
        "elapsed_seconds": float(time.perf_counter() - start_time),
        "artifact_manifest": artifact_manifest["manifest_path"],
        "detail": detail,
    }


def run_all(selected_phase: str, selected_directions: set[str] | None = None, selected_baselines: set[str] | None = None) -> dict[str, Any]:
    ensure_dir(RESULT_DIR)
    task_plan = build_task_plan()
    rows: list[dict[str, Any]] = []
    for direction, baseline, priority in task_plan:
        phase_name = "phase1" if direction in PHASE1_TASKS else "phase2"
        if selected_phase != "all" and selected_phase != phase_name:
            continue
        if selected_directions and direction not in selected_directions:
            continue
        if selected_baselines and baseline not in selected_baselines:
            continue
        trial_start = time.perf_counter()
        try:
            payload = execute_one_trial(direction, baseline)
            payload["status"] = payload["detail"]["status"]
            detail = payload.get("detail", {})
            if isinstance(detail, dict):
                numeric_checks = {
                    "prediction_mean": detail.get("prediction_mean"),
                    "loss": detail.get("loss"),
                }
                bad_fields = [
                    field_name
                    for field_name, field_value in numeric_checks.items()
                    if field_value is not None and not np.isfinite(float(field_value))
                ]
                if bad_fields:
                    raise ValueError(
                        f"{baseline} {direction} 产出了非有限值字段: {', '.join(bad_fields)}"
                    )
        except Exception as exc:  # noqa: BLE001
            payload = {
                "direction": direction,
                "baseline": baseline,
                "status": "failed",
                "elapsed_seconds": float(time.perf_counter() - trial_start),
                "error": str(exc),
                "traceback": traceback.format_exc(limit=6),
            }
        payload["phase"] = phase_name
        payload["priority"] = priority
        # #region debug-point D:trial-status-write
        if baseline == "HIST":
            import json, urllib.request; _p='.dbg/hist-medium-nan.env'; _u,_s='http://127.0.0.1:7777/event','hist-medium-nan'; exec("try:\n with open(_p) as f: c=f.read(); _u=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SERVER_URL=')),_u); _s=next((l.split('=',1)[1] for l in c.split('\\n') if l.startswith('DEBUG_SESSION_ID=')),_s)\nexcept: pass"); urllib.request.urlopen(urllib.request.Request(_u, data=json.dumps({'sessionId':_s,'runId':'post-fix','hypothesisId':'D','location':'official_baseline_medium_trial_runner.py:run_all:status-write','msg':'[DEBUG] HIST medium trial status snapshot','data':{'direction':direction,'phase':phase_name,'status':payload.get('status'),'detail_status':payload.get('detail',{}).get('status') if isinstance(payload.get('detail'), dict) else None,'prediction_mean':repr(payload.get('detail',{}).get('prediction_mean')) if isinstance(payload.get('detail'), dict) else None,'loss':repr(payload.get('detail',{}).get('loss')) if isinstance(payload.get('detail'), dict) else None,'has_error':bool(payload.get('error'))}}).encode(), headers={'Content-Type':'application/json'})).read()
        # #endregion
        rows.append(payload)

    summary_path = RESULT_DIR / f"{selected_phase}_medium_trial_summary.json"
    actual_summary_path = write_json(summary_path, rows)
    return {"summary_path": str(actual_summary_path), "task_count": len(rows)}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="运行官方 baseline 的 medium 模式首轮可行性验证")
    parser.add_argument("--phase", default="all", choices=["all", "phase1", "phase2"])
    parser.add_argument("--directions", default=None, help="可选，逗号分隔的方向过滤，如 CN_TO_US,US_TO_CN")
    parser.add_argument("--baselines", default=None, help="可选，逗号分隔的 baseline 过滤，如 QuantNet,ADGAT")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    payload = run_all(
        args.phase,
        selected_directions=parse_optional_csv(args.directions),
        selected_baselines=parse_optional_csv(args.baselines),
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
