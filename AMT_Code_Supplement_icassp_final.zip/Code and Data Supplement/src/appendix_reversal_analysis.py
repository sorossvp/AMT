"""
文件功能:
1. 基于已落盘的 `alpha_reversal_5` 预测结果, 生成 AAAIV3 附录所需的 reversal case 机制解释图与统计摘要。
2. 输出 head contribution curve、quantile return figure、top-k hit-rate 表和尾部贡献分析结果。
3. 将所有图表、CSV、JSON 和 Markdown 统一写入当前附录批次资产目录, 方便附录直接引用。

代码逻辑:
1. 读取 `CN->US` reversal case 中 AMT 与 Direct Transfer 的测试期预测。
2. 按交易日计算 top-k 头部收益贡献、正收益命中率和 top-decile 命中率。
3. 按预测分数分位数组合统计未来收益均值, 生成 quantile return 对照图。
4. 额外计算累计收益由少数极端日贡献的集中度, 作为“是否由尾部极值驱动”的补充证据。

代码结构:
1. 数据读取与按日统计函数。
2. 图表生成函数。
3. Markdown 摘要写出。
4. CLI 入口。
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from experiment_workspace import get_archive_root, get_paper_asset_path, write_dataframe, write_json


TOPK_LIST = (1, 3, 5, 10, 20)
QUANTILE_COUNT = 10


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def render_markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_empty_"
    view = df.copy()
    for column in view.columns:
        if pd.api.types.is_float_dtype(view[column]):
            view[column] = view[column].map(lambda value: f"{value:.6f}")
    headers = [str(column) for column in view.columns.tolist()]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in view.iterrows():
        lines.append("| " + " | ".join(str(value) for value in row.tolist()) + " |")
    return "\n".join(lines)


def load_prediction_frame(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values(["date", "symbol"]).reset_index(drop=True)


def load_curve_frame(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values("date").reset_index(drop=True)


def build_head_contribution_table(pred_df: pd.DataFrame, model_name: str) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for top_k in TOPK_LIST:
        daily_returns = []
        positive_hit_rates = []
        decile_hit_rates = []
        for date_value, raw_daily_df in pred_df.groupby("date"):
            daily_df = raw_daily_df.dropna(subset=["prediction", "future_return"]).copy()
            if daily_df.empty:
                continue
            selected = daily_df.sort_values("prediction", ascending=False).head(min(top_k, len(daily_df)))
            daily_returns.append(float(selected["future_return"].mean()))
            positive_hit_rates.append(float((selected["future_return"] > 0).mean()))
            decile_threshold = float(daily_df["future_return"].quantile(0.9))
            decile_hit_rates.append(float((selected["future_return"] >= decile_threshold).mean()))
        rows.append(
            {
                "model": model_name,
                "top_k": int(top_k),
                "avg_head_return": float(np.mean(daily_returns)) if daily_returns else np.nan,
                "positive_hit_rate": float(np.mean(positive_hit_rates)) if positive_hit_rates else np.nan,
                "top_decile_hit_rate": float(np.mean(decile_hit_rates)) if decile_hit_rates else np.nan,
            }
        )
    return pd.DataFrame(rows)


def build_quantile_return_table(pred_df: pd.DataFrame, model_name: str) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for date_value, raw_daily_df in pred_df.groupby("date"):
        daily_df = raw_daily_df.dropna(subset=["prediction", "future_return"]).copy()
        if len(daily_df) < QUANTILE_COUNT:
            continue
        daily_df["quantile"] = pd.qcut(
            daily_df["prediction"].rank(method="first"),
            q=QUANTILE_COUNT,
            labels=False,
        )
        for quantile_id, quantile_df in daily_df.groupby("quantile"):
            rows.append(
                {
                    "model": model_name,
                    "date": date_value,
                    "quantile": int(quantile_id) + 1,
                    "mean_future_return": float(quantile_df["future_return"].mean()),
                }
            )
    quantile_df = pd.DataFrame(rows)
    if quantile_df.empty:
        return quantile_df
    return (
        quantile_df.groupby(["model", "quantile"], as_index=False)["mean_future_return"]
        .mean()
        .sort_values(["model", "quantile"])
        .reset_index(drop=True)
    )


def build_tail_concentration_table(curve_df: pd.DataFrame, model_name: str) -> pd.DataFrame:
    if curve_df.empty:
        return pd.DataFrame()
    work_df = curve_df.copy()
    work_df["abs_return"] = work_df["portfolio_return"].abs()
    work_df = work_df.sort_values("abs_return", ascending=False).reset_index(drop=True)
    total_abs = float(work_df["abs_return"].sum()) + 1e-12
    rows = []
    for frac in (0.05, 0.10, 0.20):
        top_n = max(1, int(round(len(work_df) * frac)))
        contribution = float(work_df.head(top_n)["abs_return"].sum() / total_abs)
        rows.append(
            {
                "model": model_name,
                "top_day_fraction": frac,
                "abs_return_contribution_ratio": contribution,
            }
        )
    return pd.DataFrame(rows)


def plot_head_contribution(head_df: pd.DataFrame, output_path: Path) -> None:
    plt.figure(figsize=(6, 4))
    for model_name, group_df in head_df.groupby("model"):
        plt.plot(group_df["top_k"], group_df["avg_head_return"], marker="o", label=model_name)
    plt.xlabel("Top-k")
    plt.ylabel("Average head return")
    plt.title("Head Contribution Curve")
    plt.legend()
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def plot_quantile_return(quantile_df: pd.DataFrame, output_path: Path) -> None:
    plt.figure(figsize=(7, 4))
    for model_name, group_df in quantile_df.groupby("model"):
        plt.plot(group_df["quantile"], group_df["mean_future_return"], marker="o", label=model_name)
    plt.xlabel("Prediction quantile")
    plt.ylabel("Mean future return")
    plt.title("Quantile Return Figure")
    plt.legend()
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def build_markdown(head_df: pd.DataFrame, quantile_df: pd.DataFrame, tail_df: pd.DataFrame) -> str:
    return (
        "# AAAIV3 Reversal Case 分析\n\n"
        "## 1. Head contribution\n\n"
        f"{render_markdown_table(head_df)}\n\n"
        "## 2. Quantile return\n\n"
        f"{render_markdown_table(quantile_df)}\n\n"
        "## 3. Tail concentration\n\n"
        f"{render_markdown_table(tail_df)}\n"
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="生成 AAAIV3 reversal case 附录分析图表")
    parser.add_argument(
        "--source-batch-root",
        default="/data/zhoutm/exp2/results/full_20260729_015852",
        help="现有论文结果批次根目录",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source_batch_root = Path(args.source_batch_root).resolve()
    archive_root = get_archive_root()
    asset_dir = ensure_dir(get_paper_asset_path(archive_root, "appendix_support", "reversal_analysis", paper_name="AAAIV3"))

    jobs = {
        "AMT": source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "amt",
        "Direct Transfer": source_batch_root / "主实验" / "multi_alpha_transfer" / "alpha_reversal_5" / "cn_to_us" / "direct_transfer",
    }

    head_frames = []
    quantile_frames = []
    tail_frames = []
    for model_name, model_dir in jobs.items():
        pred_df = load_prediction_frame(model_dir / "test_predictions.csv")
        curve_df = load_curve_frame(model_dir / "equity_curve.csv")
        head_frames.append(build_head_contribution_table(pred_df, model_name=model_name))
        quantile_frames.append(build_quantile_return_table(pred_df, model_name=model_name))
        tail_frames.append(build_tail_concentration_table(curve_df, model_name=model_name))

    head_df = pd.concat(head_frames, axis=0, ignore_index=True)
    quantile_df = pd.concat(quantile_frames, axis=0, ignore_index=True)
    tail_df = pd.concat(tail_frames, axis=0, ignore_index=True)

    head_csv = write_dataframe(head_df, asset_dir / "head_contribution_table.csv", index=False, encoding="utf-8-sig")
    quantile_csv = write_dataframe(quantile_df, asset_dir / "quantile_return_table.csv", index=False, encoding="utf-8-sig")
    tail_csv = write_dataframe(tail_df, asset_dir / "tail_concentration_table.csv", index=False, encoding="utf-8-sig")

    head_png = asset_dir / "head_contribution_curve.png"
    quantile_png = asset_dir / "quantile_return_figure.png"
    plot_head_contribution(head_df, head_png)
    plot_quantile_return(quantile_df, quantile_png)

    md_path = asset_dir / "reversal_analysis.md"
    md_path.write_text(build_markdown(head_df, quantile_df, tail_df), encoding="utf-8")

    manifest = {
        "source_batch_root": str(source_batch_root),
        "archive_root": str(archive_root),
        "generated_files": {
            "head_table_csv": str(head_csv),
            "quantile_table_csv": str(quantile_csv),
            "tail_table_csv": str(tail_csv),
            "head_curve_png": str(head_png),
            "quantile_figure_png": str(quantile_png),
            "markdown": str(md_path),
        },
    }
    write_json(asset_dir / "manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
