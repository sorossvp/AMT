"""
文件功能:
1. 统一管理 AlphaMechTransfer 的 `full / medium / smoke` 运行模式配置。
2. 为论文实验、本地快速验证、官方 baseline 外层资产生成和服务器调度提供一致的参数约束。
3. 将“数据范围缩减但不破坏实验闭环”的规则显式化, 避免不同脚本各自维护一套模式参数。

代码逻辑:
1. 定义实验模式配置, 包括股票/期货的最大标的数、每个 split 保留的交易日数量以及训练轮数缩减因子。
2. 提供按市场类型解析 medium 标的规模的函数。
3. 提供按 split 截断 panel 的函数, 保留 train / valid / test 三阶段完整流程。

代码结构:
1. 模式配置数据类。
2. 配置注册表。
3. 模式解析与面板截断工具函数。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import pandas as pd


@dataclass(frozen=True)
class ExperimentProfile:
    name: str
    description: str
    stock_max_symbols: int
    future_max_symbols: int
    split_max_dates: dict[str, int | None]
    torch_epoch_scale: float
    quantnet_holdout_period: int


PROFILES: dict[str, ExperimentProfile] = {
    "full": ExperimentProfile(
        name="full",
        description="正式实验配置, 保留默认股票池规模与完整 split 时间覆盖。",
        stock_max_symbols=160,
        future_max_symbols=97,
        split_max_dates={"train": None, "valid": None, "test": None},
        torch_epoch_scale=1.0,
        quantnet_holdout_period=756,
    ),
    "medium": ExperimentProfile(
        name="medium",
        description="本地快速验证配置, 保留 train / valid / test 三阶段闭环, 但缩减标的数与每个 split 的交易日数量。",
        stock_max_symbols=64,
        future_max_symbols=32,
        split_max_dates={"train": 360, "valid": 120, "test": 160},
        torch_epoch_scale=0.4,
        quantnet_holdout_period=160,
    ),
    "smoke": ExperimentProfile(
        name="smoke",
        description="最小闭环自检配置, 只保留能够验证训练、迁移、评估全链路的极小样本。",
        stock_max_symbols=24,
        future_max_symbols=12,
        split_max_dates={"train": 80, "valid": 24, "test": 24},
        torch_epoch_scale=0.2,
        quantnet_holdout_period=60,
    ),
}


def get_profile(mode: str) -> ExperimentProfile:
    normalized = str(mode).strip().lower()
    if normalized not in PROFILES:
        raise ValueError(f"未知实验模式: {mode}")
    return PROFILES[normalized]


def resolve_max_symbols(profile: ExperimentProfile, market: str, requested_value: int | None = None) -> int:
    market_upper = market.upper()
    if requested_value is not None and requested_value > 0:
        upper_bound = profile.future_max_symbols if market_upper == "FUTURE" else profile.stock_max_symbols
        return min(int(requested_value), upper_bound)
    return profile.future_max_symbols if market_upper == "FUTURE" else profile.stock_max_symbols


def truncate_panel_by_profile(panel_df: pd.DataFrame, profile: ExperimentProfile) -> pd.DataFrame:
    if "split" not in panel_df.columns or profile.name == "full":
        return panel_df
    pieces: list[pd.DataFrame] = []
    for split_name in ("train", "valid", "test"):
        split_df = panel_df[panel_df["split"] == split_name].copy()
        keep_dates = profile.split_max_dates.get(split_name)
        if keep_dates is not None:
            valid_dates = sorted(split_df["date"].drop_duplicates().tolist())
            split_df = split_df[split_df["date"].isin(valid_dates[-int(keep_dates) :])].copy()
        pieces.append(split_df)
    truncated = pd.concat(pieces, axis=0, ignore_index=True) if pieces else panel_df.iloc[0:0].copy()
    return truncated.sort_values(["date", "symbol"]).reset_index(drop=True)


def profile_to_dict(profile: ExperimentProfile) -> dict[str, Any]:
    return asdict(profile)
