# AlphaMechTransfer (AMT) - Code and Data Supplement (ICASSP)

This repository contains the source code for the paper **"AMT: A Cross-Market Alpha Strategy Transfer Framework via Hypergraph-Based Mechanism Preservation and Structure Freezing"**.

## Directory Structure

- `src/`: Contains the complete implementation of the AlphaMechTransfer (AMT) framework, baseline models, data pipelines, and experiment runners.
  - `models.py`: Core implementation of the AMT architecture, including the temporal encoder, hypergraph neural network layers, sparse residual adaptation, and the topology-preserving KL divergence mechanism.
  - `experiment_runner.py`: The main entry point for running the bidirectional transfer experiments (CN $\rightarrow$ US and US $\rightarrow$ CN).
  - `data_pipeline.py`: Handles raw data preprocessing, cross-sectional ranking alignment, and hypergraph incidence matrix construction.
  - `market_similarity.py`: Implements the similarity-guided structure freezing policy.

## Data Availability Statement

Due to the strict file size limitations for ICASSP supplementary materials, the raw market data (price-volume sequences, cross-sectional statistics, concept-level relational features, and alpha-style vectors) for both the Chinese (CN) and U.S. (US) markets are **not included** in this zip file. 

The full dataset, along with pre-constructed hypergraph cache files, exceeds 5GB. Upon acceptance of the paper, we will provide a permanent, publicly accessible repository link (e.g., GitHub / Zenodo) containing the full reproducible data pipeline, pre-trained source anchors, and the complete datasets.

## Requirements

To run the codebase locally once data is available, you will need:
- Python 3.8+
- PyTorch 2.0+
- Qlib (for foundational market data structures)
- Pandas, NumPy, SciPy

## Reproducibility

The code is modularized to support the full pretrain-then-adapt protocol described in the paper.
1. `python src/experiment_runner.py --mode full --transfer_direction CN_to_US`
2. The framework will automatically freeze the source mechanisms based on the computed market similarity score and apply the topology-preserving KL divergence penalty during target-domain adaptation.

*Note: The current codebase in `src/` represents the finalized version (V6.6) corresponding to the ICASSP submission.*
